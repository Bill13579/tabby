/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/popup/popup.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/options.js":
/*!************************!*\
  !*** ./src/options.js ***!
  \************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, options, setOptions, stbool */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "options", function() { return options; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setOptions", function() { return setOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stbool", function() { return stbool; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _options_states__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./options/states */ "./src/options/states.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]; });





async function options() {
    return browser.storage.local.get(["options"]).then(data => data.options);
}

async function setOptions(options) {
    return browser.storage.local.set({ options: options });
}

function stbool(switch_state) {
    switch (switch_state) {
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]:
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]:
            return true;
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]:
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]:
            return false;
    }
}


/***/ }),

/***/ "./src/options/states.js":
/*!*******************************!*\
  !*** ./src/options/states.js ***!
  \*******************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, INITIAL_OPTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return SWITCH_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return SWITCH_LOCKED_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return SWITCH_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return SWITCH_LOCKED_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "INITIAL_OPTIONS", function() { return INITIAL_OPTIONS; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const SWITCH_ON = 1;
const SWITCH_LOCKED_ON = 2;
const SWITCH_OFF = 0;
const SWITCH_LOCKED_OFF = -1;

const INITIAL_OPTIONS = {
    popup: {
        size: {
            width: 730,
            height: 450
        },
        scale: 1.0,
        showDetails: SWITCH_ON,
        showPreview: SWITCH_ON,
        hideAfterTabSelection: SWITCH_ON,
        searchInURLs: SWITCH_OFF
    }
};
if (Polyfill__WEBPACK_IMPORTED_MODULE_0__["TargetBrowser"] === "chrome") {
    INITIAL_OPTIONS.popup.showPreview = SWITCH_LOCKED_OFF;
    INITIAL_OPTIONS.popup.hideAfterTabSelection = SWITCH_LOCKED_ON;
}


/***/ }),

/***/ "./src/polyfill.js":
/*!*************************!*\
  !*** ./src/polyfill.js ***!
  \*************************/
/*! exports provided: TargetBrowser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetBrowser", function() { return TargetBrowser; });
const TargetBrowser = "webext";

if (false) {}

if (!Array.from) {
    Array.from = (function () {
        let toStr = Object.prototype.toString;
        let isCallable = function (fn) {
            return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
        };
        let toInteger = function (value) {
            let number = Number(value);
            if (isNaN(number)) { return 0; }
            if (number === 0 || !isFinite(number)) { return number; }
            return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
        };
        let maxSafeInteger = Math.pow(2, 53) - 1;
        let toLength = function (value) {
            let len = toInteger(value);
            return Math.min(Math.max(len, 0), maxSafeInteger);
        };

        // The length property of the from method is 1.
        return function from(arrayLike/*, mapFn, thisArg */) {
            // 1. Let C be the this value.
            let C = this;

            // 2. Let items be ToObject(arrayLike).
            let items = Object(arrayLike);

            // 3. ReturnIfAbrupt(items).
            if (arrayLike == null) {
                throw new TypeError('Array.from requires an array-like object - not null or undefined');
            }

            // 4. If mapfn is undefined, then let mapping be false.
            let mapFn = arguments.length > 1 ? arguments[1] : void undefined;
            let T;
            if (typeof mapFn !== 'undefined') {
                // 5. else
                // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
                if (!isCallable(mapFn)) {
                    throw new TypeError('Array.from: when provided, the second argument must be a function');
                }

                // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
                if (arguments.length > 2) {
                    T = arguments[2];
                }
            }

            // 10. Let lenValue be Get(items, "length").
            // 11. Let len be ToLength(lenValue).
            let len = toLength(items.length);

            // 13. If IsConstructor(C) is true, then
            // 13. a. Let A be the result of calling the [[Construct]] internal method 
            // of C with an argument list containing the single item len.
            // 14. a. Else, Let A be ArrayCreate(len).
            let A = isCallable(C) ? Object(new C(len)) : new Array(len);

            // 16. Let k be 0.
            let k = 0;
            // 17. Repeat, while k < len… (also steps a - h)
            let kValue;
            while (k < len) {
                kValue = items[k];
                if (mapFn) {
                    A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
                } else {
                    A[k] = kValue;
                }
                k += 1;
            }
            // 18. Let putStatus be Put(A, "length", len, true).
            A.length = len;
            // 20. Return A.
            return A;
        };
    }());
}


/***/ }),

/***/ "./src/popup/captureTab.js":
/*!*********************************!*\
  !*** ./src/popup/captureTab.js ***!
  \*********************************/
/*! exports provided: available, init, captureTab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "available", function() { return available; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "init", function() { return init; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "captureTab", function() { return captureTab; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


let available = false;

function init() {
    if (window["browser"] !== undefined
        && browser.tabs["captureTab"] !== undefined) {
        available = true;
        return;
    }
}

function captureTab(id) {
    return available ? browser.tabs.captureTab(id) : new Promise((resolve, reject) => resolve(null));
}


/***/ }),

/***/ "./src/popup/domutils.js":
/*!*******************************!*\
  !*** ./src/popup/domutils.js ***!
  \*******************************/
/*! exports provided: stopPropagation, toggleClass, getActualHeight, getActualWidth */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stopPropagation", function() { return stopPropagation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toggleClass", function() { return toggleClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActualHeight", function() { return getActualHeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActualWidth", function() { return getActualWidth; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Stop propagation event listener
function stopPropagation(e) {
    e.stopPropagation();
}

// Toggle a class of an element
function toggleClass(element, c) {
    if (element.classList.contains(c)) {
        element.classList.remove(c);
    } else {
        element.classList.add(c);
    }
}

// Get actual height of an element
function getActualHeight(element) {
    let styles = window.getComputedStyle(element);
    let margin = parseFloat(styles['marginTop']) +
               parseFloat(styles['marginBottom']);
    return element.offsetHeight + margin;
}

// Get actual width of an element
function getActualWidth(element) {
    let styles = window.getComputedStyle(element);
    let margin = parseFloat(styles['marginLeft']) +
               parseFloat(styles['marginRight']);
    return element.offsetWidth + margin;
}

// getElementByClassName
Element.prototype.getElementByClassName = function (classNames) {
    return this.getElementsByClassName(classNames)[0] || null;
};


/***/ }),

/***/ "./src/popup/event-listeners/document.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/document.js ***!
  \***********************************************/
/*! exports provided: documentMouseOver, documentMouseUp, documentClicked, documentKeyPressed */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentMouseOver", function() { return documentMouseOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentMouseUp", function() { return documentMouseUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentClicked", function() { return documentClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentKeyPressed", function() { return documentKeyPressed; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");




function documentMouseOver(e) {
    e.preventDefault();
}

function documentMouseUp(e) {
    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding) Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["resetSlideSelection"])();
}

function documentClicked(e) {
    if (e.button === 0) {
        if (e.target.id === "details-close") {
            document.getElementById("details-placeholder").style.display = "inline-block";
            document.getElementById("tab-details").style.display = "none";
            browser.tabs.remove(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(document.getElementById("tab-details")));
        } else { // Note: May cause some problems
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting) Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["multiSelectReset"])();
        }
    }
}

function isInlinePrintableKey(e) {
    if (typeof e.which === "undefined") {
        return true;
    } else if (typeof e.which === "number" && e.which > 0) {
        return !e.ctrlKey && !e.metaKey && !e.altKey && e.which !== 8 && e.which !== 13;
    }
}

function documentKeyPressed(e) {
    if (isInlinePrintableKey(e)) {
        document.getElementById("search").focus();
    } else if (e.key === "Enter") {
        if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].selectedTabs === 1) {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["selectTabEntry"])(document.getElementsByClassName("multiselect")[0]);
        }
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/message.js":
/*!**********************************************!*\
  !*** ./src/popup/event-listeners/message.js ***!
  \**********************************************/
/*! exports provided: onMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMessage", function() { return onMessage; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../domutils */ "./src/popup/domutils.js");
/* harmony import */ var _net__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../net */ "./src/popup/net.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");





function onMessage(request, sender) {
    switch (request.type) {
        case "ACTIVE_TAB_CHANGED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["setActiveTab"])(request.details.windowId, request.details.tabId);
            break;
        case "TAB_FAV_ICON_CHANGED":
            browser.tabs.get(request.details.tabId).then(tab => {
                let favIconPromise;
                if (tab.incognito) {
                    favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(request.details.favIconUrl, true);
                } else {
                    favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(request.details.favIconUrl);
                }
                favIconPromise.then(function (base64Image){
                    Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getFavIconFromTabEntry"])(Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId)).src = base64Image;
                });
            });
            break;
        case "TAB_PINNED_STATUS_CHANGED":
            let tabEntry = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId);
            let pinBtn = tabEntry.getElementByClassName("tab-entry-pin-btn");
            let windowEntryList = tabEntry.parentElement;
            let pinnedTabs;
            if (request.details.pinned) {
                pinnedTabs = Array.from(windowEntryList.getElementsByClassName("pinned-tab"));
                tabEntry.classList.add("pinned-tab");
                pinBtn.style.backgroundImage = "url(../icons/pinremove.svg)";
            } else {
                pinnedTabs = Array.from(windowEntryList.getElementsByClassName("pinned-tab"));
                tabEntry.classList.remove("pinned-tab");
                pinBtn.style.backgroundImage = "url(../icons/pin.svg)";
            }
            let lastPinnedTab = pinnedTabs[pinnedTabs.length-1];
            if (lastPinnedTab !== undefined) {
                windowEntryList.insertBefore(tabEntry, lastPinnedTab.nextSibling);
            } else {
                windowEntryList.insertBefore(tabEntry, windowEntryList.childNodes[0]);
            }
            break;
        case "TAB_TITLE_CHANGED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId).getElementByClassName("tab-title").textContent = request.details.title;
            break;
        case "TAB_REMOVED":
            if (!request.details.windowClosing) {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["removeTab"])(request.details.tabId, request.details.windowId);
            }
            break;
        case "WINDOW_REMOVED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["removeWindow"])(request.details.windowId);
            break;
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/recorder.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/recorder.js ***!
  \***********************************************/
/*! exports provided: saveForLater, restore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveForLater", function() { return saveForLater; });
/* harmony import */ var _recorder__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../recorder */ "./src/popup/recorder.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "restore", function() { return _recorder__WEBPACK_IMPORTED_MODULE_0__["restore"]; });



let saveForLaterBtn = document.getElementById("save-for-later");
let sflTimeout = () => {
    saveForLaterBtn.removeAttribute("done");
};
function saveForLater() {
    saveForLaterBtn.setAttribute("disabled", "");
    Object(_recorder__WEBPACK_IMPORTED_MODULE_0__["record"])().then(() => {
        saveForLaterBtn.removeAttribute("disabled");
        saveForLaterBtn.setAttribute("done", "");
        clearTimeout(sflTimeout); setTimeout(sflTimeout, 2000);
    });
}




/***/ }),

/***/ "./src/popup/event-listeners/search.js":
/*!*********************************************!*\
  !*** ./src/popup/event-listeners/search.js ***!
  \*********************************************/
/*! exports provided: initSearch, searchTextChanged */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initSearch", function() { return initSearch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchTextChanged", function() { return searchTextChanged; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../domutils */ "./src/popup/domutils.js");





// Init
function initSearch() {
    document.getElementById("search").addEventListener("keypress", _domutils__WEBPACK_IMPORTED_MODULE_3__["stopPropagation"]);
}

function keywordSearch(s, key) {
    let keywords = key.trim().split(" "), count = 0;
    for (let i = 0; i < keywords.length; i++) {
        let word = keywords[i];
        if (word.trim() !== "" && word.match(/^[a-zA-Z0-9]+$/)) {
            if (s.toUpperCase().includes(word.toUpperCase())) {
                count++;
            }
        }
    }
    return count >= 2;
}

function search(s, key) {
    return s.toUpperCase().includes(key.toUpperCase()) || keywordSearch(s, key);
}

// Search
async function searchTextChanged(e) {
    let input, filter, tabEntries;
    input = document.getElementById("search");
    filter = input.value;
    tabEntries = document.getElementsByClassName("tab-entry");
    if (filter !== "") {
        for (let i = 0; i < tabEntries.length; i++) {
            let tabEntry = tabEntries[i];
            if (!search(tabEntry.getElementByClassName("tab-title").innerText, filter) &&
                !(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].searchInURLs && search((await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry))).url, filter))) {
                tabEntry.style.display = "none";
            } else {
                tabEntry.style.display = "flex";
            }
        }
    } else {
        for (let i = 0; i < tabEntries.length; i++) {
            let tabEntry = tabEntries[i];
            tabEntry.style.display = "flex";
        }
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/tabEntry.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/tabEntry.js ***!
  \***********************************************/
/*! exports provided: tabEntryMouseOver, tabEntryMouseLeave, tabEntryClicked, tabCloseClick, tabPinClick */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryMouseOver", function() { return tabEntryMouseOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryMouseLeave", function() { return tabEntryMouseLeave; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryClicked", function() { return tabEntryClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabCloseClick", function() { return tabCloseClick; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabPinClick", function() { return tabPinClick; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _keyutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../keyutils */ "./src/popup/keyutils.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtutils */ "./src/popup/wtutils.js");
/* harmony import */ var _captureTab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../captureTab */ "./src/popup/captureTab.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");







function tabEntryMouseOver(e) {
    e.target.getElementByClassName("tab-entry-pin-btn").style.display = "inline-block";
    if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])() && _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding) {
        if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator !== e.target) {
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator.classList.contains("multiselect")) {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelect"])(e.target);
            } else {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelectCancel"])(e.target);
            }
        }
    } else {
        let tabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getTabId"])(e.target);
        _captureTab__WEBPACK_IMPORTED_MODULE_4__["captureTab"](tabId).then(dataUri => {
            if (dataUri !== null) {
                let detailsImage = document.getElementById("details-img");
                detailsImage.src = dataUri;
            }
            let detailsTitle = document.getElementById("details-title");
            let detailsURL = document.getElementById("details-url");
            browser.tabs.get(tabId).then(tab => {
                detailsTitle.textContent = tab.title;
                detailsURL.textContent = tab.url;
                document.getElementById("details-placeholder").style.display = "none";
                document.getElementById("tab-details").style.display = "inline-block";
                document.getElementById("tab-details").setAttribute("data-tab_id", tabId);
                if (tab.pinned) {
                    document.getElementById("details-pinned").style.display = "inline";
                } else {
                    document.getElementById("details-pinned").style.display = "none";
                }
                if (tab.hidden) {
                    document.getElementById("details-hidden").style.display = "inline";
                } else {
                    document.getElementById("details-hidden").style.display = "none";
                }
                if (tab.pinned && tab.hidden) {
                    document.getElementById("details-comma").style.display = "inline";
                } else {
                    document.getElementById("details-comma").style.display = "none";
                }
            });
        });
    }
    e.preventDefault();
}

function tabEntryMouseLeave(e) {
    e.target.getElementByClassName("tab-entry-pin-btn").style.display = "none";
}

function tabEntryClicked(e) {
    if (e.button === 0) {
        if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])()) {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelectToggle"])(e.target);
            e.stopPropagation();
        } else {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["selectTabEntry"])(e.target);
        }
    }
}

function tabCloseClick(e) {
    e.stopPropagation();
    let tabId = e.target.parentElement.parentElement.getAttribute("data-tab_id");
    let tabDetails = document.getElementById("tab-details");
    if (tabDetails.getAttribute("data-tab_id") === tabId) {
        tabDetails.style.display = "none";
        document.getElementById("details-placeholder").style.display = "inline-block";
    }
    browser.tabs.remove(parseInt(tabId));
}

function tabPinClick(e) {
    e.stopPropagation();
    let tabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getTabId"])(e.target.parentElement.parentElement);
    browser.tabs.get(tabId).then(tab => {
        if (tab.pinned) {
            browser.tabs.update(tab.id, {
                pinned: false
            });
        } else {
            browser.tabs.update(tab.id, {
                pinned: true
            });
        }
    });
}


/***/ }),

/***/ "./src/popup/event-listeners/windowEntry.js":
/*!**************************************************!*\
  !*** ./src/popup/event-listeners/windowEntry.js ***!
  \**************************************************/
/*! exports provided: windowEntryDragStarted, windowEntryDraggingOver, windowEntryDropped, windowEntryTitleClicked, windowCloseClick */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDragStarted", function() { return windowEntryDragStarted; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDraggingOver", function() { return windowEntryDraggingOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDropped", function() { return windowEntryDropped; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryTitleClicked", function() { return windowEntryTitleClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowCloseClick", function() { return windowCloseClick; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _keyutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../keyutils */ "./src/popup/keyutils.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");





let multiDragging = false, sourceTab, targetTab, under, sourceWindow, sourceWindowId;

function getMultiDragImage(target, clientX, clientY) {
    let dragImage = document.createElement("div"), x, y;
    let selectedItems = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getSelectedItems"])();
    if (selectedItems.length === 1) return selectedItems[i];
    for (let i = 0; i < selectedItems.length - 1; i++) {
        let ref1 = selectedItems[i], ref2 = selectedItems[i+1];
        let ref1br = ref1.getBoundingClientRect(), ref2br = ref2.getBoundingClientRect();
        let distance = ref2br.top - (ref1br.top + ref1br.height);
        let ref1Clone = ref1.cloneNode(true);
        ref1Clone.style.marginBottom = distance + "px";
        dragImage.appendChild(ref1Clone);
    } dragImage.appendChild(selectedItems[selectedItems.length - 1].cloneNode(true));
    dragImage.style.width = selectedItems[0].getBoundingClientRect().width + "px";
    document.body.appendChild(dragImage);
    return {
        image: dragImage,
        x: 0,
        y: 0
    };
}

function windowEntryDragStarted(e) {
    if (e.target.classList.contains("tab-entry")) {
        if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])()) {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["multiSelectToggle"])(e.target);
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding = true;
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator = e.target;
            e.preventDefault();
        } else {
            sourceTab = e.target;
            sourceWindow = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(sourceTab);
            sourceWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(sourceWindow);
            e.dataTransfer.effectAllowed = "move";
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting && Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["multiSelected"])(e.target)) {
                multiDragging = true;
                let dragImage = getMultiDragImage();
                e.dataTransfer.setDragImage(dragImage.image, dragImage.x, dragImage.y);
            }
        }
        e.dataTransfer.setData('text/plain', null);
    }
}

function windowEntryDraggingOver(e) {
    e.preventDefault();
    let cursors = Array.from(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("insert-cursor"));
    for (let i = 0; i < cursors.length; i++) {
        let c = cursors[i];
        c.parentElement.removeChild(c);
    }
    let cursorWindow = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementByClassName("insert-cursor-window");
    if (cursorWindow !== null) {
        cursorWindow.classList.remove("insert-cursor-window");
    }

    let windowEntry;
    if (e.target.classList.contains("tab-entry")) {
        let tabEntryBoundingClientRect = e.target.getBoundingClientRect();
        targetTab = e.target;
        under = false;
        if ((e.clientY - tabEntryBoundingClientRect.top) >= tabEntryBoundingClientRect.height / 2) {
            targetTab = targetTab.nextSibling;
            if (targetTab === null) {
                under = true;
                targetTab = e.target;
            }
        }
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggable"])(sourceTab, targetTab, under, sourceWindow, multiDragging)) {
            let cursor = document.createElement("div");
            cursor.classList.add("insert-cursor");
            if (under) {
                targetTab.parentElement.appendChild(cursor);
            } else {
                targetTab.parentElement.insertBefore(cursor, targetTab);
            }
        }
    } else if ((windowEntry = e.target.parentElement) !== null && windowEntry.classList.contains("window-entry")) {
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggableToWindow"])(sourceTab, windowEntry, sourceWindow)) {
            e.target.classList.add("insert-cursor-window");
        }
    }
}

function windowEntryDropped(e) {
    e.preventDefault();
    e.stopPropagation();
    let cursors = Array.from(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("insert-cursor"));
    for (let i = 0; i < cursors.length; i++) {
        let cursor = cursors[i];
        cursor.parentElement.removeChild(cursor);
    }
    let cursorWindow = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementByClassName("insert-cursor-window");
    if (cursorWindow !== null) {
        cursorWindow.classList.remove("insert-cursor-window");
    }
    
    let windowEntry;
    if (e.target.classList.contains("tab-entry")) {
        if (!e.target.isSameNode(targetTab)) {
            let tabEntryBoundingClientRect = e.target.getBoundingClientRect();
            targetTab = e.target;
            under = false;
            if ((e.clientY - tabEntryBoundingClientRect.top) >= tabEntryBoundingClientRect.height / 2) {
                targetTab = targetTab.nextSibling;
                if (targetTab === null) {
                    under = true;
                    targetTab = e.target;
                }
            }
        }
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggable"])(sourceTab, targetTab, under, sourceWindow, multiDragging)) {
            let destinationWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(targetTab));
            let sourceTabIndex = Array.prototype.indexOf.call(targetTab.parentElement.childNodes, sourceTab);
            let destinationIndex = Array.prototype.indexOf.call(targetTab.parentElement.childNodes, targetTab);
            let moveIndex = under ? -1 : ((sourceTabIndex !== -1 && destinationIndex > sourceTabIndex && destinationWindowId === sourceWindowId) ? destinationIndex-1 : destinationIndex);
            let sourceTabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getTabId"])(sourceTab);
            browser.tabs.move(sourceTabId, {
                windowId: destinationWindowId,
                index: moveIndex
            });
            if (under) {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["attachTab"])(sourceTab, Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(targetTab));
            } else {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["moveTab"])(sourceTab, targetTab);
            }
        }
    } else if ((windowEntry = e.target.parentElement) !== null && windowEntry.classList.contains("window-entry")) {
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggableToWindow"])(sourceTab, windowEntry, sourceWindow)) {
            let sourceTabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getTabId"])(sourceTab);
            let destinationWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(windowEntry);
            browser.tabs.move(sourceTabId, {
                windowId: destinationWindowId,
                index: -1
            });
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["attachTab"])(sourceTab, windowEntry);
        }
    }
}

function windowEntryTitleClicked(e) {
    let windowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(e.target.parentElement);
    browser.windows.update(windowId, {
        focused: true
    });
}

function windowCloseClick(e) {
    let windowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(e.target.parentElement.parentElement.parentElement);
    browser.windows.remove(windowId);
}


/***/ }),

/***/ "./src/popup/globals.js":
/*!******************************!*\
  !*** ./src/popup/globals.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const globals = {
    tabsList: undefined,
    isSelecting: false,
    selectedTabs: 0,
    slideSelection: {
        sliding: false,
        initiator: undefined,
        vector: 0
    },
    hideAfterTabSelection: undefined,
    searchInURLs: undefined
};
/* harmony default export */ __webpack_exports__["default"] = (globals);


/***/ }),

/***/ "./src/popup/keyutils.js":
/*!*******************************!*\
  !*** ./src/popup/keyutils.js ***!
  \*******************************/
/*! exports provided: KeyTracker, Keys, ctrlOrCmd */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyTracker", function() { return KeyTracker; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Keys", function() { return Keys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ctrlOrCmd", function() { return ctrlOrCmd; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Key tracker
function KeyTracker() {
    this.keys = {};
    window.addEventListener("keydown", e => {
        this.keys[e.code] = true;
    });
    window.addEventListener("keyup", e => {
        this.keys[e.code] = false;
    });
}
KeyTracker.prototype.pressed = function (code) {
    return Boolean(this.keys[code]);
};
KeyTracker.prototype.ctrl = function () {
    return this.pressed("ControlLeft") || this.pressed("ControlRight");
};
KeyTracker.prototype.cmd = function () {
    return this.pressed("OSRight") || this.pressed("OSLeft");
};
KeyTracker.prototype.ctrlOrCmd = function () {
    if (window.navigator.platform.toUpperCase().indexOf("MAC") >= 0) {
        return this.cmd();
    }
    return this.ctrl();
};
KeyTracker.prototype.shift = function () {
    return this.pressed("ShiftLeft") || this.pressed("ShiftRight");
};
let Keys = new KeyTracker();

// Checks if either Ctrl(Windows & Linux) or Command(Mac) is pressed
function ctrlOrCmd() {
    return Keys.ctrlOrCmd();
}


/***/ }),

/***/ "./src/popup/messaging.js":
/*!********************************!*\
  !*** ./src/popup/messaging.js ***!
  \********************************/
/*! exports provided: sendRuntimeMessage, sendTabMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendRuntimeMessage", function() { return sendRuntimeMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendTabMessage", function() { return sendTabMessage; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Function to send a message to the runtime
function sendRuntimeMessage(type, data) {
    return browser.runtime.sendMessage({
        type: type,
        data: data
    });
}

// Function to send a message to a tab
function sendTabMessage(tabId, target, data) {
    return browser.tabs.sendMessage(tabId, {
        target: target,
        data: data
    });
}


/***/ }),

/***/ "./src/popup/net.js":
/*!**************************!*\
  !*** ./src/popup/net.js ***!
  \**************************/
/*! exports provided: getImage, arrayBufferToBase64 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getImage", function() { return getImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "arrayBufferToBase64", function() { return arrayBufferToBase64; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Function to get image from URL
function getImage(url, noCache=false) {
    return new Promise((resolve, reject) => {
        try {
            if (!url.startsWith("chrome://")) {
                let xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function(){
                    if (this.readyState == 4 && this.status == 200) {
                        let contentType = xhr.getResponseHeader("Content-Type").trim();
                        if (contentType.startsWith("image/")) {
                            let flag = "data:" + contentType + ";charset=utf-8;base64,";
                            let imageStr = arrayBufferToBase64(xhr.response);
                            resolve(flag + imageStr);
                        } else {
                            reject("Image Request Failed: Content-Type is not an image! (Content-Type: \"" + contentType + "\")");
                        }
                    }
                };
                xhr.responseType = "arraybuffer";
                xhr.open("GET", url, true);
                if (noCache) { xhr.setRequestHeader("Cache-Control", "no-store"); }
                xhr.send();
            } else {
                resolve();
            }
        } catch (err) {
            reject(err.message);
        }
    });
}

// Function to transform ArrayBuffer into a Base64 String
function arrayBufferToBase64(buffer) {
    let binary = "";
    let bytes = [].slice.call(new Uint8Array(buffer));
    bytes.forEach((b) => binary += String.fromCharCode(b));
    return window.btoa(binary);
}


/***/ }),

/***/ "./src/popup/popup.js":
/*!****************************!*\
  !*** ./src/popup/popup.js ***!
  \****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");
/* harmony import */ var _wtinit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wtinit */ "./src/popup/wtinit.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./domutils */ "./src/popup/domutils.js");
/* harmony import */ var _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./event-listeners/document */ "./src/popup/event-listeners/document.js");
/* harmony import */ var _event_listeners_search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-listeners/search */ "./src/popup/event-listeners/search.js");
/* harmony import */ var _event_listeners_message__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./event-listeners/message */ "./src/popup/event-listeners/message.js");
/* harmony import */ var _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./event-listeners/recorder */ "./src/popup/event-listeners/recorder.js");
/* harmony import */ var _captureTab__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./captureTab */ "./src/popup/captureTab.js");
/* harmony import */ var _options__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../options */ "./src/options.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./wtdom */ "./src/popup/wtdom.js");
/* harmony import */ var _recorder__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./recorder */ "./src/popup/recorder.js");














_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList = document.getElementById("tabs-list");

function setPopupSize(width, height) {
    document.documentElement.style.width = width + "px";
    document.documentElement.style.height = height + "px";
    document.body.style.width = width + "px";
    document.body.style.height = height + "px";
}

async function fulfillOptions() {
    let popupOptions = (await _options__WEBPACK_IMPORTED_MODULE_10__["options"]()).popup;
    // popup.size
    setPopupSize(popupOptions.size.width, popupOptions.size.height);
    // popup.scale
    document.documentElement.style.setProperty('--scale', popupOptions.scale.toString());
    // popup.showDetails
    if (!_options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.showDetails)) {
        let leftContainer = document.getElementById("left-container");
        popupOptions.size.width = popupOptions.size.width - Object(_domutils__WEBPACK_IMPORTED_MODULE_4__["getActualWidth"])(leftContainer);
        setPopupSize(popupOptions.size.width, popupOptions.size.height);
        leftContainer.style.display = "none";
        document.getElementById("tabs-container").style.width = "100%";
    } else {
        // popup.showPreview
        if (!_options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.showPreview)) Object(_wtdom__WEBPACK_IMPORTED_MODULE_11__["hideTabPreview"])();
    }
    // popup.hideAfterTabSelection
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].hideAfterTabSelection = _options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.hideAfterTabSelection);
    // popup.searchInURLs
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].searchInURLs = _options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.searchInURLs);
}

async function main() {
    // Initialize captureTab based on environment
    _captureTab__WEBPACK_IMPORTED_MODULE_9__["init"]();
    // Fulfill user options
    await fulfillOptions();
    // Make tabs list fit the panel
    Object(_wtinit__WEBPACK_IMPORTED_MODULE_3__["extendTabsList"])();
    // Fix for cross-window dragging issue
    await Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_2__["getWrongToRight"])();
    // Populate tabs list with tabs
    await Object(_wtinit__WEBPACK_IMPORTED_MODULE_3__["populateTabsList"])();
    // Update recorder tooltip
    await Object(_recorder__WEBPACK_IMPORTED_MODULE_12__["updateRecorderToolTip"])();
    // Initialize components
    Object(_event_listeners_search__WEBPACK_IMPORTED_MODULE_6__["initSearch"])();
}

/* Add event listeners */

// Starting point
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
} else {
    main();
}

document.addEventListener("mouseover", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentMouseOver"]);
document.addEventListener("mouseup", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentMouseUp"]);
document.addEventListener("click", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentClicked"]);
document.addEventListener("keypress", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentKeyPressed"]);

// Add keyup event listener and put focus on search
let search = document.getElementById("search");
search.addEventListener("keyup", _event_listeners_search__WEBPACK_IMPORTED_MODULE_6__["searchTextChanged"]);
search.focus();

// Add event listeners to all copy buttons
let copyButtons = Array.from(document.getElementsByClassName("copy-button"));
for (let i = 0; i < copyButtons.length; i++) {
    copyButtons[i].addEventListener("click", e => {
        document.oncopy = ce => {
            ce.clipboardData.setData("text", document.getElementById(e.target.getAttribute("for")).innerText);
            ce.preventDefault();
        };
        document.execCommand("copy", false, null);
        e.target.innerText = "Copied!";
        setTimeout(() => {
            e.target.innerText = "Copy";
        }, 2000);
    });
}

// Add event listener for recorder.js
document.getElementById("save-for-later").addEventListener("click", _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__["saveForLater"]);
document.getElementById("restore-now").addEventListener("click", _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__["restore"]);

// Add event listener to listen for any messages from background.js
if (!browser.runtime.onMessage.hasListener(_event_listeners_message__WEBPACK_IMPORTED_MODULE_7__["onMessage"])) {
    browser.runtime.onMessage.addListener(_event_listeners_message__WEBPACK_IMPORTED_MODULE_7__["onMessage"]);
}


/***/ }),

/***/ "./src/popup/recorder.js":
/*!*******************************!*\
  !*** ./src/popup/recorder.js ***!
  \*******************************/
/*! exports provided: lastRecord, updateRecorderToolTip, record, restore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lastRecord", function() { return lastRecord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateRecorderToolTip", function() { return updateRecorderToolTip; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "record", function() { return record; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "restore", function() { return restore; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wtdom */ "./src/popup/wtdom.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wtutils */ "./src/popup/wtutils.js");





async function lastRecord() {
    return browser.storage.sync.get(["record"]).then(data => data.record);
}

async function updateRecorderToolTip() {
    let r = await lastRecord();
    let restoreBtn = document.getElementById("restore-now");
    if (r) {
        restoreBtn.setAttribute("title", "Restore websites that have been saved on " + (new Date(r.timestamp)).toLocaleString());
        restoreBtn.removeAttribute("disabled");
    } else {
        restoreBtn.setAttribute("title", "Restore websites that have been saved");
        restoreBtn.setAttribute("disabled", "");
    }
}

function tabInfoToRecord(info) {
    return {
        url: info.url,
        pinned: info.pinned
    };
}
async function record() {
    let recordArray = [];
    for (let windowEntry of _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("window-entry")) {
        let windowRecord = [];
        for (let tabEntry of windowEntry.getElementsByClassName("tab-entry")) {
            await browser.tabs.sendMessage(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry), { target: "packd", data: { action: "pack" } }).then(async pack => {
                windowRecord.push(Object.assign({
                    pack: pack
                }, tabInfoToRecord(await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry)))));
            }).catch(async reason => {
                windowRecord.push(Object.assign({
                    pack: undefined
                }, tabInfoToRecord(await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry)))));
            });
        }
        recordArray.push(windowRecord);
    }
    let record = {
        timestamp: Date.now(),
        record: recordArray
    };
    return browser.storage.sync.set({ record: record }).then(() => updateRecorderToolTip());
}

async function restore() {
    let { record: r } = await lastRecord();
    for (let windowRecord of r) {
        if (browser.runtime.getBrowserInfo) {
            windowRecord = windowRecord.filter(tabRecord => !tabRecord.url.startsWith("about:"))
        }
        browser.windows.create({
            url: windowRecord.map(tabRecord => tabRecord.url)
        }).then(async w => {
            for (let i = 0; i < windowRecord.length; i++) {
                let tabRecord = windowRecord[i];
                await browser.tabs.update(w.tabs[i].id, {
                    pinned: tabRecord.pinned
                }).then(t => {
                    if (tabRecord.pack) {
                        Object(_wtutils__WEBPACK_IMPORTED_MODULE_3__["runAfterTabLoad"])(t.id, () => {
                            browser.tabs.sendMessage(t.id, {
                                target: "packd",
                                data: Object.assign({action: "unpack"}, tabRecord.pack)
                            });
                        });
                    }
                }).catch(e => {
                    console.log(e);
                });
            }
        });
    }
}


/***/ }),

/***/ "./src/popup/wrong-to-right.js":
/*!*************************************!*\
  !*** ./src/popup/wrong-to-right.js ***!
  \*************************************/
/*! exports provided: getWrongToRight, getCorrectTabId */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWrongToRight", function() { return getWrongToRight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCorrectTabId", function() { return getCorrectTabId; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _messaging__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./messaging */ "./src/popup/messaging.js");



let wrongToRight;

function getWrongToRight() {
    return Object(_messaging__WEBPACK_IMPORTED_MODULE_1__["sendRuntimeMessage"])("WRONG_TO_RIGHT_GET", {}).then(response => {
        wrongToRight = response.wrongToRight;
    });
}

// Function to get correct tab id
function getCorrectTabId(tabId) {
    return wrongToRight[tabId] || tabId;
}


/***/ }),

/***/ "./src/popup/wtdom.js":
/*!****************************!*\
  !*** ./src/popup/wtdom.js ***!
  \****************************/
/*! exports provided: selectTabEntry, hideTabPreview, getTabByTabEntry, getTabId, getWindowId, findTabEntryById, findCorrectTabEntryById, getFavIconFromTabEntry, findWindowEntryById, findTabEntryInWindow, getActiveTab, setActiveTab, removeTab, moveTab, moveTabs, attachTab, attachTabs, removeWindow, getWindowFromTab, getTabEntriesFromWindow, tabDraggable, tabDraggableToWindow, tabEntryIndex, getNextTabEntry, getLastTabEntry, getSelectedItems, multiSelected, multiSelect, multiSelectCancel, multiSelectReset, multiSelectToggle, resetSlideSelection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectTabEntry", function() { return selectTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hideTabPreview", function() { return hideTabPreview; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabByTabEntry", function() { return getTabByTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabId", function() { return getTabId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindowId", function() { return getWindowId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findTabEntryById", function() { return findTabEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findCorrectTabEntryById", function() { return findCorrectTabEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFavIconFromTabEntry", function() { return getFavIconFromTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findWindowEntryById", function() { return findWindowEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findTabEntryInWindow", function() { return findTabEntryInWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActiveTab", function() { return getActiveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setActiveTab", function() { return setActiveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeTab", function() { return removeTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveTab", function() { return moveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveTabs", function() { return moveTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachTab", function() { return attachTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachTabs", function() { return attachTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeWindow", function() { return removeWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindowFromTab", function() { return getWindowFromTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabEntriesFromWindow", function() { return getTabEntriesFromWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabDraggable", function() { return tabDraggable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabDraggableToWindow", function() { return tabDraggableToWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryIndex", function() { return tabEntryIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNextTabEntry", function() { return getNextTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastTabEntry", function() { return getLastTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectedItems", function() { return getSelectedItems; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelected", function() { return multiSelected; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelect", function() { return multiSelect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectCancel", function() { return multiSelectCancel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectReset", function() { return multiSelectReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectToggle", function() { return multiSelectToggle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetSlideSelection", function() { return resetSlideSelection; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wtutils */ "./src/popup/wtutils.js");





// Select tab and go to it
function selectTabEntry(tabEntry) {
    let tabId = getTabId(tabEntry);
    let parentWindowId = getWindowId(getWindowFromTab(tabEntry));
    browser.tabs.update(tabId, {
        active: true
    });
    browser.windows.get(parentWindowId).then(w => {
        Object(_wtutils__WEBPACK_IMPORTED_MODULE_3__["getLastFocusedWindow"])().then(cw => {
            if (w.id !== cw.id) {
                browser.windows.update(w.id, {
                    focused: true
                });
            } else {
                if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].hideAfterTabSelection) window.close();
            }
        });
    });
}

// Hides the tab preview
function hideTabPreview() {
    document.getElementById("details-img").style.display = "none";
}

// Get a tab by a tab entry
function getTabByTabEntry(entry) {
    return browser.tabs.get(getTabId(entry));
}

// Get the TabId of a tab entry
function getTabId(entry) {
    return parseInt(entry.getAttribute("data-tab_id"));
}

// Get the WindowId of a window entry
function getWindowId(entry) {
    return parseInt(entry.getAttribute("data-window_id"));
}

// Find tab entry by tab id
function findTabEntryById(tabId) {
    return document.querySelector(".tab-entry[data-tab_id=\"" + tabId + "\"]");
}

// Find correct tab entry by tab id
function findCorrectTabEntryById(tabId) {
    return findTabEntryById(Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_2__["getCorrectTabId"])(tabId));
}

// Get favicon from a tab entry
function getFavIconFromTabEntry(entry) {
    return entry.getElementByClassName("tab-entry-favicon");
}

// Find window entry by tab id
function findWindowEntryById(windowId) {
    return _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.querySelector("li[data-window_id=\"" + windowId + "\"]");
}

// Find tab entry inside a window entry
function findTabEntryInWindow(windowEntry, tabId) {
    return windowEntry.querySelector("li[data-tab_id=\"" + tabId + "\"]");
}

// Get active tab in the specified window
function getActiveTab(windowId) {
    let window = findWindowEntryById(windowId);
    return window.getElementByClassName("current-tab");
}

// Set active tab in the specified window
function setActiveTab(windowId, tabId) {
    let window = findWindowEntryById(windowId), lastActiveTab;
    if ((lastActiveTab = getActiveTab(windowId)) !== null) {
        lastActiveTab.classList.remove("current-tab");
    }
    findTabEntryInWindow(window, tabId).classList.add("current-tab");
}

// Remove tab
function removeTab(tabId, windowId) {
    let tabEntry = findTabEntryById(tabId);
    tabEntry.parentElement.removeChild(tabEntry);
    browser.tabs.query({
        active: true,
        windowId: windowId
    }).then(tabs => {
        findCorrectTabEntryById(tabs[0].id).classList.add("current-tab");
    });
}

// Move tab
function moveTab(target, dest) {
    getWindowFromTab(dest).getElementByClassName("window-entry-tabs").insertBefore(target, dest);
}

// Move tabs
function moveTabs(targets, dest) {
    for (let i = 0; i < targets.length; i++) moveTab(targets[i], dest);
}

// Attach tab
function attachTab(target, dest) {
    dest.getElementByClassName("window-entry-tabs").appendChild(target);
}

// Attach tabs
function attachTabs(targets, dest) {
    for (let i = 0; i < targets.length; i++) attachTab(targets[i], dest);
}

// Remove window
function removeWindow(windowId) {
    let windowEntry = findWindowEntryById(windowId);
    windowEntry.parentElement.removeChild(windowEntry);
    browser.windows.getCurrent({}).then(window => {
        findWindowEntryById(window.id).classList.add("current-window");
    });
}

function getWindowFromTab(tab) {
    return tab.parentElement.parentElement;
}
function getTabEntriesFromWindow(windowEntry) {
    return Array.from(windowEntry.getElementsByClassName("tab-entry"));
}

// Test if tab is draggable
function tabDraggable(sourceTab, targetTab, under, sourceWindow, multiDragging) {
    return !sourceTab.isSameNode(targetTab)
            && (!multiDragging || (multiSelected(sourceTab) && multiSelected(targetTab)))
            && ((!sourceTab.classList.contains("pinned-tab") && !targetTab.classList.contains("pinned-tab"))
                || (sourceTab.classList.contains("pinned-tab") && targetTab.classList.contains("pinned-tab"))
                || (under && !sourceTab.classList.contains("pinned-tab")))
            && ((!sourceWindow.classList.contains("incognito-window") && !getWindowFromTab(targetTab).classList.contains("incognito-window"))
                || (sourceWindow.classList.contains("incognito-window") && getWindowFromTab(targetTab).classList.contains("incognito-window")));
}

// Test if tab is draggable to window
function tabDraggableToWindow(sourceTab, targetWindow, sourceWindow) {
    return !sourceWindow.isSameNode(targetWindow)
            && !sourceTab.classList.contains("pinned-tab")
            && ((!sourceWindow.classList.contains("incognito-window") && !targetWindow.classList.contains("incognito-window"))
                || (sourceWindow.classList.contains("incognito-window") && targetWindow.classList.contains("incognito-window")));
}

// Returns the index of a tab entry
function tabEntryIndex(tabEntry) {
    let tabs = Array.from(document.getElementsByClassName("tab-entry"));
    for (let i = 0; i < tabs.length; i++) {
        if (tabs[i] === tabEntry) {
            return i;
        }
    }
    return -1;
}

// Get next tab
function getNextTabEntry(tabEntry) {
    if (tabEntry.nextElementSibling !== null) {
        return tabEntry.nextElementSibling;
    } else if (getWindowFromTab(tabEntry).nextElementSibling !== null) {
        return getTabEntriesFromWindow(getWindowFromTab(tabEntry).nextElementSibling)[0];
    } else {
        return null;
    }
}
// Get last tab
function getLastTabEntry(tabEntry) {
    if (tabEntry.previousElementSibling !== null) {
        return tabEntry.previousElementSibling;
    } else if (getWindowFromTab(tabEntry).previousElementSibling !== null) {
        return getTabEntriesFromWindow(getWindowFromTab(tabEntry).previousElementSibling)[0];
    } else {
        return null;
    }
}

/* Multiselect */
// On multiselect start
function onMultiselectStart() {

}
// On multiselect change
function onMultiselectChange() {

}
// On multiselect end
function onMultiselectEnd() {

}
// Get Selected Items
function getSelectedItems() {
    return Array.from(document.getElementsByClassName("multiselect"));
}
// Multiselected
function multiSelected(element) {
    return element.classList.contains("multiselect");
}
// Select
function multiSelect(element) {
    if (!element.classList.contains("multiselect")) {
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].selectedTabs++;
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = true;
        element.classList.add("multiselect");
    }
}
// Cancel Selection
function multiSelectCancel(element) {
    if (element.classList.contains("multiselect")) {
        if (--_globals__WEBPACK_IMPORTED_MODULE_1__["default"].selectedTabs == 0) {
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = false;
        }
        element.classList.remove("multiselect");
    }
}
// Reset multiselect
function multiSelectReset() {
    for (let element of Array.from(document.getElementsByClassName("multiselect"))) {
        element.classList.remove("multiselect");
    }
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].selectedTabs = 0;
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = false;
}
// Toggle Selection
function multiSelectToggle(element) {
    if (element.classList.contains("multiselect")) {
        multiSelectCancel(element);
    } else {
        multiSelect(element);
    }
}
// Reset slide selection
function resetSlideSelection() {
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding = false;
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator = undefined;
}


/***/ }),

/***/ "./src/popup/wtinit.js":
/*!*****************************!*\
  !*** ./src/popup/wtinit.js ***!
  \*****************************/
/*! exports provided: updateTabs, populateTabsList, extendTabsList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateTabs", function() { return updateTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "populateTabsList", function() { return populateTabsList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "extendTabsList", function() { return extendTabsList; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _net__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./net */ "./src/popup/net.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./wtutils */ "./src/popup/wtutils.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./domutils */ "./src/popup/domutils.js");
/* harmony import */ var _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-listeners/windowEntry */ "./src/popup/event-listeners/windowEntry.js");
/* harmony import */ var _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./event-listeners/tabEntry */ "./src/popup/event-listeners/tabEntry.js");









// Update tabs
function updateTabs(windows) {
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.innerHTML = "";
    let tabsListFragment = document.createDocumentFragment();
    let currentWindowEntry;
    /* Predefined elements for faster performance */
    // Window close button
    let WINDOW_CLOSE_BTN = document.createElement("span");
    WINDOW_CLOSE_BTN.classList.add("inline-button");
    WINDOW_CLOSE_BTN.classList.add("img-button");
    WINDOW_CLOSE_BTN.classList.add("opacity-changing-button");
    WINDOW_CLOSE_BTN.classList.add("window-entry-remove-btn");
    WINDOW_CLOSE_BTN.style.backgroundImage = "url(../icons/close.svg)";
    let DIV = document.createElement("div");
    DIV.style.display = "inline-block";
    WINDOW_CLOSE_BTN.appendChild(DIV);
    // Tab close button
    let TAB_CLOSE_BTN = document.createElement("span");
    TAB_CLOSE_BTN.classList.add("inline-button");
    TAB_CLOSE_BTN.classList.add("red-button");
    TAB_CLOSE_BTN.classList.add("img-button");
    TAB_CLOSE_BTN.classList.add("tab-entry-remove-btn");
    TAB_CLOSE_BTN.style.backgroundImage = "url(../icons/close.svg)";
    // Tab pin button
    let TAB_PIN_BTN = document.createElement("span");
    TAB_PIN_BTN.classList.add("inline-button");
    TAB_PIN_BTN.classList.add("img-button");
    TAB_PIN_BTN.classList.add("opacity-changing-button");
    TAB_PIN_BTN.classList.add("tab-entry-pin-btn");
    TAB_PIN_BTN.style.backgroundImage = "url(../icons/pin.svg)";
    // Loop through windows
    for (let i = 0; i < windows.length; i++) {
        // Set w to window
        let w = windows[i];

        // Create window entry
        let windowEntry = document.createElement("li");
        windowEntry.classList.add("window-entry");
        windowEntry.classList.add("category");

        // Create window entry fragment
        let windowEntryFragment = document.createDocumentFragment();

        // Set window id to window entry
        windowEntry.setAttribute("data-window_id", w.id);
        let span = document.createElement("span");
        span.addEventListener("click", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryTitleClicked"]);

        // Create close button
        let closeBtn = WINDOW_CLOSE_BTN.cloneNode(true);
        closeBtn.addEventListener("click", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowCloseClick"]);

        // Buttons wrapper
        let buttons = document.createElement("span");
        buttons.classList.add("window-entry-buttons");
        buttons.appendChild(closeBtn);
        
        // Create window name span
        let windowName = document.createElement("span");
        windowName.classList.add("window-title");
        windowName.textContent += "Window " + (i+1);

        // Check if window is focused
        if (w.focused) {
            currentWindowEntry = windowEntry;
            windowEntry.classList.add("current-window");
            windowName.textContent += " - Current";
        }
        // Check if window is incognito
        if (w.incognito) {
            windowEntry.classList.add("incognito-window");
            windowName.textContent += " (Incognito)";
        }

        span.appendChild(windowName);
        span.appendChild(buttons);

        span.classList.add("darker-button");

        windowEntryFragment.appendChild(span);

        // Add window entry dragstart, dragover, and drop event listeners
        windowEntry.addEventListener("dragstart", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDragStarted"]);
        windowEntry.addEventListener("dragover", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDraggingOver"]);
        windowEntry.addEventListener("drop", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDropped"]);
        windowEntry.setAttribute("draggable", "true");

        let windowTabsList = document.createElement("ul");
        windowTabsList.classList.add("category-list");
        windowTabsList.classList.add("window-entry-tabs");

        let windowTabsListFragment = document.createDocumentFragment();
        // Loop through tabs
        for (let i = 0; i < w.tabs.length; i++) {
            let tab = w.tabs[i];
            // Check tab id
            if (tab.id !== browser.tabs.TAB_ID_NONE) {
                // Create tab entry
                let tabEntry = document.createElement("li");
                tabEntry.classList.add("tab-entry");
                tabEntry.classList.add("button");
                // Set tab entry as draggable. Required to enable move tab feature
                tabEntry.setAttribute("draggable", "true");

                // Create tab entry fragment
                let tabEntryFragment = document.createDocumentFragment();

                let favicon;
                let title = document.createElement("span");
                title.classList.add("tab-title");
                title.textContent += tab.title;
                let titleWrapper = document.createElement("div");
                titleWrapper.classList.add("tab-title-wrapper");
                titleWrapper.appendChild(title);

                if (tab.active) {
                    tabEntry.classList.add("current-tab");
                }
                if (tab.favIconUrl) {
                    favicon = document.createElement("img");
                    favicon.classList.add("tab-entry-favicon");
                    let favIconPromise;
                    if (w.incognito) {
                        favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(tab.favIconUrl, true);
                    } else {
                        favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(tab.favIconUrl);
                    }
                    favIconPromise.then(base64Image => {
                        favicon.src = base64Image;
                    });
                }

                // Create close button
                closeBtn = TAB_CLOSE_BTN.cloneNode(false);
                closeBtn.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabCloseClick"]);
                closeBtn.addEventListener("mouseover", _domutils__WEBPACK_IMPORTED_MODULE_5__["stopPropagation"]);

                // Create pin button
                let pinBtn = TAB_PIN_BTN.cloneNode(false);
                pinBtn.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabPinClick"]);
                pinBtn.addEventListener("mouseover", _domutils__WEBPACK_IMPORTED_MODULE_5__["stopPropagation"]);

                // Buttons wrapper
                buttons = document.createElement("span");
                buttons.classList.add("tab-entry-buttons");
                buttons.appendChild(pinBtn);
                buttons.appendChild(closeBtn);

                // Set tab entry tab id
                tabEntry.setAttribute("data-tab_id", Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_3__["getCorrectTabId"])(tab.id));
                if (favicon !== undefined) {
                    tabEntryFragment.appendChild(favicon);
                } else {
                    tabEntry.classList.add("noicon");
                }
                tabEntryFragment.appendChild(titleWrapper);
                tabEntryFragment.appendChild(buttons);
                
                tabEntry.appendChild(tabEntryFragment);

                tabEntry.addEventListener("mouseover", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryMouseOver"]);
                tabEntry.addEventListener("mouseleave", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryMouseLeave"]);
                tabEntry.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryClicked"]);

                if (tab.pinned) {
                    pinBtn.style.backgroundImage = "url(../icons/pinremove.svg)";
                    tabEntry.classList.add("pinned-tab");
                    let pinnedTabs = Array.from(windowTabsList.getElementsByClassName("pinned-tab"));
                    let lastPinnedTab = pinnedTabs[pinnedTabs.length-1];
                    if (lastPinnedTab !== undefined) {
                        windowTabsListFragment.insertBefore(tabEntry, lastPinnedTab.nextSibling);
                    } else {
                        windowTabsListFragment.insertBefore(tabEntry, windowTabsList.childNodes[0]);
                    }
                } else {
                    windowTabsListFragment.appendChild(tabEntry);
                }
            }
        }

        // Append fragment to actual windowTabsList
        windowTabsList.appendChild(windowTabsListFragment);

        windowEntryFragment.appendChild(windowTabsList);
        windowEntry.appendChild(windowEntryFragment);
        tabsListFragment.appendChild(windowEntry);
    }
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.appendChild(tabsListFragment);
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.addEventListener("click", _domutils__WEBPACK_IMPORTED_MODULE_5__["stopPropagation"]);
    document.getElementById("tabs").style.display = "block";
    currentWindowEntry.scrollIntoView({ behavior: 'smooth' });
}

// Add tabs to list
async function populateTabsList() {
    let windows = await Object(_wtutils__WEBPACK_IMPORTED_MODULE_4__["getWindows"])();
    await Object(_wtutils__WEBPACK_IMPORTED_MODULE_4__["correctFocused"])(windows);
    updateTabs(windows);
}

// Set tabs list height to any available height
function extendTabsList() {
    let searchArea = document.getElementById("search-area");
    let searchAreaHeight = Object(_domutils__WEBPACK_IMPORTED_MODULE_5__["getActualHeight"])(searchArea);
    let tabs = document.getElementById("tabs");
    tabs.style.height = "calc(100% - " + searchAreaHeight + "px)";
}


/***/ }),

/***/ "./src/popup/wtutils.js":
/*!******************************!*\
  !*** ./src/popup/wtutils.js ***!
  \******************************/
/*! exports provided: getWindows, getLastFocusedWindowId, correctFocused, getLastFocusedWindow, runAfterTabLoad */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindows", function() { return getWindows; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastFocusedWindowId", function() { return getLastFocusedWindowId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "correctFocused", function() { return correctFocused; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastFocusedWindow", function() { return getLastFocusedWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "runAfterTabLoad", function() { return runAfterTabLoad; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Get all windows
function getWindows() {
    return browser.windows.getAll({
        populate: true,
        windowTypes: ["normal", "popup", "devtools"]
    });
}

// Get the correct last focused window id
function getLastFocusedWindowId() {
    /*
    Due to a bug in Chromium, windows.getLastFocused() will sometimes
    return incorrect windows. So here, instead of calling getLastFocused(),
    we call getCurrent().
    Reference: https://crbug.com/809822
    */
    return browser.tabs.query({ lastFocusedWindow: true }).then(function (tabs) {
        if (tabs.length > 0) {
            return tabs[0].windowId;
        }
        return -1;
    });
}

// Correct focused property of windows
// In Chromium, window.focused doesn't work, so we manually set it here
function correctFocused(windows) {
    return getLastFocusedWindowId().then(function (lastFocusedWindowId) {
        for (let i = 0; i < windows.length; i++) {
            if (windows[i].id === lastFocusedWindowId) {
                windows[i].focused = true;
            }
        }
    });
}

// Get current window
function getLastFocusedWindow() {
    // return browser.windows.getLastFocused({}); // Doesn't work due to a bug in Chromium. See explanation in getLastFocusedWindowId
    return getLastFocusedWindowId().then(windowId => browser.windows.get(windowId));
}

// Run code after a tab loads
function runAfterTabLoad(tabId, f) {
    return new Promise((resolve, reject) => {
        let listener = (uTabId, info) => {
            if (uTabId === tabId && info.status === 'complete') {
                browser.tabs.onUpdated.removeListener(listener);
                resolve(f());
            }
        };
        browser.tabs.onUpdated.addListener(listener);
    });
}


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL29wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL29wdGlvbnMvc3RhdGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9wb2x5ZmlsbC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvY2FwdHVyZVRhYi5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZG9tdXRpbHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2V2ZW50LWxpc3RlbmVycy9kb2N1bWVudC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL21lc3NhZ2UuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2V2ZW50LWxpc3RlbmVycy9yZWNvcmRlci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL3NlYXJjaC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL3RhYkVudHJ5LmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC9ldmVudC1saXN0ZW5lcnMvd2luZG93RW50cnkuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2dsb2JhbHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2tleXV0aWxzLmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC9tZXNzYWdpbmcuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL25ldC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvcG9wdXAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL3JlY29yZGVyLmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC93cm9uZy10by1yaWdodC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvd3Rkb20uanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL3d0aW5pdC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvd3R1dGlscy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7O0FDbEZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDNEU7QUFDeEI7O0FBRTlEO0FBQ1A7QUFDQTs7QUFFTztBQUNQLHNDQUFzQyxtQkFBbUI7QUFDekQ7O0FBRU87QUFDUDtBQUNBLGFBQWEseURBQVM7QUFDdEIsYUFBYSxnRUFBZ0I7QUFDN0I7QUFDQSxhQUFhLDBEQUFVO0FBQ3ZCLGFBQWEsaUVBQWlCO0FBQzlCO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3JCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF3Qzs7QUFFakM7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksc0RBQWE7QUFDakI7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDdkJBO0FBQUE7QUFBTyxzQkFBc0IsUUFBTTs7QUFFbkMsSUFBSSxLQUFtQixFQUFFLEVBRXhCOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsVUFBVTtBQUMxQyxvREFBb0QsZUFBZTtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxtRUFBbUU7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjs7QUFFVjs7QUFFQTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNkQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7O0FBRWpCO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ25DQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ1M7QUFDZ0U7O0FBRW5GO0FBQ1A7QUFDQTs7QUFFTztBQUNQLFFBQVEsZ0RBQUMseUJBQXlCLGtFQUFtQjtBQUNyRDs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLHVEQUFRO0FBQ3hDLFNBQVMsT0FBTztBQUNoQixnQkFBZ0IsZ0RBQUMsY0FBYywrREFBZ0I7QUFDL0M7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMLFlBQVksZ0RBQUM7QUFDYixZQUFZLDZEQUFjO0FBQzFCO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3hDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDRztBQUNhO0FBQzJGOztBQUVySDtBQUNQO0FBQ0E7QUFDQSxZQUFZLDJEQUFZO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMscURBQVE7QUFDN0MsaUJBQWlCO0FBQ2pCLHFDQUFxQyxxREFBUTtBQUM3QztBQUNBO0FBQ0Esb0JBQW9CLHFFQUFzQixDQUFDLCtEQUFnQjtBQUMzRCxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQSwyQkFBMkIsK0RBQWdCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwrREFBZ0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHdEQUFTO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLFlBQVksMkRBQVk7QUFDeEI7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDeERBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBeUQ7O0FBRXpEO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLElBQUksd0RBQU07QUFDVjtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDLEtBQUs7QUFDTDs7QUFFa0I7Ozs7Ozs7Ozs7Ozs7QUNmbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUztBQUNTO0FBQ1c7O0FBRTlDO0FBQ087QUFDUCxtRUFBbUUseURBQWU7QUFDbEY7O0FBRUE7QUFDQTtBQUNBLG1CQUFtQixxQkFBcUI7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1Qix1QkFBdUI7QUFDOUM7QUFDQTtBQUNBLGtCQUFrQixnREFBQyxnREFBZ0QsdURBQVE7QUFDM0U7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLHVCQUF1Qix1QkFBdUI7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2pEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUztBQUNhO0FBQ1U7QUFDTjtBQUMwRjs7QUFFOUg7QUFDUDtBQUNBLFFBQVEsMkRBQVMsTUFBTSxnREFBQztBQUN4QixZQUFZLGdEQUFDO0FBQ2IsZ0JBQWdCLGdEQUFDO0FBQ2pCLGdCQUFnQiwwREFBVztBQUMzQixhQUFhO0FBQ2IsZ0JBQWdCLGdFQUFpQjtBQUNqQztBQUNBO0FBQ0EsS0FBSztBQUNMLG9CQUFvQix1REFBUTtBQUM1QixRQUFRLHNEQUFxQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7O0FBRU87QUFDUDtBQUNBLFlBQVksMkRBQVM7QUFDckIsWUFBWSxnRUFBaUI7QUFDN0I7QUFDQSxTQUFTO0FBQ1QsWUFBWSw2REFBYztBQUMxQjtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBLGdCQUFnQix1REFBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7OztBQzdGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNTO0FBQ2E7QUFDb0o7O0FBRTNMOztBQUVBO0FBQ0E7QUFDQSx3QkFBd0IsK0RBQWdCO0FBQ3hDO0FBQ0EsbUJBQW1CLDhCQUE4QjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0EsWUFBWSwyREFBUztBQUNyQixZQUFZLGdFQUFpQjtBQUM3QixZQUFZLGdEQUFDO0FBQ2IsWUFBWSxnREFBQztBQUNiO0FBQ0EsU0FBUztBQUNUO0FBQ0EsMkJBQTJCLCtEQUFnQjtBQUMzQyw2QkFBNkIsMERBQVc7QUFDeEM7QUFDQSxnQkFBZ0IsZ0RBQUMsZ0JBQWdCLDREQUFhO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBLDZCQUE2QixnREFBQztBQUM5QixtQkFBbUIsb0JBQW9CO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixnREFBQztBQUN4QjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwyREFBWTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsWUFBWSxtRUFBb0I7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0EsNkJBQTZCLGdEQUFDO0FBQzlCLG1CQUFtQixvQkFBb0I7QUFDdkM7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLGdEQUFDO0FBQ3hCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwyREFBWTtBQUN4QixzQ0FBc0MsMERBQVcsQ0FBQywrREFBZ0I7QUFDbEU7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLHVEQUFRO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLGdCQUFnQix3REFBUyxZQUFZLCtEQUFnQjtBQUNyRCxhQUFhO0FBQ2IsZ0JBQWdCLHNEQUFPO0FBQ3ZCO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsWUFBWSxtRUFBb0I7QUFDaEMsOEJBQThCLHVEQUFRO0FBQ3RDLHNDQUFzQywwREFBVztBQUNqRDtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsWUFBWSx3REFBUztBQUNyQjtBQUNBO0FBQ0E7O0FBRU87QUFDUCxtQkFBbUIsMERBQVc7QUFDOUI7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFTztBQUNQLG1CQUFtQiwwREFBVztBQUM5QjtBQUNBOzs7Ozs7Ozs7Ozs7O0FDNUpBO0FBQUE7QUFBaUI7O0FBRWpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ2Usc0VBQU8sRUFBQzs7Ozs7Ozs7Ozs7OztBQ2R2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCOztBQUVqQjtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTzs7QUFFUDtBQUNPO0FBQ1A7QUFDQTs7Ozs7Ozs7Ozs7OztBQ25DQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjs7QUFFakI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOzs7Ozs7Ozs7Ozs7O0FDaEJBO0FBQUE7QUFBQTtBQUFBO0FBQWlCOztBQUVqQjtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRSxjQUFjO0FBQy9FO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLG1EQUFtRDtBQUNqRjtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN2Q0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNRO0FBQ3lCO0FBQ1M7QUFDaEI7QUFDeUU7QUFDNUM7QUFDbkI7QUFDZ0M7QUFDM0M7QUFDTDtBQUNHO0FBQ1c7O0FBRW5ELGdEQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhCQUE4QixpREFBZTtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxnREFBYztBQUN2QjtBQUNBLDREQUE0RCxnRUFBYztBQUMxRTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxhQUFhLGdEQUFjLDRCQUE0Qiw4REFBYztBQUNyRTtBQUNBO0FBQ0EsSUFBSSxnREFBQyx5QkFBeUIsZ0RBQWM7QUFDNUM7QUFDQSxJQUFJLGdEQUFDLGdCQUFnQixnREFBYztBQUNuQzs7QUFFQTtBQUNBO0FBQ0EsSUFBSSxnREFBZTtBQUNuQjtBQUNBO0FBQ0E7QUFDQSxJQUFJLDhEQUFjO0FBQ2xCO0FBQ0EsVUFBVSx1RUFBZTtBQUN6QjtBQUNBLFVBQVUsZ0VBQWdCO0FBQzFCO0FBQ0EsVUFBVSx3RUFBcUI7QUFDL0I7QUFDQSxJQUFJLDBFQUFVO0FBQ2Q7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7O0FBRUEsdUNBQXVDLDJFQUFpQjtBQUN4RCxxQ0FBcUMseUVBQWU7QUFDcEQsbUNBQW1DLHlFQUFlO0FBQ2xELHNDQUFzQyw0RUFBa0I7O0FBRXhEO0FBQ0E7QUFDQSxpQ0FBaUMseUVBQWlCO0FBQ2xEOztBQUVBO0FBQ0E7QUFDQSxlQUFlLHdCQUF3QjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMOztBQUVBO0FBQ0Esb0VBQW9FLHNFQUFZO0FBQ2hGLGlFQUFpRSxpRUFBZTs7QUFFaEY7QUFDQSwyQ0FBMkMsa0VBQVM7QUFDcEQsMENBQTBDLGtFQUFTO0FBQ25EOzs7Ozs7Ozs7Ozs7O0FDekdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNRO0FBQ1M7QUFDVTs7QUFFckM7QUFDUDtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsNEJBQTRCLGdEQUFDO0FBQzdCO0FBQ0E7QUFDQSwyQ0FBMkMsdURBQVEsYUFBYSx5QkFBeUIsaUJBQWlCLEVBQUU7QUFDNUc7QUFDQTtBQUNBLGlCQUFpQix5Q0FBeUMsdURBQVE7QUFDbEUsYUFBYTtBQUNiO0FBQ0E7QUFDQSxpQkFBaUIseUNBQXlDLHVEQUFRO0FBQ2xFLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxpQkFBaUI7QUFDdEQ7O0FBRU87QUFDUCxTQUFTLFlBQVk7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULDJCQUEyQix5QkFBeUI7QUFDcEQ7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0Esd0JBQXdCLGdFQUFlO0FBQ3ZDO0FBQ0E7QUFDQSxxREFBcUQsaUJBQWlCO0FBQ3RFLDZCQUE2QjtBQUM3Qix5QkFBeUI7QUFDekI7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7Ozs7Ozs7Ozs7OztBQy9FQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQytCOztBQUVoRDs7QUFFTztBQUNQLFdBQVcscUVBQWtCLHlCQUF5QjtBQUN0RDtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNPO0FBQ1A7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2RBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ1E7QUFDeUI7QUFDRDs7QUFFakQ7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsUUFBUSxxRUFBb0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYixvQkFBb0IsZ0RBQUM7QUFDckI7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUCw0QkFBNEIsdUVBQWU7QUFDM0M7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLFdBQVcsZ0RBQUM7QUFDWjs7QUFFQTtBQUNPO0FBQ1A7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLG1CQUFtQixvQkFBb0I7QUFDdkM7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLG1CQUFtQixvQkFBb0I7QUFDdkM7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQSxLQUFLO0FBQ0w7O0FBRU87QUFDUDtBQUNBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBLG1CQUFtQixpQkFBaUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSxRQUFRLGdEQUFDO0FBQ1QsUUFBUSxnREFBQztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLGNBQWMsZ0RBQUM7QUFDZixZQUFZLGdEQUFDO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnREFBQztBQUNMLElBQUksZ0RBQUM7QUFDTDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCxJQUFJLGdEQUFDO0FBQ0wsSUFBSSxnREFBQztBQUNMOzs7Ozs7Ozs7Ozs7O0FDbFBBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNRO0FBQ087QUFDa0I7QUFDSTtBQUNPO0FBQ2lHO0FBQy9COztBQUUvSDtBQUNPO0FBQ1AsSUFBSSxnREFBQztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLG9CQUFvQjtBQUN2QztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLG9GQUF1Qjs7QUFFOUQ7QUFDQTtBQUNBLDJDQUEyQyw2RUFBZ0I7O0FBRTNEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBLGtEQUFrRCxtRkFBc0I7QUFDeEUsaURBQWlELG9GQUF1QjtBQUN4RSw2Q0FBNkMsK0VBQWtCO0FBQy9EOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsdUJBQXVCLG1CQUFtQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLHFEQUFRO0FBQ2pELHFCQUFxQjtBQUNyQix5Q0FBeUMscURBQVE7QUFDakQ7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCOztBQUVBO0FBQ0E7QUFDQSxtREFBbUQsdUVBQWE7QUFDaEUsdURBQXVELHlEQUFlOztBQUV0RTtBQUNBO0FBQ0EsaURBQWlELHFFQUFXO0FBQzVELHFEQUFxRCx5REFBZTs7QUFFcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHFEQUFxRCx1RUFBZTtBQUNwRTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBLHVEQUF1RCwyRUFBaUI7QUFDeEUsd0RBQXdELDRFQUFrQjtBQUMxRSxtREFBbUQseUVBQWU7O0FBRWxFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksZ0RBQUM7QUFDTCxJQUFJLGdEQUFDLG9DQUFvQyx5REFBZTtBQUN4RDtBQUNBLHVDQUF1QyxxQkFBcUI7QUFDNUQ7O0FBRUE7QUFDTztBQUNQLHdCQUF3QiwyREFBVTtBQUNsQyxVQUFVLCtEQUFjO0FBQ3hCO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0EsMkJBQTJCLGlFQUFlO0FBQzFDO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3ZOQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjs7QUFFakI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLDBCQUEwQjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ087QUFDUDtBQUNBLHVCQUF1QixvQkFBb0I7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQLCtDQUErQyxFQUFFO0FBQ2pEO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wiLCJmaWxlIjoicG9wdXAvcG9wdXAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy9wb3B1cC9wb3B1cC5qc1wiKTtcbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCB7IFNXSVRDSF9PTiwgU1dJVENIX0xPQ0tFRF9PTiwgU1dJVENIX09GRiwgU1dJVENIX0xPQ0tFRF9PRkYgfSBmcm9tIFwiLi9vcHRpb25zL3N0YXRlc1wiXG5leHBvcnQgeyBTV0lUQ0hfT04sIFNXSVRDSF9MT0NLRURfT04sIFNXSVRDSF9PRkYsIFNXSVRDSF9MT0NLRURfT0ZGIH1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wdGlvbnMoKSB7XG4gICAgcmV0dXJuIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1wib3B0aW9uc1wiXSkudGhlbihkYXRhID0+IGRhdGEub3B0aW9ucyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRPcHRpb25zKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IG9wdGlvbnM6IG9wdGlvbnMgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdGJvb2woc3dpdGNoX3N0YXRlKSB7XG4gICAgc3dpdGNoIChzd2l0Y2hfc3RhdGUpIHtcbiAgICAgICAgY2FzZSBTV0lUQ0hfT046XG4gICAgICAgIGNhc2UgU1dJVENIX0xPQ0tFRF9PTjpcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICBjYXNlIFNXSVRDSF9PRkY6XG4gICAgICAgIGNhc2UgU1dJVENIX0xPQ0tFRF9PRkY6XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgVGFyZ2V0QnJvd3NlciB9IGZyb20gXCJQb2x5ZmlsbFwiXG5cbmV4cG9ydCBjb25zdCBTV0lUQ0hfT04gPSAxO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9MT0NLRURfT04gPSAyO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9PRkYgPSAwO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9MT0NLRURfT0ZGID0gLTE7XG5cbmV4cG9ydCBjb25zdCBJTklUSUFMX09QVElPTlMgPSB7XG4gICAgcG9wdXA6IHtcbiAgICAgICAgc2l6ZToge1xuICAgICAgICAgICAgd2lkdGg6IDczMCxcbiAgICAgICAgICAgIGhlaWdodDogNDUwXG4gICAgICAgIH0sXG4gICAgICAgIHNjYWxlOiAxLjAsXG4gICAgICAgIHNob3dEZXRhaWxzOiBTV0lUQ0hfT04sXG4gICAgICAgIHNob3dQcmV2aWV3OiBTV0lUQ0hfT04sXG4gICAgICAgIGhpZGVBZnRlclRhYlNlbGVjdGlvbjogU1dJVENIX09OLFxuICAgICAgICBzZWFyY2hJblVSTHM6IFNXSVRDSF9PRkZcbiAgICB9XG59O1xuaWYgKFRhcmdldEJyb3dzZXIgPT09IFwiY2hyb21lXCIpIHtcbiAgICBJTklUSUFMX09QVElPTlMucG9wdXAuc2hvd1ByZXZpZXcgPSBTV0lUQ0hfTE9DS0VEX09GRjtcbiAgICBJTklUSUFMX09QVElPTlMucG9wdXAuaGlkZUFmdGVyVGFiU2VsZWN0aW9uID0gU1dJVENIX0xPQ0tFRF9PTjtcbn1cbiIsImV4cG9ydCBjb25zdCBUYXJnZXRCcm93c2VyID0gVEFSR0VUO1xuXG5pZiAoVEFSR0VUID09PSBcImNocm9tZVwiKSB7XG4gICAgd2luZG93W1wiYnJvd3NlclwiXSA9IHJlcXVpcmUoXCJ3ZWJleHRlbnNpb24tcG9seWZpbGxcIik7XG59XG5cbmlmICghQXJyYXkuZnJvbSkge1xuICAgIEFycmF5LmZyb20gPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICBsZXQgdG9TdHIgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xuICAgICAgICBsZXQgaXNDYWxsYWJsZSA9IGZ1bmN0aW9uIChmbikge1xuICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiBmbiA9PT0gJ2Z1bmN0aW9uJyB8fCB0b1N0ci5jYWxsKGZuKSA9PT0gJ1tvYmplY3QgRnVuY3Rpb25dJztcbiAgICAgICAgfTtcbiAgICAgICAgbGV0IHRvSW50ZWdlciA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgbGV0IG51bWJlciA9IE51bWJlcih2YWx1ZSk7XG4gICAgICAgICAgICBpZiAoaXNOYU4obnVtYmVyKSkgeyByZXR1cm4gMDsgfVxuICAgICAgICAgICAgaWYgKG51bWJlciA9PT0gMCB8fCAhaXNGaW5pdGUobnVtYmVyKSkgeyByZXR1cm4gbnVtYmVyOyB9XG4gICAgICAgICAgICByZXR1cm4gKG51bWJlciA+IDAgPyAxIDogLTEpICogTWF0aC5mbG9vcihNYXRoLmFicyhudW1iZXIpKTtcbiAgICAgICAgfTtcbiAgICAgICAgbGV0IG1heFNhZmVJbnRlZ2VyID0gTWF0aC5wb3coMiwgNTMpIC0gMTtcbiAgICAgICAgbGV0IHRvTGVuZ3RoID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBsZXQgbGVuID0gdG9JbnRlZ2VyKHZhbHVlKTtcbiAgICAgICAgICAgIHJldHVybiBNYXRoLm1pbihNYXRoLm1heChsZW4sIDApLCBtYXhTYWZlSW50ZWdlcik7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gVGhlIGxlbmd0aCBwcm9wZXJ0eSBvZiB0aGUgZnJvbSBtZXRob2QgaXMgMS5cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGZyb20oYXJyYXlMaWtlLyosIG1hcEZuLCB0aGlzQXJnICovKSB7XG4gICAgICAgICAgICAvLyAxLiBMZXQgQyBiZSB0aGUgdGhpcyB2YWx1ZS5cbiAgICAgICAgICAgIGxldCBDID0gdGhpcztcblxuICAgICAgICAgICAgLy8gMi4gTGV0IGl0ZW1zIGJlIFRvT2JqZWN0KGFycmF5TGlrZSkuXG4gICAgICAgICAgICBsZXQgaXRlbXMgPSBPYmplY3QoYXJyYXlMaWtlKTtcblxuICAgICAgICAgICAgLy8gMy4gUmV0dXJuSWZBYnJ1cHQoaXRlbXMpLlxuICAgICAgICAgICAgaWYgKGFycmF5TGlrZSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJyYXkuZnJvbSByZXF1aXJlcyBhbiBhcnJheS1saWtlIG9iamVjdCAtIG5vdCBudWxsIG9yIHVuZGVmaW5lZCcpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyA0LiBJZiBtYXBmbiBpcyB1bmRlZmluZWQsIHRoZW4gbGV0IG1hcHBpbmcgYmUgZmFsc2UuXG4gICAgICAgICAgICBsZXQgbWFwRm4gPSBhcmd1bWVudHMubGVuZ3RoID4gMSA/IGFyZ3VtZW50c1sxXSA6IHZvaWQgdW5kZWZpbmVkO1xuICAgICAgICAgICAgbGV0IFQ7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1hcEZuICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIC8vIDUuIGVsc2VcbiAgICAgICAgICAgICAgICAvLyA1LiBhIElmIElzQ2FsbGFibGUobWFwZm4pIGlzIGZhbHNlLCB0aHJvdyBhIFR5cGVFcnJvciBleGNlcHRpb24uXG4gICAgICAgICAgICAgICAgaWYgKCFpc0NhbGxhYmxlKG1hcEZuKSkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcnJheS5mcm9tOiB3aGVuIHByb3ZpZGVkLCB0aGUgc2Vjb25kIGFyZ3VtZW50IG11c3QgYmUgYSBmdW5jdGlvbicpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIDUuIGIuIElmIHRoaXNBcmcgd2FzIHN1cHBsaWVkLCBsZXQgVCBiZSB0aGlzQXJnOyBlbHNlIGxldCBUIGJlIHVuZGVmaW5lZC5cbiAgICAgICAgICAgICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgVCA9IGFyZ3VtZW50c1syXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIDEwLiBMZXQgbGVuVmFsdWUgYmUgR2V0KGl0ZW1zLCBcImxlbmd0aFwiKS5cbiAgICAgICAgICAgIC8vIDExLiBMZXQgbGVuIGJlIFRvTGVuZ3RoKGxlblZhbHVlKS5cbiAgICAgICAgICAgIGxldCBsZW4gPSB0b0xlbmd0aChpdGVtcy5sZW5ndGgpO1xuXG4gICAgICAgICAgICAvLyAxMy4gSWYgSXNDb25zdHJ1Y3RvcihDKSBpcyB0cnVlLCB0aGVuXG4gICAgICAgICAgICAvLyAxMy4gYS4gTGV0IEEgYmUgdGhlIHJlc3VsdCBvZiBjYWxsaW5nIHRoZSBbW0NvbnN0cnVjdF1dIGludGVybmFsIG1ldGhvZCBcbiAgICAgICAgICAgIC8vIG9mIEMgd2l0aCBhbiBhcmd1bWVudCBsaXN0IGNvbnRhaW5pbmcgdGhlIHNpbmdsZSBpdGVtIGxlbi5cbiAgICAgICAgICAgIC8vIDE0LiBhLiBFbHNlLCBMZXQgQSBiZSBBcnJheUNyZWF0ZShsZW4pLlxuICAgICAgICAgICAgbGV0IEEgPSBpc0NhbGxhYmxlKEMpID8gT2JqZWN0KG5ldyBDKGxlbikpIDogbmV3IEFycmF5KGxlbik7XG5cbiAgICAgICAgICAgIC8vIDE2LiBMZXQgayBiZSAwLlxuICAgICAgICAgICAgbGV0IGsgPSAwO1xuICAgICAgICAgICAgLy8gMTcuIFJlcGVhdCwgd2hpbGUgayA8IGxlbuKApiAoYWxzbyBzdGVwcyBhIC0gaClcbiAgICAgICAgICAgIGxldCBrVmFsdWU7XG4gICAgICAgICAgICB3aGlsZSAoayA8IGxlbikge1xuICAgICAgICAgICAgICAgIGtWYWx1ZSA9IGl0ZW1zW2tdO1xuICAgICAgICAgICAgICAgIGlmIChtYXBGbikge1xuICAgICAgICAgICAgICAgICAgICBBW2tdID0gdHlwZW9mIFQgPT09ICd1bmRlZmluZWQnID8gbWFwRm4oa1ZhbHVlLCBrKSA6IG1hcEZuLmNhbGwoVCwga1ZhbHVlLCBrKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBBW2tdID0ga1ZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBrICs9IDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyAxOC4gTGV0IHB1dFN0YXR1cyBiZSBQdXQoQSwgXCJsZW5ndGhcIiwgbGVuLCB0cnVlKS5cbiAgICAgICAgICAgIEEubGVuZ3RoID0gbGVuO1xuICAgICAgICAgICAgLy8gMjAuIFJldHVybiBBLlxuICAgICAgICAgICAgcmV0dXJuIEE7XG4gICAgICAgIH07XG4gICAgfSgpKTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuZXhwb3J0IGxldCBhdmFpbGFibGUgPSBmYWxzZTtcblxuZXhwb3J0IGZ1bmN0aW9uIGluaXQoKSB7XG4gICAgaWYgKHdpbmRvd1tcImJyb3dzZXJcIl0gIT09IHVuZGVmaW5lZFxuICAgICAgICAmJiBicm93c2VyLnRhYnNbXCJjYXB0dXJlVGFiXCJdICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgYXZhaWxhYmxlID0gdHJ1ZTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNhcHR1cmVUYWIoaWQpIHtcbiAgICByZXR1cm4gYXZhaWxhYmxlID8gYnJvd3Nlci50YWJzLmNhcHR1cmVUYWIoaWQpIDogbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4gcmVzb2x2ZShudWxsKSk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbi8vIFN0b3AgcHJvcGFnYXRpb24gZXZlbnQgbGlzdGVuZXJcbmV4cG9ydCBmdW5jdGlvbiBzdG9wUHJvcGFnYXRpb24oZSkge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG59XG5cbi8vIFRvZ2dsZSBhIGNsYXNzIG9mIGFuIGVsZW1lbnRcbmV4cG9ydCBmdW5jdGlvbiB0b2dnbGVDbGFzcyhlbGVtZW50LCBjKSB7XG4gICAgaWYgKGVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKGMpKSB7XG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShjKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoYyk7XG4gICAgfVxufVxuXG4vLyBHZXQgYWN0dWFsIGhlaWdodCBvZiBhbiBlbGVtZW50XG5leHBvcnQgZnVuY3Rpb24gZ2V0QWN0dWFsSGVpZ2h0KGVsZW1lbnQpIHtcbiAgICBsZXQgc3R5bGVzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gICAgbGV0IG1hcmdpbiA9IHBhcnNlRmxvYXQoc3R5bGVzWydtYXJnaW5Ub3AnXSkgK1xuICAgICAgICAgICAgICAgcGFyc2VGbG9hdChzdHlsZXNbJ21hcmdpbkJvdHRvbSddKTtcbiAgICByZXR1cm4gZWxlbWVudC5vZmZzZXRIZWlnaHQgKyBtYXJnaW47XG59XG5cbi8vIEdldCBhY3R1YWwgd2lkdGggb2YgYW4gZWxlbWVudFxuZXhwb3J0IGZ1bmN0aW9uIGdldEFjdHVhbFdpZHRoKGVsZW1lbnQpIHtcbiAgICBsZXQgc3R5bGVzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gICAgbGV0IG1hcmdpbiA9IHBhcnNlRmxvYXQoc3R5bGVzWydtYXJnaW5MZWZ0J10pICtcbiAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoc3R5bGVzWydtYXJnaW5SaWdodCddKTtcbiAgICByZXR1cm4gZWxlbWVudC5vZmZzZXRXaWR0aCArIG1hcmdpbjtcbn1cblxuLy8gZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lXG5FbGVtZW50LnByb3RvdHlwZS5nZXRFbGVtZW50QnlDbGFzc05hbWUgPSBmdW5jdGlvbiAoY2xhc3NOYW1lcykge1xuICAgIHJldHVybiB0aGlzLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoY2xhc3NOYW1lcylbMF0gfHwgbnVsbDtcbn07XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyByZXNldFNsaWRlU2VsZWN0aW9uLCBtdWx0aVNlbGVjdFJlc2V0LCBnZXRUYWJJZCwgc2VsZWN0VGFiRW50cnkgfSBmcm9tIFwiLi4vd3Rkb21cIlxuXG5leHBvcnQgZnVuY3Rpb24gZG9jdW1lbnRNb3VzZU92ZXIoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRvY3VtZW50TW91c2VVcChlKSB7XG4gICAgaWYgKEcuc2xpZGVTZWxlY3Rpb24uc2xpZGluZykgcmVzZXRTbGlkZVNlbGVjdGlvbigpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZG9jdW1lbnRDbGlja2VkKGUpIHtcbiAgICBpZiAoZS5idXR0b24gPT09IDApIHtcbiAgICAgICAgaWYgKGUudGFyZ2V0LmlkID09PSBcImRldGFpbHMtY2xvc2VcIikge1xuICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXBsYWNlaG9sZGVyXCIpLnN0eWxlLmRpc3BsYXkgPSBcImlubGluZS1ibG9ja1wiO1xuICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0YWItZGV0YWlsc1wiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgICAgICBicm93c2VyLnRhYnMucmVtb3ZlKGdldFRhYklkKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFiLWRldGFpbHNcIikpKTtcbiAgICAgICAgfSBlbHNlIHsgLy8gTm90ZTogTWF5IGNhdXNlIHNvbWUgcHJvYmxlbXNcbiAgICAgICAgICAgIGlmIChHLmlzU2VsZWN0aW5nKSBtdWx0aVNlbGVjdFJlc2V0KCk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmZ1bmN0aW9uIGlzSW5saW5lUHJpbnRhYmxlS2V5KGUpIHtcbiAgICBpZiAodHlwZW9mIGUud2hpY2ggPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZS53aGljaCA9PT0gXCJudW1iZXJcIiAmJiBlLndoaWNoID4gMCkge1xuICAgICAgICByZXR1cm4gIWUuY3RybEtleSAmJiAhZS5tZXRhS2V5ICYmICFlLmFsdEtleSAmJiBlLndoaWNoICE9PSA4ICYmIGUud2hpY2ggIT09IDEzO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRvY3VtZW50S2V5UHJlc3NlZChlKSB7XG4gICAgaWYgKGlzSW5saW5lUHJpbnRhYmxlS2V5KGUpKSB7XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2VhcmNoXCIpLmZvY3VzKCk7XG4gICAgfSBlbHNlIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XG4gICAgICAgIGlmIChHLnNlbGVjdGVkVGFicyA9PT0gMSkge1xuICAgICAgICAgICAgc2VsZWN0VGFiRW50cnkoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcIm11bHRpc2VsZWN0XCIpWzBdKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCBcIi4uL2RvbXV0aWxzXCJcbmltcG9ydCB7IGdldEltYWdlIH0gZnJvbSBcIi4uL25ldFwiXG5pbXBvcnQgeyBmaW5kVGFiRW50cnlCeUlkLCBnZXRGYXZJY29uRnJvbVRhYkVudHJ5LCBzZXRBY3RpdmVUYWIsIHJlbW92ZVRhYiwgcmVtb3ZlV2luZG93LCBnZXRXaW5kb3dGcm9tVGFiIH0gZnJvbSBcIi4uL3d0ZG9tXCJcblxuZXhwb3J0IGZ1bmN0aW9uIG9uTWVzc2FnZShyZXF1ZXN0LCBzZW5kZXIpIHtcbiAgICBzd2l0Y2ggKHJlcXVlc3QudHlwZSkge1xuICAgICAgICBjYXNlIFwiQUNUSVZFX1RBQl9DSEFOR0VEXCI6XG4gICAgICAgICAgICBzZXRBY3RpdmVUYWIocmVxdWVzdC5kZXRhaWxzLndpbmRvd0lkLCByZXF1ZXN0LmRldGFpbHMudGFiSWQpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJUQUJfRkFWX0lDT05fQ0hBTkdFRFwiOlxuICAgICAgICAgICAgYnJvd3Nlci50YWJzLmdldChyZXF1ZXN0LmRldGFpbHMudGFiSWQpLnRoZW4odGFiID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgZmF2SWNvblByb21pc2U7XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5pbmNvZ25pdG8pIHtcbiAgICAgICAgICAgICAgICAgICAgZmF2SWNvblByb21pc2UgPSBnZXRJbWFnZShyZXF1ZXN0LmRldGFpbHMuZmF2SWNvblVybCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZmF2SWNvblByb21pc2UgPSBnZXRJbWFnZShyZXF1ZXN0LmRldGFpbHMuZmF2SWNvblVybCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZhdkljb25Qcm9taXNlLnRoZW4oZnVuY3Rpb24gKGJhc2U2NEltYWdlKXtcbiAgICAgICAgICAgICAgICAgICAgZ2V0RmF2SWNvbkZyb21UYWJFbnRyeShmaW5kVGFiRW50cnlCeUlkKHJlcXVlc3QuZGV0YWlscy50YWJJZCkpLnNyYyA9IGJhc2U2NEltYWdlO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcIlRBQl9QSU5ORURfU1RBVFVTX0NIQU5HRURcIjpcbiAgICAgICAgICAgIGxldCB0YWJFbnRyeSA9IGZpbmRUYWJFbnRyeUJ5SWQocmVxdWVzdC5kZXRhaWxzLnRhYklkKTtcbiAgICAgICAgICAgIGxldCBwaW5CdG4gPSB0YWJFbnRyeS5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ0YWItZW50cnktcGluLWJ0blwiKTtcbiAgICAgICAgICAgIGxldCB3aW5kb3dFbnRyeUxpc3QgPSB0YWJFbnRyeS5wYXJlbnRFbGVtZW50O1xuICAgICAgICAgICAgbGV0IHBpbm5lZFRhYnM7XG4gICAgICAgICAgICBpZiAocmVxdWVzdC5kZXRhaWxzLnBpbm5lZCkge1xuICAgICAgICAgICAgICAgIHBpbm5lZFRhYnMgPSBBcnJheS5mcm9tKHdpbmRvd0VudHJ5TGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwicGlubmVkLXRhYlwiKSk7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LmFkZChcInBpbm5lZC10YWJcIik7XG4gICAgICAgICAgICAgICAgcGluQnRuLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IFwidXJsKC4uL2ljb25zL3BpbnJlbW92ZS5zdmcpXCI7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHBpbm5lZFRhYnMgPSBBcnJheS5mcm9tKHdpbmRvd0VudHJ5TGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwicGlubmVkLXRhYlwiKSk7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LnJlbW92ZShcInBpbm5lZC10YWJcIik7XG4gICAgICAgICAgICAgICAgcGluQnRuLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IFwidXJsKC4uL2ljb25zL3Bpbi5zdmcpXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgbGFzdFBpbm5lZFRhYiA9IHBpbm5lZFRhYnNbcGlubmVkVGFicy5sZW5ndGgtMV07XG4gICAgICAgICAgICBpZiAobGFzdFBpbm5lZFRhYiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgd2luZG93RW50cnlMaXN0Lmluc2VydEJlZm9yZSh0YWJFbnRyeSwgbGFzdFBpbm5lZFRhYi5uZXh0U2libGluZyk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHdpbmRvd0VudHJ5TGlzdC5pbnNlcnRCZWZvcmUodGFiRW50cnksIHdpbmRvd0VudHJ5TGlzdC5jaGlsZE5vZGVzWzBdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiVEFCX1RJVExFX0NIQU5HRURcIjpcbiAgICAgICAgICAgIGZpbmRUYWJFbnRyeUJ5SWQocmVxdWVzdC5kZXRhaWxzLnRhYklkKS5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ0YWItdGl0bGVcIikudGV4dENvbnRlbnQgPSByZXF1ZXN0LmRldGFpbHMudGl0bGU7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcIlRBQl9SRU1PVkVEXCI6XG4gICAgICAgICAgICBpZiAoIXJlcXVlc3QuZGV0YWlscy53aW5kb3dDbG9zaW5nKSB7XG4gICAgICAgICAgICAgICAgcmVtb3ZlVGFiKHJlcXVlc3QuZGV0YWlscy50YWJJZCwgcmVxdWVzdC5kZXRhaWxzLndpbmRvd0lkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiV0lORE9XX1JFTU9WRURcIjpcbiAgICAgICAgICAgIHJlbW92ZVdpbmRvdyhyZXF1ZXN0LmRldGFpbHMud2luZG93SWQpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgbGFzdFJlY29yZCwgcmVjb3JkLCByZXN0b3JlIH0gZnJvbSBcIi4uL3JlY29yZGVyXCJcclxuXHJcbmxldCBzYXZlRm9yTGF0ZXJCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNhdmUtZm9yLWxhdGVyXCIpO1xyXG5sZXQgc2ZsVGltZW91dCA9ICgpID0+IHtcclxuICAgIHNhdmVGb3JMYXRlckJ0bi5yZW1vdmVBdHRyaWJ1dGUoXCJkb25lXCIpO1xyXG59O1xyXG5leHBvcnQgZnVuY3Rpb24gc2F2ZUZvckxhdGVyKCkge1xyXG4gICAgc2F2ZUZvckxhdGVyQnRuLnNldEF0dHJpYnV0ZShcImRpc2FibGVkXCIsIFwiXCIpO1xyXG4gICAgcmVjb3JkKCkudGhlbigoKSA9PiB7XHJcbiAgICAgICAgc2F2ZUZvckxhdGVyQnRuLnJlbW92ZUF0dHJpYnV0ZShcImRpc2FibGVkXCIpO1xyXG4gICAgICAgIHNhdmVGb3JMYXRlckJ0bi5zZXRBdHRyaWJ1dGUoXCJkb25lXCIsIFwiXCIpO1xyXG4gICAgICAgIGNsZWFyVGltZW91dChzZmxUaW1lb3V0KTsgc2V0VGltZW91dChzZmxUaW1lb3V0LCAyMDAwKTtcclxuICAgIH0pO1xyXG59XHJcblxyXG5leHBvcnQgeyByZXN0b3JlIH1cclxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IEcgZnJvbSBcIi4uL2dsb2JhbHNcIlxuaW1wb3J0IHsgZ2V0VGFiSWQgfSBmcm9tIFwiLi4vd3Rkb21cIlxuaW1wb3J0IHsgc3RvcFByb3BhZ2F0aW9uIH0gZnJvbSBcIi4uL2RvbXV0aWxzXCI7XG5cbi8vIEluaXRcbmV4cG9ydCBmdW5jdGlvbiBpbml0U2VhcmNoKCkge1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2VhcmNoXCIpLmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlwcmVzc1wiLCBzdG9wUHJvcGFnYXRpb24pO1xufVxuXG5mdW5jdGlvbiBrZXl3b3JkU2VhcmNoKHMsIGtleSkge1xuICAgIGxldCBrZXl3b3JkcyA9IGtleS50cmltKCkuc3BsaXQoXCIgXCIpLCBjb3VudCA9IDA7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBrZXl3b3Jkcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZXQgd29yZCA9IGtleXdvcmRzW2ldO1xuICAgICAgICBpZiAod29yZC50cmltKCkgIT09IFwiXCIgJiYgd29yZC5tYXRjaCgvXlthLXpBLVowLTldKyQvKSkge1xuICAgICAgICAgICAgaWYgKHMudG9VcHBlckNhc2UoKS5pbmNsdWRlcyh3b3JkLnRvVXBwZXJDYXNlKCkpKSB7XG4gICAgICAgICAgICAgICAgY291bnQrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gY291bnQgPj0gMjtcbn1cblxuZnVuY3Rpb24gc2VhcmNoKHMsIGtleSkge1xuICAgIHJldHVybiBzLnRvVXBwZXJDYXNlKCkuaW5jbHVkZXMoa2V5LnRvVXBwZXJDYXNlKCkpIHx8IGtleXdvcmRTZWFyY2gocywga2V5KTtcbn1cblxuLy8gU2VhcmNoXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VhcmNoVGV4dENoYW5nZWQoZSkge1xuICAgIGxldCBpbnB1dCwgZmlsdGVyLCB0YWJFbnRyaWVzO1xuICAgIGlucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJzZWFyY2hcIik7XG4gICAgZmlsdGVyID0gaW5wdXQudmFsdWU7XG4gICAgdGFiRW50cmllcyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ0YWItZW50cnlcIik7XG4gICAgaWYgKGZpbHRlciAhPT0gXCJcIikge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhYkVudHJpZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxldCB0YWJFbnRyeSA9IHRhYkVudHJpZXNbaV07XG4gICAgICAgICAgICBpZiAoIXNlYXJjaCh0YWJFbnRyeS5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ0YWItdGl0bGVcIikuaW5uZXJUZXh0LCBmaWx0ZXIpICYmXG4gICAgICAgICAgICAgICAgIShHLnNlYXJjaEluVVJMcyAmJiBzZWFyY2goKGF3YWl0IGJyb3dzZXIudGFicy5nZXQoZ2V0VGFiSWQodGFiRW50cnkpKSkudXJsLCBmaWx0ZXIpKSkge1xuICAgICAgICAgICAgICAgIHRhYkVudHJ5LnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuc3R5bGUuZGlzcGxheSA9IFwiZmxleFwiO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0YWJFbnRyaWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgdGFiRW50cnkgPSB0YWJFbnRyaWVzW2ldO1xuICAgICAgICAgICAgdGFiRW50cnkuc3R5bGUuZGlzcGxheSA9IFwiZmxleFwiO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IEcgZnJvbSBcIi4uL2dsb2JhbHNcIlxuaW1wb3J0IHsgY3RybE9yQ21kIH0gZnJvbSBcIi4uL2tleXV0aWxzXCJcbmltcG9ydCB7IGdldExhc3RGb2N1c2VkV2luZG93IH0gZnJvbSBcIi4uL3d0dXRpbHNcIlxuaW1wb3J0ICogYXMgY2FwdHVyZVRhYiBmcm9tIFwiLi4vY2FwdHVyZVRhYlwiXG5pbXBvcnQgeyBnZXRXaW5kb3dGcm9tVGFiLCBtdWx0aVNlbGVjdCwgbXVsdGlTZWxlY3RUb2dnbGUsIGdldFRhYklkLCBnZXRXaW5kb3dJZCwgbXVsdGlTZWxlY3RDYW5jZWwsIHNlbGVjdFRhYkVudHJ5IH0gZnJvbSBcIi4uL3d0ZG9tXCJcblxuZXhwb3J0IGZ1bmN0aW9uIHRhYkVudHJ5TW91c2VPdmVyKGUpIHtcbiAgICBlLnRhcmdldC5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ0YWItZW50cnktcGluLWJ0blwiKS5zdHlsZS5kaXNwbGF5ID0gXCJpbmxpbmUtYmxvY2tcIjtcbiAgICBpZiAoY3RybE9yQ21kKCkgJiYgRy5zbGlkZVNlbGVjdGlvbi5zbGlkaW5nKSB7XG4gICAgICAgIGlmIChHLnNsaWRlU2VsZWN0aW9uLmluaXRpYXRvciAhPT0gZS50YXJnZXQpIHtcbiAgICAgICAgICAgIGlmIChHLnNsaWRlU2VsZWN0aW9uLmluaXRpYXRvci5jbGFzc0xpc3QuY29udGFpbnMoXCJtdWx0aXNlbGVjdFwiKSkge1xuICAgICAgICAgICAgICAgIG11bHRpU2VsZWN0KGUudGFyZ2V0KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbXVsdGlTZWxlY3RDYW5jZWwoZS50YXJnZXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgbGV0IHRhYklkID0gZ2V0VGFiSWQoZS50YXJnZXQpO1xuICAgICAgICBjYXB0dXJlVGFiLmNhcHR1cmVUYWIodGFiSWQpLnRoZW4oZGF0YVVyaSA9PiB7XG4gICAgICAgICAgICBpZiAoZGF0YVVyaSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIGxldCBkZXRhaWxzSW1hZ2UgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtaW1nXCIpO1xuICAgICAgICAgICAgICAgIGRldGFpbHNJbWFnZS5zcmMgPSBkYXRhVXJpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGV0IGRldGFpbHNUaXRsZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGV0YWlscy10aXRsZVwiKTtcbiAgICAgICAgICAgIGxldCBkZXRhaWxzVVJMID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXVybFwiKTtcbiAgICAgICAgICAgIGJyb3dzZXIudGFicy5nZXQodGFiSWQpLnRoZW4odGFiID0+IHtcbiAgICAgICAgICAgICAgICBkZXRhaWxzVGl0bGUudGV4dENvbnRlbnQgPSB0YWIudGl0bGU7XG4gICAgICAgICAgICAgICAgZGV0YWlsc1VSTC50ZXh0Q29udGVudCA9IHRhYi51cmw7XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXBsYWNlaG9sZGVyXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYi1kZXRhaWxzXCIpLnN0eWxlLmRpc3BsYXkgPSBcImlubGluZS1ibG9ja1wiO1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFiLWRldGFpbHNcIikuc2V0QXR0cmlidXRlKFwiZGF0YS10YWJfaWRcIiwgdGFiSWQpO1xuICAgICAgICAgICAgICAgIGlmICh0YWIucGlubmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGV0YWlscy1waW5uZWRcIikuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lXCI7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXBpbm5lZFwiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICh0YWIuaGlkZGVuKSB7XG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGV0YWlscy1oaWRkZW5cIikuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lXCI7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLWhpZGRlblwiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICh0YWIucGlubmVkICYmIHRhYi5oaWRkZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLWNvbW1hXCIpLnN0eWxlLmRpc3BsYXkgPSBcImlubGluZVwiO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGV0YWlscy1jb21tYVwiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0YWJFbnRyeU1vdXNlTGVhdmUoZSkge1xuICAgIGUudGFyZ2V0LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi1lbnRyeS1waW4tYnRuXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRhYkVudHJ5Q2xpY2tlZChlKSB7XG4gICAgaWYgKGUuYnV0dG9uID09PSAwKSB7XG4gICAgICAgIGlmIChjdHJsT3JDbWQoKSkge1xuICAgICAgICAgICAgbXVsdGlTZWxlY3RUb2dnbGUoZS50YXJnZXQpO1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNlbGVjdFRhYkVudHJ5KGUudGFyZ2V0KTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRhYkNsb3NlQ2xpY2soZSkge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgbGV0IHRhYklkID0gZS50YXJnZXQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LmdldEF0dHJpYnV0ZShcImRhdGEtdGFiX2lkXCIpO1xuICAgIGxldCB0YWJEZXRhaWxzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0YWItZGV0YWlsc1wiKTtcbiAgICBpZiAodGFiRGV0YWlscy5nZXRBdHRyaWJ1dGUoXCJkYXRhLXRhYl9pZFwiKSA9PT0gdGFiSWQpIHtcbiAgICAgICAgdGFiRGV0YWlscy5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGV0YWlscy1wbGFjZWhvbGRlclwiKS5zdHlsZS5kaXNwbGF5ID0gXCJpbmxpbmUtYmxvY2tcIjtcbiAgICB9XG4gICAgYnJvd3Nlci50YWJzLnJlbW92ZShwYXJzZUludCh0YWJJZCkpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdGFiUGluQ2xpY2soZSkge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgbGV0IHRhYklkID0gZ2V0VGFiSWQoZS50YXJnZXQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50KTtcbiAgICBicm93c2VyLnRhYnMuZ2V0KHRhYklkKS50aGVuKHRhYiA9PiB7XG4gICAgICAgIGlmICh0YWIucGlubmVkKSB7XG4gICAgICAgICAgICBicm93c2VyLnRhYnMudXBkYXRlKHRhYi5pZCwge1xuICAgICAgICAgICAgICAgIHBpbm5lZDogZmFsc2VcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWIuaWQsIHtcbiAgICAgICAgICAgICAgICBwaW5uZWQ6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBjdHJsT3JDbWQgfSBmcm9tIFwiLi4va2V5dXRpbHNcIlxuaW1wb3J0IHsgbW92ZVRhYiwgYXR0YWNoVGFiLCBnZXRXaW5kb3dGcm9tVGFiLCB0YWJEcmFnZ2FibGUsIG11bHRpU2VsZWN0LCBnZXRTZWxlY3RlZEl0ZW1zLCBtdWx0aVNlbGVjdGVkLCB0YWJEcmFnZ2FibGVUb1dpbmRvdywgZ2V0VGFiSWQsIGdldFdpbmRvd0lkLCBtdWx0aVNlbGVjdFRvZ2dsZSB9IGZyb20gXCIuLi93dGRvbVwiXG5cbmxldCBtdWx0aURyYWdnaW5nID0gZmFsc2UsIHNvdXJjZVRhYiwgdGFyZ2V0VGFiLCB1bmRlciwgc291cmNlV2luZG93LCBzb3VyY2VXaW5kb3dJZDtcblxuZnVuY3Rpb24gZ2V0TXVsdGlEcmFnSW1hZ2UodGFyZ2V0LCBjbGllbnRYLCBjbGllbnRZKSB7XG4gICAgbGV0IGRyYWdJbWFnZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiksIHgsIHk7XG4gICAgbGV0IHNlbGVjdGVkSXRlbXMgPSBnZXRTZWxlY3RlZEl0ZW1zKCk7XG4gICAgaWYgKHNlbGVjdGVkSXRlbXMubGVuZ3RoID09PSAxKSByZXR1cm4gc2VsZWN0ZWRJdGVtc1tpXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlbGVjdGVkSXRlbXMubGVuZ3RoIC0gMTsgaSsrKSB7XG4gICAgICAgIGxldCByZWYxID0gc2VsZWN0ZWRJdGVtc1tpXSwgcmVmMiA9IHNlbGVjdGVkSXRlbXNbaSsxXTtcbiAgICAgICAgbGV0IHJlZjFiciA9IHJlZjEuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksIHJlZjJiciA9IHJlZjIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIGxldCBkaXN0YW5jZSA9IHJlZjJici50b3AgLSAocmVmMWJyLnRvcCArIHJlZjFici5oZWlnaHQpO1xuICAgICAgICBsZXQgcmVmMUNsb25lID0gcmVmMS5jbG9uZU5vZGUodHJ1ZSk7XG4gICAgICAgIHJlZjFDbG9uZS5zdHlsZS5tYXJnaW5Cb3R0b20gPSBkaXN0YW5jZSArIFwicHhcIjtcbiAgICAgICAgZHJhZ0ltYWdlLmFwcGVuZENoaWxkKHJlZjFDbG9uZSk7XG4gICAgfSBkcmFnSW1hZ2UuYXBwZW5kQ2hpbGQoc2VsZWN0ZWRJdGVtc1tzZWxlY3RlZEl0ZW1zLmxlbmd0aCAtIDFdLmNsb25lTm9kZSh0cnVlKSk7XG4gICAgZHJhZ0ltYWdlLnN0eWxlLndpZHRoID0gc2VsZWN0ZWRJdGVtc1swXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCArIFwicHhcIjtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGRyYWdJbWFnZSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaW1hZ2U6IGRyYWdJbWFnZSxcbiAgICAgICAgeDogMCxcbiAgICAgICAgeTogMFxuICAgIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dFbnRyeURyYWdTdGFydGVkKGUpIHtcbiAgICBpZiAoZS50YXJnZXQuY2xhc3NMaXN0LmNvbnRhaW5zKFwidGFiLWVudHJ5XCIpKSB7XG4gICAgICAgIGlmIChjdHJsT3JDbWQoKSkge1xuICAgICAgICAgICAgbXVsdGlTZWxlY3RUb2dnbGUoZS50YXJnZXQpO1xuICAgICAgICAgICAgRy5zbGlkZVNlbGVjdGlvbi5zbGlkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgIEcuc2xpZGVTZWxlY3Rpb24uaW5pdGlhdG9yID0gZS50YXJnZXQ7XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzb3VyY2VUYWIgPSBlLnRhcmdldDtcbiAgICAgICAgICAgIHNvdXJjZVdpbmRvdyA9IGdldFdpbmRvd0Zyb21UYWIoc291cmNlVGFiKTtcbiAgICAgICAgICAgIHNvdXJjZVdpbmRvd0lkID0gZ2V0V2luZG93SWQoc291cmNlV2luZG93KTtcbiAgICAgICAgICAgIGUuZGF0YVRyYW5zZmVyLmVmZmVjdEFsbG93ZWQgPSBcIm1vdmVcIjtcbiAgICAgICAgICAgIGlmIChHLmlzU2VsZWN0aW5nICYmIG11bHRpU2VsZWN0ZWQoZS50YXJnZXQpKSB7XG4gICAgICAgICAgICAgICAgbXVsdGlEcmFnZ2luZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgbGV0IGRyYWdJbWFnZSA9IGdldE11bHRpRHJhZ0ltYWdlKCk7XG4gICAgICAgICAgICAgICAgZS5kYXRhVHJhbnNmZXIuc2V0RHJhZ0ltYWdlKGRyYWdJbWFnZS5pbWFnZSwgZHJhZ0ltYWdlLngsIGRyYWdJbWFnZS55KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlLmRhdGFUcmFuc2Zlci5zZXREYXRhKCd0ZXh0L3BsYWluJywgbnVsbCk7XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gd2luZG93RW50cnlEcmFnZ2luZ092ZXIoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBsZXQgY3Vyc29ycyA9IEFycmF5LmZyb20oRy50YWJzTGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiaW5zZXJ0LWN1cnNvclwiKSk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjdXJzb3JzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGxldCBjID0gY3Vyc29yc1tpXTtcbiAgICAgICAgYy5wYXJlbnRFbGVtZW50LnJlbW92ZUNoaWxkKGMpO1xuICAgIH1cbiAgICBsZXQgY3Vyc29yV2luZG93ID0gRy50YWJzTGlzdC5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJpbnNlcnQtY3Vyc29yLXdpbmRvd1wiKTtcbiAgICBpZiAoY3Vyc29yV2luZG93ICE9PSBudWxsKSB7XG4gICAgICAgIGN1cnNvcldpbmRvdy5jbGFzc0xpc3QucmVtb3ZlKFwiaW5zZXJ0LWN1cnNvci13aW5kb3dcIik7XG4gICAgfVxuXG4gICAgbGV0IHdpbmRvd0VudHJ5O1xuICAgIGlmIChlLnRhcmdldC5jbGFzc0xpc3QuY29udGFpbnMoXCJ0YWItZW50cnlcIikpIHtcbiAgICAgICAgbGV0IHRhYkVudHJ5Qm91bmRpbmdDbGllbnRSZWN0ID0gZS50YXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIHRhcmdldFRhYiA9IGUudGFyZ2V0O1xuICAgICAgICB1bmRlciA9IGZhbHNlO1xuICAgICAgICBpZiAoKGUuY2xpZW50WSAtIHRhYkVudHJ5Qm91bmRpbmdDbGllbnRSZWN0LnRvcCkgPj0gdGFiRW50cnlCb3VuZGluZ0NsaWVudFJlY3QuaGVpZ2h0IC8gMikge1xuICAgICAgICAgICAgdGFyZ2V0VGFiID0gdGFyZ2V0VGFiLm5leHRTaWJsaW5nO1xuICAgICAgICAgICAgaWYgKHRhcmdldFRhYiA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHVuZGVyID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0YXJnZXRUYWIgPSBlLnRhcmdldDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodGFiRHJhZ2dhYmxlKHNvdXJjZVRhYiwgdGFyZ2V0VGFiLCB1bmRlciwgc291cmNlV2luZG93LCBtdWx0aURyYWdnaW5nKSkge1xuICAgICAgICAgICAgbGV0IGN1cnNvciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgICAgICBjdXJzb3IuY2xhc3NMaXN0LmFkZChcImluc2VydC1jdXJzb3JcIik7XG4gICAgICAgICAgICBpZiAodW5kZXIpIHtcbiAgICAgICAgICAgICAgICB0YXJnZXRUYWIucGFyZW50RWxlbWVudC5hcHBlbmRDaGlsZChjdXJzb3IpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0YXJnZXRUYWIucGFyZW50RWxlbWVudC5pbnNlcnRCZWZvcmUoY3Vyc29yLCB0YXJnZXRUYWIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSBlbHNlIGlmICgod2luZG93RW50cnkgPSBlLnRhcmdldC5wYXJlbnRFbGVtZW50KSAhPT0gbnVsbCAmJiB3aW5kb3dFbnRyeS5jbGFzc0xpc3QuY29udGFpbnMoXCJ3aW5kb3ctZW50cnlcIikpIHtcbiAgICAgICAgaWYgKHRhYkRyYWdnYWJsZVRvV2luZG93KHNvdXJjZVRhYiwgd2luZG93RW50cnksIHNvdXJjZVdpbmRvdykpIHtcbiAgICAgICAgICAgIGUudGFyZ2V0LmNsYXNzTGlzdC5hZGQoXCJpbnNlcnQtY3Vyc29yLXdpbmRvd1wiKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdpbmRvd0VudHJ5RHJvcHBlZChlKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgbGV0IGN1cnNvcnMgPSBBcnJheS5mcm9tKEcudGFic0xpc3QuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImluc2VydC1jdXJzb3JcIikpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3Vyc29ycy5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZXQgY3Vyc29yID0gY3Vyc29yc1tpXTtcbiAgICAgICAgY3Vyc29yLnBhcmVudEVsZW1lbnQucmVtb3ZlQ2hpbGQoY3Vyc29yKTtcbiAgICB9XG4gICAgbGV0IGN1cnNvcldpbmRvdyA9IEcudGFic0xpc3QuZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lKFwiaW5zZXJ0LWN1cnNvci13aW5kb3dcIik7XG4gICAgaWYgKGN1cnNvcldpbmRvdyAhPT0gbnVsbCkge1xuICAgICAgICBjdXJzb3JXaW5kb3cuY2xhc3NMaXN0LnJlbW92ZShcImluc2VydC1jdXJzb3Itd2luZG93XCIpO1xuICAgIH1cbiAgICBcbiAgICBsZXQgd2luZG93RW50cnk7XG4gICAgaWYgKGUudGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucyhcInRhYi1lbnRyeVwiKSkge1xuICAgICAgICBpZiAoIWUudGFyZ2V0LmlzU2FtZU5vZGUodGFyZ2V0VGFiKSkge1xuICAgICAgICAgICAgbGV0IHRhYkVudHJ5Qm91bmRpbmdDbGllbnRSZWN0ID0gZS50YXJnZXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgICAgICB0YXJnZXRUYWIgPSBlLnRhcmdldDtcbiAgICAgICAgICAgIHVuZGVyID0gZmFsc2U7XG4gICAgICAgICAgICBpZiAoKGUuY2xpZW50WSAtIHRhYkVudHJ5Qm91bmRpbmdDbGllbnRSZWN0LnRvcCkgPj0gdGFiRW50cnlCb3VuZGluZ0NsaWVudFJlY3QuaGVpZ2h0IC8gMikge1xuICAgICAgICAgICAgICAgIHRhcmdldFRhYiA9IHRhcmdldFRhYi5uZXh0U2libGluZztcbiAgICAgICAgICAgICAgICBpZiAodGFyZ2V0VGFiID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIHVuZGVyID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0VGFiID0gZS50YXJnZXQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0YWJEcmFnZ2FibGUoc291cmNlVGFiLCB0YXJnZXRUYWIsIHVuZGVyLCBzb3VyY2VXaW5kb3csIG11bHRpRHJhZ2dpbmcpKSB7XG4gICAgICAgICAgICBsZXQgZGVzdGluYXRpb25XaW5kb3dJZCA9IGdldFdpbmRvd0lkKGdldFdpbmRvd0Zyb21UYWIodGFyZ2V0VGFiKSk7XG4gICAgICAgICAgICBsZXQgc291cmNlVGFiSW5kZXggPSBBcnJheS5wcm90b3R5cGUuaW5kZXhPZi5jYWxsKHRhcmdldFRhYi5wYXJlbnRFbGVtZW50LmNoaWxkTm9kZXMsIHNvdXJjZVRhYik7XG4gICAgICAgICAgICBsZXQgZGVzdGluYXRpb25JbmRleCA9IEFycmF5LnByb3RvdHlwZS5pbmRleE9mLmNhbGwodGFyZ2V0VGFiLnBhcmVudEVsZW1lbnQuY2hpbGROb2RlcywgdGFyZ2V0VGFiKTtcbiAgICAgICAgICAgIGxldCBtb3ZlSW5kZXggPSB1bmRlciA/IC0xIDogKChzb3VyY2VUYWJJbmRleCAhPT0gLTEgJiYgZGVzdGluYXRpb25JbmRleCA+IHNvdXJjZVRhYkluZGV4ICYmIGRlc3RpbmF0aW9uV2luZG93SWQgPT09IHNvdXJjZVdpbmRvd0lkKSA/IGRlc3RpbmF0aW9uSW5kZXgtMSA6IGRlc3RpbmF0aW9uSW5kZXgpO1xuICAgICAgICAgICAgbGV0IHNvdXJjZVRhYklkID0gZ2V0VGFiSWQoc291cmNlVGFiKTtcbiAgICAgICAgICAgIGJyb3dzZXIudGFicy5tb3ZlKHNvdXJjZVRhYklkLCB7XG4gICAgICAgICAgICAgICAgd2luZG93SWQ6IGRlc3RpbmF0aW9uV2luZG93SWQsXG4gICAgICAgICAgICAgICAgaW5kZXg6IG1vdmVJbmRleFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAodW5kZXIpIHtcbiAgICAgICAgICAgICAgICBhdHRhY2hUYWIoc291cmNlVGFiLCBnZXRXaW5kb3dGcm9tVGFiKHRhcmdldFRhYikpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBtb3ZlVGFiKHNvdXJjZVRhYiwgdGFyZ2V0VGFiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAoKHdpbmRvd0VudHJ5ID0gZS50YXJnZXQucGFyZW50RWxlbWVudCkgIT09IG51bGwgJiYgd2luZG93RW50cnkuY2xhc3NMaXN0LmNvbnRhaW5zKFwid2luZG93LWVudHJ5XCIpKSB7XG4gICAgICAgIGlmICh0YWJEcmFnZ2FibGVUb1dpbmRvdyhzb3VyY2VUYWIsIHdpbmRvd0VudHJ5LCBzb3VyY2VXaW5kb3cpKSB7XG4gICAgICAgICAgICBsZXQgc291cmNlVGFiSWQgPSBnZXRUYWJJZChzb3VyY2VUYWIpO1xuICAgICAgICAgICAgbGV0IGRlc3RpbmF0aW9uV2luZG93SWQgPSBnZXRXaW5kb3dJZCh3aW5kb3dFbnRyeSk7XG4gICAgICAgICAgICBicm93c2VyLnRhYnMubW92ZShzb3VyY2VUYWJJZCwge1xuICAgICAgICAgICAgICAgIHdpbmRvd0lkOiBkZXN0aW5hdGlvbldpbmRvd0lkLFxuICAgICAgICAgICAgICAgIGluZGV4OiAtMVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBhdHRhY2hUYWIoc291cmNlVGFiLCB3aW5kb3dFbnRyeSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dFbnRyeVRpdGxlQ2xpY2tlZChlKSB7XG4gICAgbGV0IHdpbmRvd0lkID0gZ2V0V2luZG93SWQoZS50YXJnZXQucGFyZW50RWxlbWVudCk7XG4gICAgYnJvd3Nlci53aW5kb3dzLnVwZGF0ZSh3aW5kb3dJZCwge1xuICAgICAgICBmb2N1c2VkOiB0cnVlXG4gICAgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dDbG9zZUNsaWNrKGUpIHtcbiAgICBsZXQgd2luZG93SWQgPSBnZXRXaW5kb3dJZChlLnRhcmdldC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCk7XG4gICAgYnJvd3Nlci53aW5kb3dzLnJlbW92ZSh3aW5kb3dJZCk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbmNvbnN0IGdsb2JhbHMgPSB7XG4gICAgdGFic0xpc3Q6IHVuZGVmaW5lZCxcbiAgICBpc1NlbGVjdGluZzogZmFsc2UsXG4gICAgc2VsZWN0ZWRUYWJzOiAwLFxuICAgIHNsaWRlU2VsZWN0aW9uOiB7XG4gICAgICAgIHNsaWRpbmc6IGZhbHNlLFxuICAgICAgICBpbml0aWF0b3I6IHVuZGVmaW5lZCxcbiAgICAgICAgdmVjdG9yOiAwXG4gICAgfSxcbiAgICBoaWRlQWZ0ZXJUYWJTZWxlY3Rpb246IHVuZGVmaW5lZCxcbiAgICBzZWFyY2hJblVSTHM6IHVuZGVmaW5lZFxufTtcbmV4cG9ydCBkZWZhdWx0IGdsb2JhbHM7XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbi8vIEtleSB0cmFja2VyXG5leHBvcnQgZnVuY3Rpb24gS2V5VHJhY2tlcigpIHtcbiAgICB0aGlzLmtleXMgPSB7fTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgZSA9PiB7XG4gICAgICAgIHRoaXMua2V5c1tlLmNvZGVdID0gdHJ1ZTtcbiAgICB9KTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleXVwXCIsIGUgPT4ge1xuICAgICAgICB0aGlzLmtleXNbZS5jb2RlXSA9IGZhbHNlO1xuICAgIH0pO1xufVxuS2V5VHJhY2tlci5wcm90b3R5cGUucHJlc3NlZCA9IGZ1bmN0aW9uIChjb2RlKSB7XG4gICAgcmV0dXJuIEJvb2xlYW4odGhpcy5rZXlzW2NvZGVdKTtcbn07XG5LZXlUcmFja2VyLnByb3RvdHlwZS5jdHJsID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLnByZXNzZWQoXCJDb250cm9sTGVmdFwiKSB8fCB0aGlzLnByZXNzZWQoXCJDb250cm9sUmlnaHRcIik7XG59O1xuS2V5VHJhY2tlci5wcm90b3R5cGUuY21kID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLnByZXNzZWQoXCJPU1JpZ2h0XCIpIHx8IHRoaXMucHJlc3NlZChcIk9TTGVmdFwiKTtcbn07XG5LZXlUcmFja2VyLnByb3RvdHlwZS5jdHJsT3JDbWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKHdpbmRvdy5uYXZpZ2F0b3IucGxhdGZvcm0udG9VcHBlckNhc2UoKS5pbmRleE9mKFwiTUFDXCIpID49IDApIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY21kKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmN0cmwoKTtcbn07XG5LZXlUcmFja2VyLnByb3RvdHlwZS5zaGlmdCA9IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gdGhpcy5wcmVzc2VkKFwiU2hpZnRMZWZ0XCIpIHx8IHRoaXMucHJlc3NlZChcIlNoaWZ0UmlnaHRcIik7XG59O1xuZXhwb3J0IGxldCBLZXlzID0gbmV3IEtleVRyYWNrZXIoKTtcblxuLy8gQ2hlY2tzIGlmIGVpdGhlciBDdHJsKFdpbmRvd3MgJiBMaW51eCkgb3IgQ29tbWFuZChNYWMpIGlzIHByZXNzZWRcbmV4cG9ydCBmdW5jdGlvbiBjdHJsT3JDbWQoKSB7XG4gICAgcmV0dXJuIEtleXMuY3RybE9yQ21kKCk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbi8vIEZ1bmN0aW9uIHRvIHNlbmQgYSBtZXNzYWdlIHRvIHRoZSBydW50aW1lXG5leHBvcnQgZnVuY3Rpb24gc2VuZFJ1bnRpbWVNZXNzYWdlKHR5cGUsIGRhdGEpIHtcbiAgICByZXR1cm4gYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgdHlwZTogdHlwZSxcbiAgICAgICAgZGF0YTogZGF0YVxuICAgIH0pO1xufVxuXG4vLyBGdW5jdGlvbiB0byBzZW5kIGEgbWVzc2FnZSB0byBhIHRhYlxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRUYWJNZXNzYWdlKHRhYklkLCB0YXJnZXQsIGRhdGEpIHtcbiAgICByZXR1cm4gYnJvd3Nlci50YWJzLnNlbmRNZXNzYWdlKHRhYklkLCB7XG4gICAgICAgIHRhcmdldDogdGFyZ2V0LFxuICAgICAgICBkYXRhOiBkYXRhXG4gICAgfSk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbi8vIEZ1bmN0aW9uIHRvIGdldCBpbWFnZSBmcm9tIFVSTFxuZXhwb3J0IGZ1bmN0aW9uIGdldEltYWdlKHVybCwgbm9DYWNoZT1mYWxzZSkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoIXVybC5zdGFydHNXaXRoKFwiY2hyb21lOi8vXCIpKSB7XG4gICAgICAgICAgICAgICAgbGV0IHhociA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuICAgICAgICAgICAgICAgIHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5yZWFkeVN0YXRlID09IDQgJiYgdGhpcy5zdGF0dXMgPT0gMjAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29udGVudFR5cGUgPSB4aHIuZ2V0UmVzcG9uc2VIZWFkZXIoXCJDb250ZW50LVR5cGVcIikudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbnRlbnRUeXBlLnN0YXJ0c1dpdGgoXCJpbWFnZS9cIikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZmxhZyA9IFwiZGF0YTpcIiArIGNvbnRlbnRUeXBlICsgXCI7Y2hhcnNldD11dGYtODtiYXNlNjQsXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGltYWdlU3RyID0gYXJyYXlCdWZmZXJUb0Jhc2U2NCh4aHIucmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoZmxhZyArIGltYWdlU3RyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KFwiSW1hZ2UgUmVxdWVzdCBGYWlsZWQ6IENvbnRlbnQtVHlwZSBpcyBub3QgYW4gaW1hZ2UhIChDb250ZW50LVR5cGU6IFxcXCJcIiArIGNvbnRlbnRUeXBlICsgXCJcXFwiKVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgeGhyLnJlc3BvbnNlVHlwZSA9IFwiYXJyYXlidWZmZXJcIjtcbiAgICAgICAgICAgICAgICB4aHIub3BlbihcIkdFVFwiLCB1cmwsIHRydWUpO1xuICAgICAgICAgICAgICAgIGlmIChub0NhY2hlKSB7IHhoci5zZXRSZXF1ZXN0SGVhZGVyKFwiQ2FjaGUtQ29udHJvbFwiLCBcIm5vLXN0b3JlXCIpOyB9XG4gICAgICAgICAgICAgICAgeGhyLnNlbmQoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIHJlamVjdChlcnIubWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuLy8gRnVuY3Rpb24gdG8gdHJhbnNmb3JtIEFycmF5QnVmZmVyIGludG8gYSBCYXNlNjQgU3RyaW5nXG5leHBvcnQgZnVuY3Rpb24gYXJyYXlCdWZmZXJUb0Jhc2U2NChidWZmZXIpIHtcbiAgICBsZXQgYmluYXJ5ID0gXCJcIjtcbiAgICBsZXQgYnl0ZXMgPSBbXS5zbGljZS5jYWxsKG5ldyBVaW50OEFycmF5KGJ1ZmZlcikpO1xuICAgIGJ5dGVzLmZvckVhY2goKGIpID0+IGJpbmFyeSArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpKTtcbiAgICByZXR1cm4gd2luZG93LmJ0b2EoYmluYXJ5KTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCBHIGZyb20gXCIuL2dsb2JhbHNcIlxuaW1wb3J0IHsgZ2V0V3JvbmdUb1JpZ2h0IH0gZnJvbSBcIi4vd3JvbmctdG8tcmlnaHRcIlxuaW1wb3J0IHsgcG9wdWxhdGVUYWJzTGlzdCwgZXh0ZW5kVGFic0xpc3QgfSBmcm9tIFwiLi93dGluaXRcIlxuaW1wb3J0IHsgZ2V0QWN0dWFsV2lkdGggfSBmcm9tIFwiLi9kb211dGlsc1wiXG5pbXBvcnQgeyBkb2N1bWVudE1vdXNlT3ZlciwgZG9jdW1lbnRNb3VzZVVwLCBkb2N1bWVudENsaWNrZWQsIGRvY3VtZW50S2V5UHJlc3NlZCB9IGZyb20gXCIuL2V2ZW50LWxpc3RlbmVycy9kb2N1bWVudFwiXG5pbXBvcnQgeyBzZWFyY2hUZXh0Q2hhbmdlZCwgaW5pdFNlYXJjaCB9IGZyb20gXCIuL2V2ZW50LWxpc3RlbmVycy9zZWFyY2hcIlxuaW1wb3J0IHsgb25NZXNzYWdlIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL21lc3NhZ2VcIlxuaW1wb3J0IHsgc2F2ZUZvckxhdGVyLCByZXN0b3JlIGFzIHJlY29yZGVyUmVzdG9yZSB9IGZyb20gXCIuL2V2ZW50LWxpc3RlbmVycy9yZWNvcmRlclwiXG5pbXBvcnQgKiBhcyBjYXB0dXJlVGFiIGZyb20gXCIuL2NhcHR1cmVUYWJcIlxuaW1wb3J0ICogYXMgT3B0aW9ucyBmcm9tIFwiLi4vb3B0aW9uc1wiXG5pbXBvcnQgeyBoaWRlVGFiUHJldmlldyB9IGZyb20gXCIuL3d0ZG9tXCJcbmltcG9ydCB7IHVwZGF0ZVJlY29yZGVyVG9vbFRpcCB9IGZyb20gXCIuL3JlY29yZGVyXCI7XG5cbkcudGFic0xpc3QgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYnMtbGlzdFwiKTtcblxuZnVuY3Rpb24gc2V0UG9wdXBTaXplKHdpZHRoLCBoZWlnaHQpIHtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc3R5bGUud2lkdGggPSB3aWR0aCArIFwicHhcIjtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gaGVpZ2h0ICsgXCJweFwiO1xuICAgIGRvY3VtZW50LmJvZHkuc3R5bGUud2lkdGggPSB3aWR0aCArIFwicHhcIjtcbiAgICBkb2N1bWVudC5ib2R5LnN0eWxlLmhlaWdodCA9IGhlaWdodCArIFwicHhcIjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZnVsZmlsbE9wdGlvbnMoKSB7XG4gICAgbGV0IHBvcHVwT3B0aW9ucyA9IChhd2FpdCBPcHRpb25zLm9wdGlvbnMoKSkucG9wdXA7XG4gICAgLy8gcG9wdXAuc2l6ZVxuICAgIHNldFBvcHVwU2l6ZShwb3B1cE9wdGlvbnMuc2l6ZS53aWR0aCwgcG9wdXBPcHRpb25zLnNpemUuaGVpZ2h0KTtcbiAgICAvLyBwb3B1cC5zY2FsZVxuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1zY2FsZScsIHBvcHVwT3B0aW9ucy5zY2FsZS50b1N0cmluZygpKTtcbiAgICAvLyBwb3B1cC5zaG93RGV0YWlsc1xuICAgIGlmICghT3B0aW9ucy5zdGJvb2wocG9wdXBPcHRpb25zLnNob3dEZXRhaWxzKSkge1xuICAgICAgICBsZXQgbGVmdENvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibGVmdC1jb250YWluZXJcIik7XG4gICAgICAgIHBvcHVwT3B0aW9ucy5zaXplLndpZHRoID0gcG9wdXBPcHRpb25zLnNpemUud2lkdGggLSBnZXRBY3R1YWxXaWR0aChsZWZ0Q29udGFpbmVyKTtcbiAgICAgICAgc2V0UG9wdXBTaXplKHBvcHVwT3B0aW9ucy5zaXplLndpZHRoLCBwb3B1cE9wdGlvbnMuc2l6ZS5oZWlnaHQpO1xuICAgICAgICBsZWZ0Q29udGFpbmVyLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0YWJzLWNvbnRhaW5lclwiKS5zdHlsZS53aWR0aCA9IFwiMTAwJVwiO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIHBvcHVwLnNob3dQcmV2aWV3XG4gICAgICAgIGlmICghT3B0aW9ucy5zdGJvb2wocG9wdXBPcHRpb25zLnNob3dQcmV2aWV3KSkgaGlkZVRhYlByZXZpZXcoKTtcbiAgICB9XG4gICAgLy8gcG9wdXAuaGlkZUFmdGVyVGFiU2VsZWN0aW9uXG4gICAgRy5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb24gPSBPcHRpb25zLnN0Ym9vbChwb3B1cE9wdGlvbnMuaGlkZUFmdGVyVGFiU2VsZWN0aW9uKTtcbiAgICAvLyBwb3B1cC5zZWFyY2hJblVSTHNcbiAgICBHLnNlYXJjaEluVVJMcyA9IE9wdGlvbnMuc3Rib29sKHBvcHVwT3B0aW9ucy5zZWFyY2hJblVSTHMpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBtYWluKCkge1xuICAgIC8vIEluaXRpYWxpemUgY2FwdHVyZVRhYiBiYXNlZCBvbiBlbnZpcm9ubWVudFxuICAgIGNhcHR1cmVUYWIuaW5pdCgpO1xuICAgIC8vIEZ1bGZpbGwgdXNlciBvcHRpb25zXG4gICAgYXdhaXQgZnVsZmlsbE9wdGlvbnMoKTtcbiAgICAvLyBNYWtlIHRhYnMgbGlzdCBmaXQgdGhlIHBhbmVsXG4gICAgZXh0ZW5kVGFic0xpc3QoKTtcbiAgICAvLyBGaXggZm9yIGNyb3NzLXdpbmRvdyBkcmFnZ2luZyBpc3N1ZVxuICAgIGF3YWl0IGdldFdyb25nVG9SaWdodCgpO1xuICAgIC8vIFBvcHVsYXRlIHRhYnMgbGlzdCB3aXRoIHRhYnNcbiAgICBhd2FpdCBwb3B1bGF0ZVRhYnNMaXN0KCk7XG4gICAgLy8gVXBkYXRlIHJlY29yZGVyIHRvb2x0aXBcbiAgICBhd2FpdCB1cGRhdGVSZWNvcmRlclRvb2xUaXAoKTtcbiAgICAvLyBJbml0aWFsaXplIGNvbXBvbmVudHNcbiAgICBpbml0U2VhcmNoKCk7XG59XG5cbi8qIEFkZCBldmVudCBsaXN0ZW5lcnMgKi9cblxuLy8gU3RhcnRpbmcgcG9pbnRcbmlmIChkb2N1bWVudC5yZWFkeVN0YXRlID09PSBcImxvYWRpbmdcIikge1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsIG1haW4pO1xufSBlbHNlIHtcbiAgICBtYWluKCk7XG59XG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgZG9jdW1lbnRNb3VzZU92ZXIpO1xuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNldXBcIiwgZG9jdW1lbnRNb3VzZVVwKTtcbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBkb2N1bWVudENsaWNrZWQpO1xuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImtleXByZXNzXCIsIGRvY3VtZW50S2V5UHJlc3NlZCk7XG5cbi8vIEFkZCBrZXl1cCBldmVudCBsaXN0ZW5lciBhbmQgcHV0IGZvY3VzIG9uIHNlYXJjaFxubGV0IHNlYXJjaCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2VhcmNoXCIpO1xuc2VhcmNoLmFkZEV2ZW50TGlzdGVuZXIoXCJrZXl1cFwiLCBzZWFyY2hUZXh0Q2hhbmdlZCk7XG5zZWFyY2guZm9jdXMoKTtcblxuLy8gQWRkIGV2ZW50IGxpc3RlbmVycyB0byBhbGwgY29weSBidXR0b25zXG5sZXQgY29weUJ1dHRvbnMgPSBBcnJheS5mcm9tKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJjb3B5LWJ1dHRvblwiKSk7XG5mb3IgKGxldCBpID0gMDsgaSA8IGNvcHlCdXR0b25zLmxlbmd0aDsgaSsrKSB7XG4gICAgY29weUJ1dHRvbnNbaV0uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGUgPT4ge1xuICAgICAgICBkb2N1bWVudC5vbmNvcHkgPSBjZSA9PiB7XG4gICAgICAgICAgICBjZS5jbGlwYm9hcmREYXRhLnNldERhdGEoXCJ0ZXh0XCIsIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGUudGFyZ2V0LmdldEF0dHJpYnV0ZShcImZvclwiKSkuaW5uZXJUZXh0KTtcbiAgICAgICAgICAgIGNlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIH07XG4gICAgICAgIGRvY3VtZW50LmV4ZWNDb21tYW5kKFwiY29weVwiLCBmYWxzZSwgbnVsbCk7XG4gICAgICAgIGUudGFyZ2V0LmlubmVyVGV4dCA9IFwiQ29waWVkIVwiO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGUudGFyZ2V0LmlubmVyVGV4dCA9IFwiQ29weVwiO1xuICAgICAgICB9LCAyMDAwKTtcbiAgICB9KTtcbn1cblxuLy8gQWRkIGV2ZW50IGxpc3RlbmVyIGZvciByZWNvcmRlci5qc1xuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJzYXZlLWZvci1sYXRlclwiKS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgc2F2ZUZvckxhdGVyKTtcbmRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmVzdG9yZS1ub3dcIikuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHJlY29yZGVyUmVzdG9yZSk7XG5cbi8vIEFkZCBldmVudCBsaXN0ZW5lciB0byBsaXN0ZW4gZm9yIGFueSBtZXNzYWdlcyBmcm9tIGJhY2tncm91bmQuanNcbmlmICghYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5oYXNMaXN0ZW5lcihvbk1lc3NhZ2UpKSB7XG4gICAgYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihvbk1lc3NhZ2UpO1xufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxyXG5pbXBvcnQgRyBmcm9tIFwiLi9nbG9iYWxzXCJcclxuaW1wb3J0IHsgZ2V0VGFiSWQgfSBmcm9tIFwiLi93dGRvbVwiXHJcbmltcG9ydCB7IHJ1bkFmdGVyVGFiTG9hZCB9IGZyb20gXCIuL3d0dXRpbHNcIjtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBsYXN0UmVjb3JkKCkge1xyXG4gICAgcmV0dXJuIGJyb3dzZXIuc3RvcmFnZS5zeW5jLmdldChbXCJyZWNvcmRcIl0pLnRoZW4oZGF0YSA9PiBkYXRhLnJlY29yZCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVSZWNvcmRlclRvb2xUaXAoKSB7XHJcbiAgICBsZXQgciA9IGF3YWl0IGxhc3RSZWNvcmQoKTtcclxuICAgIGxldCByZXN0b3JlQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyZXN0b3JlLW5vd1wiKTtcclxuICAgIGlmIChyKSB7XHJcbiAgICAgICAgcmVzdG9yZUJ0bi5zZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiLCBcIlJlc3RvcmUgd2Vic2l0ZXMgdGhhdCBoYXZlIGJlZW4gc2F2ZWQgb24gXCIgKyAobmV3IERhdGUoci50aW1lc3RhbXApKS50b0xvY2FsZVN0cmluZygpKTtcclxuICAgICAgICByZXN0b3JlQnRuLnJlbW92ZUF0dHJpYnV0ZShcImRpc2FibGVkXCIpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICByZXN0b3JlQnRuLnNldEF0dHJpYnV0ZShcInRpdGxlXCIsIFwiUmVzdG9yZSB3ZWJzaXRlcyB0aGF0IGhhdmUgYmVlbiBzYXZlZFwiKTtcclxuICAgICAgICByZXN0b3JlQnRuLnNldEF0dHJpYnV0ZShcImRpc2FibGVkXCIsIFwiXCIpO1xyXG4gICAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiB0YWJJbmZvVG9SZWNvcmQoaW5mbykge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICB1cmw6IGluZm8udXJsLFxyXG4gICAgICAgIHBpbm5lZDogaW5mby5waW5uZWRcclxuICAgIH07XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlY29yZCgpIHtcclxuICAgIGxldCByZWNvcmRBcnJheSA9IFtdO1xyXG4gICAgZm9yIChsZXQgd2luZG93RW50cnkgb2YgRy50YWJzTGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwid2luZG93LWVudHJ5XCIpKSB7XHJcbiAgICAgICAgbGV0IHdpbmRvd1JlY29yZCA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IHRhYkVudHJ5IG9mIHdpbmRvd0VudHJ5LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ0YWItZW50cnlcIikpIHtcclxuICAgICAgICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnNlbmRNZXNzYWdlKGdldFRhYklkKHRhYkVudHJ5KSwgeyB0YXJnZXQ6IFwicGFja2RcIiwgZGF0YTogeyBhY3Rpb246IFwicGFja1wiIH0gfSkudGhlbihhc3luYyBwYWNrID0+IHtcclxuICAgICAgICAgICAgICAgIHdpbmRvd1JlY29yZC5wdXNoKE9iamVjdC5hc3NpZ24oe1xyXG4gICAgICAgICAgICAgICAgICAgIHBhY2s6IHBhY2tcclxuICAgICAgICAgICAgICAgIH0sIHRhYkluZm9Ub1JlY29yZChhd2FpdCBicm93c2VyLnRhYnMuZ2V0KGdldFRhYklkKHRhYkVudHJ5KSkpKSk7XHJcbiAgICAgICAgICAgIH0pLmNhdGNoKGFzeW5jIHJlYXNvbiA9PiB7XHJcbiAgICAgICAgICAgICAgICB3aW5kb3dSZWNvcmQucHVzaChPYmplY3QuYXNzaWduKHtcclxuICAgICAgICAgICAgICAgICAgICBwYWNrOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgIH0sIHRhYkluZm9Ub1JlY29yZChhd2FpdCBicm93c2VyLnRhYnMuZ2V0KGdldFRhYklkKHRhYkVudHJ5KSkpKSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZWNvcmRBcnJheS5wdXNoKHdpbmRvd1JlY29yZCk7XHJcbiAgICB9XHJcbiAgICBsZXQgcmVjb3JkID0ge1xyXG4gICAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSxcclxuICAgICAgICByZWNvcmQ6IHJlY29yZEFycmF5XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIGJyb3dzZXIuc3RvcmFnZS5zeW5jLnNldCh7IHJlY29yZDogcmVjb3JkIH0pLnRoZW4oKCkgPT4gdXBkYXRlUmVjb3JkZXJUb29sVGlwKCkpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVzdG9yZSgpIHtcclxuICAgIGxldCB7IHJlY29yZDogciB9ID0gYXdhaXQgbGFzdFJlY29yZCgpO1xyXG4gICAgZm9yIChsZXQgd2luZG93UmVjb3JkIG9mIHIpIHtcclxuICAgICAgICBpZiAoYnJvd3Nlci5ydW50aW1lLmdldEJyb3dzZXJJbmZvKSB7XHJcbiAgICAgICAgICAgIHdpbmRvd1JlY29yZCA9IHdpbmRvd1JlY29yZC5maWx0ZXIodGFiUmVjb3JkID0+ICF0YWJSZWNvcmQudXJsLnN0YXJ0c1dpdGgoXCJhYm91dDpcIikpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyb3dzZXIud2luZG93cy5jcmVhdGUoe1xyXG4gICAgICAgICAgICB1cmw6IHdpbmRvd1JlY29yZC5tYXAodGFiUmVjb3JkID0+IHRhYlJlY29yZC51cmwpXHJcbiAgICAgICAgfSkudGhlbihhc3luYyB3ID0+IHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3aW5kb3dSZWNvcmQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCB0YWJSZWNvcmQgPSB3aW5kb3dSZWNvcmRbaV07XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHcudGFic1tpXS5pZCwge1xyXG4gICAgICAgICAgICAgICAgICAgIHBpbm5lZDogdGFiUmVjb3JkLnBpbm5lZFxyXG4gICAgICAgICAgICAgICAgfSkudGhlbih0ID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGFiUmVjb3JkLnBhY2spIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcnVuQWZ0ZXJUYWJMb2FkKHQuaWQsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyb3dzZXIudGFicy5zZW5kTWVzc2FnZSh0LmlkLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiBcInBhY2tkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YTogT2JqZWN0LmFzc2lnbih7YWN0aW9uOiBcInVucGFja1wifSwgdGFiUmVjb3JkLnBhY2spXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSkuY2F0Y2goZSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCB7IHNlbmRSdW50aW1lTWVzc2FnZSB9IGZyb20gXCIuL21lc3NhZ2luZ1wiXG5cbmxldCB3cm9uZ1RvUmlnaHQ7XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRXcm9uZ1RvUmlnaHQoKSB7XG4gICAgcmV0dXJuIHNlbmRSdW50aW1lTWVzc2FnZShcIldST05HX1RPX1JJR0hUX0dFVFwiLCB7fSkudGhlbihyZXNwb25zZSA9PiB7XG4gICAgICAgIHdyb25nVG9SaWdodCA9IHJlc3BvbnNlLndyb25nVG9SaWdodDtcbiAgICB9KTtcbn1cblxuLy8gRnVuY3Rpb24gdG8gZ2V0IGNvcnJlY3QgdGFiIGlkXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29ycmVjdFRhYklkKHRhYklkKSB7XG4gICAgcmV0dXJuIHdyb25nVG9SaWdodFt0YWJJZF0gfHwgdGFiSWQ7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi9nbG9iYWxzXCJcbmltcG9ydCB7IGdldENvcnJlY3RUYWJJZCB9IGZyb20gXCIuL3dyb25nLXRvLXJpZ2h0XCJcbmltcG9ydCB7IGdldExhc3RGb2N1c2VkV2luZG93IH0gZnJvbSBcIi4vd3R1dGlsc1wiO1xuXG4vLyBTZWxlY3QgdGFiIGFuZCBnbyB0byBpdFxuZXhwb3J0IGZ1bmN0aW9uIHNlbGVjdFRhYkVudHJ5KHRhYkVudHJ5KSB7XG4gICAgbGV0IHRhYklkID0gZ2V0VGFiSWQodGFiRW50cnkpO1xuICAgIGxldCBwYXJlbnRXaW5kb3dJZCA9IGdldFdpbmRvd0lkKGdldFdpbmRvd0Zyb21UYWIodGFiRW50cnkpKTtcbiAgICBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7XG4gICAgICAgIGFjdGl2ZTogdHJ1ZVxuICAgIH0pO1xuICAgIGJyb3dzZXIud2luZG93cy5nZXQocGFyZW50V2luZG93SWQpLnRoZW4odyA9PiB7XG4gICAgICAgIGdldExhc3RGb2N1c2VkV2luZG93KCkudGhlbihjdyA9PiB7XG4gICAgICAgICAgICBpZiAody5pZCAhPT0gY3cuaWQpIHtcbiAgICAgICAgICAgICAgICBicm93c2VyLndpbmRvd3MudXBkYXRlKHcuaWQsIHtcbiAgICAgICAgICAgICAgICAgICAgZm9jdXNlZDogdHJ1ZVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoRy5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb24pIHdpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcbn1cblxuLy8gSGlkZXMgdGhlIHRhYiBwcmV2aWV3XG5leHBvcnQgZnVuY3Rpb24gaGlkZVRhYlByZXZpZXcoKSB7XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLWltZ1wiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG59XG5cbi8vIEdldCBhIHRhYiBieSBhIHRhYiBlbnRyeVxuZXhwb3J0IGZ1bmN0aW9uIGdldFRhYkJ5VGFiRW50cnkoZW50cnkpIHtcbiAgICByZXR1cm4gYnJvd3Nlci50YWJzLmdldChnZXRUYWJJZChlbnRyeSkpO1xufVxuXG4vLyBHZXQgdGhlIFRhYklkIG9mIGEgdGFiIGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gZ2V0VGFiSWQoZW50cnkpIHtcbiAgICByZXR1cm4gcGFyc2VJbnQoZW50cnkuZ2V0QXR0cmlidXRlKFwiZGF0YS10YWJfaWRcIikpO1xufVxuXG4vLyBHZXQgdGhlIFdpbmRvd0lkIG9mIGEgd2luZG93IGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gZ2V0V2luZG93SWQoZW50cnkpIHtcbiAgICByZXR1cm4gcGFyc2VJbnQoZW50cnkuZ2V0QXR0cmlidXRlKFwiZGF0YS13aW5kb3dfaWRcIikpO1xufVxuXG4vLyBGaW5kIHRhYiBlbnRyeSBieSB0YWIgaWRcbmV4cG9ydCBmdW5jdGlvbiBmaW5kVGFiRW50cnlCeUlkKHRhYklkKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIudGFiLWVudHJ5W2RhdGEtdGFiX2lkPVxcXCJcIiArIHRhYklkICsgXCJcXFwiXVwiKTtcbn1cblxuLy8gRmluZCBjb3JyZWN0IHRhYiBlbnRyeSBieSB0YWIgaWRcbmV4cG9ydCBmdW5jdGlvbiBmaW5kQ29ycmVjdFRhYkVudHJ5QnlJZCh0YWJJZCkge1xuICAgIHJldHVybiBmaW5kVGFiRW50cnlCeUlkKGdldENvcnJlY3RUYWJJZCh0YWJJZCkpO1xufVxuXG4vLyBHZXQgZmF2aWNvbiBmcm9tIGEgdGFiIGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gZ2V0RmF2SWNvbkZyb21UYWJFbnRyeShlbnRyeSkge1xuICAgIHJldHVybiBlbnRyeS5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ0YWItZW50cnktZmF2aWNvblwiKTtcbn1cblxuLy8gRmluZCB3aW5kb3cgZW50cnkgYnkgdGFiIGlkXG5leHBvcnQgZnVuY3Rpb24gZmluZFdpbmRvd0VudHJ5QnlJZCh3aW5kb3dJZCkge1xuICAgIHJldHVybiBHLnRhYnNMaXN0LnF1ZXJ5U2VsZWN0b3IoXCJsaVtkYXRhLXdpbmRvd19pZD1cXFwiXCIgKyB3aW5kb3dJZCArIFwiXFxcIl1cIik7XG59XG5cbi8vIEZpbmQgdGFiIGVudHJ5IGluc2lkZSBhIHdpbmRvdyBlbnRyeVxuZXhwb3J0IGZ1bmN0aW9uIGZpbmRUYWJFbnRyeUluV2luZG93KHdpbmRvd0VudHJ5LCB0YWJJZCkge1xuICAgIHJldHVybiB3aW5kb3dFbnRyeS5xdWVyeVNlbGVjdG9yKFwibGlbZGF0YS10YWJfaWQ9XFxcIlwiICsgdGFiSWQgKyBcIlxcXCJdXCIpO1xufVxuXG4vLyBHZXQgYWN0aXZlIHRhYiBpbiB0aGUgc3BlY2lmaWVkIHdpbmRvd1xuZXhwb3J0IGZ1bmN0aW9uIGdldEFjdGl2ZVRhYih3aW5kb3dJZCkge1xuICAgIGxldCB3aW5kb3cgPSBmaW5kV2luZG93RW50cnlCeUlkKHdpbmRvd0lkKTtcbiAgICByZXR1cm4gd2luZG93LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcImN1cnJlbnQtdGFiXCIpO1xufVxuXG4vLyBTZXQgYWN0aXZlIHRhYiBpbiB0aGUgc3BlY2lmaWVkIHdpbmRvd1xuZXhwb3J0IGZ1bmN0aW9uIHNldEFjdGl2ZVRhYih3aW5kb3dJZCwgdGFiSWQpIHtcbiAgICBsZXQgd2luZG93ID0gZmluZFdpbmRvd0VudHJ5QnlJZCh3aW5kb3dJZCksIGxhc3RBY3RpdmVUYWI7XG4gICAgaWYgKChsYXN0QWN0aXZlVGFiID0gZ2V0QWN0aXZlVGFiKHdpbmRvd0lkKSkgIT09IG51bGwpIHtcbiAgICAgICAgbGFzdEFjdGl2ZVRhYi5jbGFzc0xpc3QucmVtb3ZlKFwiY3VycmVudC10YWJcIik7XG4gICAgfVxuICAgIGZpbmRUYWJFbnRyeUluV2luZG93KHdpbmRvdywgdGFiSWQpLmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXRhYlwiKTtcbn1cblxuLy8gUmVtb3ZlIHRhYlxuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZVRhYih0YWJJZCwgd2luZG93SWQpIHtcbiAgICBsZXQgdGFiRW50cnkgPSBmaW5kVGFiRW50cnlCeUlkKHRhYklkKTtcbiAgICB0YWJFbnRyeS5wYXJlbnRFbGVtZW50LnJlbW92ZUNoaWxkKHRhYkVudHJ5KTtcbiAgICBicm93c2VyLnRhYnMucXVlcnkoe1xuICAgICAgICBhY3RpdmU6IHRydWUsXG4gICAgICAgIHdpbmRvd0lkOiB3aW5kb3dJZFxuICAgIH0pLnRoZW4odGFicyA9PiB7XG4gICAgICAgIGZpbmRDb3JyZWN0VGFiRW50cnlCeUlkKHRhYnNbMF0uaWQpLmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXRhYlwiKTtcbiAgICB9KTtcbn1cblxuLy8gTW92ZSB0YWJcbmV4cG9ydCBmdW5jdGlvbiBtb3ZlVGFiKHRhcmdldCwgZGVzdCkge1xuICAgIGdldFdpbmRvd0Zyb21UYWIoZGVzdCkuZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lKFwid2luZG93LWVudHJ5LXRhYnNcIikuaW5zZXJ0QmVmb3JlKHRhcmdldCwgZGVzdCk7XG59XG5cbi8vIE1vdmUgdGFic1xuZXhwb3J0IGZ1bmN0aW9uIG1vdmVUYWJzKHRhcmdldHMsIGRlc3QpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhcmdldHMubGVuZ3RoOyBpKyspIG1vdmVUYWIodGFyZ2V0c1tpXSwgZGVzdCk7XG59XG5cbi8vIEF0dGFjaCB0YWJcbmV4cG9ydCBmdW5jdGlvbiBhdHRhY2hUYWIodGFyZ2V0LCBkZXN0KSB7XG4gICAgZGVzdC5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ3aW5kb3ctZW50cnktdGFic1wiKS5hcHBlbmRDaGlsZCh0YXJnZXQpO1xufVxuXG4vLyBBdHRhY2ggdGFic1xuZXhwb3J0IGZ1bmN0aW9uIGF0dGFjaFRhYnModGFyZ2V0cywgZGVzdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFyZ2V0cy5sZW5ndGg7IGkrKykgYXR0YWNoVGFiKHRhcmdldHNbaV0sIGRlc3QpO1xufVxuXG4vLyBSZW1vdmUgd2luZG93XG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlV2luZG93KHdpbmRvd0lkKSB7XG4gICAgbGV0IHdpbmRvd0VudHJ5ID0gZmluZFdpbmRvd0VudHJ5QnlJZCh3aW5kb3dJZCk7XG4gICAgd2luZG93RW50cnkucGFyZW50RWxlbWVudC5yZW1vdmVDaGlsZCh3aW5kb3dFbnRyeSk7XG4gICAgYnJvd3Nlci53aW5kb3dzLmdldEN1cnJlbnQoe30pLnRoZW4od2luZG93ID0+IHtcbiAgICAgICAgZmluZFdpbmRvd0VudHJ5QnlJZCh3aW5kb3cuaWQpLmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXdpbmRvd1wiKTtcbiAgICB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFdpbmRvd0Zyb21UYWIodGFiKSB7XG4gICAgcmV0dXJuIHRhYi5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQ7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0VGFiRW50cmllc0Zyb21XaW5kb3cod2luZG93RW50cnkpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbSh3aW5kb3dFbnRyeS5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwidGFiLWVudHJ5XCIpKTtcbn1cblxuLy8gVGVzdCBpZiB0YWIgaXMgZHJhZ2dhYmxlXG5leHBvcnQgZnVuY3Rpb24gdGFiRHJhZ2dhYmxlKHNvdXJjZVRhYiwgdGFyZ2V0VGFiLCB1bmRlciwgc291cmNlV2luZG93LCBtdWx0aURyYWdnaW5nKSB7XG4gICAgcmV0dXJuICFzb3VyY2VUYWIuaXNTYW1lTm9kZSh0YXJnZXRUYWIpXG4gICAgICAgICAgICAmJiAoIW11bHRpRHJhZ2dpbmcgfHwgKG11bHRpU2VsZWN0ZWQoc291cmNlVGFiKSAmJiBtdWx0aVNlbGVjdGVkKHRhcmdldFRhYikpKVxuICAgICAgICAgICAgJiYgKCghc291cmNlVGFiLmNsYXNzTGlzdC5jb250YWlucyhcInBpbm5lZC10YWJcIikgJiYgIXRhcmdldFRhYi5jbGFzc0xpc3QuY29udGFpbnMoXCJwaW5uZWQtdGFiXCIpKVxuICAgICAgICAgICAgICAgIHx8IChzb3VyY2VUYWIuY2xhc3NMaXN0LmNvbnRhaW5zKFwicGlubmVkLXRhYlwiKSAmJiB0YXJnZXRUYWIuY2xhc3NMaXN0LmNvbnRhaW5zKFwicGlubmVkLXRhYlwiKSlcbiAgICAgICAgICAgICAgICB8fCAodW5kZXIgJiYgIXNvdXJjZVRhYi5jbGFzc0xpc3QuY29udGFpbnMoXCJwaW5uZWQtdGFiXCIpKSlcbiAgICAgICAgICAgICYmICgoIXNvdXJjZVdpbmRvdy5jbGFzc0xpc3QuY29udGFpbnMoXCJpbmNvZ25pdG8td2luZG93XCIpICYmICFnZXRXaW5kb3dGcm9tVGFiKHRhcmdldFRhYikuY2xhc3NMaXN0LmNvbnRhaW5zKFwiaW5jb2duaXRvLXdpbmRvd1wiKSlcbiAgICAgICAgICAgICAgICB8fCAoc291cmNlV2luZG93LmNsYXNzTGlzdC5jb250YWlucyhcImluY29nbml0by13aW5kb3dcIikgJiYgZ2V0V2luZG93RnJvbVRhYih0YXJnZXRUYWIpLmNsYXNzTGlzdC5jb250YWlucyhcImluY29nbml0by13aW5kb3dcIikpKTtcbn1cblxuLy8gVGVzdCBpZiB0YWIgaXMgZHJhZ2dhYmxlIHRvIHdpbmRvd1xuZXhwb3J0IGZ1bmN0aW9uIHRhYkRyYWdnYWJsZVRvV2luZG93KHNvdXJjZVRhYiwgdGFyZ2V0V2luZG93LCBzb3VyY2VXaW5kb3cpIHtcbiAgICByZXR1cm4gIXNvdXJjZVdpbmRvdy5pc1NhbWVOb2RlKHRhcmdldFdpbmRvdylcbiAgICAgICAgICAgICYmICFzb3VyY2VUYWIuY2xhc3NMaXN0LmNvbnRhaW5zKFwicGlubmVkLXRhYlwiKVxuICAgICAgICAgICAgJiYgKCghc291cmNlV2luZG93LmNsYXNzTGlzdC5jb250YWlucyhcImluY29nbml0by13aW5kb3dcIikgJiYgIXRhcmdldFdpbmRvdy5jbGFzc0xpc3QuY29udGFpbnMoXCJpbmNvZ25pdG8td2luZG93XCIpKVxuICAgICAgICAgICAgICAgIHx8IChzb3VyY2VXaW5kb3cuY2xhc3NMaXN0LmNvbnRhaW5zKFwiaW5jb2duaXRvLXdpbmRvd1wiKSAmJiB0YXJnZXRXaW5kb3cuY2xhc3NMaXN0LmNvbnRhaW5zKFwiaW5jb2duaXRvLXdpbmRvd1wiKSkpO1xufVxuXG4vLyBSZXR1cm5zIHRoZSBpbmRleCBvZiBhIHRhYiBlbnRyeVxuZXhwb3J0IGZ1bmN0aW9uIHRhYkVudHJ5SW5kZXgodGFiRW50cnkpIHtcbiAgICBsZXQgdGFicyA9IEFycmF5LmZyb20oZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInRhYi1lbnRyeVwiKSk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0YWJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmICh0YWJzW2ldID09PSB0YWJFbnRyeSkge1xuICAgICAgICAgICAgcmV0dXJuIGk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIC0xO1xufVxuXG4vLyBHZXQgbmV4dCB0YWJcbmV4cG9ydCBmdW5jdGlvbiBnZXROZXh0VGFiRW50cnkodGFiRW50cnkpIHtcbiAgICBpZiAodGFiRW50cnkubmV4dEVsZW1lbnRTaWJsaW5nICE9PSBudWxsKSB7XG4gICAgICAgIHJldHVybiB0YWJFbnRyeS5uZXh0RWxlbWVudFNpYmxpbmc7XG4gICAgfSBlbHNlIGlmIChnZXRXaW5kb3dGcm9tVGFiKHRhYkVudHJ5KS5uZXh0RWxlbWVudFNpYmxpbmcgIT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIGdldFRhYkVudHJpZXNGcm9tV2luZG93KGdldFdpbmRvd0Zyb21UYWIodGFiRW50cnkpLm5leHRFbGVtZW50U2libGluZylbMF07XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufVxuLy8gR2V0IGxhc3QgdGFiXG5leHBvcnQgZnVuY3Rpb24gZ2V0TGFzdFRhYkVudHJ5KHRhYkVudHJ5KSB7XG4gICAgaWYgKHRhYkVudHJ5LnByZXZpb3VzRWxlbWVudFNpYmxpbmcgIT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRhYkVudHJ5LnByZXZpb3VzRWxlbWVudFNpYmxpbmc7XG4gICAgfSBlbHNlIGlmIChnZXRXaW5kb3dGcm9tVGFiKHRhYkVudHJ5KS5wcmV2aW91c0VsZW1lbnRTaWJsaW5nICE9PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBnZXRUYWJFbnRyaWVzRnJvbVdpbmRvdyhnZXRXaW5kb3dGcm9tVGFiKHRhYkVudHJ5KS5wcmV2aW91c0VsZW1lbnRTaWJsaW5nKVswXTtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG5cbi8qIE11bHRpc2VsZWN0ICovXG4vLyBPbiBtdWx0aXNlbGVjdCBzdGFydFxuZnVuY3Rpb24gb25NdWx0aXNlbGVjdFN0YXJ0KCkge1xuXG59XG4vLyBPbiBtdWx0aXNlbGVjdCBjaGFuZ2VcbmZ1bmN0aW9uIG9uTXVsdGlzZWxlY3RDaGFuZ2UoKSB7XG5cbn1cbi8vIE9uIG11bHRpc2VsZWN0IGVuZFxuZnVuY3Rpb24gb25NdWx0aXNlbGVjdEVuZCgpIHtcblxufVxuLy8gR2V0IFNlbGVjdGVkIEl0ZW1zXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2VsZWN0ZWRJdGVtcygpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbShkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibXVsdGlzZWxlY3RcIikpO1xufVxuLy8gTXVsdGlzZWxlY3RlZFxuZXhwb3J0IGZ1bmN0aW9uIG11bHRpU2VsZWN0ZWQoZWxlbWVudCkge1xuICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcIm11bHRpc2VsZWN0XCIpO1xufVxuLy8gU2VsZWN0XG5leHBvcnQgZnVuY3Rpb24gbXVsdGlTZWxlY3QoZWxlbWVudCkge1xuICAgIGlmICghZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJtdWx0aXNlbGVjdFwiKSkge1xuICAgICAgICBHLnNlbGVjdGVkVGFicysrO1xuICAgICAgICBHLmlzU2VsZWN0aW5nID0gdHJ1ZTtcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKFwibXVsdGlzZWxlY3RcIik7XG4gICAgfVxufVxuLy8gQ2FuY2VsIFNlbGVjdGlvblxuZXhwb3J0IGZ1bmN0aW9uIG11bHRpU2VsZWN0Q2FuY2VsKGVsZW1lbnQpIHtcbiAgICBpZiAoZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJtdWx0aXNlbGVjdFwiKSkge1xuICAgICAgICBpZiAoLS1HLnNlbGVjdGVkVGFicyA9PSAwKSB7XG4gICAgICAgICAgICBHLmlzU2VsZWN0aW5nID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKFwibXVsdGlzZWxlY3RcIik7XG4gICAgfVxufVxuLy8gUmVzZXQgbXVsdGlzZWxlY3RcbmV4cG9ydCBmdW5jdGlvbiBtdWx0aVNlbGVjdFJlc2V0KCkge1xuICAgIGZvciAobGV0IGVsZW1lbnQgb2YgQXJyYXkuZnJvbShkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibXVsdGlzZWxlY3RcIikpKSB7XG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShcIm11bHRpc2VsZWN0XCIpO1xuICAgIH1cbiAgICBHLnNlbGVjdGVkVGFicyA9IDA7XG4gICAgRy5pc1NlbGVjdGluZyA9IGZhbHNlO1xufVxuLy8gVG9nZ2xlIFNlbGVjdGlvblxuZXhwb3J0IGZ1bmN0aW9uIG11bHRpU2VsZWN0VG9nZ2xlKGVsZW1lbnQpIHtcbiAgICBpZiAoZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJtdWx0aXNlbGVjdFwiKSkge1xuICAgICAgICBtdWx0aVNlbGVjdENhbmNlbChlbGVtZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBtdWx0aVNlbGVjdChlbGVtZW50KTtcbiAgICB9XG59XG4vLyBSZXNldCBzbGlkZSBzZWxlY3Rpb25cbmV4cG9ydCBmdW5jdGlvbiByZXNldFNsaWRlU2VsZWN0aW9uKCkge1xuICAgIEcuc2xpZGVTZWxlY3Rpb24uc2xpZGluZyA9IGZhbHNlO1xuICAgIEcuc2xpZGVTZWxlY3Rpb24uaW5pdGlhdG9yID0gdW5kZWZpbmVkO1xufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IEcgZnJvbSBcIi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBnZXRJbWFnZSB9IGZyb20gXCIuL25ldFwiXG5pbXBvcnQgeyBnZXRDb3JyZWN0VGFiSWQgfSBmcm9tIFwiLi93cm9uZy10by1yaWdodFwiXG5pbXBvcnQgeyBnZXRXaW5kb3dzLCBjb3JyZWN0Rm9jdXNlZCB9IGZyb20gXCIuL3d0dXRpbHNcIlxuaW1wb3J0IHsgZ2V0QWN0dWFsSGVpZ2h0LCBzdG9wUHJvcGFnYXRpb24gfSBmcm9tIFwiLi9kb211dGlsc1wiXG5pbXBvcnQgeyB3aW5kb3dFbnRyeURyYWdTdGFydGVkLCB3aW5kb3dFbnRyeURyYWdnaW5nT3Zlciwgd2luZG93RW50cnlEcm9wcGVkLCB3aW5kb3dFbnRyeVRpdGxlQ2xpY2tlZCwgd2luZG93Q2xvc2VDbGljayB9IGZyb20gXCIuL2V2ZW50LWxpc3RlbmVycy93aW5kb3dFbnRyeVwiXG5pbXBvcnQgeyB0YWJFbnRyeU1vdXNlT3ZlciwgdGFiRW50cnlNb3VzZUxlYXZlLCB0YWJFbnRyeUNsaWNrZWQsIHRhYkNsb3NlQ2xpY2ssIHRhYlBpbkNsaWNrIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL3RhYkVudHJ5XCJcblxuLy8gVXBkYXRlIHRhYnNcbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVUYWJzKHdpbmRvd3MpIHtcbiAgICBHLnRhYnNMaXN0LmlubmVySFRNTCA9IFwiXCI7XG4gICAgbGV0IHRhYnNMaXN0RnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgbGV0IGN1cnJlbnRXaW5kb3dFbnRyeTtcbiAgICAvKiBQcmVkZWZpbmVkIGVsZW1lbnRzIGZvciBmYXN0ZXIgcGVyZm9ybWFuY2UgKi9cbiAgICAvLyBXaW5kb3cgY2xvc2UgYnV0dG9uXG4gICAgbGV0IFdJTkRPV19DTE9TRV9CVE4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICBXSU5ET1dfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJpbmxpbmUtYnV0dG9uXCIpO1xuICAgIFdJTkRPV19DTE9TRV9CVE4uY2xhc3NMaXN0LmFkZChcImltZy1idXR0b25cIik7XG4gICAgV0lORE9XX0NMT1NFX0JUTi5jbGFzc0xpc3QuYWRkKFwib3BhY2l0eS1jaGFuZ2luZy1idXR0b25cIik7XG4gICAgV0lORE9XX0NMT1NFX0JUTi5jbGFzc0xpc3QuYWRkKFwid2luZG93LWVudHJ5LXJlbW92ZS1idG5cIik7XG4gICAgV0lORE9XX0NMT1NFX0JUTi5zdHlsZS5iYWNrZ3JvdW5kSW1hZ2UgPSBcInVybCguLi9pY29ucy9jbG9zZS5zdmcpXCI7XG4gICAgbGV0IERJViA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgRElWLnN0eWxlLmRpc3BsYXkgPSBcImlubGluZS1ibG9ja1wiO1xuICAgIFdJTkRPV19DTE9TRV9CVE4uYXBwZW5kQ2hpbGQoRElWKTtcbiAgICAvLyBUYWIgY2xvc2UgYnV0dG9uXG4gICAgbGV0IFRBQl9DTE9TRV9CVE4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICBUQUJfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJpbmxpbmUtYnV0dG9uXCIpO1xuICAgIFRBQl9DTE9TRV9CVE4uY2xhc3NMaXN0LmFkZChcInJlZC1idXR0b25cIik7XG4gICAgVEFCX0NMT1NFX0JUTi5jbGFzc0xpc3QuYWRkKFwiaW1nLWJ1dHRvblwiKTtcbiAgICBUQUJfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJ0YWItZW50cnktcmVtb3ZlLWJ0blwiKTtcbiAgICBUQUJfQ0xPU0VfQlROLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IFwidXJsKC4uL2ljb25zL2Nsb3NlLnN2ZylcIjtcbiAgICAvLyBUYWIgcGluIGJ1dHRvblxuICAgIGxldCBUQUJfUElOX0JUTiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgIFRBQl9QSU5fQlROLmNsYXNzTGlzdC5hZGQoXCJpbmxpbmUtYnV0dG9uXCIpO1xuICAgIFRBQl9QSU5fQlROLmNsYXNzTGlzdC5hZGQoXCJpbWctYnV0dG9uXCIpO1xuICAgIFRBQl9QSU5fQlROLmNsYXNzTGlzdC5hZGQoXCJvcGFjaXR5LWNoYW5naW5nLWJ1dHRvblwiKTtcbiAgICBUQUJfUElOX0JUTi5jbGFzc0xpc3QuYWRkKFwidGFiLWVudHJ5LXBpbi1idG5cIik7XG4gICAgVEFCX1BJTl9CVE4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvcGluLnN2ZylcIjtcbiAgICAvLyBMb29wIHRocm91Z2ggd2luZG93c1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgd2luZG93cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAvLyBTZXQgdyB0byB3aW5kb3dcbiAgICAgICAgbGV0IHcgPSB3aW5kb3dzW2ldO1xuXG4gICAgICAgIC8vIENyZWF0ZSB3aW5kb3cgZW50cnlcbiAgICAgICAgbGV0IHdpbmRvd0VudHJ5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xuICAgICAgICB3aW5kb3dFbnRyeS5jbGFzc0xpc3QuYWRkKFwid2luZG93LWVudHJ5XCIpO1xuICAgICAgICB3aW5kb3dFbnRyeS5jbGFzc0xpc3QuYWRkKFwiY2F0ZWdvcnlcIik7XG5cbiAgICAgICAgLy8gQ3JlYXRlIHdpbmRvdyBlbnRyeSBmcmFnbWVudFxuICAgICAgICBsZXQgd2luZG93RW50cnlGcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcblxuICAgICAgICAvLyBTZXQgd2luZG93IGlkIHRvIHdpbmRvdyBlbnRyeVxuICAgICAgICB3aW5kb3dFbnRyeS5zZXRBdHRyaWJ1dGUoXCJkYXRhLXdpbmRvd19pZFwiLCB3LmlkKTtcbiAgICAgICAgbGV0IHNwYW4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICAgICAgc3Bhbi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgd2luZG93RW50cnlUaXRsZUNsaWNrZWQpO1xuXG4gICAgICAgIC8vIENyZWF0ZSBjbG9zZSBidXR0b25cbiAgICAgICAgbGV0IGNsb3NlQnRuID0gV0lORE9XX0NMT1NFX0JUTi5jbG9uZU5vZGUodHJ1ZSk7XG4gICAgICAgIGNsb3NlQnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCB3aW5kb3dDbG9zZUNsaWNrKTtcblxuICAgICAgICAvLyBCdXR0b25zIHdyYXBwZXJcbiAgICAgICAgbGV0IGJ1dHRvbnMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICAgICAgYnV0dG9ucy5jbGFzc0xpc3QuYWRkKFwid2luZG93LWVudHJ5LWJ1dHRvbnNcIik7XG4gICAgICAgIGJ1dHRvbnMuYXBwZW5kQ2hpbGQoY2xvc2VCdG4pO1xuICAgICAgICBcbiAgICAgICAgLy8gQ3JlYXRlIHdpbmRvdyBuYW1lIHNwYW5cbiAgICAgICAgbGV0IHdpbmRvd05hbWUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICAgICAgd2luZG93TmFtZS5jbGFzc0xpc3QuYWRkKFwid2luZG93LXRpdGxlXCIpO1xuICAgICAgICB3aW5kb3dOYW1lLnRleHRDb250ZW50ICs9IFwiV2luZG93IFwiICsgKGkrMSk7XG5cbiAgICAgICAgLy8gQ2hlY2sgaWYgd2luZG93IGlzIGZvY3VzZWRcbiAgICAgICAgaWYgKHcuZm9jdXNlZCkge1xuICAgICAgICAgICAgY3VycmVudFdpbmRvd0VudHJ5ID0gd2luZG93RW50cnk7XG4gICAgICAgICAgICB3aW5kb3dFbnRyeS5jbGFzc0xpc3QuYWRkKFwiY3VycmVudC13aW5kb3dcIik7XG4gICAgICAgICAgICB3aW5kb3dOYW1lLnRleHRDb250ZW50ICs9IFwiIC0gQ3VycmVudFwiO1xuICAgICAgICB9XG4gICAgICAgIC8vIENoZWNrIGlmIHdpbmRvdyBpcyBpbmNvZ25pdG9cbiAgICAgICAgaWYgKHcuaW5jb2duaXRvKSB7XG4gICAgICAgICAgICB3aW5kb3dFbnRyeS5jbGFzc0xpc3QuYWRkKFwiaW5jb2duaXRvLXdpbmRvd1wiKTtcbiAgICAgICAgICAgIHdpbmRvd05hbWUudGV4dENvbnRlbnQgKz0gXCIgKEluY29nbml0bylcIjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNwYW4uYXBwZW5kQ2hpbGQod2luZG93TmFtZSk7XG4gICAgICAgIHNwYW4uYXBwZW5kQ2hpbGQoYnV0dG9ucyk7XG5cbiAgICAgICAgc3Bhbi5jbGFzc0xpc3QuYWRkKFwiZGFya2VyLWJ1dHRvblwiKTtcblxuICAgICAgICB3aW5kb3dFbnRyeUZyYWdtZW50LmFwcGVuZENoaWxkKHNwYW4pO1xuXG4gICAgICAgIC8vIEFkZCB3aW5kb3cgZW50cnkgZHJhZ3N0YXJ0LCBkcmFnb3ZlciwgYW5kIGRyb3AgZXZlbnQgbGlzdGVuZXJzXG4gICAgICAgIHdpbmRvd0VudHJ5LmFkZEV2ZW50TGlzdGVuZXIoXCJkcmFnc3RhcnRcIiwgd2luZG93RW50cnlEcmFnU3RhcnRlZCk7XG4gICAgICAgIHdpbmRvd0VudHJ5LmFkZEV2ZW50TGlzdGVuZXIoXCJkcmFnb3ZlclwiLCB3aW5kb3dFbnRyeURyYWdnaW5nT3Zlcik7XG4gICAgICAgIHdpbmRvd0VudHJ5LmFkZEV2ZW50TGlzdGVuZXIoXCJkcm9wXCIsIHdpbmRvd0VudHJ5RHJvcHBlZCk7XG4gICAgICAgIHdpbmRvd0VudHJ5LnNldEF0dHJpYnV0ZShcImRyYWdnYWJsZVwiLCBcInRydWVcIik7XG5cbiAgICAgICAgbGV0IHdpbmRvd1RhYnNMaXN0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInVsXCIpO1xuICAgICAgICB3aW5kb3dUYWJzTGlzdC5jbGFzc0xpc3QuYWRkKFwiY2F0ZWdvcnktbGlzdFwiKTtcbiAgICAgICAgd2luZG93VGFic0xpc3QuY2xhc3NMaXN0LmFkZChcIndpbmRvdy1lbnRyeS10YWJzXCIpO1xuXG4gICAgICAgIGxldCB3aW5kb3dUYWJzTGlzdEZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xuICAgICAgICAvLyBMb29wIHRocm91Z2ggdGFic1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHcudGFicy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbGV0IHRhYiA9IHcudGFic1tpXTtcbiAgICAgICAgICAgIC8vIENoZWNrIHRhYiBpZFxuICAgICAgICAgICAgaWYgKHRhYi5pZCAhPT0gYnJvd3Nlci50YWJzLlRBQl9JRF9OT05FKSB7XG4gICAgICAgICAgICAgICAgLy8gQ3JlYXRlIHRhYiBlbnRyeVxuICAgICAgICAgICAgICAgIGxldCB0YWJFbnRyeSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaVwiKTtcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5jbGFzc0xpc3QuYWRkKFwidGFiLWVudHJ5XCIpO1xuICAgICAgICAgICAgICAgIHRhYkVudHJ5LmNsYXNzTGlzdC5hZGQoXCJidXR0b25cIik7XG4gICAgICAgICAgICAgICAgLy8gU2V0IHRhYiBlbnRyeSBhcyBkcmFnZ2FibGUuIFJlcXVpcmVkIHRvIGVuYWJsZSBtb3ZlIHRhYiBmZWF0dXJlXG4gICAgICAgICAgICAgICAgdGFiRW50cnkuc2V0QXR0cmlidXRlKFwiZHJhZ2dhYmxlXCIsIFwidHJ1ZVwiKTtcblxuICAgICAgICAgICAgICAgIC8vIENyZWF0ZSB0YWIgZW50cnkgZnJhZ21lbnRcbiAgICAgICAgICAgICAgICBsZXQgdGFiRW50cnlGcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcblxuICAgICAgICAgICAgICAgIGxldCBmYXZpY29uO1xuICAgICAgICAgICAgICAgIGxldCB0aXRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICAgICAgICAgIHRpdGxlLmNsYXNzTGlzdC5hZGQoXCJ0YWItdGl0bGVcIik7XG4gICAgICAgICAgICAgICAgdGl0bGUudGV4dENvbnRlbnQgKz0gdGFiLnRpdGxlO1xuICAgICAgICAgICAgICAgIGxldCB0aXRsZVdyYXBwZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICAgICAgICAgIHRpdGxlV3JhcHBlci5jbGFzc0xpc3QuYWRkKFwidGFiLXRpdGxlLXdyYXBwZXJcIik7XG4gICAgICAgICAgICAgICAgdGl0bGVXcmFwcGVyLmFwcGVuZENoaWxkKHRpdGxlKTtcblxuICAgICAgICAgICAgICAgIGlmICh0YWIuYWN0aXZlKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhYkVudHJ5LmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXRhYlwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5mYXZJY29uVXJsKSB7XG4gICAgICAgICAgICAgICAgICAgIGZhdmljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW1nXCIpO1xuICAgICAgICAgICAgICAgICAgICBmYXZpY29uLmNsYXNzTGlzdC5hZGQoXCJ0YWItZW50cnktZmF2aWNvblwiKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGZhdkljb25Qcm9taXNlO1xuICAgICAgICAgICAgICAgICAgICBpZiAody5pbmNvZ25pdG8pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhdkljb25Qcm9taXNlID0gZ2V0SW1hZ2UodGFiLmZhdkljb25VcmwsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmF2SWNvblByb21pc2UgPSBnZXRJbWFnZSh0YWIuZmF2SWNvblVybCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZmF2SWNvblByb21pc2UudGhlbihiYXNlNjRJbWFnZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmYXZpY29uLnNyYyA9IGJhc2U2NEltYWdlO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBDcmVhdGUgY2xvc2UgYnV0dG9uXG4gICAgICAgICAgICAgICAgY2xvc2VCdG4gPSBUQUJfQ0xPU0VfQlROLmNsb25lTm9kZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgY2xvc2VCdG4uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHRhYkNsb3NlQ2xpY2spO1xuICAgICAgICAgICAgICAgIGNsb3NlQnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgc3RvcFByb3BhZ2F0aW9uKTtcblxuICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBwaW4gYnV0dG9uXG4gICAgICAgICAgICAgICAgbGV0IHBpbkJ0biA9IFRBQl9QSU5fQlROLmNsb25lTm9kZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgcGluQnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCB0YWJQaW5DbGljayk7XG4gICAgICAgICAgICAgICAgcGluQnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgc3RvcFByb3BhZ2F0aW9uKTtcblxuICAgICAgICAgICAgICAgIC8vIEJ1dHRvbnMgd3JhcHBlclxuICAgICAgICAgICAgICAgIGJ1dHRvbnMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcbiAgICAgICAgICAgICAgICBidXR0b25zLmNsYXNzTGlzdC5hZGQoXCJ0YWItZW50cnktYnV0dG9uc1wiKTtcbiAgICAgICAgICAgICAgICBidXR0b25zLmFwcGVuZENoaWxkKHBpbkJ0bik7XG4gICAgICAgICAgICAgICAgYnV0dG9ucy5hcHBlbmRDaGlsZChjbG9zZUJ0bik7XG5cbiAgICAgICAgICAgICAgICAvLyBTZXQgdGFiIGVudHJ5IHRhYiBpZFxuICAgICAgICAgICAgICAgIHRhYkVudHJ5LnNldEF0dHJpYnV0ZShcImRhdGEtdGFiX2lkXCIsIGdldENvcnJlY3RUYWJJZCh0YWIuaWQpKTtcbiAgICAgICAgICAgICAgICBpZiAoZmF2aWNvbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhYkVudHJ5RnJhZ21lbnQuYXBwZW5kQ2hpbGQoZmF2aWNvbik7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LmFkZChcIm5vaWNvblwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGFiRW50cnlGcmFnbWVudC5hcHBlbmRDaGlsZCh0aXRsZVdyYXBwZXIpO1xuICAgICAgICAgICAgICAgIHRhYkVudHJ5RnJhZ21lbnQuYXBwZW5kQ2hpbGQoYnV0dG9ucyk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgdGFiRW50cnkuYXBwZW5kQ2hpbGQodGFiRW50cnlGcmFnbWVudCk7XG5cbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5hZGRFdmVudExpc3RlbmVyKFwibW91c2VvdmVyXCIsIHRhYkVudHJ5TW91c2VPdmVyKTtcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5hZGRFdmVudExpc3RlbmVyKFwibW91c2VsZWF2ZVwiLCB0YWJFbnRyeU1vdXNlTGVhdmUpO1xuICAgICAgICAgICAgICAgIHRhYkVudHJ5LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCB0YWJFbnRyeUNsaWNrZWQpO1xuXG4gICAgICAgICAgICAgICAgaWYgKHRhYi5waW5uZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcGluQnRuLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IFwidXJsKC4uL2ljb25zL3BpbnJlbW92ZS5zdmcpXCI7XG4gICAgICAgICAgICAgICAgICAgIHRhYkVudHJ5LmNsYXNzTGlzdC5hZGQoXCJwaW5uZWQtdGFiXCIpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgcGlubmVkVGFicyA9IEFycmF5LmZyb20od2luZG93VGFic0xpc3QuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInBpbm5lZC10YWJcIikpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgbGFzdFBpbm5lZFRhYiA9IHBpbm5lZFRhYnNbcGlubmVkVGFicy5sZW5ndGgtMV07XG4gICAgICAgICAgICAgICAgICAgIGlmIChsYXN0UGlubmVkVGFiICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvd1RhYnNMaXN0RnJhZ21lbnQuaW5zZXJ0QmVmb3JlKHRhYkVudHJ5LCBsYXN0UGlubmVkVGFiLm5leHRTaWJsaW5nKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvd1RhYnNMaXN0RnJhZ21lbnQuaW5zZXJ0QmVmb3JlKHRhYkVudHJ5LCB3aW5kb3dUYWJzTGlzdC5jaGlsZE5vZGVzWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvd1RhYnNMaXN0RnJhZ21lbnQuYXBwZW5kQ2hpbGQodGFiRW50cnkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEFwcGVuZCBmcmFnbWVudCB0byBhY3R1YWwgd2luZG93VGFic0xpc3RcbiAgICAgICAgd2luZG93VGFic0xpc3QuYXBwZW5kQ2hpbGQod2luZG93VGFic0xpc3RGcmFnbWVudCk7XG5cbiAgICAgICAgd2luZG93RW50cnlGcmFnbWVudC5hcHBlbmRDaGlsZCh3aW5kb3dUYWJzTGlzdCk7XG4gICAgICAgIHdpbmRvd0VudHJ5LmFwcGVuZENoaWxkKHdpbmRvd0VudHJ5RnJhZ21lbnQpO1xuICAgICAgICB0YWJzTGlzdEZyYWdtZW50LmFwcGVuZENoaWxkKHdpbmRvd0VudHJ5KTtcbiAgICB9XG4gICAgRy50YWJzTGlzdC5hcHBlbmRDaGlsZCh0YWJzTGlzdEZyYWdtZW50KTtcbiAgICBHLnRhYnNMaXN0LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBzdG9wUHJvcGFnYXRpb24pO1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFic1wiKS5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xuICAgIGN1cnJlbnRXaW5kb3dFbnRyeS5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbn1cblxuLy8gQWRkIHRhYnMgdG8gbGlzdFxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBvcHVsYXRlVGFic0xpc3QoKSB7XG4gICAgbGV0IHdpbmRvd3MgPSBhd2FpdCBnZXRXaW5kb3dzKCk7XG4gICAgYXdhaXQgY29ycmVjdEZvY3VzZWQod2luZG93cyk7XG4gICAgdXBkYXRlVGFicyh3aW5kb3dzKTtcbn1cblxuLy8gU2V0IHRhYnMgbGlzdCBoZWlnaHQgdG8gYW55IGF2YWlsYWJsZSBoZWlnaHRcbmV4cG9ydCBmdW5jdGlvbiBleHRlbmRUYWJzTGlzdCgpIHtcbiAgICBsZXQgc2VhcmNoQXJlYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2VhcmNoLWFyZWFcIik7XG4gICAgbGV0IHNlYXJjaEFyZWFIZWlnaHQgPSBnZXRBY3R1YWxIZWlnaHQoc2VhcmNoQXJlYSk7XG4gICAgbGV0IHRhYnMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYnNcIik7XG4gICAgdGFicy5zdHlsZS5oZWlnaHQgPSBcImNhbGMoMTAwJSAtIFwiICsgc2VhcmNoQXJlYUhlaWdodCArIFwicHgpXCI7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbi8vIEdldCBhbGwgd2luZG93c1xuZXhwb3J0IGZ1bmN0aW9uIGdldFdpbmRvd3MoKSB7XG4gICAgcmV0dXJuIGJyb3dzZXIud2luZG93cy5nZXRBbGwoe1xuICAgICAgICBwb3B1bGF0ZTogdHJ1ZSxcbiAgICAgICAgd2luZG93VHlwZXM6IFtcIm5vcm1hbFwiLCBcInBvcHVwXCIsIFwiZGV2dG9vbHNcIl1cbiAgICB9KTtcbn1cblxuLy8gR2V0IHRoZSBjb3JyZWN0IGxhc3QgZm9jdXNlZCB3aW5kb3cgaWRcbmV4cG9ydCBmdW5jdGlvbiBnZXRMYXN0Rm9jdXNlZFdpbmRvd0lkKCkge1xuICAgIC8qXG4gICAgRHVlIHRvIGEgYnVnIGluIENocm9taXVtLCB3aW5kb3dzLmdldExhc3RGb2N1c2VkKCkgd2lsbCBzb21ldGltZXNcbiAgICByZXR1cm4gaW5jb3JyZWN0IHdpbmRvd3MuIFNvIGhlcmUsIGluc3RlYWQgb2YgY2FsbGluZyBnZXRMYXN0Rm9jdXNlZCgpLFxuICAgIHdlIGNhbGwgZ2V0Q3VycmVudCgpLlxuICAgIFJlZmVyZW5jZTogaHR0cHM6Ly9jcmJ1Zy5jb20vODA5ODIyXG4gICAgKi9cbiAgICByZXR1cm4gYnJvd3Nlci50YWJzLnF1ZXJ5KHsgbGFzdEZvY3VzZWRXaW5kb3c6IHRydWUgfSkudGhlbihmdW5jdGlvbiAodGFicykge1xuICAgICAgICBpZiAodGFicy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICByZXR1cm4gdGFic1swXS53aW5kb3dJZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gLTE7XG4gICAgfSk7XG59XG5cbi8vIENvcnJlY3QgZm9jdXNlZCBwcm9wZXJ0eSBvZiB3aW5kb3dzXG4vLyBJbiBDaHJvbWl1bSwgd2luZG93LmZvY3VzZWQgZG9lc24ndCB3b3JrLCBzbyB3ZSBtYW51YWxseSBzZXQgaXQgaGVyZVxuZXhwb3J0IGZ1bmN0aW9uIGNvcnJlY3RGb2N1c2VkKHdpbmRvd3MpIHtcbiAgICByZXR1cm4gZ2V0TGFzdEZvY3VzZWRXaW5kb3dJZCgpLnRoZW4oZnVuY3Rpb24gKGxhc3RGb2N1c2VkV2luZG93SWQpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3aW5kb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAod2luZG93c1tpXS5pZCA9PT0gbGFzdEZvY3VzZWRXaW5kb3dJZCkge1xuICAgICAgICAgICAgICAgIHdpbmRvd3NbaV0uZm9jdXNlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuLy8gR2V0IGN1cnJlbnQgd2luZG93XG5leHBvcnQgZnVuY3Rpb24gZ2V0TGFzdEZvY3VzZWRXaW5kb3coKSB7XG4gICAgLy8gcmV0dXJuIGJyb3dzZXIud2luZG93cy5nZXRMYXN0Rm9jdXNlZCh7fSk7IC8vIERvZXNuJ3Qgd29yayBkdWUgdG8gYSBidWcgaW4gQ2hyb21pdW0uIFNlZSBleHBsYW5hdGlvbiBpbiBnZXRMYXN0Rm9jdXNlZFdpbmRvd0lkXG4gICAgcmV0dXJuIGdldExhc3RGb2N1c2VkV2luZG93SWQoKS50aGVuKHdpbmRvd0lkID0+IGJyb3dzZXIud2luZG93cy5nZXQod2luZG93SWQpKTtcbn1cblxuLy8gUnVuIGNvZGUgYWZ0ZXIgYSB0YWIgbG9hZHNcbmV4cG9ydCBmdW5jdGlvbiBydW5BZnRlclRhYkxvYWQodGFiSWQsIGYpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBsZXQgbGlzdGVuZXIgPSAodVRhYklkLCBpbmZvKSA9PiB7XG4gICAgICAgICAgICBpZiAodVRhYklkID09PSB0YWJJZCAmJiBpbmZvLnN0YXR1cyA9PT0gJ2NvbXBsZXRlJykge1xuICAgICAgICAgICAgICAgIGJyb3dzZXIudGFicy5vblVwZGF0ZWQucmVtb3ZlTGlzdGVuZXIobGlzdGVuZXIpO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoZigpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgYnJvd3Nlci50YWJzLm9uVXBkYXRlZC5hZGRMaXN0ZW5lcihsaXN0ZW5lcik7XG4gICAgfSk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9