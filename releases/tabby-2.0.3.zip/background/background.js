/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/background/background.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/background/background.js":
/*!**************************************!*\
  !*** ./src/background/background.js ***!
  \**************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/background/globals.js");
/* harmony import */ var _event_listeners_message__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./event-listeners/message */ "./src/background/event-listeners/message.js");
/* harmony import */ var _event_listeners_tab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./event-listeners/tab */ "./src/background/event-listeners/tab.js");
/* harmony import */ var _event_listeners_window__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./event-listeners/window */ "./src/background/event-listeners/window.js");
/* harmony import */ var _event_listeners_command__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./event-listeners/command */ "./src/background/event-listeners/command.js");
/* harmony import */ var _event_listeners_installed__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-listeners/installed */ "./src/background/event-listeners/installed.js");








if (!browser.runtime.onInstalled.hasListener(_event_listeners_installed__WEBPACK_IMPORTED_MODULE_6__["onInstalled"])) {
    browser.runtime.onInstalled.addListener(_event_listeners_installed__WEBPACK_IMPORTED_MODULE_6__["onInstalled"]);
}

// Set initial tab id
browser.tabs.query({
    active: true,
    currentWindow: true
}).then(tabs => {
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId = tabs[0].id;
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentTabId = true;
});

// Set initial window id
browser.windows.getLastFocused({}).then(w => {
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentWindowId = w.id;
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentWindowId = true;
});

// Watch out for any changes in tabs & windows
browser.tabs.onUpdated.addListener(_event_listeners_tab__WEBPACK_IMPORTED_MODULE_3__["tabUpdated"]);
browser.tabs.onActivated.addListener(_event_listeners_tab__WEBPACK_IMPORTED_MODULE_3__["tabActivated"]);
browser.tabs.onRemoved.addListener(_event_listeners_tab__WEBPACK_IMPORTED_MODULE_3__["tabRemoved"]);
browser.windows.onRemoved.addListener(_event_listeners_window__WEBPACK_IMPORTED_MODULE_4__["windowRemoved"]);
browser.windows.onFocusChanged.addListener(_event_listeners_window__WEBPACK_IMPORTED_MODULE_4__["windowFocusChanged"]);

// Watch out for any commands
browser.commands.onCommand.addListener(_event_listeners_command__WEBPACK_IMPORTED_MODULE_5__["onCommand"]);

// Watch out for any messages
browser.runtime.onMessage.addListener(_event_listeners_message__WEBPACK_IMPORTED_MODULE_2__["onMessage"]);


/***/ }),

/***/ "./src/background/event-listeners/command.js":
/*!***************************************************!*\
  !*** ./src/background/event-listeners/command.js ***!
  \***************************************************/
/*! exports provided: onCommand */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onCommand", function() { return onCommand; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/background/globals.js");



function onCommand(name) {
    switch (name) {
        case "last-used-tab":
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastTabId !== undefined) {
                browser.tabs.update(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastTabId, {
                    active: true
                });
                browser.windows.getLastFocused({}).then(w => {
                    browser.tabs.get(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastTabId).then(tab => {
                        if (w.id !== tab.windowId) {
                            browser.windows.update(tab.windowId, {
                                focused: true
                            });
                            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastTabId = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId;
                        }
                    });
                });
            }
            break;
        case "last-used-window":
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastWindowId !== undefined) {
                browser.windows.update(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastWindowId, {
                    focused: true
                });
            }
            break;
    }
}


/***/ }),

/***/ "./src/background/event-listeners/installed.js":
/*!*****************************************************!*\
  !*** ./src/background/event-listeners/installed.js ***!
  \*****************************************************/
/*! exports provided: onInstalled */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onInstalled", function() { return onInstalled; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _options_states__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../options/states */ "./src/options/states.js");



// On Installed
function onInstalled(details) {
    // Initialize options
    browser.storage.local.get(["options"]).then(data => {
        if (data["options"] === undefined) {
            data.options = _options_states__WEBPACK_IMPORTED_MODULE_1__["INITIAL_OPTIONS"];
            browser.storage.local.set(data);
        }
    });
}


/***/ }),

/***/ "./src/background/event-listeners/message.js":
/*!***************************************************!*\
  !*** ./src/background/event-listeners/message.js ***!
  \***************************************************/
/*! exports provided: onMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMessage", function() { return onMessage; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/background/globals.js");



function onMessage(request, sender) {
    switch (request.type) {
        case "WRONG_TO_RIGHT_GET":
            return Promise.resolve({
                wrongToRight: _globals__WEBPACK_IMPORTED_MODULE_1__["default"].wrongToRight
            });
    }
}


/***/ }),

/***/ "./src/background/event-listeners/tab.js":
/*!***********************************************!*\
  !*** ./src/background/event-listeners/tab.js ***!
  \***********************************************/
/*! exports provided: tabActivated, tabUpdated, tabRemoved */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabActivated", function() { return tabActivated; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabUpdated", function() { return tabUpdated; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabRemoved", function() { return tabRemoved; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/background/globals.js");
/* harmony import */ var _messaging__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../messaging */ "./src/background/messaging.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wrong-to-right */ "./src/background/wrong-to-right.js");





function tabActivated(activeInfo) {
    Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["sendTabMessage"])({
        windowId: activeInfo.windowId,
        tabId: activeInfo.tabId
    }, "ACTIVE_TAB_CHANGED");
    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentTabId) {
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastTabId = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId;
    } else {
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentTabId = true;
    }
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId = activeInfo.tabId;
}

function tabUpdated(tabId, changeInfo, tab) {
    if (changeInfo.favIconUrl !== undefined) {
        Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["sendTabMessage"])({
            tabId: Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_3__["getCorrectTabId"])(tabId),
            favIconUrl: changeInfo.favIconUrl
        }, "TAB_FAV_ICON_CHANGED");
    }
    if (changeInfo.pinned !== undefined) {
        Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["sendTabMessage"])({
            tabId: Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_3__["getCorrectTabId"])(tabId),
            pinned: changeInfo.pinned
        }, "TAB_PINNED_STATUS_CHANGED");
    }
    if (changeInfo.title !== undefined) {
        Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["sendTabMessage"])({
            tabId: Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_3__["getCorrectTabId"])(tabId),
            title: changeInfo.title
        }, "TAB_TITLE_CHANGED");
    }
}

function tabRemoved(tabId, removeInfo) {
    Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["sendTabMessage"])({
        tabId: tabId,
        windowId: removeInfo.windowId,
        windowClosing: removeInfo.isWindowClosing
    }, "TAB_REMOVED");
    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastTabId === tabId) {
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastTabId = undefined;
    }
    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId === tabId) {
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId = undefined;
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentTabId = false;
    }
}


/***/ }),

/***/ "./src/background/event-listeners/window.js":
/*!**************************************************!*\
  !*** ./src/background/event-listeners/window.js ***!
  \**************************************************/
/*! exports provided: windowFocusChanged, windowRemoved */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowFocusChanged", function() { return windowFocusChanged; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowRemoved", function() { return windowRemoved; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/background/globals.js");
/* harmony import */ var _messaging__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../messaging */ "./src/background/messaging.js");




function windowFocusChanged(windowId) {
    if (windowId !== browser.windows.WINDOW_ID_NONE) {
        if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentWindowId) {
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastWindowId = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentWindowId;
        } else {
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentWindowId = true;
        }
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentWindowId = windowId;
        browser.tabs.query({
            active: true,
            windowId: windowId
        }).then(tabs => {
            if (tabs[0].id !== _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId) {
                if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentTabId) {
                    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastTabId = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId;
                } else {
                    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentTabId = true;
                }
                _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentTabId = tabs[0].id;
            }
        });
    }
}

function windowRemoved(windowId) {
    Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["sendTabMessage"])({
        windowId: windowId
    }, "WINDOW_REMOVED");
    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastWindowId === windowId) {
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].lastWindowId = undefined;
    }
    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentWindowId === windowId) {
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].currentWindowId = undefined;
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].dropCurrentWindowId = false;
    }
}


/***/ }),

/***/ "./src/background/globals.js":
/*!***********************************!*\
  !*** ./src/background/globals.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const globals = {
    wrongToRight: undefined,
    lastTabId: undefined,
    currentTabId: undefined,
    lastWindowId: undefined,
    currentWindowId: undefined,
    dropCurrentTabId: false,
    dropCurrentWindowId: false
};
/* harmony default export */ __webpack_exports__["default"] = (globals);


/***/ }),

/***/ "./src/background/messaging.js":
/*!*************************************!*\
  !*** ./src/background/messaging.js ***!
  \*************************************/
/*! exports provided: sendTabMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendTabMessage", function() { return sendTabMessage; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Function to send a message
function sendTabMessage(details, type=undefined) {
    browser.runtime.sendMessage({
        type: type,
        details: details
    });
}


/***/ }),

/***/ "./src/background/wrong-to-right.js":
/*!******************************************!*\
  !*** ./src/background/wrong-to-right.js ***!
  \******************************************/
/*! exports provided: getCorrectTabId */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCorrectTabId", function() { return getCorrectTabId; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/background/globals.js");



_globals__WEBPACK_IMPORTED_MODULE_1__["default"].wrongToRight = {};
let rightToWrong = {};

browser.tabs.onAttached.addListener(fixOnAttached);
browser.tabs.onRemoved.addListener(fixOnRemoved);

function fixOnAttached(tabId, attachInfo) {
    browser.tabs.get(tabId).then(function (tab) {
        if (tabId !== tab.id) {
            let lastWrongId = rightToWrong[tabId];
            if (lastWrongId) {
                delete _globals__WEBPACK_IMPORTED_MODULE_1__["default"].wrongToRight[lastWrongId];
            }
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].wrongToRight[tab.id] = tabId;
            rightToWrong[tabId] = tab.id;
        }
    });
}

function fixOnRemoved(tabId, removeInfo) {
    let wrongId = rightToWrong[tabId];
    if (wrongId) {
        delete _globals__WEBPACK_IMPORTED_MODULE_1__["default"].wrongToRight[wrongId];
    }
    delete rightToWrong[tabId];
}

function getCorrectTabId(tabId) {
    return _globals__WEBPACK_IMPORTED_MODULE_1__["default"].wrongToRight[tabId] || tabId;
}

/***/ }),

/***/ "./src/options/states.js":
/*!*******************************!*\
  !*** ./src/options/states.js ***!
  \*******************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, INITIAL_OPTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return SWITCH_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return SWITCH_LOCKED_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return SWITCH_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return SWITCH_LOCKED_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "INITIAL_OPTIONS", function() { return INITIAL_OPTIONS; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const SWITCH_ON = 1;
const SWITCH_LOCKED_ON = 2;
const SWITCH_OFF = 0;
const SWITCH_LOCKED_OFF = -1;

const INITIAL_OPTIONS = {
    popup: {
        size: {
            width: 730,
            height: 450
        },
        scale: 1.0,
        showDetails: SWITCH_ON,
        showPreview: SWITCH_ON,
        hideAfterTabSelection: SWITCH_ON,
        searchInURLs: SWITCH_OFF
    }
};
if (Polyfill__WEBPACK_IMPORTED_MODULE_0__["TargetBrowser"] === "chrome") {
    INITIAL_OPTIONS.popup.showPreview = SWITCH_LOCKED_OFF;
    INITIAL_OPTIONS.popup.hideAfterTabSelection = SWITCH_LOCKED_ON;
}


/***/ }),

/***/ "./src/polyfill.js":
/*!*************************!*\
  !*** ./src/polyfill.js ***!
  \*************************/
/*! exports provided: TargetBrowser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetBrowser", function() { return TargetBrowser; });
const TargetBrowser = "webext";

if (false) {}

if (!Array.from) {
    Array.from = (function () {
        let toStr = Object.prototype.toString;
        let isCallable = function (fn) {
            return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
        };
        let toInteger = function (value) {
            let number = Number(value);
            if (isNaN(number)) { return 0; }
            if (number === 0 || !isFinite(number)) { return number; }
            return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
        };
        let maxSafeInteger = Math.pow(2, 53) - 1;
        let toLength = function (value) {
            let len = toInteger(value);
            return Math.min(Math.max(len, 0), maxSafeInteger);
        };

        // The length property of the from method is 1.
        return function from(arrayLike/*, mapFn, thisArg */) {
            // 1. Let C be the this value.
            let C = this;

            // 2. Let items be ToObject(arrayLike).
            let items = Object(arrayLike);

            // 3. ReturnIfAbrupt(items).
            if (arrayLike == null) {
                throw new TypeError('Array.from requires an array-like object - not null or undefined');
            }

            // 4. If mapfn is undefined, then let mapping be false.
            let mapFn = arguments.length > 1 ? arguments[1] : void undefined;
            let T;
            if (typeof mapFn !== 'undefined') {
                // 5. else
                // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
                if (!isCallable(mapFn)) {
                    throw new TypeError('Array.from: when provided, the second argument must be a function');
                }

                // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
                if (arguments.length > 2) {
                    T = arguments[2];
                }
            }

            // 10. Let lenValue be Get(items, "length").
            // 11. Let len be ToLength(lenValue).
            let len = toLength(items.length);

            // 13. If IsConstructor(C) is true, then
            // 13. a. Let A be the result of calling the [[Construct]] internal method 
            // of C with an argument list containing the single item len.
            // 14. a. Else, Let A be ArrayCreate(len).
            let A = isCallable(C) ? Object(new C(len)) : new Array(len);

            // 16. Let k be 0.
            let k = 0;
            // 17. Repeat, while k < len… (also steps a - h)
            let kValue;
            while (k < len) {
                kValue = items[k];
                if (mapFn) {
                    A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
                } else {
                    A[k] = kValue;
                }
                k += 1;
            }
            // 18. Let putStatus be Put(A, "length", len, true).
            A.length = len;
            // 20. Return A.
            return A;
        };
    }());
}


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2JhY2tncm91bmQvYmFja2dyb3VuZC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvYmFja2dyb3VuZC9ldmVudC1saXN0ZW5lcnMvY29tbWFuZC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvYmFja2dyb3VuZC9ldmVudC1saXN0ZW5lcnMvaW5zdGFsbGVkLmpzIiwid2VicGFjazovLy8uL3NyYy9iYWNrZ3JvdW5kL2V2ZW50LWxpc3RlbmVycy9tZXNzYWdlLmpzIiwid2VicGFjazovLy8uL3NyYy9iYWNrZ3JvdW5kL2V2ZW50LWxpc3RlbmVycy90YWIuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2JhY2tncm91bmQvZXZlbnQtbGlzdGVuZXJzL3dpbmRvdy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvYmFja2dyb3VuZC9nbG9iYWxzLmpzIiwid2VicGFjazovLy8uL3NyYy9iYWNrZ3JvdW5kL21lc3NhZ2luZy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvYmFja2dyb3VuZC93cm9uZy10by1yaWdodC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvb3B0aW9ucy9zdGF0ZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvbHlmaWxsLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNRO0FBQzRCO0FBQ3VCO0FBQ0E7QUFDdkI7QUFDSTs7QUFFekQsNkNBQTZDLHNFQUFXO0FBQ3hELDRDQUE0QyxzRUFBVztBQUN2RDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRCxJQUFJLGdEQUFDO0FBQ0wsSUFBSSxnREFBQztBQUNMLENBQUM7O0FBRUQ7QUFDQSxpQ0FBaUM7QUFDakMsSUFBSSxnREFBQztBQUNMLElBQUksZ0RBQUM7QUFDTCxDQUFDOztBQUVEO0FBQ0EsbUNBQW1DLCtEQUFVO0FBQzdDLHFDQUFxQyxpRUFBWTtBQUNqRCxtQ0FBbUMsK0RBQVU7QUFDN0Msc0NBQXNDLHFFQUFhO0FBQ25ELDJDQUEyQywwRUFBa0I7O0FBRTdEO0FBQ0EsdUNBQXVDLGtFQUFTOztBQUVoRDtBQUNBLHNDQUFzQyxrRUFBUzs7Ozs7Ozs7Ozs7OztBQ3RDL0M7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUzs7QUFFbkI7QUFDUDtBQUNBO0FBQ0EsZ0JBQWdCLGdEQUFDO0FBQ2pCLG9DQUFvQyxnREFBQztBQUNyQztBQUNBLGlCQUFpQjtBQUNqQixpREFBaUQ7QUFDakQscUNBQXFDLGdEQUFDO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QjtBQUM3Qiw0QkFBNEIsZ0RBQUMsYUFBYSxnREFBQztBQUMzQztBQUNBLHFCQUFxQjtBQUNyQixpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLGdEQUFDO0FBQ2pCLHVDQUF1QyxnREFBQztBQUN4QztBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQzlCQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNxQzs7QUFFdEQ7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQiwrREFBZTtBQUMxQztBQUNBO0FBQ0EsS0FBSztBQUNMOzs7Ozs7Ozs7Ozs7O0FDWkE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUzs7QUFFbkI7QUFDUDtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsZ0RBQUM7QUFDL0IsYUFBYTtBQUNiO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNWQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ1M7QUFDbUI7QUFDTTs7QUFFNUM7QUFDUCxJQUFJLGlFQUFjO0FBQ2xCO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsUUFBUSxnREFBQztBQUNULFFBQVEsZ0RBQUMsYUFBYSxnREFBQztBQUN2QixLQUFLO0FBQ0wsUUFBUSxnREFBQztBQUNUO0FBQ0EsSUFBSSxnREFBQztBQUNMOztBQUVPO0FBQ1A7QUFDQSxRQUFRLGlFQUFjO0FBQ3RCLG1CQUFtQix1RUFBZTtBQUNsQztBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsUUFBUSxpRUFBYztBQUN0QixtQkFBbUIsdUVBQWU7QUFDbEM7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLFFBQVEsaUVBQWM7QUFDdEIsbUJBQW1CLHVFQUFlO0FBQ2xDO0FBQ0EsU0FBUztBQUNUO0FBQ0E7O0FBRU87QUFDUCxJQUFJLGlFQUFjO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxRQUFRLGdEQUFDO0FBQ1QsUUFBUSxnREFBQztBQUNUO0FBQ0EsUUFBUSxnREFBQztBQUNULFFBQVEsZ0RBQUM7QUFDVCxRQUFRLGdEQUFDO0FBQ1Q7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3BEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUztBQUNtQjs7QUFFdEM7QUFDUDtBQUNBLFlBQVksZ0RBQUM7QUFDYixZQUFZLGdEQUFDLGdCQUFnQixnREFBQztBQUM5QixTQUFTO0FBQ1QsWUFBWSxnREFBQztBQUNiO0FBQ0EsUUFBUSxnREFBQztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCwrQkFBK0IsZ0RBQUM7QUFDaEMsb0JBQW9CLGdEQUFDO0FBQ3JCLG9CQUFvQixnREFBQyxhQUFhLGdEQUFDO0FBQ25DLGlCQUFpQjtBQUNqQixvQkFBb0IsZ0RBQUM7QUFDckI7QUFDQSxnQkFBZ0IsZ0RBQUM7QUFDakI7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7QUFFTztBQUNQLElBQUksaUVBQWM7QUFDbEI7QUFDQSxLQUFLO0FBQ0wsUUFBUSxnREFBQztBQUNULFFBQVEsZ0RBQUM7QUFDVDtBQUNBLFFBQVEsZ0RBQUM7QUFDVCxRQUFRLGdEQUFDO0FBQ1QsUUFBUSxnREFBQztBQUNUO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN2Q0E7QUFBQTtBQUFpQjs7QUFFakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2Usc0VBQU8sRUFBQzs7Ozs7Ozs7Ozs7OztBQ1h2QjtBQUFBO0FBQUE7QUFBaUI7O0FBRWpCO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7Ozs7Ozs7Ozs7Ozs7QUNSQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNROztBQUV6QixnREFBQztBQUNEOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixnREFBQztBQUN4QjtBQUNBLFlBQVksZ0RBQUM7QUFDYjtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsZ0RBQUM7QUFDaEI7QUFDQTtBQUNBOztBQUVPO0FBQ1AsV0FBVyxnREFBQztBQUNaLEM7Ozs7Ozs7Ozs7OztBQ2hDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF3Qzs7QUFFakM7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksc0RBQWE7QUFDakI7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDdkJBO0FBQUE7QUFBTyxzQkFBc0IsUUFBTTs7QUFFbkMsSUFBSSxLQUFtQixFQUFFLEVBRXhCOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsVUFBVTtBQUMxQyxvREFBb0QsZUFBZTtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxtRUFBbUU7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wiLCJmaWxlIjoiYmFja2dyb3VuZC9iYWNrZ3JvdW5kLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9zcmMvYmFja2dyb3VuZC9iYWNrZ3JvdW5kLmpzXCIpO1xuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IEcgZnJvbSBcIi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBvbk1lc3NhZ2UgfSBmcm9tIFwiLi9ldmVudC1saXN0ZW5lcnMvbWVzc2FnZVwiXG5pbXBvcnQgeyB0YWJBY3RpdmF0ZWQsIHRhYlVwZGF0ZWQsIHRhYlJlbW92ZWQgfSBmcm9tIFwiLi9ldmVudC1saXN0ZW5lcnMvdGFiXCJcbmltcG9ydCB7IHdpbmRvd0ZvY3VzQ2hhbmdlZCwgd2luZG93UmVtb3ZlZCB9IGZyb20gXCIuL2V2ZW50LWxpc3RlbmVycy93aW5kb3dcIlxuaW1wb3J0IHsgb25Db21tYW5kIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL2NvbW1hbmRcIlxuaW1wb3J0IHsgb25JbnN0YWxsZWQgfSBmcm9tIFwiLi9ldmVudC1saXN0ZW5lcnMvaW5zdGFsbGVkXCJcblxuaWYgKCFicm93c2VyLnJ1bnRpbWUub25JbnN0YWxsZWQuaGFzTGlzdGVuZXIob25JbnN0YWxsZWQpKSB7XG4gICAgYnJvd3Nlci5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKG9uSW5zdGFsbGVkKTtcbn1cblxuLy8gU2V0IGluaXRpYWwgdGFiIGlkXG5icm93c2VyLnRhYnMucXVlcnkoe1xuICAgIGFjdGl2ZTogdHJ1ZSxcbiAgICBjdXJyZW50V2luZG93OiB0cnVlXG59KS50aGVuKHRhYnMgPT4ge1xuICAgIEcuY3VycmVudFRhYklkID0gdGFic1swXS5pZDtcbiAgICBHLmRyb3BDdXJyZW50VGFiSWQgPSB0cnVlO1xufSk7XG5cbi8vIFNldCBpbml0aWFsIHdpbmRvdyBpZFxuYnJvd3Nlci53aW5kb3dzLmdldExhc3RGb2N1c2VkKHt9KS50aGVuKHcgPT4ge1xuICAgIEcuY3VycmVudFdpbmRvd0lkID0gdy5pZDtcbiAgICBHLmRyb3BDdXJyZW50V2luZG93SWQgPSB0cnVlO1xufSk7XG5cbi8vIFdhdGNoIG91dCBmb3IgYW55IGNoYW5nZXMgaW4gdGFicyAmIHdpbmRvd3NcbmJyb3dzZXIudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIodGFiVXBkYXRlZCk7XG5icm93c2VyLnRhYnMub25BY3RpdmF0ZWQuYWRkTGlzdGVuZXIodGFiQWN0aXZhdGVkKTtcbmJyb3dzZXIudGFicy5vblJlbW92ZWQuYWRkTGlzdGVuZXIodGFiUmVtb3ZlZCk7XG5icm93c2VyLndpbmRvd3Mub25SZW1vdmVkLmFkZExpc3RlbmVyKHdpbmRvd1JlbW92ZWQpO1xuYnJvd3Nlci53aW5kb3dzLm9uRm9jdXNDaGFuZ2VkLmFkZExpc3RlbmVyKHdpbmRvd0ZvY3VzQ2hhbmdlZCk7XG5cbi8vIFdhdGNoIG91dCBmb3IgYW55IGNvbW1hbmRzXG5icm93c2VyLmNvbW1hbmRzLm9uQ29tbWFuZC5hZGRMaXN0ZW5lcihvbkNvbW1hbmQpO1xuXG4vLyBXYXRjaCBvdXQgZm9yIGFueSBtZXNzYWdlc1xuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihvbk1lc3NhZ2UpO1xuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IEcgZnJvbSBcIi4uL2dsb2JhbHNcIlxuXG5leHBvcnQgZnVuY3Rpb24gb25Db21tYW5kKG5hbWUpIHtcbiAgICBzd2l0Y2ggKG5hbWUpIHtcbiAgICAgICAgY2FzZSBcImxhc3QtdXNlZC10YWJcIjpcbiAgICAgICAgICAgIGlmIChHLmxhc3RUYWJJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgYnJvd3Nlci50YWJzLnVwZGF0ZShHLmxhc3RUYWJJZCwge1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmU6IHRydWVcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBicm93c2VyLndpbmRvd3MuZ2V0TGFzdEZvY3VzZWQoe30pLnRoZW4odyA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGJyb3dzZXIudGFicy5nZXQoRy5sYXN0VGFiSWQpLnRoZW4odGFiID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh3LmlkICE9PSB0YWIud2luZG93SWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicm93c2VyLndpbmRvd3MudXBkYXRlKHRhYi53aW5kb3dJZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1c2VkOiB0cnVlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRy5sYXN0VGFiSWQgPSBHLmN1cnJlbnRUYWJJZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcImxhc3QtdXNlZC13aW5kb3dcIjpcbiAgICAgICAgICAgIGlmIChHLmxhc3RXaW5kb3dJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgYnJvd3Nlci53aW5kb3dzLnVwZGF0ZShHLmxhc3RXaW5kb3dJZCwge1xuICAgICAgICAgICAgICAgICAgICBmb2N1c2VkOiB0cnVlXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICB9XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgeyBJTklUSUFMX09QVElPTlMgfSBmcm9tIFwiLi4vLi4vb3B0aW9ucy9zdGF0ZXNcIlxuXG4vLyBPbiBJbnN0YWxsZWRcbmV4cG9ydCBmdW5jdGlvbiBvbkluc3RhbGxlZChkZXRhaWxzKSB7XG4gICAgLy8gSW5pdGlhbGl6ZSBvcHRpb25zXG4gICAgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChbXCJvcHRpb25zXCJdKS50aGVuKGRhdGEgPT4ge1xuICAgICAgICBpZiAoZGF0YVtcIm9wdGlvbnNcIl0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgZGF0YS5vcHRpb25zID0gSU5JVElBTF9PUFRJT05TO1xuICAgICAgICAgICAgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldChkYXRhKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IEcgZnJvbSBcIi4uL2dsb2JhbHNcIlxuXG5leHBvcnQgZnVuY3Rpb24gb25NZXNzYWdlKHJlcXVlc3QsIHNlbmRlcikge1xuICAgIHN3aXRjaCAocmVxdWVzdC50eXBlKSB7XG4gICAgICAgIGNhc2UgXCJXUk9OR19UT19SSUdIVF9HRVRcIjpcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgICAgICAgICAgIHdyb25nVG9SaWdodDogRy53cm9uZ1RvUmlnaHRcbiAgICAgICAgICAgIH0pO1xuICAgIH1cbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCBHIGZyb20gXCIuLi9nbG9iYWxzXCJcbmltcG9ydCB7IHNlbmRUYWJNZXNzYWdlIH0gZnJvbSBcIi4uL21lc3NhZ2luZ1wiXG5pbXBvcnQgeyBnZXRDb3JyZWN0VGFiSWQgfSBmcm9tIFwiLi4vd3JvbmctdG8tcmlnaHRcIlxuXG5leHBvcnQgZnVuY3Rpb24gdGFiQWN0aXZhdGVkKGFjdGl2ZUluZm8pIHtcbiAgICBzZW5kVGFiTWVzc2FnZSh7XG4gICAgICAgIHdpbmRvd0lkOiBhY3RpdmVJbmZvLndpbmRvd0lkLFxuICAgICAgICB0YWJJZDogYWN0aXZlSW5mby50YWJJZFxuICAgIH0sIFwiQUNUSVZFX1RBQl9DSEFOR0VEXCIpO1xuICAgIGlmIChHLmRyb3BDdXJyZW50VGFiSWQpIHtcbiAgICAgICAgRy5sYXN0VGFiSWQgPSBHLmN1cnJlbnRUYWJJZDtcbiAgICB9IGVsc2Uge1xuICAgICAgICBHLmRyb3BDdXJyZW50VGFiSWQgPSB0cnVlO1xuICAgIH1cbiAgICBHLmN1cnJlbnRUYWJJZCA9IGFjdGl2ZUluZm8udGFiSWQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0YWJVcGRhdGVkKHRhYklkLCBjaGFuZ2VJbmZvLCB0YWIpIHtcbiAgICBpZiAoY2hhbmdlSW5mby5mYXZJY29uVXJsICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgc2VuZFRhYk1lc3NhZ2Uoe1xuICAgICAgICAgICAgdGFiSWQ6IGdldENvcnJlY3RUYWJJZCh0YWJJZCksXG4gICAgICAgICAgICBmYXZJY29uVXJsOiBjaGFuZ2VJbmZvLmZhdkljb25VcmxcbiAgICAgICAgfSwgXCJUQUJfRkFWX0lDT05fQ0hBTkdFRFwiKTtcbiAgICB9XG4gICAgaWYgKGNoYW5nZUluZm8ucGlubmVkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgc2VuZFRhYk1lc3NhZ2Uoe1xuICAgICAgICAgICAgdGFiSWQ6IGdldENvcnJlY3RUYWJJZCh0YWJJZCksXG4gICAgICAgICAgICBwaW5uZWQ6IGNoYW5nZUluZm8ucGlubmVkXG4gICAgICAgIH0sIFwiVEFCX1BJTk5FRF9TVEFUVVNfQ0hBTkdFRFwiKTtcbiAgICB9XG4gICAgaWYgKGNoYW5nZUluZm8udGl0bGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBzZW5kVGFiTWVzc2FnZSh7XG4gICAgICAgICAgICB0YWJJZDogZ2V0Q29ycmVjdFRhYklkKHRhYklkKSxcbiAgICAgICAgICAgIHRpdGxlOiBjaGFuZ2VJbmZvLnRpdGxlXG4gICAgICAgIH0sIFwiVEFCX1RJVExFX0NIQU5HRURcIik7XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdGFiUmVtb3ZlZCh0YWJJZCwgcmVtb3ZlSW5mbykge1xuICAgIHNlbmRUYWJNZXNzYWdlKHtcbiAgICAgICAgdGFiSWQ6IHRhYklkLFxuICAgICAgICB3aW5kb3dJZDogcmVtb3ZlSW5mby53aW5kb3dJZCxcbiAgICAgICAgd2luZG93Q2xvc2luZzogcmVtb3ZlSW5mby5pc1dpbmRvd0Nsb3NpbmdcbiAgICB9LCBcIlRBQl9SRU1PVkVEXCIpO1xuICAgIGlmIChHLmxhc3RUYWJJZCA9PT0gdGFiSWQpIHtcbiAgICAgICAgRy5sYXN0VGFiSWQgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmIChHLmN1cnJlbnRUYWJJZCA9PT0gdGFiSWQpIHtcbiAgICAgICAgRy5jdXJyZW50VGFiSWQgPSB1bmRlZmluZWQ7XG4gICAgICAgIEcuZHJvcEN1cnJlbnRUYWJJZCA9IGZhbHNlO1xuICAgIH1cbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCBHIGZyb20gXCIuLi9nbG9iYWxzXCJcbmltcG9ydCB7IHNlbmRUYWJNZXNzYWdlIH0gZnJvbSBcIi4uL21lc3NhZ2luZ1wiXG5cbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dGb2N1c0NoYW5nZWQod2luZG93SWQpIHtcbiAgICBpZiAod2luZG93SWQgIT09IGJyb3dzZXIud2luZG93cy5XSU5ET1dfSURfTk9ORSkge1xuICAgICAgICBpZiAoRy5kcm9wQ3VycmVudFdpbmRvd0lkKSB7XG4gICAgICAgICAgICBHLmxhc3RXaW5kb3dJZCA9IEcuY3VycmVudFdpbmRvd0lkO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgRy5kcm9wQ3VycmVudFdpbmRvd0lkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBHLmN1cnJlbnRXaW5kb3dJZCA9IHdpbmRvd0lkO1xuICAgICAgICBicm93c2VyLnRhYnMucXVlcnkoe1xuICAgICAgICAgICAgYWN0aXZlOiB0cnVlLFxuICAgICAgICAgICAgd2luZG93SWQ6IHdpbmRvd0lkXG4gICAgICAgIH0pLnRoZW4odGFicyA9PiB7XG4gICAgICAgICAgICBpZiAodGFic1swXS5pZCAhPT0gRy5jdXJyZW50VGFiSWQpIHtcbiAgICAgICAgICAgICAgICBpZiAoRy5kcm9wQ3VycmVudFRhYklkKSB7XG4gICAgICAgICAgICAgICAgICAgIEcubGFzdFRhYklkID0gRy5jdXJyZW50VGFiSWQ7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgRy5kcm9wQ3VycmVudFRhYklkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgRy5jdXJyZW50VGFiSWQgPSB0YWJzWzBdLmlkO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dSZW1vdmVkKHdpbmRvd0lkKSB7XG4gICAgc2VuZFRhYk1lc3NhZ2Uoe1xuICAgICAgICB3aW5kb3dJZDogd2luZG93SWRcbiAgICB9LCBcIldJTkRPV19SRU1PVkVEXCIpO1xuICAgIGlmIChHLmxhc3RXaW5kb3dJZCA9PT0gd2luZG93SWQpIHtcbiAgICAgICAgRy5sYXN0V2luZG93SWQgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmIChHLmN1cnJlbnRXaW5kb3dJZCA9PT0gd2luZG93SWQpIHtcbiAgICAgICAgRy5jdXJyZW50V2luZG93SWQgPSB1bmRlZmluZWQ7XG4gICAgICAgIEcuZHJvcEN1cnJlbnRXaW5kb3dJZCA9IGZhbHNlO1xuICAgIH1cbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuY29uc3QgZ2xvYmFscyA9IHtcbiAgICB3cm9uZ1RvUmlnaHQ6IHVuZGVmaW5lZCxcbiAgICBsYXN0VGFiSWQ6IHVuZGVmaW5lZCxcbiAgICBjdXJyZW50VGFiSWQ6IHVuZGVmaW5lZCxcbiAgICBsYXN0V2luZG93SWQ6IHVuZGVmaW5lZCxcbiAgICBjdXJyZW50V2luZG93SWQ6IHVuZGVmaW5lZCxcbiAgICBkcm9wQ3VycmVudFRhYklkOiBmYWxzZSxcbiAgICBkcm9wQ3VycmVudFdpbmRvd0lkOiBmYWxzZVxufTtcbmV4cG9ydCBkZWZhdWx0IGdsb2JhbHM7XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbi8vIEZ1bmN0aW9uIHRvIHNlbmQgYSBtZXNzYWdlXG5leHBvcnQgZnVuY3Rpb24gc2VuZFRhYk1lc3NhZ2UoZGV0YWlscywgdHlwZT11bmRlZmluZWQpIHtcbiAgICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICBkZXRhaWxzOiBkZXRhaWxzXG4gICAgfSk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi9nbG9iYWxzXCJcblxuRy53cm9uZ1RvUmlnaHQgPSB7fTtcbmxldCByaWdodFRvV3JvbmcgPSB7fTtcblxuYnJvd3Nlci50YWJzLm9uQXR0YWNoZWQuYWRkTGlzdGVuZXIoZml4T25BdHRhY2hlZCk7XG5icm93c2VyLnRhYnMub25SZW1vdmVkLmFkZExpc3RlbmVyKGZpeE9uUmVtb3ZlZCk7XG5cbmZ1bmN0aW9uIGZpeE9uQXR0YWNoZWQodGFiSWQsIGF0dGFjaEluZm8pIHtcbiAgICBicm93c2VyLnRhYnMuZ2V0KHRhYklkKS50aGVuKGZ1bmN0aW9uICh0YWIpIHtcbiAgICAgICAgaWYgKHRhYklkICE9PSB0YWIuaWQpIHtcbiAgICAgICAgICAgIGxldCBsYXN0V3JvbmdJZCA9IHJpZ2h0VG9Xcm9uZ1t0YWJJZF07XG4gICAgICAgICAgICBpZiAobGFzdFdyb25nSWQpIHtcbiAgICAgICAgICAgICAgICBkZWxldGUgRy53cm9uZ1RvUmlnaHRbbGFzdFdyb25nSWRdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgRy53cm9uZ1RvUmlnaHRbdGFiLmlkXSA9IHRhYklkO1xuICAgICAgICAgICAgcmlnaHRUb1dyb25nW3RhYklkXSA9IHRhYi5pZDtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBmaXhPblJlbW92ZWQodGFiSWQsIHJlbW92ZUluZm8pIHtcbiAgICBsZXQgd3JvbmdJZCA9IHJpZ2h0VG9Xcm9uZ1t0YWJJZF07XG4gICAgaWYgKHdyb25nSWQpIHtcbiAgICAgICAgZGVsZXRlIEcud3JvbmdUb1JpZ2h0W3dyb25nSWRdO1xuICAgIH1cbiAgICBkZWxldGUgcmlnaHRUb1dyb25nW3RhYklkXTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldENvcnJlY3RUYWJJZCh0YWJJZCkge1xuICAgIHJldHVybiBHLndyb25nVG9SaWdodFt0YWJJZF0gfHwgdGFiSWQ7XG59IiwiaW1wb3J0IHsgVGFyZ2V0QnJvd3NlciB9IGZyb20gXCJQb2x5ZmlsbFwiXG5cbmV4cG9ydCBjb25zdCBTV0lUQ0hfT04gPSAxO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9MT0NLRURfT04gPSAyO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9PRkYgPSAwO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9MT0NLRURfT0ZGID0gLTE7XG5cbmV4cG9ydCBjb25zdCBJTklUSUFMX09QVElPTlMgPSB7XG4gICAgcG9wdXA6IHtcbiAgICAgICAgc2l6ZToge1xuICAgICAgICAgICAgd2lkdGg6IDczMCxcbiAgICAgICAgICAgIGhlaWdodDogNDUwXG4gICAgICAgIH0sXG4gICAgICAgIHNjYWxlOiAxLjAsXG4gICAgICAgIHNob3dEZXRhaWxzOiBTV0lUQ0hfT04sXG4gICAgICAgIHNob3dQcmV2aWV3OiBTV0lUQ0hfT04sXG4gICAgICAgIGhpZGVBZnRlclRhYlNlbGVjdGlvbjogU1dJVENIX09OLFxuICAgICAgICBzZWFyY2hJblVSTHM6IFNXSVRDSF9PRkZcbiAgICB9XG59O1xuaWYgKFRhcmdldEJyb3dzZXIgPT09IFwiY2hyb21lXCIpIHtcbiAgICBJTklUSUFMX09QVElPTlMucG9wdXAuc2hvd1ByZXZpZXcgPSBTV0lUQ0hfTE9DS0VEX09GRjtcbiAgICBJTklUSUFMX09QVElPTlMucG9wdXAuaGlkZUFmdGVyVGFiU2VsZWN0aW9uID0gU1dJVENIX0xPQ0tFRF9PTjtcbn1cbiIsImV4cG9ydCBjb25zdCBUYXJnZXRCcm93c2VyID0gVEFSR0VUO1xuXG5pZiAoVEFSR0VUID09PSBcImNocm9tZVwiKSB7XG4gICAgd2luZG93W1wiYnJvd3NlclwiXSA9IHJlcXVpcmUoXCJ3ZWJleHRlbnNpb24tcG9seWZpbGxcIik7XG59XG5cbmlmICghQXJyYXkuZnJvbSkge1xuICAgIEFycmF5LmZyb20gPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICBsZXQgdG9TdHIgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xuICAgICAgICBsZXQgaXNDYWxsYWJsZSA9IGZ1bmN0aW9uIChmbikge1xuICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiBmbiA9PT0gJ2Z1bmN0aW9uJyB8fCB0b1N0ci5jYWxsKGZuKSA9PT0gJ1tvYmplY3QgRnVuY3Rpb25dJztcbiAgICAgICAgfTtcbiAgICAgICAgbGV0IHRvSW50ZWdlciA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgbGV0IG51bWJlciA9IE51bWJlcih2YWx1ZSk7XG4gICAgICAgICAgICBpZiAoaXNOYU4obnVtYmVyKSkgeyByZXR1cm4gMDsgfVxuICAgICAgICAgICAgaWYgKG51bWJlciA9PT0gMCB8fCAhaXNGaW5pdGUobnVtYmVyKSkgeyByZXR1cm4gbnVtYmVyOyB9XG4gICAgICAgICAgICByZXR1cm4gKG51bWJlciA+IDAgPyAxIDogLTEpICogTWF0aC5mbG9vcihNYXRoLmFicyhudW1iZXIpKTtcbiAgICAgICAgfTtcbiAgICAgICAgbGV0IG1heFNhZmVJbnRlZ2VyID0gTWF0aC5wb3coMiwgNTMpIC0gMTtcbiAgICAgICAgbGV0IHRvTGVuZ3RoID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBsZXQgbGVuID0gdG9JbnRlZ2VyKHZhbHVlKTtcbiAgICAgICAgICAgIHJldHVybiBNYXRoLm1pbihNYXRoLm1heChsZW4sIDApLCBtYXhTYWZlSW50ZWdlcik7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gVGhlIGxlbmd0aCBwcm9wZXJ0eSBvZiB0aGUgZnJvbSBtZXRob2QgaXMgMS5cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGZyb20oYXJyYXlMaWtlLyosIG1hcEZuLCB0aGlzQXJnICovKSB7XG4gICAgICAgICAgICAvLyAxLiBMZXQgQyBiZSB0aGUgdGhpcyB2YWx1ZS5cbiAgICAgICAgICAgIGxldCBDID0gdGhpcztcblxuICAgICAgICAgICAgLy8gMi4gTGV0IGl0ZW1zIGJlIFRvT2JqZWN0KGFycmF5TGlrZSkuXG4gICAgICAgICAgICBsZXQgaXRlbXMgPSBPYmplY3QoYXJyYXlMaWtlKTtcblxuICAgICAgICAgICAgLy8gMy4gUmV0dXJuSWZBYnJ1cHQoaXRlbXMpLlxuICAgICAgICAgICAgaWYgKGFycmF5TGlrZSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJyYXkuZnJvbSByZXF1aXJlcyBhbiBhcnJheS1saWtlIG9iamVjdCAtIG5vdCBudWxsIG9yIHVuZGVmaW5lZCcpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyA0LiBJZiBtYXBmbiBpcyB1bmRlZmluZWQsIHRoZW4gbGV0IG1hcHBpbmcgYmUgZmFsc2UuXG4gICAgICAgICAgICBsZXQgbWFwRm4gPSBhcmd1bWVudHMubGVuZ3RoID4gMSA/IGFyZ3VtZW50c1sxXSA6IHZvaWQgdW5kZWZpbmVkO1xuICAgICAgICAgICAgbGV0IFQ7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1hcEZuICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIC8vIDUuIGVsc2VcbiAgICAgICAgICAgICAgICAvLyA1LiBhIElmIElzQ2FsbGFibGUobWFwZm4pIGlzIGZhbHNlLCB0aHJvdyBhIFR5cGVFcnJvciBleGNlcHRpb24uXG4gICAgICAgICAgICAgICAgaWYgKCFpc0NhbGxhYmxlKG1hcEZuKSkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcnJheS5mcm9tOiB3aGVuIHByb3ZpZGVkLCB0aGUgc2Vjb25kIGFyZ3VtZW50IG11c3QgYmUgYSBmdW5jdGlvbicpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIDUuIGIuIElmIHRoaXNBcmcgd2FzIHN1cHBsaWVkLCBsZXQgVCBiZSB0aGlzQXJnOyBlbHNlIGxldCBUIGJlIHVuZGVmaW5lZC5cbiAgICAgICAgICAgICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgVCA9IGFyZ3VtZW50c1syXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIDEwLiBMZXQgbGVuVmFsdWUgYmUgR2V0KGl0ZW1zLCBcImxlbmd0aFwiKS5cbiAgICAgICAgICAgIC8vIDExLiBMZXQgbGVuIGJlIFRvTGVuZ3RoKGxlblZhbHVlKS5cbiAgICAgICAgICAgIGxldCBsZW4gPSB0b0xlbmd0aChpdGVtcy5sZW5ndGgpO1xuXG4gICAgICAgICAgICAvLyAxMy4gSWYgSXNDb25zdHJ1Y3RvcihDKSBpcyB0cnVlLCB0aGVuXG4gICAgICAgICAgICAvLyAxMy4gYS4gTGV0IEEgYmUgdGhlIHJlc3VsdCBvZiBjYWxsaW5nIHRoZSBbW0NvbnN0cnVjdF1dIGludGVybmFsIG1ldGhvZCBcbiAgICAgICAgICAgIC8vIG9mIEMgd2l0aCBhbiBhcmd1bWVudCBsaXN0IGNvbnRhaW5pbmcgdGhlIHNpbmdsZSBpdGVtIGxlbi5cbiAgICAgICAgICAgIC8vIDE0LiBhLiBFbHNlLCBMZXQgQSBiZSBBcnJheUNyZWF0ZShsZW4pLlxuICAgICAgICAgICAgbGV0IEEgPSBpc0NhbGxhYmxlKEMpID8gT2JqZWN0KG5ldyBDKGxlbikpIDogbmV3IEFycmF5KGxlbik7XG5cbiAgICAgICAgICAgIC8vIDE2LiBMZXQgayBiZSAwLlxuICAgICAgICAgICAgbGV0IGsgPSAwO1xuICAgICAgICAgICAgLy8gMTcuIFJlcGVhdCwgd2hpbGUgayA8IGxlbuKApiAoYWxzbyBzdGVwcyBhIC0gaClcbiAgICAgICAgICAgIGxldCBrVmFsdWU7XG4gICAgICAgICAgICB3aGlsZSAoayA8IGxlbikge1xuICAgICAgICAgICAgICAgIGtWYWx1ZSA9IGl0ZW1zW2tdO1xuICAgICAgICAgICAgICAgIGlmIChtYXBGbikge1xuICAgICAgICAgICAgICAgICAgICBBW2tdID0gdHlwZW9mIFQgPT09ICd1bmRlZmluZWQnID8gbWFwRm4oa1ZhbHVlLCBrKSA6IG1hcEZuLmNhbGwoVCwga1ZhbHVlLCBrKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBBW2tdID0ga1ZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBrICs9IDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyAxOC4gTGV0IHB1dFN0YXR1cyBiZSBQdXQoQSwgXCJsZW5ndGhcIiwgbGVuLCB0cnVlKS5cbiAgICAgICAgICAgIEEubGVuZ3RoID0gbGVuO1xuICAgICAgICAgICAgLy8gMjAuIFJldHVybiBBLlxuICAgICAgICAgICAgcmV0dXJuIEE7XG4gICAgICAgIH07XG4gICAgfSgpKTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0=