/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/options/options.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/options.js":
/*!************************!*\
  !*** ./src/options.js ***!
  \************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, options, setOptions, stbool */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "options", function() { return options; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setOptions", function() { return setOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stbool", function() { return stbool; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _options_states__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./options/states */ "./src/options/states.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]; });





async function options() {
    return browser.storage.local.get(["options"]).then(data => data.options);
}

async function setOptions(options) {
    return browser.storage.local.set({ options: options });
}

function stbool(switch_state) {
    switch (switch_state) {
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]:
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]:
            return true;
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]:
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]:
            return false;
    }
}


/***/ }),

/***/ "./src/options/options.js":
/*!********************************!*\
  !*** ./src/options/options.js ***!
  \********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _states__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./states */ "./src/options/states.js");
/* harmony import */ var _options__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../options */ "./src/options.js");




function setSwitchState(switchElement, state) {
    switch (state) {
        case _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]:
            switchElement.setAttribute("value", "on");
            break;
        case _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]:
            switchElement.setAttribute("value", "on");
            switchElement.setAttribute("disabled", "");
            break;
        case _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]:
            switchElement.setAttribute("value", "off");
            break;
        case _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]:
            switchElement.setAttribute("value", "off");
            switchElement.setAttribute("disabled", "");
            break;
    }
}

function getSwitchState(switchElement) {
    if (switchElement.getAttribute("value") === "on") {
        if (switchElement.hasAttribute("disabled")) {
            return _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"];
        } else {
            return _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"];
        }
    } else if (switchElement.getAttribute("value") === "off") {
        if (switchElement.hasAttribute("disabled")) {
            return _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"];
        } else {
            return _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"];
        }
    }
}

function readOptions() {
    browser.storage.local.get(["options"]).then(data => {
        let options = data.options;
        document.getElementById("option-popup-width").value = options.popup.size.width;
        document.getElementById("option-popup-height").value = options.popup.size.height;
        document.getElementById("option-popup-scale").value = options.popup.scale;
        setSwitchState(document.getElementById("option-details"), options.popup.showDetails);
        setSwitchState(document.getElementById("option-preview"), options.popup.showPreview);
        setSubOptionState(options.popup.showDetails, document.getElementById("option-preview").parentElement);
        setSwitchState(document.getElementById("option-hide-after-tab-switch"), options.popup.hideAfterTabSelection);
        setSwitchState(document.getElementById("option-search-urls"), options.popup.searchInURLs);
    });
}

function setSubOptionState(parentState, subOption) {
    if (parentState === _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]) {
        if (subOption.hasAttribute("disabled")) {
            subOption.removeAttribute("disabled");
        }
    } else if (parentState === _states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]) {
        subOption.setAttribute("disabled", "");
    }
}

function addEventListeners() {
    document.getElementById("option-popup-width").addEventListener("input", e => {
        browser.storage.local.get(["options"]).then(data => {
            data.options.popup.size.width = parseFloat(e.target.value);
            browser.storage.local.set(data);
        });
    });
    document.getElementById("option-popup-height").addEventListener("input", e => {
        browser.storage.local.get(["options"]).then(data => {
            data.options.popup.size.height = parseFloat(e.target.value);
            browser.storage.local.set(data);
        });
    });

    document.getElementById("option-popup-scale").addEventListener("input", e => {
        browser.storage.local.get(["options"]).then(data => {
            data.options.popup.scale = parseFloat(e.target.value);
            browser.storage.local.set(data);
        });
    });

    document.getElementById("option-details").addEventListener("input", e => {
        browser.storage.local.get(["options"]).then(data => {
            data.options.popup.showDetails = getSwitchState(e.target);
            setSubOptionState(data.options.popup.showDetails, document.getElementById("option-preview").parentElement);
            browser.storage.local.set(data);
        });
    });

    document.getElementById("option-preview").addEventListener("input", e => {
        browser.storage.local.get(["options"]).then(data => {
            data.options.popup.showPreview = getSwitchState(e.target);
            browser.storage.local.set(data);
        });
    });

    document.getElementById("option-hide-after-tab-switch").addEventListener("input", e => {
        browser.storage.local.get(["options"]).then(data => {
            data.options.popup.hideAfterTabSelection = getSwitchState(e.target);
            browser.storage.local.set(data);
        });
    });

    document.getElementById("option-search-urls").addEventListener("input", e => {
        browser.storage.local.get(["options"]).then(data => {
            data.options.popup.searchInURLs = getSwitchState(e.target);
            browser.storage.local.set(data);
        });
    });
}

function main() {
    readOptions();
    addEventListeners();
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
} else {
    main();
}


/***/ }),

/***/ "./src/options/states.js":
/*!*******************************!*\
  !*** ./src/options/states.js ***!
  \*******************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, INITIAL_OPTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return SWITCH_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return SWITCH_LOCKED_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return SWITCH_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return SWITCH_LOCKED_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "INITIAL_OPTIONS", function() { return INITIAL_OPTIONS; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const SWITCH_ON = 1;
const SWITCH_LOCKED_ON = 2;
const SWITCH_OFF = 0;
const SWITCH_LOCKED_OFF = -1;

const INITIAL_OPTIONS = {
    popup: {
        size: {
            width: 730,
            height: 450
        },
        scale: 1.0,
        showDetails: SWITCH_ON,
        showPreview: SWITCH_ON,
        hideAfterTabSelection: SWITCH_ON,
        searchInURLs: SWITCH_OFF
    }
};
if (Polyfill__WEBPACK_IMPORTED_MODULE_0__["TargetBrowser"] === "chrome") {
    INITIAL_OPTIONS.popup.showPreview = SWITCH_LOCKED_OFF;
    INITIAL_OPTIONS.popup.hideAfterTabSelection = SWITCH_LOCKED_ON;
}


/***/ }),

/***/ "./src/polyfill.js":
/*!*************************!*\
  !*** ./src/polyfill.js ***!
  \*************************/
/*! exports provided: TargetBrowser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetBrowser", function() { return TargetBrowser; });
const TargetBrowser = "webext";

if (false) {}

if (!Array.from) {
    Array.from = (function () {
        let toStr = Object.prototype.toString;
        let isCallable = function (fn) {
            return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
        };
        let toInteger = function (value) {
            let number = Number(value);
            if (isNaN(number)) { return 0; }
            if (number === 0 || !isFinite(number)) { return number; }
            return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
        };
        let maxSafeInteger = Math.pow(2, 53) - 1;
        let toLength = function (value) {
            let len = toInteger(value);
            return Math.min(Math.max(len, 0), maxSafeInteger);
        };

        // The length property of the from method is 1.
        return function from(arrayLike/*, mapFn, thisArg */) {
            // 1. Let C be the this value.
            let C = this;

            // 2. Let items be ToObject(arrayLike).
            let items = Object(arrayLike);

            // 3. ReturnIfAbrupt(items).
            if (arrayLike == null) {
                throw new TypeError('Array.from requires an array-like object - not null or undefined');
            }

            // 4. If mapfn is undefined, then let mapping be false.
            let mapFn = arguments.length > 1 ? arguments[1] : void undefined;
            let T;
            if (typeof mapFn !== 'undefined') {
                // 5. else
                // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
                if (!isCallable(mapFn)) {
                    throw new TypeError('Array.from: when provided, the second argument must be a function');
                }

                // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
                if (arguments.length > 2) {
                    T = arguments[2];
                }
            }

            // 10. Let lenValue be Get(items, "length").
            // 11. Let len be ToLength(lenValue).
            let len = toLength(items.length);

            // 13. If IsConstructor(C) is true, then
            // 13. a. Let A be the result of calling the [[Construct]] internal method 
            // of C with an argument list containing the single item len.
            // 14. a. Else, Let A be ArrayCreate(len).
            let A = isCallable(C) ? Object(new C(len)) : new Array(len);

            // 16. Let k be 0.
            let k = 0;
            // 17. Repeat, while k < len… (also steps a - h)
            let kValue;
            while (k < len) {
                kValue = items[k];
                if (mapFn) {
                    A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
                } else {
                    A[k] = kValue;
                }
                k += 1;
            }
            // 18. Let putStatus be Put(A, "length", len, true).
            A.length = len;
            // 20. Return A.
            return A;
        };
    }());
}


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL29wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL29wdGlvbnMvb3B0aW9ucy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvb3B0aW9ucy9zdGF0ZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvbHlmaWxsLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUM0RTtBQUN4Qjs7QUFFOUQ7QUFDUDtBQUNBOztBQUVPO0FBQ1Asc0NBQXNDLG1CQUFtQjtBQUN6RDs7QUFFTztBQUNQO0FBQ0EsYUFBYSx5REFBUztBQUN0QixhQUFhLGdFQUFnQjtBQUM3QjtBQUNBLGFBQWEsMERBQVU7QUFDdkIsYUFBYSxpRUFBaUI7QUFDOUI7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDckJBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ3FGO0FBQ25FOztBQUVuQztBQUNBO0FBQ0EsYUFBYSxpREFBUztBQUN0QjtBQUNBO0FBQ0EsYUFBYSx3REFBZ0I7QUFDN0I7QUFDQTtBQUNBO0FBQ0EsYUFBYSxrREFBVTtBQUN2QjtBQUNBO0FBQ0EsYUFBYSx5REFBaUI7QUFDOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsd0RBQWdCO0FBQ25DLFNBQVM7QUFDVCxtQkFBbUIsaURBQVM7QUFDNUI7QUFDQSxLQUFLO0FBQ0w7QUFDQSxtQkFBbUIseURBQWlCO0FBQ3BDLFNBQVM7QUFDVCxtQkFBbUIsa0RBQVU7QUFDN0I7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQSx3QkFBd0IsaURBQVM7QUFDakM7QUFDQTtBQUNBO0FBQ0EsS0FBSywwQkFBMEIsa0RBQVU7QUFDekM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7O0FBRUw7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSzs7QUFFTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7O0FBRUw7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSzs7QUFFTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLOztBQUVMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUMzSEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBd0M7O0FBRWpDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLHNEQUFhO0FBQ2pCO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3ZCQTtBQUFBO0FBQU8sc0JBQXNCLFFBQU07O0FBRW5DLElBQUksS0FBbUIsRUFBRSxFQUV4Qjs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLFVBQVU7QUFDMUMsb0RBQW9ELGVBQWU7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsbUVBQW1FO0FBQ25FO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMIiwiZmlsZSI6Im9wdGlvbnMvb3B0aW9ucy5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vc3JjL29wdGlvbnMvb3B0aW9ucy5qc1wiKTtcbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCB7IFNXSVRDSF9PTiwgU1dJVENIX0xPQ0tFRF9PTiwgU1dJVENIX09GRiwgU1dJVENIX0xPQ0tFRF9PRkYgfSBmcm9tIFwiLi9vcHRpb25zL3N0YXRlc1wiXG5leHBvcnQgeyBTV0lUQ0hfT04sIFNXSVRDSF9MT0NLRURfT04sIFNXSVRDSF9PRkYsIFNXSVRDSF9MT0NLRURfT0ZGIH1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wdGlvbnMoKSB7XG4gICAgcmV0dXJuIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1wib3B0aW9uc1wiXSkudGhlbihkYXRhID0+IGRhdGEub3B0aW9ucyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRPcHRpb25zKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IG9wdGlvbnM6IG9wdGlvbnMgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdGJvb2woc3dpdGNoX3N0YXRlKSB7XG4gICAgc3dpdGNoIChzd2l0Y2hfc3RhdGUpIHtcbiAgICAgICAgY2FzZSBTV0lUQ0hfT046XG4gICAgICAgIGNhc2UgU1dJVENIX0xPQ0tFRF9PTjpcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICBjYXNlIFNXSVRDSF9PRkY6XG4gICAgICAgIGNhc2UgU1dJVENIX0xPQ0tFRF9PRkY6XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IHsgU1dJVENIX09OLCBTV0lUQ0hfTE9DS0VEX09OLCBTV0lUQ0hfT0ZGLCBTV0lUQ0hfTE9DS0VEX09GRiwgSU5JVElBTF9PUFRJT05TIH0gZnJvbSBcIi4vc3RhdGVzXCJcbmltcG9ydCB7IHN0Ym9vbCB9IGZyb20gXCIuLi9vcHRpb25zXCJcblxuZnVuY3Rpb24gc2V0U3dpdGNoU3RhdGUoc3dpdGNoRWxlbWVudCwgc3RhdGUpIHtcbiAgICBzd2l0Y2ggKHN0YXRlKSB7XG4gICAgICAgIGNhc2UgU1dJVENIX09OOlxuICAgICAgICAgICAgc3dpdGNoRWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJ2YWx1ZVwiLCBcIm9uXCIpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgU1dJVENIX0xPQ0tFRF9PTjpcbiAgICAgICAgICAgIHN3aXRjaEVsZW1lbnQuc2V0QXR0cmlidXRlKFwidmFsdWVcIiwgXCJvblwiKTtcbiAgICAgICAgICAgIHN3aXRjaEVsZW1lbnQuc2V0QXR0cmlidXRlKFwiZGlzYWJsZWRcIiwgXCJcIik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBTV0lUQ0hfT0ZGOlxuICAgICAgICAgICAgc3dpdGNoRWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJ2YWx1ZVwiLCBcIm9mZlwiKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFNXSVRDSF9MT0NLRURfT0ZGOlxuICAgICAgICAgICAgc3dpdGNoRWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJ2YWx1ZVwiLCBcIm9mZlwiKTtcbiAgICAgICAgICAgIHN3aXRjaEVsZW1lbnQuc2V0QXR0cmlidXRlKFwiZGlzYWJsZWRcIiwgXCJcIik7XG4gICAgICAgICAgICBicmVhaztcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGdldFN3aXRjaFN0YXRlKHN3aXRjaEVsZW1lbnQpIHtcbiAgICBpZiAoc3dpdGNoRWxlbWVudC5nZXRBdHRyaWJ1dGUoXCJ2YWx1ZVwiKSA9PT0gXCJvblwiKSB7XG4gICAgICAgIGlmIChzd2l0Y2hFbGVtZW50Lmhhc0F0dHJpYnV0ZShcImRpc2FibGVkXCIpKSB7XG4gICAgICAgICAgICByZXR1cm4gU1dJVENIX0xPQ0tFRF9PTjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBTV0lUQ0hfT047XG4gICAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHN3aXRjaEVsZW1lbnQuZ2V0QXR0cmlidXRlKFwidmFsdWVcIikgPT09IFwib2ZmXCIpIHtcbiAgICAgICAgaWYgKHN3aXRjaEVsZW1lbnQuaGFzQXR0cmlidXRlKFwiZGlzYWJsZWRcIikpIHtcbiAgICAgICAgICAgIHJldHVybiBTV0lUQ0hfTE9DS0VEX09GRjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBTV0lUQ0hfT0ZGO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5mdW5jdGlvbiByZWFkT3B0aW9ucygpIHtcbiAgICBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcIm9wdGlvbnNcIl0pLnRoZW4oZGF0YSA9PiB7XG4gICAgICAgIGxldCBvcHRpb25zID0gZGF0YS5vcHRpb25zO1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm9wdGlvbi1wb3B1cC13aWR0aFwiKS52YWx1ZSA9IG9wdGlvbnMucG9wdXAuc2l6ZS53aWR0aDtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24tcG9wdXAtaGVpZ2h0XCIpLnZhbHVlID0gb3B0aW9ucy5wb3B1cC5zaXplLmhlaWdodDtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24tcG9wdXAtc2NhbGVcIikudmFsdWUgPSBvcHRpb25zLnBvcHVwLnNjYWxlO1xuICAgICAgICBzZXRTd2l0Y2hTdGF0ZShkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm9wdGlvbi1kZXRhaWxzXCIpLCBvcHRpb25zLnBvcHVwLnNob3dEZXRhaWxzKTtcbiAgICAgICAgc2V0U3dpdGNoU3RhdGUoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24tcHJldmlld1wiKSwgb3B0aW9ucy5wb3B1cC5zaG93UHJldmlldyk7XG4gICAgICAgIHNldFN1Yk9wdGlvblN0YXRlKG9wdGlvbnMucG9wdXAuc2hvd0RldGFpbHMsIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwib3B0aW9uLXByZXZpZXdcIikucGFyZW50RWxlbWVudCk7XG4gICAgICAgIHNldFN3aXRjaFN0YXRlKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwib3B0aW9uLWhpZGUtYWZ0ZXItdGFiLXN3aXRjaFwiKSwgb3B0aW9ucy5wb3B1cC5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb24pO1xuICAgICAgICBzZXRTd2l0Y2hTdGF0ZShkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm9wdGlvbi1zZWFyY2gtdXJsc1wiKSwgb3B0aW9ucy5wb3B1cC5zZWFyY2hJblVSTHMpO1xuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBzZXRTdWJPcHRpb25TdGF0ZShwYXJlbnRTdGF0ZSwgc3ViT3B0aW9uKSB7XG4gICAgaWYgKHBhcmVudFN0YXRlID09PSBTV0lUQ0hfT04pIHtcbiAgICAgICAgaWYgKHN1Yk9wdGlvbi5oYXNBdHRyaWJ1dGUoXCJkaXNhYmxlZFwiKSkge1xuICAgICAgICAgICAgc3ViT3B0aW9uLnJlbW92ZUF0dHJpYnV0ZShcImRpc2FibGVkXCIpO1xuICAgICAgICB9XG4gICAgfSBlbHNlIGlmIChwYXJlbnRTdGF0ZSA9PT0gU1dJVENIX09GRikge1xuICAgICAgICBzdWJPcHRpb24uc2V0QXR0cmlidXRlKFwiZGlzYWJsZWRcIiwgXCJcIik7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhZGRFdmVudExpc3RlbmVycygpIHtcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm9wdGlvbi1wb3B1cC13aWR0aFwiKS5hZGRFdmVudExpc3RlbmVyKFwiaW5wdXRcIiwgZSA9PiB7XG4gICAgICAgIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1wib3B0aW9uc1wiXSkudGhlbihkYXRhID0+IHtcbiAgICAgICAgICAgIGRhdGEub3B0aW9ucy5wb3B1cC5zaXplLndpZHRoID0gcGFyc2VGbG9hdChlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KGRhdGEpO1xuICAgICAgICB9KTtcbiAgICB9KTtcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm9wdGlvbi1wb3B1cC1oZWlnaHRcIikuYWRkRXZlbnRMaXN0ZW5lcihcImlucHV0XCIsIGUgPT4ge1xuICAgICAgICBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcIm9wdGlvbnNcIl0pLnRoZW4oZGF0YSA9PiB7XG4gICAgICAgICAgICBkYXRhLm9wdGlvbnMucG9wdXAuc2l6ZS5oZWlnaHQgPSBwYXJzZUZsb2F0KGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoZGF0YSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24tcG9wdXAtc2NhbGVcIikuYWRkRXZlbnRMaXN0ZW5lcihcImlucHV0XCIsIGUgPT4ge1xuICAgICAgICBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcIm9wdGlvbnNcIl0pLnRoZW4oZGF0YSA9PiB7XG4gICAgICAgICAgICBkYXRhLm9wdGlvbnMucG9wdXAuc2NhbGUgPSBwYXJzZUZsb2F0KGUudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgICAgIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoZGF0YSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24tZGV0YWlsc1wiKS5hZGRFdmVudExpc3RlbmVyKFwiaW5wdXRcIiwgZSA9PiB7XG4gICAgICAgIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1wib3B0aW9uc1wiXSkudGhlbihkYXRhID0+IHtcbiAgICAgICAgICAgIGRhdGEub3B0aW9ucy5wb3B1cC5zaG93RGV0YWlscyA9IGdldFN3aXRjaFN0YXRlKGUudGFyZ2V0KTtcbiAgICAgICAgICAgIHNldFN1Yk9wdGlvblN0YXRlKGRhdGEub3B0aW9ucy5wb3B1cC5zaG93RGV0YWlscywgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24tcHJldmlld1wiKS5wYXJlbnRFbGVtZW50KTtcbiAgICAgICAgICAgIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoZGF0YSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24tcHJldmlld1wiKS5hZGRFdmVudExpc3RlbmVyKFwiaW5wdXRcIiwgZSA9PiB7XG4gICAgICAgIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1wib3B0aW9uc1wiXSkudGhlbihkYXRhID0+IHtcbiAgICAgICAgICAgIGRhdGEub3B0aW9ucy5wb3B1cC5zaG93UHJldmlldyA9IGdldFN3aXRjaFN0YXRlKGUudGFyZ2V0KTtcbiAgICAgICAgICAgIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoZGF0YSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24taGlkZS1hZnRlci10YWItc3dpdGNoXCIpLmFkZEV2ZW50TGlzdGVuZXIoXCJpbnB1dFwiLCBlID0+IHtcbiAgICAgICAgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChbXCJvcHRpb25zXCJdKS50aGVuKGRhdGEgPT4ge1xuICAgICAgICAgICAgZGF0YS5vcHRpb25zLnBvcHVwLmhpZGVBZnRlclRhYlNlbGVjdGlvbiA9IGdldFN3aXRjaFN0YXRlKGUudGFyZ2V0KTtcbiAgICAgICAgICAgIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoZGF0YSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJvcHRpb24tc2VhcmNoLXVybHNcIikuYWRkRXZlbnRMaXN0ZW5lcihcImlucHV0XCIsIGUgPT4ge1xuICAgICAgICBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcIm9wdGlvbnNcIl0pLnRoZW4oZGF0YSA9PiB7XG4gICAgICAgICAgICBkYXRhLm9wdGlvbnMucG9wdXAuc2VhcmNoSW5VUkxzID0gZ2V0U3dpdGNoU3RhdGUoZS50YXJnZXQpO1xuICAgICAgICAgICAgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldChkYXRhKTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIG1haW4oKSB7XG4gICAgcmVhZE9wdGlvbnMoKTtcbiAgICBhZGRFdmVudExpc3RlbmVycygpO1xufVxuXG5pZiAoZG9jdW1lbnQucmVhZHlTdGF0ZSA9PT0gXCJsb2FkaW5nXCIpIHtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCBtYWluKTtcbn0gZWxzZSB7XG4gICAgbWFpbigpO1xufVxuIiwiaW1wb3J0IHsgVGFyZ2V0QnJvd3NlciB9IGZyb20gXCJQb2x5ZmlsbFwiXG5cbmV4cG9ydCBjb25zdCBTV0lUQ0hfT04gPSAxO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9MT0NLRURfT04gPSAyO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9PRkYgPSAwO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9MT0NLRURfT0ZGID0gLTE7XG5cbmV4cG9ydCBjb25zdCBJTklUSUFMX09QVElPTlMgPSB7XG4gICAgcG9wdXA6IHtcbiAgICAgICAgc2l6ZToge1xuICAgICAgICAgICAgd2lkdGg6IDczMCxcbiAgICAgICAgICAgIGhlaWdodDogNDUwXG4gICAgICAgIH0sXG4gICAgICAgIHNjYWxlOiAxLjAsXG4gICAgICAgIHNob3dEZXRhaWxzOiBTV0lUQ0hfT04sXG4gICAgICAgIHNob3dQcmV2aWV3OiBTV0lUQ0hfT04sXG4gICAgICAgIGhpZGVBZnRlclRhYlNlbGVjdGlvbjogU1dJVENIX09OLFxuICAgICAgICBzZWFyY2hJblVSTHM6IFNXSVRDSF9PRkZcbiAgICB9XG59O1xuaWYgKFRhcmdldEJyb3dzZXIgPT09IFwiY2hyb21lXCIpIHtcbiAgICBJTklUSUFMX09QVElPTlMucG9wdXAuc2hvd1ByZXZpZXcgPSBTV0lUQ0hfTE9DS0VEX09GRjtcbiAgICBJTklUSUFMX09QVElPTlMucG9wdXAuaGlkZUFmdGVyVGFiU2VsZWN0aW9uID0gU1dJVENIX0xPQ0tFRF9PTjtcbn1cbiIsImV4cG9ydCBjb25zdCBUYXJnZXRCcm93c2VyID0gVEFSR0VUO1xuXG5pZiAoVEFSR0VUID09PSBcImNocm9tZVwiKSB7XG4gICAgd2luZG93W1wiYnJvd3NlclwiXSA9IHJlcXVpcmUoXCJ3ZWJleHRlbnNpb24tcG9seWZpbGxcIik7XG59XG5cbmlmICghQXJyYXkuZnJvbSkge1xuICAgIEFycmF5LmZyb20gPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICBsZXQgdG9TdHIgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xuICAgICAgICBsZXQgaXNDYWxsYWJsZSA9IGZ1bmN0aW9uIChmbikge1xuICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiBmbiA9PT0gJ2Z1bmN0aW9uJyB8fCB0b1N0ci5jYWxsKGZuKSA9PT0gJ1tvYmplY3QgRnVuY3Rpb25dJztcbiAgICAgICAgfTtcbiAgICAgICAgbGV0IHRvSW50ZWdlciA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgbGV0IG51bWJlciA9IE51bWJlcih2YWx1ZSk7XG4gICAgICAgICAgICBpZiAoaXNOYU4obnVtYmVyKSkgeyByZXR1cm4gMDsgfVxuICAgICAgICAgICAgaWYgKG51bWJlciA9PT0gMCB8fCAhaXNGaW5pdGUobnVtYmVyKSkgeyByZXR1cm4gbnVtYmVyOyB9XG4gICAgICAgICAgICByZXR1cm4gKG51bWJlciA+IDAgPyAxIDogLTEpICogTWF0aC5mbG9vcihNYXRoLmFicyhudW1iZXIpKTtcbiAgICAgICAgfTtcbiAgICAgICAgbGV0IG1heFNhZmVJbnRlZ2VyID0gTWF0aC5wb3coMiwgNTMpIC0gMTtcbiAgICAgICAgbGV0IHRvTGVuZ3RoID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBsZXQgbGVuID0gdG9JbnRlZ2VyKHZhbHVlKTtcbiAgICAgICAgICAgIHJldHVybiBNYXRoLm1pbihNYXRoLm1heChsZW4sIDApLCBtYXhTYWZlSW50ZWdlcik7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gVGhlIGxlbmd0aCBwcm9wZXJ0eSBvZiB0aGUgZnJvbSBtZXRob2QgaXMgMS5cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGZyb20oYXJyYXlMaWtlLyosIG1hcEZuLCB0aGlzQXJnICovKSB7XG4gICAgICAgICAgICAvLyAxLiBMZXQgQyBiZSB0aGUgdGhpcyB2YWx1ZS5cbiAgICAgICAgICAgIGxldCBDID0gdGhpcztcblxuICAgICAgICAgICAgLy8gMi4gTGV0IGl0ZW1zIGJlIFRvT2JqZWN0KGFycmF5TGlrZSkuXG4gICAgICAgICAgICBsZXQgaXRlbXMgPSBPYmplY3QoYXJyYXlMaWtlKTtcblxuICAgICAgICAgICAgLy8gMy4gUmV0dXJuSWZBYnJ1cHQoaXRlbXMpLlxuICAgICAgICAgICAgaWYgKGFycmF5TGlrZSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJyYXkuZnJvbSByZXF1aXJlcyBhbiBhcnJheS1saWtlIG9iamVjdCAtIG5vdCBudWxsIG9yIHVuZGVmaW5lZCcpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyA0LiBJZiBtYXBmbiBpcyB1bmRlZmluZWQsIHRoZW4gbGV0IG1hcHBpbmcgYmUgZmFsc2UuXG4gICAgICAgICAgICBsZXQgbWFwRm4gPSBhcmd1bWVudHMubGVuZ3RoID4gMSA/IGFyZ3VtZW50c1sxXSA6IHZvaWQgdW5kZWZpbmVkO1xuICAgICAgICAgICAgbGV0IFQ7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1hcEZuICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIC8vIDUuIGVsc2VcbiAgICAgICAgICAgICAgICAvLyA1LiBhIElmIElzQ2FsbGFibGUobWFwZm4pIGlzIGZhbHNlLCB0aHJvdyBhIFR5cGVFcnJvciBleGNlcHRpb24uXG4gICAgICAgICAgICAgICAgaWYgKCFpc0NhbGxhYmxlKG1hcEZuKSkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcnJheS5mcm9tOiB3aGVuIHByb3ZpZGVkLCB0aGUgc2Vjb25kIGFyZ3VtZW50IG11c3QgYmUgYSBmdW5jdGlvbicpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIDUuIGIuIElmIHRoaXNBcmcgd2FzIHN1cHBsaWVkLCBsZXQgVCBiZSB0aGlzQXJnOyBlbHNlIGxldCBUIGJlIHVuZGVmaW5lZC5cbiAgICAgICAgICAgICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgVCA9IGFyZ3VtZW50c1syXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIDEwLiBMZXQgbGVuVmFsdWUgYmUgR2V0KGl0ZW1zLCBcImxlbmd0aFwiKS5cbiAgICAgICAgICAgIC8vIDExLiBMZXQgbGVuIGJlIFRvTGVuZ3RoKGxlblZhbHVlKS5cbiAgICAgICAgICAgIGxldCBsZW4gPSB0b0xlbmd0aChpdGVtcy5sZW5ndGgpO1xuXG4gICAgICAgICAgICAvLyAxMy4gSWYgSXNDb25zdHJ1Y3RvcihDKSBpcyB0cnVlLCB0aGVuXG4gICAgICAgICAgICAvLyAxMy4gYS4gTGV0IEEgYmUgdGhlIHJlc3VsdCBvZiBjYWxsaW5nIHRoZSBbW0NvbnN0cnVjdF1dIGludGVybmFsIG1ldGhvZCBcbiAgICAgICAgICAgIC8vIG9mIEMgd2l0aCBhbiBhcmd1bWVudCBsaXN0IGNvbnRhaW5pbmcgdGhlIHNpbmdsZSBpdGVtIGxlbi5cbiAgICAgICAgICAgIC8vIDE0LiBhLiBFbHNlLCBMZXQgQSBiZSBBcnJheUNyZWF0ZShsZW4pLlxuICAgICAgICAgICAgbGV0IEEgPSBpc0NhbGxhYmxlKEMpID8gT2JqZWN0KG5ldyBDKGxlbikpIDogbmV3IEFycmF5KGxlbik7XG5cbiAgICAgICAgICAgIC8vIDE2LiBMZXQgayBiZSAwLlxuICAgICAgICAgICAgbGV0IGsgPSAwO1xuICAgICAgICAgICAgLy8gMTcuIFJlcGVhdCwgd2hpbGUgayA8IGxlbuKApiAoYWxzbyBzdGVwcyBhIC0gaClcbiAgICAgICAgICAgIGxldCBrVmFsdWU7XG4gICAgICAgICAgICB3aGlsZSAoayA8IGxlbikge1xuICAgICAgICAgICAgICAgIGtWYWx1ZSA9IGl0ZW1zW2tdO1xuICAgICAgICAgICAgICAgIGlmIChtYXBGbikge1xuICAgICAgICAgICAgICAgICAgICBBW2tdID0gdHlwZW9mIFQgPT09ICd1bmRlZmluZWQnID8gbWFwRm4oa1ZhbHVlLCBrKSA6IG1hcEZuLmNhbGwoVCwga1ZhbHVlLCBrKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBBW2tdID0ga1ZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBrICs9IDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyAxOC4gTGV0IHB1dFN0YXR1cyBiZSBQdXQoQSwgXCJsZW5ndGhcIiwgbGVuLCB0cnVlKS5cbiAgICAgICAgICAgIEEubGVuZ3RoID0gbGVuO1xuICAgICAgICAgICAgLy8gMjAuIFJldHVybiBBLlxuICAgICAgICAgICAgcmV0dXJuIEE7XG4gICAgICAgIH07XG4gICAgfSgpKTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0=