/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/popup/popup.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/options.js":
/*!************************!*\
  !*** ./src/options.js ***!
  \************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, options, setOptions, stbool */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "options", function() { return options; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setOptions", function() { return setOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stbool", function() { return stbool; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _options_states__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./options/states */ "./src/options/states.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]; });





async function options() {
    return browser.storage.local.get(["options"]).then(data => data.options);
}

async function setOptions(options) {
    return browser.storage.local.set({ options: options });
}

function stbool(switch_state) {
    switch (switch_state) {
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]:
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]:
            return true;
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]:
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]:
            return false;
    }
}


/***/ }),

/***/ "./src/options/states.js":
/*!*******************************!*\
  !*** ./src/options/states.js ***!
  \*******************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, INITIAL_OPTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return SWITCH_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return SWITCH_LOCKED_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return SWITCH_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return SWITCH_LOCKED_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "INITIAL_OPTIONS", function() { return INITIAL_OPTIONS; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const SWITCH_ON = 1;
const SWITCH_LOCKED_ON = 2;
const SWITCH_OFF = 0;
const SWITCH_LOCKED_OFF = -1;

const INITIAL_OPTIONS = {
    popup: {
        size: {
            width: 730,
            height: 450
        },
        scale: 1.0,
        showDetails: SWITCH_ON,
        showPreview: SWITCH_ON,
        hideAfterTabSelection: SWITCH_ON,
        searchInURLs: SWITCH_OFF
    }
};
if (Polyfill__WEBPACK_IMPORTED_MODULE_0__["TargetBrowser"] === "chrome") {
    INITIAL_OPTIONS.popup.showPreview = SWITCH_LOCKED_OFF;
    INITIAL_OPTIONS.popup.hideAfterTabSelection = SWITCH_LOCKED_ON;
}


/***/ }),

/***/ "./src/polyfill.js":
/*!*************************!*\
  !*** ./src/polyfill.js ***!
  \*************************/
/*! exports provided: TargetBrowser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetBrowser", function() { return TargetBrowser; });
const TargetBrowser = "webext";

if (false) {}

if (!Array.from) {
    Array.from = (function () {
        let toStr = Object.prototype.toString;
        let isCallable = function (fn) {
            return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
        };
        let toInteger = function (value) {
            let number = Number(value);
            if (isNaN(number)) { return 0; }
            if (number === 0 || !isFinite(number)) { return number; }
            return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
        };
        let maxSafeInteger = Math.pow(2, 53) - 1;
        let toLength = function (value) {
            let len = toInteger(value);
            return Math.min(Math.max(len, 0), maxSafeInteger);
        };

        // The length property of the from method is 1.
        return function from(arrayLike/*, mapFn, thisArg */) {
            // 1. Let C be the this value.
            let C = this;

            // 2. Let items be ToObject(arrayLike).
            let items = Object(arrayLike);

            // 3. ReturnIfAbrupt(items).
            if (arrayLike == null) {
                throw new TypeError('Array.from requires an array-like object - not null or undefined');
            }

            // 4. If mapfn is undefined, then let mapping be false.
            let mapFn = arguments.length > 1 ? arguments[1] : void undefined;
            let T;
            if (typeof mapFn !== 'undefined') {
                // 5. else
                // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
                if (!isCallable(mapFn)) {
                    throw new TypeError('Array.from: when provided, the second argument must be a function');
                }

                // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
                if (arguments.length > 2) {
                    T = arguments[2];
                }
            }

            // 10. Let lenValue be Get(items, "length").
            // 11. Let len be ToLength(lenValue).
            let len = toLength(items.length);

            // 13. If IsConstructor(C) is true, then
            // 13. a. Let A be the result of calling the [[Construct]] internal method 
            // of C with an argument list containing the single item len.
            // 14. a. Else, Let A be ArrayCreate(len).
            let A = isCallable(C) ? Object(new C(len)) : new Array(len);

            // 16. Let k be 0.
            let k = 0;
            // 17. Repeat, while k < len… (also steps a - h)
            let kValue;
            while (k < len) {
                kValue = items[k];
                if (mapFn) {
                    A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
                } else {
                    A[k] = kValue;
                }
                k += 1;
            }
            // 18. Let putStatus be Put(A, "length", len, true).
            A.length = len;
            // 20. Return A.
            return A;
        };
    }());
}


/***/ }),

/***/ "./src/popup/captureTab.js":
/*!*********************************!*\
  !*** ./src/popup/captureTab.js ***!
  \*********************************/
/*! exports provided: available, init, captureTab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "available", function() { return available; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "init", function() { return init; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "captureTab", function() { return captureTab; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


let available = false;

function init() {
    if (window["browser"] !== undefined
        && browser.tabs["captureTab"] !== undefined) {
        available = true;
        return;
    }
}

function captureTab(id) {
    return available ? browser.tabs.captureTab(id) : new Promise((resolve, reject) => resolve(null));
}


/***/ }),

/***/ "./src/popup/domutils.js":
/*!*******************************!*\
  !*** ./src/popup/domutils.js ***!
  \*******************************/
/*! exports provided: toggleClass, getActualHeight, getActualWidth */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toggleClass", function() { return toggleClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActualHeight", function() { return getActualHeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActualWidth", function() { return getActualWidth; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Toggle a class of an element
function toggleClass(element, c) {
    if (element.classList.contains(c)) {
        element.classList.remove(c);
    } else {
        element.classList.add(c);
    }
}

// Get actual height of an element
function getActualHeight(element) {
    let styles = window.getComputedStyle(element);
    let margin = parseFloat(styles['marginTop']) +
               parseFloat(styles['marginBottom']);
    return element.offsetHeight + margin;
}

// Get actual width of an element
function getActualWidth(element) {
    let styles = window.getComputedStyle(element);
    let margin = parseFloat(styles['marginLeft']) +
               parseFloat(styles['marginRight']);
    return element.offsetWidth + margin;
}

// getElementByClassName
Element.prototype.getElementByClassName = function (classNames) {
    return this.getElementsByClassName(classNames)[0] || null;
};


/***/ }),

/***/ "./src/popup/event-listeners/document.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/document.js ***!
  \***********************************************/
/*! exports provided: documentMouseOver, documentMouseUp, documentClicked, documentKeyPressed */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentMouseOver", function() { return documentMouseOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentMouseUp", function() { return documentMouseUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentClicked", function() { return documentClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentKeyPressed", function() { return documentKeyPressed; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _keyutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../keyutils */ "./src/popup/keyutils.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtutils */ "./src/popup/wtutils.js");
/* harmony import */ var _captureTab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../captureTab */ "./src/popup/captureTab.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");







function documentMouseOver(e) {
    e.preventDefault();
}

function documentMouseUp(e) {
    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding) Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["resetSlideSelection"])();
}

function documentClicked(e) {
    if (e.button === 0) {
        if (e.target.id === "details-close") {
            document.getElementById("details-placeholder").style.display = "inline-block";
            document.getElementById("tab-details").style.display = "none";
            browser.tabs.remove(Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getTabId"])(document.getElementById("tab-details")));
        } else {// Note: May cause some problems
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting) Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelectReset"])();
        }
    }
}

function isInlinePrintableKey(e) {
    if (typeof e.which === "undefined") {
        return true;
    } else if (typeof e.which === "number" && e.which > 0) {
        return !e.ctrlKey && !e.metaKey && !e.altKey && e.which !== 8 && e.which !== 13;
    }
}

function documentKeyPressed(e) {
    if (isInlinePrintableKey(e)) {
        document.getElementById("search").focus();
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/message.js":
/*!**********************************************!*\
  !*** ./src/popup/event-listeners/message.js ***!
  \**********************************************/
/*! exports provided: onMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMessage", function() { return onMessage; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../domutils */ "./src/popup/domutils.js");
/* harmony import */ var _net__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../net */ "./src/popup/net.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");





function onMessage(request, sender) {
    switch (request.type) {
        case "ACTIVE_TAB_CHANGED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["setActiveTab"])(request.details.windowId, request.details.tabId);
            break;
        case "TAB_FAV_ICON_CHANGED":
            browser.tabs.get(request.details.tabId).then(tab => {
                let favIconPromise;
                if (tab.incognito) {
                    favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(request.details.favIconUrl, true);
                } else {
                    favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(request.details.favIconUrl);
                }
                favIconPromise.then(function (base64Image){
                    Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getFavIconFromTabEntry"])(Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId)).src = base64Image;
                });
            });
            break;
        case "TAB_PINNED_STATUS_CHANGED":
            let tabEntry = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId);
            let pinBtn = tabEntry.getElementByClassName("tab-entry-pin-btn");
            let windowEntryList = tabEntry.parentElement;
            let pinnedTabs;
            if (request.details.pinned) {
                pinnedTabs = Array.from(windowEntryList.getElementsByClassName("pinned-tab"));
                tabEntry.classList.add("pinned-tab");
                pinBtn.style.backgroundImage = "url(../icons/pinremove.svg)";
            } else {
                pinnedTabs = Array.from(windowEntryList.getElementsByClassName("pinned-tab"));
                tabEntry.classList.remove("pinned-tab");
                pinBtn.style.backgroundImage = "url(../icons/pin.svg)";
            }
            let lastPinnedTab = pinnedTabs[pinnedTabs.length-1];
            if (lastPinnedTab !== undefined) {
                windowEntryList.insertBefore(tabEntry, lastPinnedTab.nextSibling);
            } else {
                windowEntryList.insertBefore(tabEntry, windowEntryList.childNodes[0]);
            }
            break;
        case "TAB_TITLE_CHANGED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId).getElementByClassName("tab-title").textContent = request.details.title;
            break;
        case "TAB_REMOVED":
            if (!request.details.windowClosing) {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["removeTab"])(request.details.tabId, request.details.windowId);
            }
            break;
        case "WINDOW_REMOVED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["removeWindow"])(request.details.windowId);
            break;
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/recorder.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/recorder.js ***!
  \***********************************************/
/*! exports provided: saveForLater, restore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveForLater", function() { return saveForLater; });
/* harmony import */ var _recorder__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../recorder */ "./src/popup/recorder.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "restore", function() { return _recorder__WEBPACK_IMPORTED_MODULE_0__["restore"]; });



let saveForLaterBtn = document.getElementById("save-for-later");
let sflTimeout = () => {
    saveForLaterBtn.removeAttribute("done");
};
function saveForLater() {
    saveForLaterBtn.setAttribute("disabled", "");
    Object(_recorder__WEBPACK_IMPORTED_MODULE_0__["record"])().then(() => {
        saveForLaterBtn.removeAttribute("disabled");
        saveForLaterBtn.setAttribute("done", "");
        clearTimeout(sflTimeout); setTimeout(sflTimeout, 2000);
    });
}




/***/ }),

/***/ "./src/popup/event-listeners/search.js":
/*!*********************************************!*\
  !*** ./src/popup/event-listeners/search.js ***!
  \*********************************************/
/*! exports provided: searchTextChanged */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchTextChanged", function() { return searchTextChanged; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");




function keywordSearch(s, key) {
    let keywords = key.trim().split(" "), count = 0;
    for (let i = 0; i < keywords.length; i++) {
        let word = keywords[i];
        if (word.trim() !== "" && word.match(/^[a-zA-Z0-9]+$/)) {
            if (s.toUpperCase().includes(word.toUpperCase())) {
                count++;
            }
        }
    }
    return count >= 2;
}

function search(s, key) {
    return s.toUpperCase().includes(key.toUpperCase()) || keywordSearch(s, key);
}

// Search
async function searchTextChanged(e) {
    let input, filter, tabEntries;
    input = document.getElementById("search");
    filter = input.value;
    tabEntries = document.getElementsByClassName("tab-entry");
    if (filter !== "") {
        for (let i = 0; i < tabEntries.length; i++) {
            let tabEntry = tabEntries[i];
            if (!search(tabEntry.getElementByClassName("tab-title").innerText, filter) &&
                !(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].searchInURLs && search((await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry))).url, filter))) {
                tabEntry.style.display = "none";
            } else {
                tabEntry.style.display = "flex";
            }
        }
    } else {
        for (let i = 0; i < tabEntries.length; i++) {
            let tabEntry = tabEntries[i];
            tabEntry.style.display = "flex";
        }
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/tabEntry.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/tabEntry.js ***!
  \***********************************************/
/*! exports provided: tabEntryMouseOver, tabEntryMouseLeave, tabEntryClicked, tabCloseClick, tabPinClick */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryMouseOver", function() { return tabEntryMouseOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryMouseLeave", function() { return tabEntryMouseLeave; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryClicked", function() { return tabEntryClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabCloseClick", function() { return tabCloseClick; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabPinClick", function() { return tabPinClick; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _keyutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../keyutils */ "./src/popup/keyutils.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtutils */ "./src/popup/wtutils.js");
/* harmony import */ var _captureTab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../captureTab */ "./src/popup/captureTab.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");







function tabEntryMouseOver(e) {
    e.target.getElementByClassName("tab-entry-pin-btn").style.display = "inline-block";
    if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])() && _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding) {
        Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelect"])(e.target);
    } else {
        let tabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getTabId"])(e.target);
        _captureTab__WEBPACK_IMPORTED_MODULE_4__["captureTab"](tabId).then(dataUri => {
            if (dataUri !== null) {
                let detailsImage = document.getElementById("details-img");
                detailsImage.src = dataUri;
            }
            let detailsTitle = document.getElementById("details-title");
            let detailsURL = document.getElementById("details-url");
            browser.tabs.get(tabId).then(tab => {
                detailsTitle.textContent = tab.title;
                detailsURL.textContent = tab.url;
                document.getElementById("details-placeholder").style.display = "none";
                document.getElementById("tab-details").style.display = "inline-block";
                document.getElementById("tab-details").setAttribute("data-tab_id", tabId);
                if (tab.pinned) {
                    document.getElementById("details-pinned").style.display = "inline";
                } else {
                    document.getElementById("details-pinned").style.display = "none";
                }
                if (tab.hidden) {
                    document.getElementById("details-hidden").style.display = "inline";
                } else {
                    document.getElementById("details-hidden").style.display = "none";
                }
                if (tab.pinned && tab.hidden) {
                    document.getElementById("details-comma").style.display = "inline";
                } else {
                    document.getElementById("details-comma").style.display = "none";
                }
            });
        });
    }
    e.preventDefault();
}

function tabEntryMouseLeave(e) {
    e.target.getElementByClassName("tab-entry-pin-btn").style.display = "none";
}

function tabEntryClicked(e) {
    if (e.button === 0) {
        if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])()) {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelectToggle"])(e.target);
        } else {
            let tabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getTabId"])(e.target);
            let parentWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getWindowId"])(Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getWindowFromTab"])(e.target));
            browser.tabs.update(tabId, {
                active: true
            });
            browser.windows.get(parentWindowId).then(w => {
                Object(_wtutils__WEBPACK_IMPORTED_MODULE_3__["getLastFocusedWindow"])().then(cw => {
                    if (w.id !== cw.id) {
                        browser.windows.update(w.id, {
                            focused: true
                        });
                    }
                    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].hideAfterTabSelection) window.close();
                });
            });
        }
    }
}

function tabCloseClick(e) {
    let tabId = e.target.parentElement.parentElement.getAttribute("data-tab_id");
    let tabDetails = document.getElementById("tab-details");
    if (tabDetails.getAttribute("data-tab_id") === tabId) {
        tabDetails.style.display = "none";
        document.getElementById("details-placeholder").style.display = "inline-block";
    }
    browser.tabs.remove(parseInt(tabId));
}

function tabPinClick(e) {
    let tabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getTabId"])(e.target.parentElement.parentElement);
    browser.tabs.get(tabId).then(tab => {
        if (tab.pinned) {
            browser.tabs.update(tab.id, {
                pinned: false
            });
        } else {
            browser.tabs.update(tab.id, {
                pinned: true
            });
        }
    });
}


/***/ }),

/***/ "./src/popup/event-listeners/windowEntry.js":
/*!**************************************************!*\
  !*** ./src/popup/event-listeners/windowEntry.js ***!
  \**************************************************/
/*! exports provided: windowEntryDragStarted, windowEntryDraggingOver, windowEntryDropped, windowEntryTitleClicked, windowCloseClick */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDragStarted", function() { return windowEntryDragStarted; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDraggingOver", function() { return windowEntryDraggingOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDropped", function() { return windowEntryDropped; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryTitleClicked", function() { return windowEntryTitleClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowCloseClick", function() { return windowCloseClick; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _keyutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../keyutils */ "./src/popup/keyutils.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");





let multiDragging = false, sourceTab, targetTab, under, sourceWindow, sourceWindowId;

function getMultiDragImage(target, clientX, clientY) {
    let dragImage = document.createElement("div"), x, y;
    let selectedItems = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getSelectedItems"])();
    if (selectedItems.length === 1) return selectedItems[i];
    for (let i = 0; i < selectedItems.length - 1; i++) {
        let ref1 = selectedItems[i], ref2 = selectedItems[i+1];
        let ref1br = ref1.getBoundingClientRect(), ref2br = ref2.getBoundingClientRect();
        let distance = ref2br.top - (ref1br.top + ref1br.height);
        let ref1Clone = ref1.cloneNode(true);
        ref1Clone.style.marginBottom = distance + "px";
        dragImage.appendChild(ref1Clone);
    } dragImage.appendChild(selectedItems[selectedItems.length - 1].cloneNode(true));
    dragImage.style.width = selectedItems[0].getBoundingClientRect().width + "px";
    document.body.appendChild(dragImage);
    return {
        image: dragImage,
        x: 0,
        y: 0
    };
}

function windowEntryDragStarted(e) {
    if (e.target.classList.contains("tab-entry")) {
        if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])()) {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["multiSelect"])(e.target);
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding = true;
            e.preventDefault();
        } else {
            sourceTab = e.target;
            sourceWindow = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(sourceTab);
            sourceWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(sourceWindow);
            e.dataTransfer.effectAllowed = "move";
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting && Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["multiSelected"])(e.target)) {
                multiDragging = true;
                let dragImage = getMultiDragImage();
                e.dataTransfer.setDragImage(dragImage.image, dragImage.x, dragImage.y);
            }
        }
        e.dataTransfer.setData('text/plain', null);
    }
}

function windowEntryDraggingOver(e) {
    e.preventDefault();
    let cursors = Array.from(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("insert-cursor"));
    for (let i = 0; i < cursors.length; i++) {
        let c = cursors[i];
        c.parentElement.removeChild(c);
    }
    let cursorWindow = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementByClassName("insert-cursor-window");
    if (cursorWindow !== null) {
        cursorWindow.classList.remove("insert-cursor-window");
    }

    let windowEntry;
    if (e.target.classList.contains("tab-entry")) {
        let tabEntryBoundingClientRect = e.target.getBoundingClientRect();
        targetTab = e.target;
        under = false;
        if ((e.clientY - tabEntryBoundingClientRect.top) >= tabEntryBoundingClientRect.height / 2) {
            targetTab = targetTab.nextSibling;
            if (targetTab === null) {
                under = true;
                targetTab = e.target;
            }
        }
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggable"])(sourceTab, targetTab, under, sourceWindow, multiDragging)) {
            let cursor = document.createElement("div");
            cursor.classList.add("insert-cursor");
            if (under) {
                targetTab.parentElement.appendChild(cursor);
            } else {
                targetTab.parentElement.insertBefore(cursor, targetTab);
            }
        }
    } else if ((windowEntry = e.target.parentElement) !== null && windowEntry.classList.contains("window-entry")) {
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggableToWindow"])(sourceTab, windowEntry, sourceWindow)) {
            e.target.classList.add("insert-cursor-window");
        }
    }
}

function windowEntryDropped(e) {
    e.preventDefault();
    e.stopPropagation();
    let cursors = Array.from(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("insert-cursor"));
    for (let i = 0; i < cursors.length; i++) {
        let cursor = cursors[i];
        cursor.parentElement.removeChild(cursor);
    }
    let cursorWindow = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementByClassName("insert-cursor-window");
    if (cursorWindow !== null) {
        cursorWindow.classList.remove("insert-cursor-window");
    }
    
    let windowEntry;
    if (e.target.classList.contains("tab-entry")) {
        if (!e.target.isSameNode(targetTab)) {
            let tabEntryBoundingClientRect = e.target.getBoundingClientRect();
            targetTab = e.target;
            under = false;
            if ((e.clientY - tabEntryBoundingClientRect.top) >= tabEntryBoundingClientRect.height / 2) {
                targetTab = targetTab.nextSibling;
                if (targetTab === null) {
                    under = true;
                    targetTab = e.target;
                }
            }
        }
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggable"])(sourceTab, targetTab, under, sourceWindow, multiDragging)) {
            let destinationWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(targetTab));
            let sourceTabIndex = Array.prototype.indexOf.call(targetTab.parentElement.childNodes, sourceTab);
            let destinationIndex = Array.prototype.indexOf.call(targetTab.parentElement.childNodes, targetTab);
            let moveIndex = under ? -1 : ((sourceTabIndex !== -1 && destinationIndex > sourceTabIndex && destinationWindowId === sourceWindowId) ? destinationIndex-1 : destinationIndex);
            let sourceTabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getTabId"])(sourceTab);
            browser.tabs.move(sourceTabId, {
                windowId: destinationWindowId,
                index: moveIndex
            });
            if (under) {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["attachTab"])(sourceTab, Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(targetTab));
            } else {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["moveTab"])(sourceTab, targetTab);
            }
        }
    } else if ((windowEntry = e.target.parentElement) !== null && windowEntry.classList.contains("window-entry")) {
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggableToWindow"])(sourceTab, windowEntry, sourceWindow)) {
            let sourceTabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getTabId"])(sourceTab);
            let destinationWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(windowEntry);
            browser.tabs.move(sourceTabId, {
                windowId: destinationWindowId,
                index: -1
            });
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["attachTab"])(sourceTab, windowEntry);
        }
    }
}

function windowEntryTitleClicked(e) {
    let windowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(e.target.parentElement);
    browser.windows.update(windowId, {
        focused: true
    });
}

function windowCloseClick(e) {
    let windowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(e.target.parentElement.parentElement.parentElement);
    browser.windows.remove(windowId);
}


/***/ }),

/***/ "./src/popup/globals.js":
/*!******************************!*\
  !*** ./src/popup/globals.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const globals = {
    tabsList: undefined,
    isSelecting: false,
    slideSelection: {
        sliding: false,
        initiator: undefined,
        vector: 0
    },
    hideAfterTabSelection: undefined,
    searchInURLs: undefined
};
/* harmony default export */ __webpack_exports__["default"] = (globals);


/***/ }),

/***/ "./src/popup/keyutils.js":
/*!*******************************!*\
  !*** ./src/popup/keyutils.js ***!
  \*******************************/
/*! exports provided: ctrlOrCmd */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ctrlOrCmd", function() { return ctrlOrCmd; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


let keyPressed = {};
onkeydown = onkeyup = e => {
    e = e || event;
    keyPressed[e.code] = e.type == "keydown";
};

// Checks if either Ctrl(Windows & Linux) or Command(Mac) is pressed
function ctrlOrCmd() {
    if (window.navigator.platform.toUpperCase().indexOf("MAC") >= 0) {
        return keyPressed["OSRight"] || keyPressed["OSLeft"];
    }
    return keyPressed["ControlLeft"] || keyPressed["ControlRight"];
}


/***/ }),

/***/ "./src/popup/messaging.js":
/*!********************************!*\
  !*** ./src/popup/messaging.js ***!
  \********************************/
/*! exports provided: sendRuntimeMessage, sendTabMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendRuntimeMessage", function() { return sendRuntimeMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendTabMessage", function() { return sendTabMessage; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Function to send a message to the runtime
function sendRuntimeMessage(type, data) {
    return browser.runtime.sendMessage({
        type: type,
        data: data
    });
}

// Function to send a message to a tab
function sendTabMessage(tabId, target, data) {
    return browser.tabs.sendMessage(tabId, {
        target: target,
        data: data
    });
}


/***/ }),

/***/ "./src/popup/net.js":
/*!**************************!*\
  !*** ./src/popup/net.js ***!
  \**************************/
/*! exports provided: getImage, arrayBufferToBase64 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getImage", function() { return getImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "arrayBufferToBase64", function() { return arrayBufferToBase64; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Function to get image from URL
function getImage(url, noCache=false) {
    return new Promise((resolve, reject) => {
        try {
            if (!url.startsWith("chrome://")) {
                let xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function(){
                    if (this.readyState == 4 && this.status == 200) {
                        let contentType = xhr.getResponseHeader("Content-Type").trim();
                        if (contentType.startsWith("image/")) {
                            let flag = "data:" + contentType + ";charset=utf-8;base64,";
                            let imageStr = arrayBufferToBase64(xhr.response);
                            resolve(flag + imageStr);
                        } else {
                            reject("Image Request Failed: Content-Type is not an image! (Content-Type: \"" + contentType + "\")");
                        }
                    }
                };
                xhr.responseType = "arraybuffer";
                xhr.open("GET", url, true);
                if (noCache) { xhr.setRequestHeader("Cache-Control", "no-store"); }
                xhr.send();
            } else {
                resolve();
            }
        } catch (err) {
            reject(err.message);
        }
    });
}

// Function to transform ArrayBuffer into a Base64 String
function arrayBufferToBase64(buffer) {
    let binary = "";
    let bytes = [].slice.call(new Uint8Array(buffer));
    bytes.forEach((b) => binary += String.fromCharCode(b));
    return window.btoa(binary);
}


/***/ }),

/***/ "./src/popup/popup.js":
/*!****************************!*\
  !*** ./src/popup/popup.js ***!
  \****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");
/* harmony import */ var _wtinit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wtinit */ "./src/popup/wtinit.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./domutils */ "./src/popup/domutils.js");
/* harmony import */ var _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./event-listeners/document */ "./src/popup/event-listeners/document.js");
/* harmony import */ var _event_listeners_search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-listeners/search */ "./src/popup/event-listeners/search.js");
/* harmony import */ var _event_listeners_message__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./event-listeners/message */ "./src/popup/event-listeners/message.js");
/* harmony import */ var _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./event-listeners/recorder */ "./src/popup/event-listeners/recorder.js");
/* harmony import */ var _captureTab__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./captureTab */ "./src/popup/captureTab.js");
/* harmony import */ var _options__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../options */ "./src/options.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./wtdom */ "./src/popup/wtdom.js");
/* harmony import */ var _recorder__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./recorder */ "./src/popup/recorder.js");














_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList = document.getElementById("tabs-list");

function setPopupSize(width, height) {
    document.documentElement.style.width = width + "px";
    document.documentElement.style.height = height + "px";
    document.body.style.width = width + "px";
    document.body.style.height = height + "px";
}

async function fulfillOptions() {
    let popupOptions = (await _options__WEBPACK_IMPORTED_MODULE_10__["options"]()).popup;
    // popup.size
    setPopupSize(popupOptions.size.width, popupOptions.size.height);
    // popup.scale
    document.documentElement.style.setProperty('--scale', popupOptions.scale.toString());
    // popup.showDetails
    if (!_options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.showDetails)) {
        let leftContainer = document.getElementById("left-container");
        popupOptions.size.width = popupOptions.size.width - Object(_domutils__WEBPACK_IMPORTED_MODULE_4__["getActualWidth"])(leftContainer);
        setPopupSize(popupOptions.size.width, popupOptions.size.height);
        leftContainer.style.display = "none";
        document.getElementById("tabs-container").style.width = "100%";
    } else {
        // popup.showPreview
        if (!_options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.showPreview)) Object(_wtdom__WEBPACK_IMPORTED_MODULE_11__["hideTabPreview"])();
    }
    // popup.hideAfterTabSelection
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].hideAfterTabSelection = _options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.hideAfterTabSelection);
    // popup.searchInURLs
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].searchInURLs = _options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.searchInURLs);
}

async function main() {
    // Initialize captureTab based on environment
    _captureTab__WEBPACK_IMPORTED_MODULE_9__["init"]();
    // Fulfill user options
    await fulfillOptions();
    // Make tabs list fit the panel
    Object(_wtinit__WEBPACK_IMPORTED_MODULE_3__["extendTabsList"])();
    // Fix for cross-window dragging issue
    await Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_2__["getWrongToRight"])();
    // Populate tabs list with tabs
    await Object(_wtinit__WEBPACK_IMPORTED_MODULE_3__["populateTabsList"])();
    // Update recorder tooltip
    await Object(_recorder__WEBPACK_IMPORTED_MODULE_12__["updateRecorderToolTip"])();
}

/* Add event listeners */

// Starting point
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
} else {
    main();
}

document.addEventListener("mouseover", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentMouseOver"]);
document.addEventListener("mouseup", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentMouseUp"]);
document.addEventListener("click", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentClicked"]);
document.addEventListener("keypress", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentKeyPressed"]);

// Add keyup event listener and put focus on search
let search = document.getElementById("search");
search.addEventListener("keyup", _event_listeners_search__WEBPACK_IMPORTED_MODULE_6__["searchTextChanged"]);
search.focus();

// Add event listeners to all copy buttons
let copyButtons = Array.from(document.getElementsByClassName("copy-button"));
for (let i = 0; i < copyButtons.length; i++) {
    copyButtons[i].addEventListener("click", e => {
        document.oncopy = ce => {
            ce.clipboardData.setData("text", document.getElementById(e.target.getAttribute("for")).innerText);
            ce.preventDefault();
        };
        document.execCommand("copy", false, null);
        e.target.innerText = "Copied!";
        setTimeout(() => {
            e.target.innerText = "Copy";
        }, 2000);
    });
}

// Add event listener for recorder.js
document.getElementById("save-for-later").addEventListener("click", _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__["saveForLater"]);
document.getElementById("restore-now").addEventListener("click", _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__["restore"]);

// Add event listener to listen for any messages from background.js
if (!browser.runtime.onMessage.hasListener(_event_listeners_message__WEBPACK_IMPORTED_MODULE_7__["onMessage"])) {
    browser.runtime.onMessage.addListener(_event_listeners_message__WEBPACK_IMPORTED_MODULE_7__["onMessage"]);
}


/***/ }),

/***/ "./src/popup/recorder.js":
/*!*******************************!*\
  !*** ./src/popup/recorder.js ***!
  \*******************************/
/*! exports provided: lastRecord, updateRecorderToolTip, record, restore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lastRecord", function() { return lastRecord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateRecorderToolTip", function() { return updateRecorderToolTip; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "record", function() { return record; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "restore", function() { return restore; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wtdom */ "./src/popup/wtdom.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wtutils */ "./src/popup/wtutils.js");





async function lastRecord() {
    return browser.storage.local.get(["record"]).then(data => data.record);
}

async function updateRecorderToolTip() {
    let r = await lastRecord();
    let restoreBtn = document.getElementById("restore-now");
    if (r) {
        restoreBtn.setAttribute("title", "Restore websites that have been saved on " + (new Date(r.timestamp)).toLocaleString());
        restoreBtn.removeAttribute("disabled");
    } else {
        restoreBtn.setAttribute("title", "Restore websites that have been saved");
        restoreBtn.setAttribute("disabled", "");
    }
}

function tabInfoToRecord(info) {
    return {
        url: info.url,
        pinned: info.pinned
    };
}
async function record() {
    let recordArray = [];
    for (let windowEntry of _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("window-entry")) {
        let windowRecord = [];
        for (let tabEntry of windowEntry.getElementsByClassName("tab-entry")) {
            await browser.tabs.sendMessage(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry), { target: "packd", data: { action: "pack" } }).then(async pack => {
                windowRecord.push(Object.assign({
                    pack: pack
                }, tabInfoToRecord(await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry)))));
            }).catch(async reason => {
                windowRecord.push(Object.assign({
                    pack: undefined
                }, tabInfoToRecord(await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry)))));
            });
        }
        recordArray.push(windowRecord);
    }
    let record = {
        timestamp: Date.now(),
        record: recordArray
    };
    return browser.storage.local.set({ record: record }).then(() => updateRecorderToolTip());
}

async function restore() {
    let { record: r } = await lastRecord();
    for (let windowRecord of r) {
        if (browser.runtime.getBrowserInfo) {
            windowRecord = windowRecord.filter(tabRecord => !tabRecord.url.startsWith("about:"))
        }
        browser.windows.create({
            url: windowRecord.map(tabRecord => tabRecord.url)
        }).then(async w => {
            for (let i = 0; i < windowRecord.length; i++) {
                let tabRecord = windowRecord[i];
                await browser.tabs.update(w.tabs[i].id, {
                    pinned: tabRecord.pinned
                }).then(t => {
                    if (tabRecord.pack) {
                        Object(_wtutils__WEBPACK_IMPORTED_MODULE_3__["runAfterTabLoad"])(t.id, () => {
                            browser.tabs.sendMessage(t.id, {
                                target: "packd",
                                data: Object.assign({action: "unpack"}, tabRecord.pack)
                            });
                        });
                    }
                }).catch(e => {
                    console.log(e);
                });
            }
        });
    }
}


/***/ }),

/***/ "./src/popup/wrong-to-right.js":
/*!*************************************!*\
  !*** ./src/popup/wrong-to-right.js ***!
  \*************************************/
/*! exports provided: getWrongToRight, getCorrectTabId */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWrongToRight", function() { return getWrongToRight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCorrectTabId", function() { return getCorrectTabId; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _messaging__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./messaging */ "./src/popup/messaging.js");



let wrongToRight;

function getWrongToRight() {
    return Object(_messaging__WEBPACK_IMPORTED_MODULE_1__["sendRuntimeMessage"])("WRONG_TO_RIGHT_GET", {}).then(response => {
        wrongToRight = response.wrongToRight;
    });
}

// Function to get correct tab id
function getCorrectTabId(tabId) {
    return wrongToRight[tabId] || tabId;
}


/***/ }),

/***/ "./src/popup/wtdom.js":
/*!****************************!*\
  !*** ./src/popup/wtdom.js ***!
  \****************************/
/*! exports provided: hideTabPreview, getTabByTabEntry, getTabId, getWindowId, findTabEntryById, findCorrectTabEntryById, getFavIconFromTabEntry, findWindowEntryById, findTabEntryInWindow, getActiveTab, setActiveTab, removeTab, moveTab, moveTabs, attachTab, attachTabs, removeWindow, getWindowFromTab, tabDraggable, tabDraggableToWindow, tabEntryIndex, getSelectedItems, multiSelected, multiSelect, multiSelectCancel, multiSelectReset, multiSelectToggle, resetSlideSelection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hideTabPreview", function() { return hideTabPreview; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabByTabEntry", function() { return getTabByTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabId", function() { return getTabId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindowId", function() { return getWindowId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findTabEntryById", function() { return findTabEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findCorrectTabEntryById", function() { return findCorrectTabEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFavIconFromTabEntry", function() { return getFavIconFromTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findWindowEntryById", function() { return findWindowEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findTabEntryInWindow", function() { return findTabEntryInWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActiveTab", function() { return getActiveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setActiveTab", function() { return setActiveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeTab", function() { return removeTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveTab", function() { return moveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveTabs", function() { return moveTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachTab", function() { return attachTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachTabs", function() { return attachTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeWindow", function() { return removeWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindowFromTab", function() { return getWindowFromTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabDraggable", function() { return tabDraggable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabDraggableToWindow", function() { return tabDraggableToWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryIndex", function() { return tabEntryIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectedItems", function() { return getSelectedItems; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelected", function() { return multiSelected; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelect", function() { return multiSelect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectCancel", function() { return multiSelectCancel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectReset", function() { return multiSelectReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectToggle", function() { return multiSelectToggle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetSlideSelection", function() { return resetSlideSelection; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");




// Hides the tab preview
function hideTabPreview() {
    document.getElementById("details-img").style.display = "none";
}

// Get a tab by a tab entry
function getTabByTabEntry(entry) {
    return browser.tabs.get(getTabId(entry));
}

// Get the TabId of a tab entry
function getTabId(entry) {
    return parseInt(entry.getAttribute("data-tab_id"));
}

// Get the WindowId of a window entry
function getWindowId(entry) {
    return parseInt(entry.getAttribute("data-window_id"));
}

// Find tab entry by tab id
function findTabEntryById(tabId) {
    return document.querySelector(".tab-entry[data-tab_id=\"" + tabId + "\"]");
}

// Find correct tab entry by tab id
function findCorrectTabEntryById(tabId) {
    return findTabEntryById(Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_2__["getCorrectTabId"])(tabId));
}

// Get favicon from a tab entry
function getFavIconFromTabEntry(entry) {
    return entry.getElementByClassName("tab-entry-favicon");
}

// Find window entry by tab id
function findWindowEntryById(windowId) {
    return _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.querySelector("li[data-window_id=\"" + windowId + "\"]");
}

// Find tab entry inside a window entry
function findTabEntryInWindow(windowEntry, tabId) {
    return windowEntry.querySelector("li[data-tab_id=\"" + tabId + "\"]");
}

// Get active tab in the specified window
function getActiveTab(windowId) {
    let window = findWindowEntryById(windowId);
    return window.getElementByClassName("current-tab");
}

// Set active tab in the specified window
function setActiveTab(windowId, tabId) {
    let window = findWindowEntryById(windowId), lastActiveTab;
    if ((lastActiveTab = getActiveTab(windowId)) !== null) {
        lastActiveTab.classList.remove("current-tab");
    }
    findTabEntryInWindow(window, tabId).classList.add("current-tab");
}

// Remove tab
function removeTab(tabId, windowId) {
    let tabEntry = findTabEntryById(tabId);
    tabEntry.parentElement.removeChild(tabEntry);
    browser.tabs.query({
        active: true,
        windowId: windowId
    }).then(tabs => {
        findCorrectTabEntryById(tabs[0].id).classList.add("current-tab");
    });
}

// Move tab
function moveTab(target, dest) {
    getWindowFromTab(dest).getElementByClassName("window-entry-tabs").insertBefore(target, dest);
}

// Move tabs
function moveTabs(targets, dest) {
    for (let i = 0; i < targets.length; i++) moveTab(targets[i], dest);
}

// Attach tab
function attachTab(target, dest) {
    dest.getElementByClassName("window-entry-tabs").appendChild(target);
}

// Attach tabs
function attachTabs(targets, dest) {
    for (let i = 0; i < targets.length; i++) attachTab(targets[i], dest);
}

// Remove window
function removeWindow(windowId) {
    let windowEntry = findWindowEntryById(windowId);
    windowEntry.parentElement.removeChild(windowEntry);
    browser.windows.getCurrent({}).then(window => {
        findWindowEntryById(window.id).classList.add("current-window");
    });
}

function getWindowFromTab(tab) {
    return tab.parentElement.parentElement;
}

// Test if tab is draggable
function tabDraggable(sourceTab, targetTab, under, sourceWindow, multiDragging) {
    return !sourceTab.isSameNode(targetTab)
            && (!multiDragging || (multiSelected(sourceTab) && multiSelected(targetTab)))
            && ((!sourceTab.classList.contains("pinned-tab") && !targetTab.classList.contains("pinned-tab"))
                || (sourceTab.classList.contains("pinned-tab") && targetTab.classList.contains("pinned-tab"))
                || (under && !sourceTab.classList.contains("pinned-tab")))
            && ((!sourceWindow.classList.contains("incognito-window") && !getWindowFromTab(targetTab).classList.contains("incognito-window"))
                || (sourceWindow.classList.contains("incognito-window") && getWindowFromTab(targetTab).classList.contains("incognito-window")));
}

// Test if tab is draggable to window
function tabDraggableToWindow(sourceTab, targetWindow, sourceWindow) {
    return !sourceWindow.isSameNode(targetWindow)
            && !sourceTab.classList.contains("pinned-tab")
            && ((!sourceWindow.classList.contains("incognito-window") && !targetWindow.classList.contains("incognito-window"))
                || (sourceWindow.classList.contains("incognito-window") && targetWindow.classList.contains("incognito-window")));
}

// Returns the index of a tab entry
function tabEntryIndex(tabEntry) {
    let tabs = Array.from(document.getElementsByClassName("tab-entry"));
    for (let i = 0; i < tabs.length; i++) {
        if (tabs[i] === tabEntry) {
            return i;
        }
    }
    return -1;
}

/* Multiselect */
let selectedTabs = 0;
// Get Selected Items
function getSelectedItems() {
    return Array.from(document.getElementsByClassName("multiselect"));
}
// Multiselected
function multiSelected(element) {
    return element.classList.contains("multiselect");
}
// Select
function multiSelect(element) {
    if (!element.classList.contains("multiselect")) {
        selectedTabs++;
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = true;
        element.classList.add("multiselect");
    }
}
// Cancel Selection
function multiSelectCancel(element) {
    if (element.classList.contains("multiselect")) {
        if (--selectedTabs == 0) {
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = false;
        }
        element.classList.remove("multiselect");
    }
}
// Reset multiselect
function multiSelectReset() {
    for (let element of Array.from(document.getElementsByClassName("multiselect"))) {
        element.classList.remove("multiselect");
    }
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = false;
}
// Toggle Selection
function multiSelectToggle(element) {
    if (element.classList.contains("multiselect")) {
        multiSelectCancel(element);
    } else {
        multiSelect(element);
    }
}
// Reset slide selection
function resetSlideSelection() {
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding = false;
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator = undefined;
}


/***/ }),

/***/ "./src/popup/wtinit.js":
/*!*****************************!*\
  !*** ./src/popup/wtinit.js ***!
  \*****************************/
/*! exports provided: updateTabs, populateTabsList, extendTabsList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateTabs", function() { return updateTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "populateTabsList", function() { return populateTabsList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "extendTabsList", function() { return extendTabsList; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _net__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./net */ "./src/popup/net.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./wtutils */ "./src/popup/wtutils.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./domutils */ "./src/popup/domutils.js");
/* harmony import */ var _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-listeners/windowEntry */ "./src/popup/event-listeners/windowEntry.js");
/* harmony import */ var _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./event-listeners/tabEntry */ "./src/popup/event-listeners/tabEntry.js");









// Update tabs
function updateTabs(windows) {
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.innerHTML = "";
    let tabsListFragment = document.createDocumentFragment();
    let currentWindowEntry;
    /* Predefined elements for faster performance */
    // Window close button
    let WINDOW_CLOSE_BTN = document.createElement("span");
    WINDOW_CLOSE_BTN.classList.add("inline-button");
    WINDOW_CLOSE_BTN.classList.add("img-button");
    WINDOW_CLOSE_BTN.classList.add("opacity-changing-button");
    WINDOW_CLOSE_BTN.classList.add("window-entry-remove-btn");
    WINDOW_CLOSE_BTN.style.backgroundImage = "url(../icons/close.svg)";
    let DIV = document.createElement("div");
    DIV.style.display = "inline-block";
    WINDOW_CLOSE_BTN.appendChild(DIV);
    // Tab close button
    let TAB_CLOSE_BTN = document.createElement("span");
    TAB_CLOSE_BTN.classList.add("inline-button");
    TAB_CLOSE_BTN.classList.add("red-button");
    TAB_CLOSE_BTN.classList.add("img-button");
    TAB_CLOSE_BTN.classList.add("tab-entry-remove-btn");
    TAB_CLOSE_BTN.style.backgroundImage = "url(../icons/close.svg)";
    // Tab pin button
    let TAB_PIN_BTN = document.createElement("span");
    TAB_PIN_BTN.classList.add("inline-button");
    TAB_PIN_BTN.classList.add("img-button");
    TAB_PIN_BTN.classList.add("opacity-changing-button");
    TAB_PIN_BTN.classList.add("tab-entry-pin-btn");
    TAB_PIN_BTN.style.backgroundImage = "url(../icons/pin.svg)";
    // Loop through windows
    for (let i = 0; i < windows.length; i++) {
        // Set w to window
        let w = windows[i];

        // Create window entry
        let windowEntry = document.createElement("li");
        windowEntry.classList.add("window-entry");
        windowEntry.classList.add("category");

        // Create window entry fragment
        let windowEntryFragment = document.createDocumentFragment();

        // Set window id to window entry
        windowEntry.setAttribute("data-window_id", w.id);
        let span = document.createElement("span");
        span.addEventListener("click", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryTitleClicked"]);

        // Create close button
        let closeBtn = WINDOW_CLOSE_BTN.cloneNode(true);
        closeBtn.addEventListener("click", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowCloseClick"]);

        // Buttons wrapper
        let buttons = document.createElement("span");
        buttons.classList.add("window-entry-buttons");
        buttons.appendChild(closeBtn);
        
        // Create window name span
        let windowName = document.createElement("span");
        windowName.classList.add("window-title");
        windowName.textContent += "Window " + (i+1);

        // Check if window is focused
        if (w.focused) {
            currentWindowEntry = windowEntry;
            windowEntry.classList.add("current-window");
            windowName.textContent += " - Current";
        }
        // Check if window is incognito
        if (w.incognito) {
            windowEntry.classList.add("incognito-window");
            windowName.textContent += " (Incognito)";
        }

        span.appendChild(windowName);
        span.appendChild(buttons);

        span.classList.add("darker-button");

        windowEntryFragment.appendChild(span);

        // Add window entry dragstart, dragover, and drop event listeners
        windowEntry.addEventListener("dragstart", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDragStarted"]);
        windowEntry.addEventListener("dragover", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDraggingOver"]);
        windowEntry.addEventListener("drop", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDropped"]);
        windowEntry.setAttribute("draggable", "true");

        let windowTabsList = document.createElement("ul");
        windowTabsList.classList.add("category-list");
        windowTabsList.classList.add("window-entry-tabs");

        let windowTabsListFragment = document.createDocumentFragment();
        // Loop through tabs
        for (let i = 0; i < w.tabs.length; i++) {
            let tab = w.tabs[i];
            // Check tab id
            if (tab.id !== browser.tabs.TAB_ID_NONE) {
                // Create tab entry
                let tabEntry = document.createElement("li");
                tabEntry.classList.add("tab-entry");
                tabEntry.classList.add("button");
                // Set tab entry as draggable. Required to enable move tab feature
                tabEntry.setAttribute("draggable", "true");

                // Create tab entry fragment
                let tabEntryFragment = document.createDocumentFragment();

                let favicon;
                let title = document.createElement("span");
                title.classList.add("tab-title");
                title.textContent += tab.title;
                let titleWrapper = document.createElement("div");
                titleWrapper.classList.add("tab-title-wrapper");
                titleWrapper.appendChild(title);

                if (tab.active) {
                    tabEntry.classList.add("current-tab");
                }
                if (tab.favIconUrl) {
                    favicon = document.createElement("img");
                    favicon.classList.add("tab-entry-favicon");
                    let favIconPromise;
                    if (w.incognito) {
                        favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(tab.favIconUrl, true);
                    } else {
                        favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(tab.favIconUrl);
                    }
                    favIconPromise.then(base64Image => {
                        favicon.src = base64Image;
                    });
                }

                // Create close button
                closeBtn = TAB_CLOSE_BTN.cloneNode(false);
                closeBtn.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabCloseClick"]);

                // Create pin button
                let pinBtn = TAB_PIN_BTN.cloneNode(false);
                pinBtn.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabPinClick"]);

                // Buttons wrapper
                buttons = document.createElement("span");
                buttons.classList.add("tab-entry-buttons");
                buttons.appendChild(pinBtn);
                buttons.appendChild(closeBtn);

                // Set tab entry tab id
                tabEntry.setAttribute("data-tab_id", Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_3__["getCorrectTabId"])(tab.id));
                if (favicon !== undefined) {
                    tabEntryFragment.appendChild(favicon);
                } else {
                    tabEntry.classList.add("noicon");
                }
                tabEntryFragment.appendChild(titleWrapper);
                tabEntryFragment.appendChild(buttons);
                
                tabEntry.appendChild(tabEntryFragment);

                tabEntry.addEventListener("mouseover", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryMouseOver"]);
                tabEntry.addEventListener("mouseleave", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryMouseLeave"]);
                tabEntry.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryClicked"]);

                if (tab.pinned) {
                    pinBtn.style.backgroundImage = "url(../icons/pinremove.svg)";
                    tabEntry.classList.add("pinned-tab");
                    let pinnedTabs = Array.from(windowTabsList.getElementsByClassName("pinned-tab"));
                    let lastPinnedTab = pinnedTabs[pinnedTabs.length-1];
                    if (lastPinnedTab !== undefined) {
                        windowTabsListFragment.insertBefore(tabEntry, lastPinnedTab.nextSibling);
                    } else {
                        windowTabsListFragment.insertBefore(tabEntry, windowTabsList.childNodes[0]);
                    }
                } else {
                    windowTabsListFragment.appendChild(tabEntry);
                }
            }
        }

        // Append fragment to actual windowTabsList
        windowTabsList.appendChild(windowTabsListFragment);

        windowEntryFragment.appendChild(windowTabsList);
        windowEntry.appendChild(windowEntryFragment);
        tabsListFragment.appendChild(windowEntry);
    }
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.appendChild(tabsListFragment);
    document.getElementById("tabs").style.display = "block";
    currentWindowEntry.scrollIntoView({ behavior: 'smooth' });
}

// Add tabs to list
async function populateTabsList() {
    let windows = await Object(_wtutils__WEBPACK_IMPORTED_MODULE_4__["getWindows"])();
    await Object(_wtutils__WEBPACK_IMPORTED_MODULE_4__["correctFocused"])(windows);
    updateTabs(windows);
}

// Set tabs list height to any available height
function extendTabsList() {
    let searchArea = document.getElementById("search-area");
    let searchAreaHeight = Object(_domutils__WEBPACK_IMPORTED_MODULE_5__["getActualHeight"])(searchArea);
    let tabs = document.getElementById("tabs");
    tabs.style.height = "calc(100% - " + searchAreaHeight + "px)";
}


/***/ }),

/***/ "./src/popup/wtutils.js":
/*!******************************!*\
  !*** ./src/popup/wtutils.js ***!
  \******************************/
/*! exports provided: getWindows, getLastFocusedWindowId, correctFocused, getLastFocusedWindow, runAfterTabLoad */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindows", function() { return getWindows; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastFocusedWindowId", function() { return getLastFocusedWindowId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "correctFocused", function() { return correctFocused; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastFocusedWindow", function() { return getLastFocusedWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "runAfterTabLoad", function() { return runAfterTabLoad; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Get all windows
function getWindows() {
    return browser.windows.getAll({
        populate: true,
        windowTypes: ["normal", "popup", "devtools"]
    });
}

// Get the correct last focused window id
function getLastFocusedWindowId() {
    /*
    Due to a bug in Chromium, windows.getLastFocused() will sometimes
    return incorrect windows. So here, instead of calling getLastFocused(),
    we call getCurrent().
    Reference: https://crbug.com/809822
    */
    return browser.tabs.query({ lastFocusedWindow: true }).then(function (tabs) {
        if (tabs.length > 0) {
            return tabs[0].windowId;
        }
        return -1;
    });
}

// Correct focused property of windows
// In Chromium, window.focused doesn't work, so we manually set it here
function correctFocused(windows) {
    return getLastFocusedWindowId().then(function (lastFocusedWindowId) {
        for (let i = 0; i < windows.length; i++) {
            if (windows[i].id === lastFocusedWindowId) {
                windows[i].focused = true;
            }
        }
    });
}

// Get current window
function getLastFocusedWindow() {
    // return browser.windows.getLastFocused({}); // Doesn't work due to a bug in Chromium. See explanation in getLastFocusedWindowId
    return getLastFocusedWindowId().then(windowId => browser.windows.get(windowId));
}

// Run code after a tab loads
function runAfterTabLoad(tabId, f) {
    return new Promise((resolve, reject) => {
        let listener = (uTabId, info) => {
            if (uTabId === tabId && info.status === 'complete') {
                browser.tabs.onUpdated.removeListener(listener);
                resolve(f());
            }
        };
        browser.tabs.onUpdated.addListener(listener);
    });
}


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL29wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL29wdGlvbnMvc3RhdGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9wb2x5ZmlsbC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvY2FwdHVyZVRhYi5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZG9tdXRpbHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2V2ZW50LWxpc3RlbmVycy9kb2N1bWVudC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL21lc3NhZ2UuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2V2ZW50LWxpc3RlbmVycy9yZWNvcmRlci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL3NlYXJjaC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL3RhYkVudHJ5LmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC9ldmVudC1saXN0ZW5lcnMvd2luZG93RW50cnkuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2dsb2JhbHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2tleXV0aWxzLmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC9tZXNzYWdpbmcuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL25ldC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvcG9wdXAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL3JlY29yZGVyLmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC93cm9uZy10by1yaWdodC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvd3Rkb20uanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL3d0aW5pdC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvd3R1dGlscy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7O0FDbEZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDNEU7QUFDeEI7O0FBRTlEO0FBQ1A7QUFDQTs7QUFFTztBQUNQLHNDQUFzQyxtQkFBbUI7QUFDekQ7O0FBRU87QUFDUDtBQUNBLGFBQWEseURBQVM7QUFDdEIsYUFBYSxnRUFBZ0I7QUFDN0I7QUFDQSxhQUFhLDBEQUFVO0FBQ3ZCLGFBQWEsaUVBQWlCO0FBQzlCO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3JCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF3Qzs7QUFFakM7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksc0RBQWE7QUFDakI7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDdkJBO0FBQUE7QUFBTyxzQkFBc0IsUUFBTTs7QUFFbkMsSUFBSSxLQUFtQixFQUFFLEVBRXhCOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsVUFBVTtBQUMxQyxvREFBb0QsZUFBZTtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxtRUFBbUU7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjs7QUFFVjs7QUFFQTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNkQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCOztBQUVqQjtBQUNPO0FBQ1A7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUM5QkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNTO0FBQ2E7QUFDVTtBQUNOO0FBQzhGOztBQUVsSTtBQUNQO0FBQ0E7O0FBRU87QUFDUCxRQUFRLGdEQUFDLHlCQUF5QixrRUFBbUI7QUFDckQ7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyx1REFBUTtBQUN4QyxTQUFTLE9BQU87QUFDaEIsZ0JBQWdCLGdEQUFDLGNBQWMsK0RBQWdCO0FBQy9DO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN2Q0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ0c7QUFDYTtBQUMyRjs7QUFFckg7QUFDUDtBQUNBO0FBQ0EsWUFBWSwyREFBWTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLHFEQUFRO0FBQzdDLGlCQUFpQjtBQUNqQixxQ0FBcUMscURBQVE7QUFDN0M7QUFDQTtBQUNBLG9CQUFvQixxRUFBc0IsQ0FBQywrREFBZ0I7QUFDM0QsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0EsMkJBQTJCLCtEQUFnQjtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksK0RBQWdCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQix3REFBUztBQUN6QjtBQUNBO0FBQ0E7QUFDQSxZQUFZLDJEQUFZO0FBQ3hCO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3hEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXlEOztBQUV6RDtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSxJQUFJLHdEQUFNO0FBQ1Y7QUFDQTtBQUNBLGlDQUFpQztBQUNqQyxLQUFLO0FBQ0w7O0FBRWtCOzs7Ozs7Ozs7Ozs7O0FDZmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUztBQUNTOztBQUVuQztBQUNBO0FBQ0EsbUJBQW1CLHFCQUFxQjtBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLHVCQUF1QjtBQUM5QztBQUNBO0FBQ0Esa0JBQWtCLGdEQUFDLGdEQUFnRCx1REFBUTtBQUMzRTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsdUJBQXVCLHVCQUF1QjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDM0NBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNTO0FBQ2E7QUFDVTtBQUNOO0FBQzhGOztBQUVsSTtBQUNQO0FBQ0EsUUFBUSwyREFBUyxNQUFNLGdEQUFDO0FBQ3hCLFFBQVEsMERBQVc7QUFDbkIsS0FBSztBQUNMLG9CQUFvQix1REFBUTtBQUM1QixRQUFRLHNEQUFxQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7O0FBRU87QUFDUDtBQUNBLFlBQVksMkRBQVM7QUFDckIsWUFBWSxnRUFBaUI7QUFDN0IsU0FBUztBQUNULHdCQUF3Qix1REFBUTtBQUNoQyxpQ0FBaUMsMERBQVcsQ0FBQywrREFBZ0I7QUFDN0Q7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLGdCQUFnQixxRUFBb0I7QUFDcEM7QUFDQTtBQUNBO0FBQ0EseUJBQXlCO0FBQ3pCO0FBQ0Esd0JBQXdCLGdEQUFDO0FBQ3pCLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQLGdCQUFnQix1REFBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7OztBQ2xHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNTO0FBQ2E7QUFDaUk7O0FBRXhLOztBQUVBO0FBQ0E7QUFDQSx3QkFBd0IsK0RBQWdCO0FBQ3hDO0FBQ0EsbUJBQW1CLDhCQUE4QjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0EsWUFBWSwyREFBUztBQUNyQixZQUFZLDBEQUFXO0FBQ3ZCLFlBQVksZ0RBQUM7QUFDYjtBQUNBLFNBQVM7QUFDVDtBQUNBLDJCQUEyQiwrREFBZ0I7QUFDM0MsNkJBQTZCLDBEQUFXO0FBQ3hDO0FBQ0EsZ0JBQWdCLGdEQUFDLGdCQUFnQiw0REFBYTtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQSw2QkFBNkIsZ0RBQUM7QUFDOUIsbUJBQW1CLG9CQUFvQjtBQUN2QztBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsZ0RBQUM7QUFDeEI7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksMkRBQVk7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLFlBQVksbUVBQW9CO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBLDZCQUE2QixnREFBQztBQUM5QixtQkFBbUIsb0JBQW9CO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixnREFBQztBQUN4QjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksMkRBQVk7QUFDeEIsc0NBQXNDLDBEQUFXLENBQUMsK0RBQWdCO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBLDhCQUE4Qix1REFBUTtBQUN0QztBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxnQkFBZ0Isd0RBQVMsWUFBWSwrREFBZ0I7QUFDckQsYUFBYTtBQUNiLGdCQUFnQixzREFBTztBQUN2QjtBQUNBO0FBQ0EsS0FBSztBQUNMLFlBQVksbUVBQW9CO0FBQ2hDLDhCQUE4Qix1REFBUTtBQUN0QyxzQ0FBc0MsMERBQVc7QUFDakQ7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFlBQVksd0RBQVM7QUFDckI7QUFDQTtBQUNBOztBQUVPO0FBQ1AsbUJBQW1CLDBEQUFXO0FBQzlCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRU87QUFDUCxtQkFBbUIsMERBQVc7QUFDOUI7QUFDQTs7Ozs7Ozs7Ozs7OztBQzNKQTtBQUFBO0FBQWlCOztBQUVqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDZSxzRUFBTyxFQUFDOzs7Ozs7Ozs7Ozs7O0FDYnZCO0FBQUE7QUFBQTtBQUFpQjs7QUFFakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2RBO0FBQUE7QUFBQTtBQUFBO0FBQWlCOztBQUVqQjtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7Ozs7Ozs7Ozs7Ozs7QUNoQkE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7O0FBRWpCO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLGNBQWM7QUFDL0U7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsbURBQW1EO0FBQ2pGO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3ZDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ1E7QUFDeUI7QUFDUztBQUNoQjtBQUN5RTtBQUN4RDtBQUNQO0FBQ2dDO0FBQzNDO0FBQ0w7QUFDRztBQUNXOztBQUVuRCxnREFBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4QkFBOEIsaURBQWU7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsZ0RBQWM7QUFDdkI7QUFDQSw0REFBNEQsZ0VBQWM7QUFDMUU7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsYUFBYSxnREFBYyw0QkFBNEIsOERBQWM7QUFDckU7QUFDQTtBQUNBLElBQUksZ0RBQUMseUJBQXlCLGdEQUFjO0FBQzVDO0FBQ0EsSUFBSSxnREFBQyxnQkFBZ0IsZ0RBQWM7QUFDbkM7O0FBRUE7QUFDQTtBQUNBLElBQUksZ0RBQWU7QUFDbkI7QUFDQTtBQUNBO0FBQ0EsSUFBSSw4REFBYztBQUNsQjtBQUNBLFVBQVUsdUVBQWU7QUFDekI7QUFDQSxVQUFVLGdFQUFnQjtBQUMxQjtBQUNBLFVBQVUsd0VBQXFCO0FBQy9COztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBOztBQUVBLHVDQUF1QywyRUFBaUI7QUFDeEQscUNBQXFDLHlFQUFlO0FBQ3BELG1DQUFtQyx5RUFBZTtBQUNsRCxzQ0FBc0MsNEVBQWtCOztBQUV4RDtBQUNBO0FBQ0EsaUNBQWlDLHlFQUFpQjtBQUNsRDs7QUFFQTtBQUNBO0FBQ0EsZUFBZSx3QkFBd0I7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDs7QUFFQTtBQUNBLG9FQUFvRSxzRUFBWTtBQUNoRixpRUFBaUUsaUVBQWU7O0FBRWhGO0FBQ0EsMkNBQTJDLGtFQUFTO0FBQ3BELDBDQUEwQyxrRUFBUztBQUNuRDs7Ozs7Ozs7Ozs7OztBQ3ZHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUTtBQUNTO0FBQ1U7O0FBRXJDO0FBQ1A7QUFDQTs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLDRCQUE0QixnREFBQztBQUM3QjtBQUNBO0FBQ0EsMkNBQTJDLHVEQUFRLGFBQWEseUJBQXlCLGlCQUFpQixFQUFFO0FBQzVHO0FBQ0E7QUFDQSxpQkFBaUIseUNBQXlDLHVEQUFRO0FBQ2xFLGFBQWE7QUFDYjtBQUNBO0FBQ0EsaUJBQWlCLHlDQUF5Qyx1REFBUTtBQUNsRSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsaUJBQWlCO0FBQ3ZEOztBQUVPO0FBQ1AsU0FBUyxZQUFZO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCwyQkFBMkIseUJBQXlCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLHdCQUF3QixnRUFBZTtBQUN2QztBQUNBO0FBQ0EscURBQXFELGlCQUFpQjtBQUN0RSw2QkFBNkI7QUFDN0IseUJBQXlCO0FBQ3pCO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsU0FBUztBQUNUO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUMvRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUMrQjs7QUFFaEQ7O0FBRU87QUFDUCxXQUFXLHFFQUFrQix5QkFBeUI7QUFDdEQ7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNkQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ1E7QUFDeUI7O0FBRWxEO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUCw0QkFBNEIsdUVBQWU7QUFDM0M7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLFdBQVcsZ0RBQUM7QUFDWjs7QUFFQTtBQUNPO0FBQ1A7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLG1CQUFtQixvQkFBb0I7QUFDdkM7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLG1CQUFtQixvQkFBb0I7QUFDdkM7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQSxLQUFLO0FBQ0w7O0FBRU87QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBLG1CQUFtQixpQkFBaUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSxRQUFRLGdEQUFDO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSxZQUFZLGdEQUFDO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnREFBQztBQUNMO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQLElBQUksZ0RBQUM7QUFDTCxJQUFJLGdEQUFDO0FBQ0w7Ozs7Ozs7Ozs7Ozs7QUN6TEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ1E7QUFDTztBQUNrQjtBQUNJO0FBQ1Y7QUFDa0g7QUFDL0I7O0FBRS9IO0FBQ087QUFDUCxJQUFJLGdEQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsb0JBQW9CO0FBQ3ZDO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsb0ZBQXVCOztBQUU5RDtBQUNBO0FBQ0EsMkNBQTJDLDZFQUFnQjs7QUFFM0Q7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0Esa0RBQWtELG1GQUFzQjtBQUN4RSxpREFBaUQsb0ZBQXVCO0FBQ3hFLDZDQUE2QywrRUFBa0I7QUFDL0Q7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSx1QkFBdUIsbUJBQW1CO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUMscURBQVE7QUFDakQscUJBQXFCO0FBQ3JCLHlDQUF5QyxxREFBUTtBQUNqRDtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7O0FBRUE7QUFDQTtBQUNBLG1EQUFtRCx1RUFBYTs7QUFFaEU7QUFDQTtBQUNBLGlEQUFpRCxxRUFBVzs7QUFFNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHFEQUFxRCx1RUFBZTtBQUNwRTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBLHVEQUF1RCwyRUFBaUI7QUFDeEUsd0RBQXdELDRFQUFrQjtBQUMxRSxtREFBbUQseUVBQWU7O0FBRWxFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksZ0RBQUM7QUFDTDtBQUNBLHVDQUF1QyxxQkFBcUI7QUFDNUQ7O0FBRUE7QUFDTztBQUNQLHdCQUF3QiwyREFBVTtBQUNsQyxVQUFVLCtEQUFjO0FBQ3hCO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0EsMkJBQTJCLGlFQUFlO0FBQzFDO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3BOQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjs7QUFFakI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLDBCQUEwQjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ087QUFDUDtBQUNBLHVCQUF1QixvQkFBb0I7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQLCtDQUErQyxFQUFFO0FBQ2pEO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wiLCJmaWxlIjoicG9wdXAvcG9wdXAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy9wb3B1cC9wb3B1cC5qc1wiKTtcbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCB7IFNXSVRDSF9PTiwgU1dJVENIX0xPQ0tFRF9PTiwgU1dJVENIX09GRiwgU1dJVENIX0xPQ0tFRF9PRkYgfSBmcm9tIFwiLi9vcHRpb25zL3N0YXRlc1wiXG5leHBvcnQgeyBTV0lUQ0hfT04sIFNXSVRDSF9MT0NLRURfT04sIFNXSVRDSF9PRkYsIFNXSVRDSF9MT0NLRURfT0ZGIH1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wdGlvbnMoKSB7XG4gICAgcmV0dXJuIGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoW1wib3B0aW9uc1wiXSkudGhlbihkYXRhID0+IGRhdGEub3B0aW9ucyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRPcHRpb25zKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IG9wdGlvbnM6IG9wdGlvbnMgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdGJvb2woc3dpdGNoX3N0YXRlKSB7XG4gICAgc3dpdGNoIChzd2l0Y2hfc3RhdGUpIHtcbiAgICAgICAgY2FzZSBTV0lUQ0hfT046XG4gICAgICAgIGNhc2UgU1dJVENIX0xPQ0tFRF9PTjpcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICBjYXNlIFNXSVRDSF9PRkY6XG4gICAgICAgIGNhc2UgU1dJVENIX0xPQ0tFRF9PRkY6XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgVGFyZ2V0QnJvd3NlciB9IGZyb20gXCJQb2x5ZmlsbFwiXG5cbmV4cG9ydCBjb25zdCBTV0lUQ0hfT04gPSAxO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9MT0NLRURfT04gPSAyO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9PRkYgPSAwO1xuZXhwb3J0IGNvbnN0IFNXSVRDSF9MT0NLRURfT0ZGID0gLTE7XG5cbmV4cG9ydCBjb25zdCBJTklUSUFMX09QVElPTlMgPSB7XG4gICAgcG9wdXA6IHtcbiAgICAgICAgc2l6ZToge1xuICAgICAgICAgICAgd2lkdGg6IDczMCxcbiAgICAgICAgICAgIGhlaWdodDogNDUwXG4gICAgICAgIH0sXG4gICAgICAgIHNjYWxlOiAxLjAsXG4gICAgICAgIHNob3dEZXRhaWxzOiBTV0lUQ0hfT04sXG4gICAgICAgIHNob3dQcmV2aWV3OiBTV0lUQ0hfT04sXG4gICAgICAgIGhpZGVBZnRlclRhYlNlbGVjdGlvbjogU1dJVENIX09OLFxuICAgICAgICBzZWFyY2hJblVSTHM6IFNXSVRDSF9PRkZcbiAgICB9XG59O1xuaWYgKFRhcmdldEJyb3dzZXIgPT09IFwiY2hyb21lXCIpIHtcbiAgICBJTklUSUFMX09QVElPTlMucG9wdXAuc2hvd1ByZXZpZXcgPSBTV0lUQ0hfTE9DS0VEX09GRjtcbiAgICBJTklUSUFMX09QVElPTlMucG9wdXAuaGlkZUFmdGVyVGFiU2VsZWN0aW9uID0gU1dJVENIX0xPQ0tFRF9PTjtcbn1cbiIsImV4cG9ydCBjb25zdCBUYXJnZXRCcm93c2VyID0gVEFSR0VUO1xuXG5pZiAoVEFSR0VUID09PSBcImNocm9tZVwiKSB7XG4gICAgd2luZG93W1wiYnJvd3NlclwiXSA9IHJlcXVpcmUoXCJ3ZWJleHRlbnNpb24tcG9seWZpbGxcIik7XG59XG5cbmlmICghQXJyYXkuZnJvbSkge1xuICAgIEFycmF5LmZyb20gPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICBsZXQgdG9TdHIgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nO1xuICAgICAgICBsZXQgaXNDYWxsYWJsZSA9IGZ1bmN0aW9uIChmbikge1xuICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiBmbiA9PT0gJ2Z1bmN0aW9uJyB8fCB0b1N0ci5jYWxsKGZuKSA9PT0gJ1tvYmplY3QgRnVuY3Rpb25dJztcbiAgICAgICAgfTtcbiAgICAgICAgbGV0IHRvSW50ZWdlciA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgbGV0IG51bWJlciA9IE51bWJlcih2YWx1ZSk7XG4gICAgICAgICAgICBpZiAoaXNOYU4obnVtYmVyKSkgeyByZXR1cm4gMDsgfVxuICAgICAgICAgICAgaWYgKG51bWJlciA9PT0gMCB8fCAhaXNGaW5pdGUobnVtYmVyKSkgeyByZXR1cm4gbnVtYmVyOyB9XG4gICAgICAgICAgICByZXR1cm4gKG51bWJlciA+IDAgPyAxIDogLTEpICogTWF0aC5mbG9vcihNYXRoLmFicyhudW1iZXIpKTtcbiAgICAgICAgfTtcbiAgICAgICAgbGV0IG1heFNhZmVJbnRlZ2VyID0gTWF0aC5wb3coMiwgNTMpIC0gMTtcbiAgICAgICAgbGV0IHRvTGVuZ3RoID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBsZXQgbGVuID0gdG9JbnRlZ2VyKHZhbHVlKTtcbiAgICAgICAgICAgIHJldHVybiBNYXRoLm1pbihNYXRoLm1heChsZW4sIDApLCBtYXhTYWZlSW50ZWdlcik7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gVGhlIGxlbmd0aCBwcm9wZXJ0eSBvZiB0aGUgZnJvbSBtZXRob2QgaXMgMS5cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGZyb20oYXJyYXlMaWtlLyosIG1hcEZuLCB0aGlzQXJnICovKSB7XG4gICAgICAgICAgICAvLyAxLiBMZXQgQyBiZSB0aGUgdGhpcyB2YWx1ZS5cbiAgICAgICAgICAgIGxldCBDID0gdGhpcztcblxuICAgICAgICAgICAgLy8gMi4gTGV0IGl0ZW1zIGJlIFRvT2JqZWN0KGFycmF5TGlrZSkuXG4gICAgICAgICAgICBsZXQgaXRlbXMgPSBPYmplY3QoYXJyYXlMaWtlKTtcblxuICAgICAgICAgICAgLy8gMy4gUmV0dXJuSWZBYnJ1cHQoaXRlbXMpLlxuICAgICAgICAgICAgaWYgKGFycmF5TGlrZSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQXJyYXkuZnJvbSByZXF1aXJlcyBhbiBhcnJheS1saWtlIG9iamVjdCAtIG5vdCBudWxsIG9yIHVuZGVmaW5lZCcpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyA0LiBJZiBtYXBmbiBpcyB1bmRlZmluZWQsIHRoZW4gbGV0IG1hcHBpbmcgYmUgZmFsc2UuXG4gICAgICAgICAgICBsZXQgbWFwRm4gPSBhcmd1bWVudHMubGVuZ3RoID4gMSA/IGFyZ3VtZW50c1sxXSA6IHZvaWQgdW5kZWZpbmVkO1xuICAgICAgICAgICAgbGV0IFQ7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1hcEZuICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIC8vIDUuIGVsc2VcbiAgICAgICAgICAgICAgICAvLyA1LiBhIElmIElzQ2FsbGFibGUobWFwZm4pIGlzIGZhbHNlLCB0aHJvdyBhIFR5cGVFcnJvciBleGNlcHRpb24uXG4gICAgICAgICAgICAgICAgaWYgKCFpc0NhbGxhYmxlKG1hcEZuKSkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcnJheS5mcm9tOiB3aGVuIHByb3ZpZGVkLCB0aGUgc2Vjb25kIGFyZ3VtZW50IG11c3QgYmUgYSBmdW5jdGlvbicpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIDUuIGIuIElmIHRoaXNBcmcgd2FzIHN1cHBsaWVkLCBsZXQgVCBiZSB0aGlzQXJnOyBlbHNlIGxldCBUIGJlIHVuZGVmaW5lZC5cbiAgICAgICAgICAgICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgVCA9IGFyZ3VtZW50c1syXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIDEwLiBMZXQgbGVuVmFsdWUgYmUgR2V0KGl0ZW1zLCBcImxlbmd0aFwiKS5cbiAgICAgICAgICAgIC8vIDExLiBMZXQgbGVuIGJlIFRvTGVuZ3RoKGxlblZhbHVlKS5cbiAgICAgICAgICAgIGxldCBsZW4gPSB0b0xlbmd0aChpdGVtcy5sZW5ndGgpO1xuXG4gICAgICAgICAgICAvLyAxMy4gSWYgSXNDb25zdHJ1Y3RvcihDKSBpcyB0cnVlLCB0aGVuXG4gICAgICAgICAgICAvLyAxMy4gYS4gTGV0IEEgYmUgdGhlIHJlc3VsdCBvZiBjYWxsaW5nIHRoZSBbW0NvbnN0cnVjdF1dIGludGVybmFsIG1ldGhvZCBcbiAgICAgICAgICAgIC8vIG9mIEMgd2l0aCBhbiBhcmd1bWVudCBsaXN0IGNvbnRhaW5pbmcgdGhlIHNpbmdsZSBpdGVtIGxlbi5cbiAgICAgICAgICAgIC8vIDE0LiBhLiBFbHNlLCBMZXQgQSBiZSBBcnJheUNyZWF0ZShsZW4pLlxuICAgICAgICAgICAgbGV0IEEgPSBpc0NhbGxhYmxlKEMpID8gT2JqZWN0KG5ldyBDKGxlbikpIDogbmV3IEFycmF5KGxlbik7XG5cbiAgICAgICAgICAgIC8vIDE2LiBMZXQgayBiZSAwLlxuICAgICAgICAgICAgbGV0IGsgPSAwO1xuICAgICAgICAgICAgLy8gMTcuIFJlcGVhdCwgd2hpbGUgayA8IGxlbuKApiAoYWxzbyBzdGVwcyBhIC0gaClcbiAgICAgICAgICAgIGxldCBrVmFsdWU7XG4gICAgICAgICAgICB3aGlsZSAoayA8IGxlbikge1xuICAgICAgICAgICAgICAgIGtWYWx1ZSA9IGl0ZW1zW2tdO1xuICAgICAgICAgICAgICAgIGlmIChtYXBGbikge1xuICAgICAgICAgICAgICAgICAgICBBW2tdID0gdHlwZW9mIFQgPT09ICd1bmRlZmluZWQnID8gbWFwRm4oa1ZhbHVlLCBrKSA6IG1hcEZuLmNhbGwoVCwga1ZhbHVlLCBrKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBBW2tdID0ga1ZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBrICs9IDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyAxOC4gTGV0IHB1dFN0YXR1cyBiZSBQdXQoQSwgXCJsZW5ndGhcIiwgbGVuLCB0cnVlKS5cbiAgICAgICAgICAgIEEubGVuZ3RoID0gbGVuO1xuICAgICAgICAgICAgLy8gMjAuIFJldHVybiBBLlxuICAgICAgICAgICAgcmV0dXJuIEE7XG4gICAgICAgIH07XG4gICAgfSgpKTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuZXhwb3J0IGxldCBhdmFpbGFibGUgPSBmYWxzZTtcblxuZXhwb3J0IGZ1bmN0aW9uIGluaXQoKSB7XG4gICAgaWYgKHdpbmRvd1tcImJyb3dzZXJcIl0gIT09IHVuZGVmaW5lZFxuICAgICAgICAmJiBicm93c2VyLnRhYnNbXCJjYXB0dXJlVGFiXCJdICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgYXZhaWxhYmxlID0gdHJ1ZTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNhcHR1cmVUYWIoaWQpIHtcbiAgICByZXR1cm4gYXZhaWxhYmxlID8gYnJvd3Nlci50YWJzLmNhcHR1cmVUYWIoaWQpIDogbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4gcmVzb2x2ZShudWxsKSk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbi8vIFRvZ2dsZSBhIGNsYXNzIG9mIGFuIGVsZW1lbnRcbmV4cG9ydCBmdW5jdGlvbiB0b2dnbGVDbGFzcyhlbGVtZW50LCBjKSB7XG4gICAgaWYgKGVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKGMpKSB7XG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShjKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoYyk7XG4gICAgfVxufVxuXG4vLyBHZXQgYWN0dWFsIGhlaWdodCBvZiBhbiBlbGVtZW50XG5leHBvcnQgZnVuY3Rpb24gZ2V0QWN0dWFsSGVpZ2h0KGVsZW1lbnQpIHtcbiAgICBsZXQgc3R5bGVzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gICAgbGV0IG1hcmdpbiA9IHBhcnNlRmxvYXQoc3R5bGVzWydtYXJnaW5Ub3AnXSkgK1xuICAgICAgICAgICAgICAgcGFyc2VGbG9hdChzdHlsZXNbJ21hcmdpbkJvdHRvbSddKTtcbiAgICByZXR1cm4gZWxlbWVudC5vZmZzZXRIZWlnaHQgKyBtYXJnaW47XG59XG5cbi8vIEdldCBhY3R1YWwgd2lkdGggb2YgYW4gZWxlbWVudFxuZXhwb3J0IGZ1bmN0aW9uIGdldEFjdHVhbFdpZHRoKGVsZW1lbnQpIHtcbiAgICBsZXQgc3R5bGVzID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gICAgbGV0IG1hcmdpbiA9IHBhcnNlRmxvYXQoc3R5bGVzWydtYXJnaW5MZWZ0J10pICtcbiAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoc3R5bGVzWydtYXJnaW5SaWdodCddKTtcbiAgICByZXR1cm4gZWxlbWVudC5vZmZzZXRXaWR0aCArIG1hcmdpbjtcbn1cblxuLy8gZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lXG5FbGVtZW50LnByb3RvdHlwZS5nZXRFbGVtZW50QnlDbGFzc05hbWUgPSBmdW5jdGlvbiAoY2xhc3NOYW1lcykge1xuICAgIHJldHVybiB0aGlzLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoY2xhc3NOYW1lcylbMF0gfHwgbnVsbDtcbn07XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBjdHJsT3JDbWQgfSBmcm9tIFwiLi4va2V5dXRpbHNcIlxuaW1wb3J0IHsgZ2V0TGFzdEZvY3VzZWRXaW5kb3cgfSBmcm9tIFwiLi4vd3R1dGlsc1wiXG5pbXBvcnQgKiBhcyBjYXB0dXJlVGFiIGZyb20gXCIuLi9jYXB0dXJlVGFiXCJcbmltcG9ydCB7IGdldFdpbmRvd0Zyb21UYWIsIG11bHRpU2VsZWN0LCBtdWx0aVNlbGVjdFRvZ2dsZSwgcmVzZXRTbGlkZVNlbGVjdGlvbiwgbXVsdGlTZWxlY3RSZXNldCwgZ2V0VGFiSWQsIGdldFdpbmRvd0lkIH0gZnJvbSBcIi4uL3d0ZG9tXCJcblxuZXhwb3J0IGZ1bmN0aW9uIGRvY3VtZW50TW91c2VPdmVyKGUpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkb2N1bWVudE1vdXNlVXAoZSkge1xuICAgIGlmIChHLnNsaWRlU2VsZWN0aW9uLnNsaWRpbmcpIHJlc2V0U2xpZGVTZWxlY3Rpb24oKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRvY3VtZW50Q2xpY2tlZChlKSB7XG4gICAgaWYgKGUuYnV0dG9uID09PSAwKSB7XG4gICAgICAgIGlmIChlLnRhcmdldC5pZCA9PT0gXCJkZXRhaWxzLWNsb3NlXCIpIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGV0YWlscy1wbGFjZWhvbGRlclwiKS5zdHlsZS5kaXNwbGF5ID0gXCJpbmxpbmUtYmxvY2tcIjtcbiAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFiLWRldGFpbHNcIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgICAgYnJvd3Nlci50YWJzLnJlbW92ZShnZXRUYWJJZChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYi1kZXRhaWxzXCIpKSk7XG4gICAgICAgIH0gZWxzZSB7Ly8gTm90ZTogTWF5IGNhdXNlIHNvbWUgcHJvYmxlbXNcbiAgICAgICAgICAgIGlmIChHLmlzU2VsZWN0aW5nKSBtdWx0aVNlbGVjdFJlc2V0KCk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmZ1bmN0aW9uIGlzSW5saW5lUHJpbnRhYmxlS2V5KGUpIHtcbiAgICBpZiAodHlwZW9mIGUud2hpY2ggPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZS53aGljaCA9PT0gXCJudW1iZXJcIiAmJiBlLndoaWNoID4gMCkge1xuICAgICAgICByZXR1cm4gIWUuY3RybEtleSAmJiAhZS5tZXRhS2V5ICYmICFlLmFsdEtleSAmJiBlLndoaWNoICE9PSA4ICYmIGUud2hpY2ggIT09IDEzO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRvY3VtZW50S2V5UHJlc3NlZChlKSB7XG4gICAgaWYgKGlzSW5saW5lUHJpbnRhYmxlS2V5KGUpKSB7XG4gICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2VhcmNoXCIpLmZvY3VzKCk7XG4gICAgfVxufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IFwiLi4vZG9tdXRpbHNcIlxuaW1wb3J0IHsgZ2V0SW1hZ2UgfSBmcm9tIFwiLi4vbmV0XCJcbmltcG9ydCB7IGZpbmRUYWJFbnRyeUJ5SWQsIGdldEZhdkljb25Gcm9tVGFiRW50cnksIHNldEFjdGl2ZVRhYiwgcmVtb3ZlVGFiLCByZW1vdmVXaW5kb3csIGdldFdpbmRvd0Zyb21UYWIgfSBmcm9tIFwiLi4vd3Rkb21cIlxuXG5leHBvcnQgZnVuY3Rpb24gb25NZXNzYWdlKHJlcXVlc3QsIHNlbmRlcikge1xuICAgIHN3aXRjaCAocmVxdWVzdC50eXBlKSB7XG4gICAgICAgIGNhc2UgXCJBQ1RJVkVfVEFCX0NIQU5HRURcIjpcbiAgICAgICAgICAgIHNldEFjdGl2ZVRhYihyZXF1ZXN0LmRldGFpbHMud2luZG93SWQsIHJlcXVlc3QuZGV0YWlscy50YWJJZCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcIlRBQl9GQVZfSUNPTl9DSEFOR0VEXCI6XG4gICAgICAgICAgICBicm93c2VyLnRhYnMuZ2V0KHJlcXVlc3QuZGV0YWlscy50YWJJZCkudGhlbih0YWIgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBmYXZJY29uUHJvbWlzZTtcbiAgICAgICAgICAgICAgICBpZiAodGFiLmluY29nbml0bykge1xuICAgICAgICAgICAgICAgICAgICBmYXZJY29uUHJvbWlzZSA9IGdldEltYWdlKHJlcXVlc3QuZGV0YWlscy5mYXZJY29uVXJsLCB0cnVlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmYXZJY29uUHJvbWlzZSA9IGdldEltYWdlKHJlcXVlc3QuZGV0YWlscy5mYXZJY29uVXJsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZmF2SWNvblByb21pc2UudGhlbihmdW5jdGlvbiAoYmFzZTY0SW1hZ2Upe1xuICAgICAgICAgICAgICAgICAgICBnZXRGYXZJY29uRnJvbVRhYkVudHJ5KGZpbmRUYWJFbnRyeUJ5SWQocmVxdWVzdC5kZXRhaWxzLnRhYklkKSkuc3JjID0gYmFzZTY0SW1hZ2U7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiVEFCX1BJTk5FRF9TVEFUVVNfQ0hBTkdFRFwiOlxuICAgICAgICAgICAgbGV0IHRhYkVudHJ5ID0gZmluZFRhYkVudHJ5QnlJZChyZXF1ZXN0LmRldGFpbHMudGFiSWQpO1xuICAgICAgICAgICAgbGV0IHBpbkJ0biA9IHRhYkVudHJ5LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi1lbnRyeS1waW4tYnRuXCIpO1xuICAgICAgICAgICAgbGV0IHdpbmRvd0VudHJ5TGlzdCA9IHRhYkVudHJ5LnBhcmVudEVsZW1lbnQ7XG4gICAgICAgICAgICBsZXQgcGlubmVkVGFicztcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0LmRldGFpbHMucGlubmVkKSB7XG4gICAgICAgICAgICAgICAgcGlubmVkVGFicyA9IEFycmF5LmZyb20od2luZG93RW50cnlMaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJwaW5uZWQtdGFiXCIpKTtcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5jbGFzc0xpc3QuYWRkKFwicGlubmVkLXRhYlwiKTtcbiAgICAgICAgICAgICAgICBwaW5CdG4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvcGlucmVtb3ZlLnN2ZylcIjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcGlubmVkVGFicyA9IEFycmF5LmZyb20od2luZG93RW50cnlMaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJwaW5uZWQtdGFiXCIpKTtcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5jbGFzc0xpc3QucmVtb3ZlKFwicGlubmVkLXRhYlwiKTtcbiAgICAgICAgICAgICAgICBwaW5CdG4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvcGluLnN2ZylcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBsYXN0UGlubmVkVGFiID0gcGlubmVkVGFic1twaW5uZWRUYWJzLmxlbmd0aC0xXTtcbiAgICAgICAgICAgIGlmIChsYXN0UGlubmVkVGFiICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3dFbnRyeUxpc3QuaW5zZXJ0QmVmb3JlKHRhYkVudHJ5LCBsYXN0UGlubmVkVGFiLm5leHRTaWJsaW5nKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgd2luZG93RW50cnlMaXN0Lmluc2VydEJlZm9yZSh0YWJFbnRyeSwgd2luZG93RW50cnlMaXN0LmNoaWxkTm9kZXNbMF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJUQUJfVElUTEVfQ0hBTkdFRFwiOlxuICAgICAgICAgICAgZmluZFRhYkVudHJ5QnlJZChyZXF1ZXN0LmRldGFpbHMudGFiSWQpLmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi10aXRsZVwiKS50ZXh0Q29udGVudCA9IHJlcXVlc3QuZGV0YWlscy50aXRsZTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiVEFCX1JFTU9WRURcIjpcbiAgICAgICAgICAgIGlmICghcmVxdWVzdC5kZXRhaWxzLndpbmRvd0Nsb3NpbmcpIHtcbiAgICAgICAgICAgICAgICByZW1vdmVUYWIocmVxdWVzdC5kZXRhaWxzLnRhYklkLCByZXF1ZXN0LmRldGFpbHMud2luZG93SWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJXSU5ET1dfUkVNT1ZFRFwiOlxuICAgICAgICAgICAgcmVtb3ZlV2luZG93KHJlcXVlc3QuZGV0YWlscy53aW5kb3dJZCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBsYXN0UmVjb3JkLCByZWNvcmQsIHJlc3RvcmUgfSBmcm9tIFwiLi4vcmVjb3JkZXJcIlxyXG5cclxubGV0IHNhdmVGb3JMYXRlckJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2F2ZS1mb3ItbGF0ZXJcIik7XHJcbmxldCBzZmxUaW1lb3V0ID0gKCkgPT4ge1xyXG4gICAgc2F2ZUZvckxhdGVyQnRuLnJlbW92ZUF0dHJpYnV0ZShcImRvbmVcIik7XHJcbn07XHJcbmV4cG9ydCBmdW5jdGlvbiBzYXZlRm9yTGF0ZXIoKSB7XHJcbiAgICBzYXZlRm9yTGF0ZXJCdG4uc2V0QXR0cmlidXRlKFwiZGlzYWJsZWRcIiwgXCJcIik7XHJcbiAgICByZWNvcmQoKS50aGVuKCgpID0+IHtcclxuICAgICAgICBzYXZlRm9yTGF0ZXJCdG4ucmVtb3ZlQXR0cmlidXRlKFwiZGlzYWJsZWRcIik7XHJcbiAgICAgICAgc2F2ZUZvckxhdGVyQnRuLnNldEF0dHJpYnV0ZShcImRvbmVcIiwgXCJcIik7XHJcbiAgICAgICAgY2xlYXJUaW1lb3V0KHNmbFRpbWVvdXQpOyBzZXRUaW1lb3V0KHNmbFRpbWVvdXQsIDIwMDApO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCB7IHJlc3RvcmUgfVxyXG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBnZXRUYWJJZCB9IGZyb20gXCIuLi93dGRvbVwiXG5cbmZ1bmN0aW9uIGtleXdvcmRTZWFyY2gocywga2V5KSB7XG4gICAgbGV0IGtleXdvcmRzID0ga2V5LnRyaW0oKS5zcGxpdChcIiBcIiksIGNvdW50ID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXdvcmRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGxldCB3b3JkID0ga2V5d29yZHNbaV07XG4gICAgICAgIGlmICh3b3JkLnRyaW0oKSAhPT0gXCJcIiAmJiB3b3JkLm1hdGNoKC9eW2EtekEtWjAtOV0rJC8pKSB7XG4gICAgICAgICAgICBpZiAocy50b1VwcGVyQ2FzZSgpLmluY2x1ZGVzKHdvcmQudG9VcHBlckNhc2UoKSkpIHtcbiAgICAgICAgICAgICAgICBjb3VudCsrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjb3VudCA+PSAyO1xufVxuXG5mdW5jdGlvbiBzZWFyY2gocywga2V5KSB7XG4gICAgcmV0dXJuIHMudG9VcHBlckNhc2UoKS5pbmNsdWRlcyhrZXkudG9VcHBlckNhc2UoKSkgfHwga2V5d29yZFNlYXJjaChzLCBrZXkpO1xufVxuXG4vLyBTZWFyY2hcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hUZXh0Q2hhbmdlZChlKSB7XG4gICAgbGV0IGlucHV0LCBmaWx0ZXIsIHRhYkVudHJpZXM7XG4gICAgaW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNlYXJjaFwiKTtcbiAgICBmaWx0ZXIgPSBpbnB1dC52YWx1ZTtcbiAgICB0YWJFbnRyaWVzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInRhYi1lbnRyeVwiKTtcbiAgICBpZiAoZmlsdGVyICE9PSBcIlwiKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFiRW50cmllcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbGV0IHRhYkVudHJ5ID0gdGFiRW50cmllc1tpXTtcbiAgICAgICAgICAgIGlmICghc2VhcmNoKHRhYkVudHJ5LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi10aXRsZVwiKS5pbm5lclRleHQsIGZpbHRlcikgJiZcbiAgICAgICAgICAgICAgICAhKEcuc2VhcmNoSW5VUkxzICYmIHNlYXJjaCgoYXdhaXQgYnJvd3Nlci50YWJzLmdldChnZXRUYWJJZCh0YWJFbnRyeSkpKS51cmwsIGZpbHRlcikpKSB7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhYkVudHJpZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxldCB0YWJFbnRyeSA9IHRhYkVudHJpZXNbaV07XG4gICAgICAgICAgICB0YWJFbnRyeS5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBjdHJsT3JDbWQgfSBmcm9tIFwiLi4va2V5dXRpbHNcIlxuaW1wb3J0IHsgZ2V0TGFzdEZvY3VzZWRXaW5kb3cgfSBmcm9tIFwiLi4vd3R1dGlsc1wiXG5pbXBvcnQgKiBhcyBjYXB0dXJlVGFiIGZyb20gXCIuLi9jYXB0dXJlVGFiXCJcbmltcG9ydCB7IGdldFdpbmRvd0Zyb21UYWIsIG11bHRpU2VsZWN0LCBtdWx0aVNlbGVjdFRvZ2dsZSwgcmVzZXRTbGlkZVNlbGVjdGlvbiwgbXVsdGlTZWxlY3RSZXNldCwgZ2V0VGFiSWQsIGdldFdpbmRvd0lkIH0gZnJvbSBcIi4uL3d0ZG9tXCJcblxuZXhwb3J0IGZ1bmN0aW9uIHRhYkVudHJ5TW91c2VPdmVyKGUpIHtcbiAgICBlLnRhcmdldC5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ0YWItZW50cnktcGluLWJ0blwiKS5zdHlsZS5kaXNwbGF5ID0gXCJpbmxpbmUtYmxvY2tcIjtcbiAgICBpZiAoY3RybE9yQ21kKCkgJiYgRy5zbGlkZVNlbGVjdGlvbi5zbGlkaW5nKSB7XG4gICAgICAgIG11bHRpU2VsZWN0KGUudGFyZ2V0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBsZXQgdGFiSWQgPSBnZXRUYWJJZChlLnRhcmdldCk7XG4gICAgICAgIGNhcHR1cmVUYWIuY2FwdHVyZVRhYih0YWJJZCkudGhlbihkYXRhVXJpID0+IHtcbiAgICAgICAgICAgIGlmIChkYXRhVXJpICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgbGV0IGRldGFpbHNJbWFnZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGV0YWlscy1pbWdcIik7XG4gICAgICAgICAgICAgICAgZGV0YWlsc0ltYWdlLnNyYyA9IGRhdGFVcmk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZGV0YWlsc1RpdGxlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXRpdGxlXCIpO1xuICAgICAgICAgICAgbGV0IGRldGFpbHNVUkwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtdXJsXCIpO1xuICAgICAgICAgICAgYnJvd3Nlci50YWJzLmdldCh0YWJJZCkudGhlbih0YWIgPT4ge1xuICAgICAgICAgICAgICAgIGRldGFpbHNUaXRsZS50ZXh0Q29udGVudCA9IHRhYi50aXRsZTtcbiAgICAgICAgICAgICAgICBkZXRhaWxzVVJMLnRleHRDb250ZW50ID0gdGFiLnVybDtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtcGxhY2Vob2xkZXJcIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFiLWRldGFpbHNcIikuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lLWJsb2NrXCI7XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0YWItZGV0YWlsc1wiKS5zZXRBdHRyaWJ1dGUoXCJkYXRhLXRhYl9pZFwiLCB0YWJJZCk7XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5waW5uZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXBpbm5lZFwiKS5zdHlsZS5kaXNwbGF5ID0gXCJpbmxpbmVcIjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtcGlubmVkXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5oaWRkZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLWhpZGRlblwiKS5zdHlsZS5kaXNwbGF5ID0gXCJpbmxpbmVcIjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtaGlkZGVuXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5waW5uZWQgJiYgdGFiLmhpZGRlbikge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtY29tbWFcIikuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lXCI7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLWNvbW1hXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGUucHJldmVudERlZmF1bHQoKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRhYkVudHJ5TW91c2VMZWF2ZShlKSB7XG4gICAgZS50YXJnZXQuZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lKFwidGFiLWVudHJ5LXBpbi1idG5cIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdGFiRW50cnlDbGlja2VkKGUpIHtcbiAgICBpZiAoZS5idXR0b24gPT09IDApIHtcbiAgICAgICAgaWYgKGN0cmxPckNtZCgpKSB7XG4gICAgICAgICAgICBtdWx0aVNlbGVjdFRvZ2dsZShlLnRhcmdldCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsZXQgdGFiSWQgPSBnZXRUYWJJZChlLnRhcmdldCk7XG4gICAgICAgICAgICBsZXQgcGFyZW50V2luZG93SWQgPSBnZXRXaW5kb3dJZChnZXRXaW5kb3dGcm9tVGFiKGUudGFyZ2V0KSk7XG4gICAgICAgICAgICBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7XG4gICAgICAgICAgICAgICAgYWN0aXZlOiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGJyb3dzZXIud2luZG93cy5nZXQocGFyZW50V2luZG93SWQpLnRoZW4odyA9PiB7XG4gICAgICAgICAgICAgICAgZ2V0TGFzdEZvY3VzZWRXaW5kb3coKS50aGVuKGN3ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHcuaWQgIT09IGN3LmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBicm93c2VyLndpbmRvd3MudXBkYXRlKHcuaWQsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1c2VkOiB0cnVlXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoRy5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb24pIHdpbmRvdy5jbG9zZSgpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0YWJDbG9zZUNsaWNrKGUpIHtcbiAgICBsZXQgdGFiSWQgPSBlLnRhcmdldC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQuZ2V0QXR0cmlidXRlKFwiZGF0YS10YWJfaWRcIik7XG4gICAgbGV0IHRhYkRldGFpbHMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYi1kZXRhaWxzXCIpO1xuICAgIGlmICh0YWJEZXRhaWxzLmdldEF0dHJpYnV0ZShcImRhdGEtdGFiX2lkXCIpID09PSB0YWJJZCkge1xuICAgICAgICB0YWJEZXRhaWxzLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXBsYWNlaG9sZGVyXCIpLnN0eWxlLmRpc3BsYXkgPSBcImlubGluZS1ibG9ja1wiO1xuICAgIH1cbiAgICBicm93c2VyLnRhYnMucmVtb3ZlKHBhcnNlSW50KHRhYklkKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0YWJQaW5DbGljayhlKSB7XG4gICAgbGV0IHRhYklkID0gZ2V0VGFiSWQoZS50YXJnZXQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50KTtcbiAgICBicm93c2VyLnRhYnMuZ2V0KHRhYklkKS50aGVuKHRhYiA9PiB7XG4gICAgICAgIGlmICh0YWIucGlubmVkKSB7XG4gICAgICAgICAgICBicm93c2VyLnRhYnMudXBkYXRlKHRhYi5pZCwge1xuICAgICAgICAgICAgICAgIHBpbm5lZDogZmFsc2VcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWIuaWQsIHtcbiAgICAgICAgICAgICAgICBwaW5uZWQ6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBjdHJsT3JDbWQgfSBmcm9tIFwiLi4va2V5dXRpbHNcIlxuaW1wb3J0IHsgbW92ZVRhYiwgYXR0YWNoVGFiLCBnZXRXaW5kb3dGcm9tVGFiLCB0YWJEcmFnZ2FibGUsIG11bHRpU2VsZWN0LCBnZXRTZWxlY3RlZEl0ZW1zLCBtdWx0aVNlbGVjdGVkLCB0YWJEcmFnZ2FibGVUb1dpbmRvdywgZ2V0VGFiSWQsIGdldFdpbmRvd0lkIH0gZnJvbSBcIi4uL3d0ZG9tXCJcblxubGV0IG11bHRpRHJhZ2dpbmcgPSBmYWxzZSwgc291cmNlVGFiLCB0YXJnZXRUYWIsIHVuZGVyLCBzb3VyY2VXaW5kb3csIHNvdXJjZVdpbmRvd0lkO1xuXG5mdW5jdGlvbiBnZXRNdWx0aURyYWdJbWFnZSh0YXJnZXQsIGNsaWVudFgsIGNsaWVudFkpIHtcbiAgICBsZXQgZHJhZ0ltYWdlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSwgeCwgeTtcbiAgICBsZXQgc2VsZWN0ZWRJdGVtcyA9IGdldFNlbGVjdGVkSXRlbXMoKTtcbiAgICBpZiAoc2VsZWN0ZWRJdGVtcy5sZW5ndGggPT09IDEpIHJldHVybiBzZWxlY3RlZEl0ZW1zW2ldO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VsZWN0ZWRJdGVtcy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICAgICAgbGV0IHJlZjEgPSBzZWxlY3RlZEl0ZW1zW2ldLCByZWYyID0gc2VsZWN0ZWRJdGVtc1tpKzFdO1xuICAgICAgICBsZXQgcmVmMWJyID0gcmVmMS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSwgcmVmMmJyID0gcmVmMi5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgbGV0IGRpc3RhbmNlID0gcmVmMmJyLnRvcCAtIChyZWYxYnIudG9wICsgcmVmMWJyLmhlaWdodCk7XG4gICAgICAgIGxldCByZWYxQ2xvbmUgPSByZWYxLmNsb25lTm9kZSh0cnVlKTtcbiAgICAgICAgcmVmMUNsb25lLnN0eWxlLm1hcmdpbkJvdHRvbSA9IGRpc3RhbmNlICsgXCJweFwiO1xuICAgICAgICBkcmFnSW1hZ2UuYXBwZW5kQ2hpbGQocmVmMUNsb25lKTtcbiAgICB9IGRyYWdJbWFnZS5hcHBlbmRDaGlsZChzZWxlY3RlZEl0ZW1zW3NlbGVjdGVkSXRlbXMubGVuZ3RoIC0gMV0uY2xvbmVOb2RlKHRydWUpKTtcbiAgICBkcmFnSW1hZ2Uuc3R5bGUud2lkdGggPSBzZWxlY3RlZEl0ZW1zWzBdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoICsgXCJweFwiO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZHJhZ0ltYWdlKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBpbWFnZTogZHJhZ0ltYWdlLFxuICAgICAgICB4OiAwLFxuICAgICAgICB5OiAwXG4gICAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdpbmRvd0VudHJ5RHJhZ1N0YXJ0ZWQoZSkge1xuICAgIGlmIChlLnRhcmdldC5jbGFzc0xpc3QuY29udGFpbnMoXCJ0YWItZW50cnlcIikpIHtcbiAgICAgICAgaWYgKGN0cmxPckNtZCgpKSB7XG4gICAgICAgICAgICBtdWx0aVNlbGVjdChlLnRhcmdldCk7XG4gICAgICAgICAgICBHLnNsaWRlU2VsZWN0aW9uLnNsaWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc291cmNlVGFiID0gZS50YXJnZXQ7XG4gICAgICAgICAgICBzb3VyY2VXaW5kb3cgPSBnZXRXaW5kb3dGcm9tVGFiKHNvdXJjZVRhYik7XG4gICAgICAgICAgICBzb3VyY2VXaW5kb3dJZCA9IGdldFdpbmRvd0lkKHNvdXJjZVdpbmRvdyk7XG4gICAgICAgICAgICBlLmRhdGFUcmFuc2Zlci5lZmZlY3RBbGxvd2VkID0gXCJtb3ZlXCI7XG4gICAgICAgICAgICBpZiAoRy5pc1NlbGVjdGluZyAmJiBtdWx0aVNlbGVjdGVkKGUudGFyZ2V0KSkge1xuICAgICAgICAgICAgICAgIG11bHRpRHJhZ2dpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGxldCBkcmFnSW1hZ2UgPSBnZXRNdWx0aURyYWdJbWFnZSgpO1xuICAgICAgICAgICAgICAgIGUuZGF0YVRyYW5zZmVyLnNldERyYWdJbWFnZShkcmFnSW1hZ2UuaW1hZ2UsIGRyYWdJbWFnZS54LCBkcmFnSW1hZ2UueSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZS5kYXRhVHJhbnNmZXIuc2V0RGF0YSgndGV4dC9wbGFpbicsIG51bGwpO1xuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdpbmRvd0VudHJ5RHJhZ2dpbmdPdmVyKGUpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgbGV0IGN1cnNvcnMgPSBBcnJheS5mcm9tKEcudGFic0xpc3QuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImluc2VydC1jdXJzb3JcIikpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3Vyc29ycy5sZW5ndGg7IGkrKykge1xuICAgICAgICBsZXQgYyA9IGN1cnNvcnNbaV07XG4gICAgICAgIGMucGFyZW50RWxlbWVudC5yZW1vdmVDaGlsZChjKTtcbiAgICB9XG4gICAgbGV0IGN1cnNvcldpbmRvdyA9IEcudGFic0xpc3QuZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lKFwiaW5zZXJ0LWN1cnNvci13aW5kb3dcIik7XG4gICAgaWYgKGN1cnNvcldpbmRvdyAhPT0gbnVsbCkge1xuICAgICAgICBjdXJzb3JXaW5kb3cuY2xhc3NMaXN0LnJlbW92ZShcImluc2VydC1jdXJzb3Itd2luZG93XCIpO1xuICAgIH1cblxuICAgIGxldCB3aW5kb3dFbnRyeTtcbiAgICBpZiAoZS50YXJnZXQuY2xhc3NMaXN0LmNvbnRhaW5zKFwidGFiLWVudHJ5XCIpKSB7XG4gICAgICAgIGxldCB0YWJFbnRyeUJvdW5kaW5nQ2xpZW50UmVjdCA9IGUudGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICB0YXJnZXRUYWIgPSBlLnRhcmdldDtcbiAgICAgICAgdW5kZXIgPSBmYWxzZTtcbiAgICAgICAgaWYgKChlLmNsaWVudFkgLSB0YWJFbnRyeUJvdW5kaW5nQ2xpZW50UmVjdC50b3ApID49IHRhYkVudHJ5Qm91bmRpbmdDbGllbnRSZWN0LmhlaWdodCAvIDIpIHtcbiAgICAgICAgICAgIHRhcmdldFRhYiA9IHRhcmdldFRhYi5uZXh0U2libGluZztcbiAgICAgICAgICAgIGlmICh0YXJnZXRUYWIgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICB1bmRlciA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGFyZ2V0VGFiID0gZS50YXJnZXQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRhYkRyYWdnYWJsZShzb3VyY2VUYWIsIHRhcmdldFRhYiwgdW5kZXIsIHNvdXJjZVdpbmRvdywgbXVsdGlEcmFnZ2luZykpIHtcbiAgICAgICAgICAgIGxldCBjdXJzb3IgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICAgICAgY3Vyc29yLmNsYXNzTGlzdC5hZGQoXCJpbnNlcnQtY3Vyc29yXCIpO1xuICAgICAgICAgICAgaWYgKHVuZGVyKSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0VGFiLnBhcmVudEVsZW1lbnQuYXBwZW5kQ2hpbGQoY3Vyc29yKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0VGFiLnBhcmVudEVsZW1lbnQuaW5zZXJ0QmVmb3JlKGN1cnNvciwgdGFyZ2V0VGFiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAoKHdpbmRvd0VudHJ5ID0gZS50YXJnZXQucGFyZW50RWxlbWVudCkgIT09IG51bGwgJiYgd2luZG93RW50cnkuY2xhc3NMaXN0LmNvbnRhaW5zKFwid2luZG93LWVudHJ5XCIpKSB7XG4gICAgICAgIGlmICh0YWJEcmFnZ2FibGVUb1dpbmRvdyhzb3VyY2VUYWIsIHdpbmRvd0VudHJ5LCBzb3VyY2VXaW5kb3cpKSB7XG4gICAgICAgICAgICBlLnRhcmdldC5jbGFzc0xpc3QuYWRkKFwiaW5zZXJ0LWN1cnNvci13aW5kb3dcIik7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dFbnRyeURyb3BwZWQoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGxldCBjdXJzb3JzID0gQXJyYXkuZnJvbShHLnRhYnNMaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJpbnNlcnQtY3Vyc29yXCIpKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGN1cnNvcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbGV0IGN1cnNvciA9IGN1cnNvcnNbaV07XG4gICAgICAgIGN1cnNvci5wYXJlbnRFbGVtZW50LnJlbW92ZUNoaWxkKGN1cnNvcik7XG4gICAgfVxuICAgIGxldCBjdXJzb3JXaW5kb3cgPSBHLnRhYnNMaXN0LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcImluc2VydC1jdXJzb3Itd2luZG93XCIpO1xuICAgIGlmIChjdXJzb3JXaW5kb3cgIT09IG51bGwpIHtcbiAgICAgICAgY3Vyc29yV2luZG93LmNsYXNzTGlzdC5yZW1vdmUoXCJpbnNlcnQtY3Vyc29yLXdpbmRvd1wiKTtcbiAgICB9XG4gICAgXG4gICAgbGV0IHdpbmRvd0VudHJ5O1xuICAgIGlmIChlLnRhcmdldC5jbGFzc0xpc3QuY29udGFpbnMoXCJ0YWItZW50cnlcIikpIHtcbiAgICAgICAgaWYgKCFlLnRhcmdldC5pc1NhbWVOb2RlKHRhcmdldFRhYikpIHtcbiAgICAgICAgICAgIGxldCB0YWJFbnRyeUJvdW5kaW5nQ2xpZW50UmVjdCA9IGUudGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICAgICAgdGFyZ2V0VGFiID0gZS50YXJnZXQ7XG4gICAgICAgICAgICB1bmRlciA9IGZhbHNlO1xuICAgICAgICAgICAgaWYgKChlLmNsaWVudFkgLSB0YWJFbnRyeUJvdW5kaW5nQ2xpZW50UmVjdC50b3ApID49IHRhYkVudHJ5Qm91bmRpbmdDbGllbnRSZWN0LmhlaWdodCAvIDIpIHtcbiAgICAgICAgICAgICAgICB0YXJnZXRUYWIgPSB0YXJnZXRUYWIubmV4dFNpYmxpbmc7XG4gICAgICAgICAgICAgICAgaWYgKHRhcmdldFRhYiA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICB1bmRlciA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIHRhcmdldFRhYiA9IGUudGFyZ2V0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAodGFiRHJhZ2dhYmxlKHNvdXJjZVRhYiwgdGFyZ2V0VGFiLCB1bmRlciwgc291cmNlV2luZG93LCBtdWx0aURyYWdnaW5nKSkge1xuICAgICAgICAgICAgbGV0IGRlc3RpbmF0aW9uV2luZG93SWQgPSBnZXRXaW5kb3dJZChnZXRXaW5kb3dGcm9tVGFiKHRhcmdldFRhYikpO1xuICAgICAgICAgICAgbGV0IHNvdXJjZVRhYkluZGV4ID0gQXJyYXkucHJvdG90eXBlLmluZGV4T2YuY2FsbCh0YXJnZXRUYWIucGFyZW50RWxlbWVudC5jaGlsZE5vZGVzLCBzb3VyY2VUYWIpO1xuICAgICAgICAgICAgbGV0IGRlc3RpbmF0aW9uSW5kZXggPSBBcnJheS5wcm90b3R5cGUuaW5kZXhPZi5jYWxsKHRhcmdldFRhYi5wYXJlbnRFbGVtZW50LmNoaWxkTm9kZXMsIHRhcmdldFRhYik7XG4gICAgICAgICAgICBsZXQgbW92ZUluZGV4ID0gdW5kZXIgPyAtMSA6ICgoc291cmNlVGFiSW5kZXggIT09IC0xICYmIGRlc3RpbmF0aW9uSW5kZXggPiBzb3VyY2VUYWJJbmRleCAmJiBkZXN0aW5hdGlvbldpbmRvd0lkID09PSBzb3VyY2VXaW5kb3dJZCkgPyBkZXN0aW5hdGlvbkluZGV4LTEgOiBkZXN0aW5hdGlvbkluZGV4KTtcbiAgICAgICAgICAgIGxldCBzb3VyY2VUYWJJZCA9IGdldFRhYklkKHNvdXJjZVRhYik7XG4gICAgICAgICAgICBicm93c2VyLnRhYnMubW92ZShzb3VyY2VUYWJJZCwge1xuICAgICAgICAgICAgICAgIHdpbmRvd0lkOiBkZXN0aW5hdGlvbldpbmRvd0lkLFxuICAgICAgICAgICAgICAgIGluZGV4OiBtb3ZlSW5kZXhcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKHVuZGVyKSB7XG4gICAgICAgICAgICAgICAgYXR0YWNoVGFiKHNvdXJjZVRhYiwgZ2V0V2luZG93RnJvbVRhYih0YXJnZXRUYWIpKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbW92ZVRhYihzb3VyY2VUYWIsIHRhcmdldFRhYik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCh3aW5kb3dFbnRyeSA9IGUudGFyZ2V0LnBhcmVudEVsZW1lbnQpICE9PSBudWxsICYmIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5jb250YWlucyhcIndpbmRvdy1lbnRyeVwiKSkge1xuICAgICAgICBpZiAodGFiRHJhZ2dhYmxlVG9XaW5kb3coc291cmNlVGFiLCB3aW5kb3dFbnRyeSwgc291cmNlV2luZG93KSkge1xuICAgICAgICAgICAgbGV0IHNvdXJjZVRhYklkID0gZ2V0VGFiSWQoc291cmNlVGFiKTtcbiAgICAgICAgICAgIGxldCBkZXN0aW5hdGlvbldpbmRvd0lkID0gZ2V0V2luZG93SWQod2luZG93RW50cnkpO1xuICAgICAgICAgICAgYnJvd3Nlci50YWJzLm1vdmUoc291cmNlVGFiSWQsIHtcbiAgICAgICAgICAgICAgICB3aW5kb3dJZDogZGVzdGluYXRpb25XaW5kb3dJZCxcbiAgICAgICAgICAgICAgICBpbmRleDogLTFcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgYXR0YWNoVGFiKHNvdXJjZVRhYiwgd2luZG93RW50cnkpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gd2luZG93RW50cnlUaXRsZUNsaWNrZWQoZSkge1xuICAgIGxldCB3aW5kb3dJZCA9IGdldFdpbmRvd0lkKGUudGFyZ2V0LnBhcmVudEVsZW1lbnQpO1xuICAgIGJyb3dzZXIud2luZG93cy51cGRhdGUod2luZG93SWQsIHtcbiAgICAgICAgZm9jdXNlZDogdHJ1ZVxuICAgIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gd2luZG93Q2xvc2VDbGljayhlKSB7XG4gICAgbGV0IHdpbmRvd0lkID0gZ2V0V2luZG93SWQoZS50YXJnZXQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQpO1xuICAgIGJyb3dzZXIud2luZG93cy5yZW1vdmUod2luZG93SWQpO1xufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuXG5jb25zdCBnbG9iYWxzID0ge1xuICAgIHRhYnNMaXN0OiB1bmRlZmluZWQsXG4gICAgaXNTZWxlY3Rpbmc6IGZhbHNlLFxuICAgIHNsaWRlU2VsZWN0aW9uOiB7XG4gICAgICAgIHNsaWRpbmc6IGZhbHNlLFxuICAgICAgICBpbml0aWF0b3I6IHVuZGVmaW5lZCxcbiAgICAgICAgdmVjdG9yOiAwXG4gICAgfSxcbiAgICBoaWRlQWZ0ZXJUYWJTZWxlY3Rpb246IHVuZGVmaW5lZCxcbiAgICBzZWFyY2hJblVSTHM6IHVuZGVmaW5lZFxufTtcbmV4cG9ydCBkZWZhdWx0IGdsb2JhbHM7XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbmxldCBrZXlQcmVzc2VkID0ge307XG5vbmtleWRvd24gPSBvbmtleXVwID0gZSA9PiB7XG4gICAgZSA9IGUgfHwgZXZlbnQ7XG4gICAga2V5UHJlc3NlZFtlLmNvZGVdID0gZS50eXBlID09IFwia2V5ZG93blwiO1xufTtcblxuLy8gQ2hlY2tzIGlmIGVpdGhlciBDdHJsKFdpbmRvd3MgJiBMaW51eCkgb3IgQ29tbWFuZChNYWMpIGlzIHByZXNzZWRcbmV4cG9ydCBmdW5jdGlvbiBjdHJsT3JDbWQoKSB7XG4gICAgaWYgKHdpbmRvdy5uYXZpZ2F0b3IucGxhdGZvcm0udG9VcHBlckNhc2UoKS5pbmRleE9mKFwiTUFDXCIpID49IDApIHtcbiAgICAgICAgcmV0dXJuIGtleVByZXNzZWRbXCJPU1JpZ2h0XCJdIHx8IGtleVByZXNzZWRbXCJPU0xlZnRcIl07XG4gICAgfVxuICAgIHJldHVybiBrZXlQcmVzc2VkW1wiQ29udHJvbExlZnRcIl0gfHwga2V5UHJlc3NlZFtcIkNvbnRyb2xSaWdodFwiXTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuLy8gRnVuY3Rpb24gdG8gc2VuZCBhIG1lc3NhZ2UgdG8gdGhlIHJ1bnRpbWVcbmV4cG9ydCBmdW5jdGlvbiBzZW5kUnVudGltZU1lc3NhZ2UodHlwZSwgZGF0YSkge1xuICAgIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICBkYXRhOiBkYXRhXG4gICAgfSk7XG59XG5cbi8vIEZ1bmN0aW9uIHRvIHNlbmQgYSBtZXNzYWdlIHRvIGEgdGFiXG5leHBvcnQgZnVuY3Rpb24gc2VuZFRhYk1lc3NhZ2UodGFiSWQsIHRhcmdldCwgZGF0YSkge1xuICAgIHJldHVybiBicm93c2VyLnRhYnMuc2VuZE1lc3NhZ2UodGFiSWQsIHtcbiAgICAgICAgdGFyZ2V0OiB0YXJnZXQsXG4gICAgICAgIGRhdGE6IGRhdGFcbiAgICB9KTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuLy8gRnVuY3Rpb24gdG8gZ2V0IGltYWdlIGZyb20gVVJMXG5leHBvcnQgZnVuY3Rpb24gZ2V0SW1hZ2UodXJsLCBub0NhY2hlPWZhbHNlKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmICghdXJsLnN0YXJ0c1dpdGgoXCJjaHJvbWU6Ly9cIikpIHtcbiAgICAgICAgICAgICAgICBsZXQgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgICAgICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnJlYWR5U3RhdGUgPT0gNCAmJiB0aGlzLnN0YXR1cyA9PSAyMDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb250ZW50VHlwZSA9IHhoci5nZXRSZXNwb25zZUhlYWRlcihcIkNvbnRlbnQtVHlwZVwiKS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29udGVudFR5cGUuc3RhcnRzV2l0aChcImltYWdlL1wiKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBmbGFnID0gXCJkYXRhOlwiICsgY29udGVudFR5cGUgKyBcIjtjaGFyc2V0PXV0Zi04O2Jhc2U2NCxcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaW1hZ2VTdHIgPSBhcnJheUJ1ZmZlclRvQmFzZTY0KHhoci5yZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShmbGFnICsgaW1hZ2VTdHIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoXCJJbWFnZSBSZXF1ZXN0IEZhaWxlZDogQ29udGVudC1UeXBlIGlzIG5vdCBhbiBpbWFnZSEgKENvbnRlbnQtVHlwZTogXFxcIlwiICsgY29udGVudFR5cGUgKyBcIlxcXCIpXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB4aHIucmVzcG9uc2VUeXBlID0gXCJhcnJheWJ1ZmZlclwiO1xuICAgICAgICAgICAgICAgIHhoci5vcGVuKFwiR0VUXCIsIHVybCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKG5vQ2FjaGUpIHsgeGhyLnNldFJlcXVlc3RIZWFkZXIoXCJDYWNoZS1Db250cm9sXCIsIFwibm8tc3RvcmVcIik7IH1cbiAgICAgICAgICAgICAgICB4aHIuc2VuZCgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgcmVqZWN0KGVyci5tZXNzYWdlKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG4vLyBGdW5jdGlvbiB0byB0cmFuc2Zvcm0gQXJyYXlCdWZmZXIgaW50byBhIEJhc2U2NCBTdHJpbmdcbmV4cG9ydCBmdW5jdGlvbiBhcnJheUJ1ZmZlclRvQmFzZTY0KGJ1ZmZlcikge1xuICAgIGxldCBiaW5hcnkgPSBcIlwiO1xuICAgIGxldCBieXRlcyA9IFtdLnNsaWNlLmNhbGwobmV3IFVpbnQ4QXJyYXkoYnVmZmVyKSk7XG4gICAgYnl0ZXMuZm9yRWFjaCgoYikgPT4gYmluYXJ5ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYikpO1xuICAgIHJldHVybiB3aW5kb3cuYnRvYShiaW5hcnkpO1xufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IEcgZnJvbSBcIi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBnZXRXcm9uZ1RvUmlnaHQgfSBmcm9tIFwiLi93cm9uZy10by1yaWdodFwiXG5pbXBvcnQgeyBwb3B1bGF0ZVRhYnNMaXN0LCBleHRlbmRUYWJzTGlzdCB9IGZyb20gXCIuL3d0aW5pdFwiXG5pbXBvcnQgeyBnZXRBY3R1YWxXaWR0aCB9IGZyb20gXCIuL2RvbXV0aWxzXCJcbmltcG9ydCB7IGRvY3VtZW50TW91c2VPdmVyLCBkb2N1bWVudE1vdXNlVXAsIGRvY3VtZW50Q2xpY2tlZCwgZG9jdW1lbnRLZXlQcmVzc2VkIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL2RvY3VtZW50XCJcbmltcG9ydCB7IHNlYXJjaFRleHRDaGFuZ2VkIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL3NlYXJjaFwiXG5pbXBvcnQgeyBvbk1lc3NhZ2UgfSBmcm9tIFwiLi9ldmVudC1saXN0ZW5lcnMvbWVzc2FnZVwiXG5pbXBvcnQgeyBzYXZlRm9yTGF0ZXIsIHJlc3RvcmUgYXMgcmVjb3JkZXJSZXN0b3JlIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL3JlY29yZGVyXCJcbmltcG9ydCAqIGFzIGNhcHR1cmVUYWIgZnJvbSBcIi4vY2FwdHVyZVRhYlwiXG5pbXBvcnQgKiBhcyBPcHRpb25zIGZyb20gXCIuLi9vcHRpb25zXCJcbmltcG9ydCB7IGhpZGVUYWJQcmV2aWV3IH0gZnJvbSBcIi4vd3Rkb21cIlxuaW1wb3J0IHsgdXBkYXRlUmVjb3JkZXJUb29sVGlwIH0gZnJvbSBcIi4vcmVjb3JkZXJcIjtcblxuRy50YWJzTGlzdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFicy1saXN0XCIpO1xuXG5mdW5jdGlvbiBzZXRQb3B1cFNpemUod2lkdGgsIGhlaWdodCkge1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS53aWR0aCA9IHdpZHRoICsgXCJweFwiO1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS5oZWlnaHQgPSBoZWlnaHQgKyBcInB4XCI7XG4gICAgZG9jdW1lbnQuYm9keS5zdHlsZS53aWR0aCA9IHdpZHRoICsgXCJweFwiO1xuICAgIGRvY3VtZW50LmJvZHkuc3R5bGUuaGVpZ2h0ID0gaGVpZ2h0ICsgXCJweFwiO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmdWxmaWxsT3B0aW9ucygpIHtcbiAgICBsZXQgcG9wdXBPcHRpb25zID0gKGF3YWl0IE9wdGlvbnMub3B0aW9ucygpKS5wb3B1cDtcbiAgICAvLyBwb3B1cC5zaXplXG4gICAgc2V0UG9wdXBTaXplKHBvcHVwT3B0aW9ucy5zaXplLndpZHRoLCBwb3B1cE9wdGlvbnMuc2l6ZS5oZWlnaHQpO1xuICAgIC8vIHBvcHVwLnNjYWxlXG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlLnNldFByb3BlcnR5KCctLXNjYWxlJywgcG9wdXBPcHRpb25zLnNjYWxlLnRvU3RyaW5nKCkpO1xuICAgIC8vIHBvcHVwLnNob3dEZXRhaWxzXG4gICAgaWYgKCFPcHRpb25zLnN0Ym9vbChwb3B1cE9wdGlvbnMuc2hvd0RldGFpbHMpKSB7XG4gICAgICAgIGxldCBsZWZ0Q29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJsZWZ0LWNvbnRhaW5lclwiKTtcbiAgICAgICAgcG9wdXBPcHRpb25zLnNpemUud2lkdGggPSBwb3B1cE9wdGlvbnMuc2l6ZS53aWR0aCAtIGdldEFjdHVhbFdpZHRoKGxlZnRDb250YWluZXIpO1xuICAgICAgICBzZXRQb3B1cFNpemUocG9wdXBPcHRpb25zLnNpemUud2lkdGgsIHBvcHVwT3B0aW9ucy5zaXplLmhlaWdodCk7XG4gICAgICAgIGxlZnRDb250YWluZXIuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYnMtY29udGFpbmVyXCIpLnN0eWxlLndpZHRoID0gXCIxMDAlXCI7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgLy8gcG9wdXAuc2hvd1ByZXZpZXdcbiAgICAgICAgaWYgKCFPcHRpb25zLnN0Ym9vbChwb3B1cE9wdGlvbnMuc2hvd1ByZXZpZXcpKSBoaWRlVGFiUHJldmlldygpO1xuICAgIH1cbiAgICAvLyBwb3B1cC5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb25cbiAgICBHLmhpZGVBZnRlclRhYlNlbGVjdGlvbiA9IE9wdGlvbnMuc3Rib29sKHBvcHVwT3B0aW9ucy5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb24pO1xuICAgIC8vIHBvcHVwLnNlYXJjaEluVVJMc1xuICAgIEcuc2VhcmNoSW5VUkxzID0gT3B0aW9ucy5zdGJvb2wocG9wdXBPcHRpb25zLnNlYXJjaEluVVJMcyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG4gICAgLy8gSW5pdGlhbGl6ZSBjYXB0dXJlVGFiIGJhc2VkIG9uIGVudmlyb25tZW50XG4gICAgY2FwdHVyZVRhYi5pbml0KCk7XG4gICAgLy8gRnVsZmlsbCB1c2VyIG9wdGlvbnNcbiAgICBhd2FpdCBmdWxmaWxsT3B0aW9ucygpO1xuICAgIC8vIE1ha2UgdGFicyBsaXN0IGZpdCB0aGUgcGFuZWxcbiAgICBleHRlbmRUYWJzTGlzdCgpO1xuICAgIC8vIEZpeCBmb3IgY3Jvc3Mtd2luZG93IGRyYWdnaW5nIGlzc3VlXG4gICAgYXdhaXQgZ2V0V3JvbmdUb1JpZ2h0KCk7XG4gICAgLy8gUG9wdWxhdGUgdGFicyBsaXN0IHdpdGggdGFic1xuICAgIGF3YWl0IHBvcHVsYXRlVGFic0xpc3QoKTtcbiAgICAvLyBVcGRhdGUgcmVjb3JkZXIgdG9vbHRpcFxuICAgIGF3YWl0IHVwZGF0ZVJlY29yZGVyVG9vbFRpcCgpO1xufVxuXG4vKiBBZGQgZXZlbnQgbGlzdGVuZXJzICovXG5cbi8vIFN0YXJ0aW5nIHBvaW50XG5pZiAoZG9jdW1lbnQucmVhZHlTdGF0ZSA9PT0gXCJsb2FkaW5nXCIpIHtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCBtYWluKTtcbn0gZWxzZSB7XG4gICAgbWFpbigpO1xufVxuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwibW91c2VvdmVyXCIsIGRvY3VtZW50TW91c2VPdmVyKTtcbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZXVwXCIsIGRvY3VtZW50TW91c2VVcCk7XG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZG9jdW1lbnRDbGlja2VkKTtcbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlwcmVzc1wiLCBkb2N1bWVudEtleVByZXNzZWQpO1xuXG4vLyBBZGQga2V5dXAgZXZlbnQgbGlzdGVuZXIgYW5kIHB1dCBmb2N1cyBvbiBzZWFyY2hcbmxldCBzZWFyY2ggPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNlYXJjaFwiKTtcbnNlYXJjaC5hZGRFdmVudExpc3RlbmVyKFwia2V5dXBcIiwgc2VhcmNoVGV4dENoYW5nZWQpO1xuc2VhcmNoLmZvY3VzKCk7XG5cbi8vIEFkZCBldmVudCBsaXN0ZW5lcnMgdG8gYWxsIGNvcHkgYnV0dG9uc1xubGV0IGNvcHlCdXR0b25zID0gQXJyYXkuZnJvbShkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiY29weS1idXR0b25cIikpO1xuZm9yIChsZXQgaSA9IDA7IGkgPCBjb3B5QnV0dG9ucy5sZW5ndGg7IGkrKykge1xuICAgIGNvcHlCdXR0b25zW2ldLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBlID0+IHtcbiAgICAgICAgZG9jdW1lbnQub25jb3B5ID0gY2UgPT4ge1xuICAgICAgICAgICAgY2UuY2xpcGJvYXJkRGF0YS5zZXREYXRhKFwidGV4dFwiLCBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChlLnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJmb3JcIikpLmlubmVyVGV4dCk7XG4gICAgICAgICAgICBjZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB9O1xuICAgICAgICBkb2N1bWVudC5leGVjQ29tbWFuZChcImNvcHlcIiwgZmFsc2UsIG51bGwpO1xuICAgICAgICBlLnRhcmdldC5pbm5lclRleHQgPSBcIkNvcGllZCFcIjtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBlLnRhcmdldC5pbm5lclRleHQgPSBcIkNvcHlcIjtcbiAgICAgICAgfSwgMjAwMCk7XG4gICAgfSk7XG59XG5cbi8vIEFkZCBldmVudCBsaXN0ZW5lciBmb3IgcmVjb3JkZXIuanNcbmRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2F2ZS1mb3ItbGF0ZXJcIikuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHNhdmVGb3JMYXRlcik7XG5kb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJlc3RvcmUtbm93XCIpLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCByZWNvcmRlclJlc3RvcmUpO1xuXG4vLyBBZGQgZXZlbnQgbGlzdGVuZXIgdG8gbGlzdGVuIGZvciBhbnkgbWVzc2FnZXMgZnJvbSBiYWNrZ3JvdW5kLmpzXG5pZiAoIWJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuaGFzTGlzdGVuZXIob25NZXNzYWdlKSkge1xuICAgIGJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlKTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcclxuaW1wb3J0IEcgZnJvbSBcIi4vZ2xvYmFsc1wiXHJcbmltcG9ydCB7IGdldFRhYklkIH0gZnJvbSBcIi4vd3Rkb21cIlxyXG5pbXBvcnQgeyBydW5BZnRlclRhYkxvYWQgfSBmcm9tIFwiLi93dHV0aWxzXCI7XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbGFzdFJlY29yZCgpIHtcclxuICAgIHJldHVybiBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFtcInJlY29yZFwiXSkudGhlbihkYXRhID0+IGRhdGEucmVjb3JkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVJlY29yZGVyVG9vbFRpcCgpIHtcclxuICAgIGxldCByID0gYXdhaXQgbGFzdFJlY29yZCgpO1xyXG4gICAgbGV0IHJlc3RvcmVCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJlc3RvcmUtbm93XCIpO1xyXG4gICAgaWYgKHIpIHtcclxuICAgICAgICByZXN0b3JlQnRuLnNldEF0dHJpYnV0ZShcInRpdGxlXCIsIFwiUmVzdG9yZSB3ZWJzaXRlcyB0aGF0IGhhdmUgYmVlbiBzYXZlZCBvbiBcIiArIChuZXcgRGF0ZShyLnRpbWVzdGFtcCkpLnRvTG9jYWxlU3RyaW5nKCkpO1xyXG4gICAgICAgIHJlc3RvcmVCdG4ucmVtb3ZlQXR0cmlidXRlKFwiZGlzYWJsZWRcIik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlc3RvcmVCdG4uc2V0QXR0cmlidXRlKFwidGl0bGVcIiwgXCJSZXN0b3JlIHdlYnNpdGVzIHRoYXQgaGF2ZSBiZWVuIHNhdmVkXCIpO1xyXG4gICAgICAgIHJlc3RvcmVCdG4uc2V0QXR0cmlidXRlKFwiZGlzYWJsZWRcIiwgXCJcIik7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRhYkluZm9Ub1JlY29yZChpbmZvKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIHVybDogaW5mby51cmwsXHJcbiAgICAgICAgcGlubmVkOiBpbmZvLnBpbm5lZFxyXG4gICAgfTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVjb3JkKCkge1xyXG4gICAgbGV0IHJlY29yZEFycmF5ID0gW107XHJcbiAgICBmb3IgKGxldCB3aW5kb3dFbnRyeSBvZiBHLnRhYnNMaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ3aW5kb3ctZW50cnlcIikpIHtcclxuICAgICAgICBsZXQgd2luZG93UmVjb3JkID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgdGFiRW50cnkgb2Ygd2luZG93RW50cnkuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInRhYi1lbnRyeVwiKSkge1xyXG4gICAgICAgICAgICBhd2FpdCBicm93c2VyLnRhYnMuc2VuZE1lc3NhZ2UoZ2V0VGFiSWQodGFiRW50cnkpLCB7IHRhcmdldDogXCJwYWNrZFwiLCBkYXRhOiB7IGFjdGlvbjogXCJwYWNrXCIgfSB9KS50aGVuKGFzeW5jIHBhY2sgPT4ge1xyXG4gICAgICAgICAgICAgICAgd2luZG93UmVjb3JkLnB1c2goT2JqZWN0LmFzc2lnbih7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFjazogcGFja1xyXG4gICAgICAgICAgICAgICAgfSwgdGFiSW5mb1RvUmVjb3JkKGF3YWl0IGJyb3dzZXIudGFicy5nZXQoZ2V0VGFiSWQodGFiRW50cnkpKSkpKTtcclxuICAgICAgICAgICAgfSkuY2F0Y2goYXN5bmMgcmVhc29uID0+IHtcclxuICAgICAgICAgICAgICAgIHdpbmRvd1JlY29yZC5wdXNoKE9iamVjdC5hc3NpZ24oe1xyXG4gICAgICAgICAgICAgICAgICAgIHBhY2s6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgfSwgdGFiSW5mb1RvUmVjb3JkKGF3YWl0IGJyb3dzZXIudGFicy5nZXQoZ2V0VGFiSWQodGFiRW50cnkpKSkpKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJlY29yZEFycmF5LnB1c2god2luZG93UmVjb3JkKTtcclxuICAgIH1cclxuICAgIGxldCByZWNvcmQgPSB7XHJcbiAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxyXG4gICAgICAgIHJlY29yZDogcmVjb3JkQXJyYXlcclxuICAgIH07XHJcbiAgICByZXR1cm4gYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IHJlY29yZDogcmVjb3JkIH0pLnRoZW4oKCkgPT4gdXBkYXRlUmVjb3JkZXJUb29sVGlwKCkpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVzdG9yZSgpIHtcclxuICAgIGxldCB7IHJlY29yZDogciB9ID0gYXdhaXQgbGFzdFJlY29yZCgpO1xyXG4gICAgZm9yIChsZXQgd2luZG93UmVjb3JkIG9mIHIpIHtcclxuICAgICAgICBpZiAoYnJvd3Nlci5ydW50aW1lLmdldEJyb3dzZXJJbmZvKSB7XHJcbiAgICAgICAgICAgIHdpbmRvd1JlY29yZCA9IHdpbmRvd1JlY29yZC5maWx0ZXIodGFiUmVjb3JkID0+ICF0YWJSZWNvcmQudXJsLnN0YXJ0c1dpdGgoXCJhYm91dDpcIikpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyb3dzZXIud2luZG93cy5jcmVhdGUoe1xyXG4gICAgICAgICAgICB1cmw6IHdpbmRvd1JlY29yZC5tYXAodGFiUmVjb3JkID0+IHRhYlJlY29yZC51cmwpXHJcbiAgICAgICAgfSkudGhlbihhc3luYyB3ID0+IHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3aW5kb3dSZWNvcmQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCB0YWJSZWNvcmQgPSB3aW5kb3dSZWNvcmRbaV07XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHcudGFic1tpXS5pZCwge1xyXG4gICAgICAgICAgICAgICAgICAgIHBpbm5lZDogdGFiUmVjb3JkLnBpbm5lZFxyXG4gICAgICAgICAgICAgICAgfSkudGhlbih0ID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGFiUmVjb3JkLnBhY2spIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcnVuQWZ0ZXJUYWJMb2FkKHQuaWQsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyb3dzZXIudGFicy5zZW5kTWVzc2FnZSh0LmlkLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiBcInBhY2tkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YTogT2JqZWN0LmFzc2lnbih7YWN0aW9uOiBcInVucGFja1wifSwgdGFiUmVjb3JkLnBhY2spXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSkuY2F0Y2goZSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCB7IHNlbmRSdW50aW1lTWVzc2FnZSB9IGZyb20gXCIuL21lc3NhZ2luZ1wiXG5cbmxldCB3cm9uZ1RvUmlnaHQ7XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRXcm9uZ1RvUmlnaHQoKSB7XG4gICAgcmV0dXJuIHNlbmRSdW50aW1lTWVzc2FnZShcIldST05HX1RPX1JJR0hUX0dFVFwiLCB7fSkudGhlbihyZXNwb25zZSA9PiB7XG4gICAgICAgIHdyb25nVG9SaWdodCA9IHJlc3BvbnNlLndyb25nVG9SaWdodDtcbiAgICB9KTtcbn1cblxuLy8gRnVuY3Rpb24gdG8gZ2V0IGNvcnJlY3QgdGFiIGlkXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q29ycmVjdFRhYklkKHRhYklkKSB7XG4gICAgcmV0dXJuIHdyb25nVG9SaWdodFt0YWJJZF0gfHwgdGFiSWQ7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi9nbG9iYWxzXCJcbmltcG9ydCB7IGdldENvcnJlY3RUYWJJZCB9IGZyb20gXCIuL3dyb25nLXRvLXJpZ2h0XCJcblxuLy8gSGlkZXMgdGhlIHRhYiBwcmV2aWV3XG5leHBvcnQgZnVuY3Rpb24gaGlkZVRhYlByZXZpZXcoKSB7XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLWltZ1wiKS5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG59XG5cbi8vIEdldCBhIHRhYiBieSBhIHRhYiBlbnRyeVxuZXhwb3J0IGZ1bmN0aW9uIGdldFRhYkJ5VGFiRW50cnkoZW50cnkpIHtcbiAgICByZXR1cm4gYnJvd3Nlci50YWJzLmdldChnZXRUYWJJZChlbnRyeSkpO1xufVxuXG4vLyBHZXQgdGhlIFRhYklkIG9mIGEgdGFiIGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gZ2V0VGFiSWQoZW50cnkpIHtcbiAgICByZXR1cm4gcGFyc2VJbnQoZW50cnkuZ2V0QXR0cmlidXRlKFwiZGF0YS10YWJfaWRcIikpO1xufVxuXG4vLyBHZXQgdGhlIFdpbmRvd0lkIG9mIGEgd2luZG93IGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gZ2V0V2luZG93SWQoZW50cnkpIHtcbiAgICByZXR1cm4gcGFyc2VJbnQoZW50cnkuZ2V0QXR0cmlidXRlKFwiZGF0YS13aW5kb3dfaWRcIikpO1xufVxuXG4vLyBGaW5kIHRhYiBlbnRyeSBieSB0YWIgaWRcbmV4cG9ydCBmdW5jdGlvbiBmaW5kVGFiRW50cnlCeUlkKHRhYklkKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIudGFiLWVudHJ5W2RhdGEtdGFiX2lkPVxcXCJcIiArIHRhYklkICsgXCJcXFwiXVwiKTtcbn1cblxuLy8gRmluZCBjb3JyZWN0IHRhYiBlbnRyeSBieSB0YWIgaWRcbmV4cG9ydCBmdW5jdGlvbiBmaW5kQ29ycmVjdFRhYkVudHJ5QnlJZCh0YWJJZCkge1xuICAgIHJldHVybiBmaW5kVGFiRW50cnlCeUlkKGdldENvcnJlY3RUYWJJZCh0YWJJZCkpO1xufVxuXG4vLyBHZXQgZmF2aWNvbiBmcm9tIGEgdGFiIGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gZ2V0RmF2SWNvbkZyb21UYWJFbnRyeShlbnRyeSkge1xuICAgIHJldHVybiBlbnRyeS5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ0YWItZW50cnktZmF2aWNvblwiKTtcbn1cblxuLy8gRmluZCB3aW5kb3cgZW50cnkgYnkgdGFiIGlkXG5leHBvcnQgZnVuY3Rpb24gZmluZFdpbmRvd0VudHJ5QnlJZCh3aW5kb3dJZCkge1xuICAgIHJldHVybiBHLnRhYnNMaXN0LnF1ZXJ5U2VsZWN0b3IoXCJsaVtkYXRhLXdpbmRvd19pZD1cXFwiXCIgKyB3aW5kb3dJZCArIFwiXFxcIl1cIik7XG59XG5cbi8vIEZpbmQgdGFiIGVudHJ5IGluc2lkZSBhIHdpbmRvdyBlbnRyeVxuZXhwb3J0IGZ1bmN0aW9uIGZpbmRUYWJFbnRyeUluV2luZG93KHdpbmRvd0VudHJ5LCB0YWJJZCkge1xuICAgIHJldHVybiB3aW5kb3dFbnRyeS5xdWVyeVNlbGVjdG9yKFwibGlbZGF0YS10YWJfaWQ9XFxcIlwiICsgdGFiSWQgKyBcIlxcXCJdXCIpO1xufVxuXG4vLyBHZXQgYWN0aXZlIHRhYiBpbiB0aGUgc3BlY2lmaWVkIHdpbmRvd1xuZXhwb3J0IGZ1bmN0aW9uIGdldEFjdGl2ZVRhYih3aW5kb3dJZCkge1xuICAgIGxldCB3aW5kb3cgPSBmaW5kV2luZG93RW50cnlCeUlkKHdpbmRvd0lkKTtcbiAgICByZXR1cm4gd2luZG93LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcImN1cnJlbnQtdGFiXCIpO1xufVxuXG4vLyBTZXQgYWN0aXZlIHRhYiBpbiB0aGUgc3BlY2lmaWVkIHdpbmRvd1xuZXhwb3J0IGZ1bmN0aW9uIHNldEFjdGl2ZVRhYih3aW5kb3dJZCwgdGFiSWQpIHtcbiAgICBsZXQgd2luZG93ID0gZmluZFdpbmRvd0VudHJ5QnlJZCh3aW5kb3dJZCksIGxhc3RBY3RpdmVUYWI7XG4gICAgaWYgKChsYXN0QWN0aXZlVGFiID0gZ2V0QWN0aXZlVGFiKHdpbmRvd0lkKSkgIT09IG51bGwpIHtcbiAgICAgICAgbGFzdEFjdGl2ZVRhYi5jbGFzc0xpc3QucmVtb3ZlKFwiY3VycmVudC10YWJcIik7XG4gICAgfVxuICAgIGZpbmRUYWJFbnRyeUluV2luZG93KHdpbmRvdywgdGFiSWQpLmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXRhYlwiKTtcbn1cblxuLy8gUmVtb3ZlIHRhYlxuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZVRhYih0YWJJZCwgd2luZG93SWQpIHtcbiAgICBsZXQgdGFiRW50cnkgPSBmaW5kVGFiRW50cnlCeUlkKHRhYklkKTtcbiAgICB0YWJFbnRyeS5wYXJlbnRFbGVtZW50LnJlbW92ZUNoaWxkKHRhYkVudHJ5KTtcbiAgICBicm93c2VyLnRhYnMucXVlcnkoe1xuICAgICAgICBhY3RpdmU6IHRydWUsXG4gICAgICAgIHdpbmRvd0lkOiB3aW5kb3dJZFxuICAgIH0pLnRoZW4odGFicyA9PiB7XG4gICAgICAgIGZpbmRDb3JyZWN0VGFiRW50cnlCeUlkKHRhYnNbMF0uaWQpLmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXRhYlwiKTtcbiAgICB9KTtcbn1cblxuLy8gTW92ZSB0YWJcbmV4cG9ydCBmdW5jdGlvbiBtb3ZlVGFiKHRhcmdldCwgZGVzdCkge1xuICAgIGdldFdpbmRvd0Zyb21UYWIoZGVzdCkuZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lKFwid2luZG93LWVudHJ5LXRhYnNcIikuaW5zZXJ0QmVmb3JlKHRhcmdldCwgZGVzdCk7XG59XG5cbi8vIE1vdmUgdGFic1xuZXhwb3J0IGZ1bmN0aW9uIG1vdmVUYWJzKHRhcmdldHMsIGRlc3QpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhcmdldHMubGVuZ3RoOyBpKyspIG1vdmVUYWIodGFyZ2V0c1tpXSwgZGVzdCk7XG59XG5cbi8vIEF0dGFjaCB0YWJcbmV4cG9ydCBmdW5jdGlvbiBhdHRhY2hUYWIodGFyZ2V0LCBkZXN0KSB7XG4gICAgZGVzdC5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ3aW5kb3ctZW50cnktdGFic1wiKS5hcHBlbmRDaGlsZCh0YXJnZXQpO1xufVxuXG4vLyBBdHRhY2ggdGFic1xuZXhwb3J0IGZ1bmN0aW9uIGF0dGFjaFRhYnModGFyZ2V0cywgZGVzdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFyZ2V0cy5sZW5ndGg7IGkrKykgYXR0YWNoVGFiKHRhcmdldHNbaV0sIGRlc3QpO1xufVxuXG4vLyBSZW1vdmUgd2luZG93XG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlV2luZG93KHdpbmRvd0lkKSB7XG4gICAgbGV0IHdpbmRvd0VudHJ5ID0gZmluZFdpbmRvd0VudHJ5QnlJZCh3aW5kb3dJZCk7XG4gICAgd2luZG93RW50cnkucGFyZW50RWxlbWVudC5yZW1vdmVDaGlsZCh3aW5kb3dFbnRyeSk7XG4gICAgYnJvd3Nlci53aW5kb3dzLmdldEN1cnJlbnQoe30pLnRoZW4od2luZG93ID0+IHtcbiAgICAgICAgZmluZFdpbmRvd0VudHJ5QnlJZCh3aW5kb3cuaWQpLmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXdpbmRvd1wiKTtcbiAgICB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFdpbmRvd0Zyb21UYWIodGFiKSB7XG4gICAgcmV0dXJuIHRhYi5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQ7XG59XG5cbi8vIFRlc3QgaWYgdGFiIGlzIGRyYWdnYWJsZVxuZXhwb3J0IGZ1bmN0aW9uIHRhYkRyYWdnYWJsZShzb3VyY2VUYWIsIHRhcmdldFRhYiwgdW5kZXIsIHNvdXJjZVdpbmRvdywgbXVsdGlEcmFnZ2luZykge1xuICAgIHJldHVybiAhc291cmNlVGFiLmlzU2FtZU5vZGUodGFyZ2V0VGFiKVxuICAgICAgICAgICAgJiYgKCFtdWx0aURyYWdnaW5nIHx8IChtdWx0aVNlbGVjdGVkKHNvdXJjZVRhYikgJiYgbXVsdGlTZWxlY3RlZCh0YXJnZXRUYWIpKSlcbiAgICAgICAgICAgICYmICgoIXNvdXJjZVRhYi5jbGFzc0xpc3QuY29udGFpbnMoXCJwaW5uZWQtdGFiXCIpICYmICF0YXJnZXRUYWIuY2xhc3NMaXN0LmNvbnRhaW5zKFwicGlubmVkLXRhYlwiKSlcbiAgICAgICAgICAgICAgICB8fCAoc291cmNlVGFiLmNsYXNzTGlzdC5jb250YWlucyhcInBpbm5lZC10YWJcIikgJiYgdGFyZ2V0VGFiLmNsYXNzTGlzdC5jb250YWlucyhcInBpbm5lZC10YWJcIikpXG4gICAgICAgICAgICAgICAgfHwgKHVuZGVyICYmICFzb3VyY2VUYWIuY2xhc3NMaXN0LmNvbnRhaW5zKFwicGlubmVkLXRhYlwiKSkpXG4gICAgICAgICAgICAmJiAoKCFzb3VyY2VXaW5kb3cuY2xhc3NMaXN0LmNvbnRhaW5zKFwiaW5jb2duaXRvLXdpbmRvd1wiKSAmJiAhZ2V0V2luZG93RnJvbVRhYih0YXJnZXRUYWIpLmNsYXNzTGlzdC5jb250YWlucyhcImluY29nbml0by13aW5kb3dcIikpXG4gICAgICAgICAgICAgICAgfHwgKHNvdXJjZVdpbmRvdy5jbGFzc0xpc3QuY29udGFpbnMoXCJpbmNvZ25pdG8td2luZG93XCIpICYmIGdldFdpbmRvd0Zyb21UYWIodGFyZ2V0VGFiKS5jbGFzc0xpc3QuY29udGFpbnMoXCJpbmNvZ25pdG8td2luZG93XCIpKSk7XG59XG5cbi8vIFRlc3QgaWYgdGFiIGlzIGRyYWdnYWJsZSB0byB3aW5kb3dcbmV4cG9ydCBmdW5jdGlvbiB0YWJEcmFnZ2FibGVUb1dpbmRvdyhzb3VyY2VUYWIsIHRhcmdldFdpbmRvdywgc291cmNlV2luZG93KSB7XG4gICAgcmV0dXJuICFzb3VyY2VXaW5kb3cuaXNTYW1lTm9kZSh0YXJnZXRXaW5kb3cpXG4gICAgICAgICAgICAmJiAhc291cmNlVGFiLmNsYXNzTGlzdC5jb250YWlucyhcInBpbm5lZC10YWJcIilcbiAgICAgICAgICAgICYmICgoIXNvdXJjZVdpbmRvdy5jbGFzc0xpc3QuY29udGFpbnMoXCJpbmNvZ25pdG8td2luZG93XCIpICYmICF0YXJnZXRXaW5kb3cuY2xhc3NMaXN0LmNvbnRhaW5zKFwiaW5jb2duaXRvLXdpbmRvd1wiKSlcbiAgICAgICAgICAgICAgICB8fCAoc291cmNlV2luZG93LmNsYXNzTGlzdC5jb250YWlucyhcImluY29nbml0by13aW5kb3dcIikgJiYgdGFyZ2V0V2luZG93LmNsYXNzTGlzdC5jb250YWlucyhcImluY29nbml0by13aW5kb3dcIikpKTtcbn1cblxuLy8gUmV0dXJucyB0aGUgaW5kZXggb2YgYSB0YWIgZW50cnlcbmV4cG9ydCBmdW5jdGlvbiB0YWJFbnRyeUluZGV4KHRhYkVudHJ5KSB7XG4gICAgbGV0IHRhYnMgPSBBcnJheS5mcm9tKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ0YWItZW50cnlcIikpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFicy5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAodGFic1tpXSA9PT0gdGFiRW50cnkpIHtcbiAgICAgICAgICAgIHJldHVybiBpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiAtMTtcbn1cblxuLyogTXVsdGlzZWxlY3QgKi9cbmxldCBzZWxlY3RlZFRhYnMgPSAwO1xuLy8gR2V0IFNlbGVjdGVkIEl0ZW1zXG5leHBvcnQgZnVuY3Rpb24gZ2V0U2VsZWN0ZWRJdGVtcygpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbShkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibXVsdGlzZWxlY3RcIikpO1xufVxuLy8gTXVsdGlzZWxlY3RlZFxuZXhwb3J0IGZ1bmN0aW9uIG11bHRpU2VsZWN0ZWQoZWxlbWVudCkge1xuICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcIm11bHRpc2VsZWN0XCIpO1xufVxuLy8gU2VsZWN0XG5leHBvcnQgZnVuY3Rpb24gbXVsdGlTZWxlY3QoZWxlbWVudCkge1xuICAgIGlmICghZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoXCJtdWx0aXNlbGVjdFwiKSkge1xuICAgICAgICBzZWxlY3RlZFRhYnMrKztcbiAgICAgICAgRy5pc1NlbGVjdGluZyA9IHRydWU7XG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZChcIm11bHRpc2VsZWN0XCIpO1xuICAgIH1cbn1cbi8vIENhbmNlbCBTZWxlY3Rpb25cbmV4cG9ydCBmdW5jdGlvbiBtdWx0aVNlbGVjdENhbmNlbChlbGVtZW50KSB7XG4gICAgaWYgKGVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwibXVsdGlzZWxlY3RcIikpIHtcbiAgICAgICAgaWYgKC0tc2VsZWN0ZWRUYWJzID09IDApIHtcbiAgICAgICAgICAgIEcuaXNTZWxlY3RpbmcgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoXCJtdWx0aXNlbGVjdFwiKTtcbiAgICB9XG59XG4vLyBSZXNldCBtdWx0aXNlbGVjdFxuZXhwb3J0IGZ1bmN0aW9uIG11bHRpU2VsZWN0UmVzZXQoKSB7XG4gICAgZm9yIChsZXQgZWxlbWVudCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJtdWx0aXNlbGVjdFwiKSkpIHtcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKFwibXVsdGlzZWxlY3RcIik7XG4gICAgfVxuICAgIEcuaXNTZWxlY3RpbmcgPSBmYWxzZTtcbn1cbi8vIFRvZ2dsZSBTZWxlY3Rpb25cbmV4cG9ydCBmdW5jdGlvbiBtdWx0aVNlbGVjdFRvZ2dsZShlbGVtZW50KSB7XG4gICAgaWYgKGVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwibXVsdGlzZWxlY3RcIikpIHtcbiAgICAgICAgbXVsdGlTZWxlY3RDYW5jZWwoZWxlbWVudCk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgbXVsdGlTZWxlY3QoZWxlbWVudCk7XG4gICAgfVxufVxuLy8gUmVzZXQgc2xpZGUgc2VsZWN0aW9uXG5leHBvcnQgZnVuY3Rpb24gcmVzZXRTbGlkZVNlbGVjdGlvbigpIHtcbiAgICBHLnNsaWRlU2VsZWN0aW9uLnNsaWRpbmcgPSBmYWxzZTtcbiAgICBHLnNsaWRlU2VsZWN0aW9uLmluaXRpYXRvciA9IHVuZGVmaW5lZDtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCBHIGZyb20gXCIuL2dsb2JhbHNcIlxuaW1wb3J0IHsgZ2V0SW1hZ2UgfSBmcm9tIFwiLi9uZXRcIlxuaW1wb3J0IHsgZ2V0Q29ycmVjdFRhYklkIH0gZnJvbSBcIi4vd3JvbmctdG8tcmlnaHRcIlxuaW1wb3J0IHsgZ2V0V2luZG93cywgY29ycmVjdEZvY3VzZWQgfSBmcm9tIFwiLi93dHV0aWxzXCJcbmltcG9ydCB7IGdldEFjdHVhbEhlaWdodCB9IGZyb20gXCIuL2RvbXV0aWxzXCJcbmltcG9ydCB7IHdpbmRvd0VudHJ5RHJhZ1N0YXJ0ZWQsIHdpbmRvd0VudHJ5RHJhZ2dpbmdPdmVyLCB3aW5kb3dFbnRyeURyb3BwZWQsIHdpbmRvd0VudHJ5VGl0bGVDbGlja2VkLCB3aW5kb3dDbG9zZUNsaWNrIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL3dpbmRvd0VudHJ5XCJcbmltcG9ydCB7IHRhYkVudHJ5TW91c2VPdmVyLCB0YWJFbnRyeU1vdXNlTGVhdmUsIHRhYkVudHJ5Q2xpY2tlZCwgdGFiQ2xvc2VDbGljaywgdGFiUGluQ2xpY2sgfSBmcm9tIFwiLi9ldmVudC1saXN0ZW5lcnMvdGFiRW50cnlcIlxuXG4vLyBVcGRhdGUgdGFic1xuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZVRhYnMod2luZG93cykge1xuICAgIEcudGFic0xpc3QuaW5uZXJIVE1MID0gXCJcIjtcbiAgICBsZXQgdGFic0xpc3RGcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcbiAgICBsZXQgY3VycmVudFdpbmRvd0VudHJ5O1xuICAgIC8qIFByZWRlZmluZWQgZWxlbWVudHMgZm9yIGZhc3RlciBwZXJmb3JtYW5jZSAqL1xuICAgIC8vIFdpbmRvdyBjbG9zZSBidXR0b25cbiAgICBsZXQgV0lORE9XX0NMT1NFX0JUTiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgIFdJTkRPV19DTE9TRV9CVE4uY2xhc3NMaXN0LmFkZChcImlubGluZS1idXR0b25cIik7XG4gICAgV0lORE9XX0NMT1NFX0JUTi5jbGFzc0xpc3QuYWRkKFwiaW1nLWJ1dHRvblwiKTtcbiAgICBXSU5ET1dfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJvcGFjaXR5LWNoYW5naW5nLWJ1dHRvblwiKTtcbiAgICBXSU5ET1dfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJ3aW5kb3ctZW50cnktcmVtb3ZlLWJ0blwiKTtcbiAgICBXSU5ET1dfQ0xPU0VfQlROLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IFwidXJsKC4uL2ljb25zL2Nsb3NlLnN2ZylcIjtcbiAgICBsZXQgRElWID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICBESVYuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lLWJsb2NrXCI7XG4gICAgV0lORE9XX0NMT1NFX0JUTi5hcHBlbmRDaGlsZChESVYpO1xuICAgIC8vIFRhYiBjbG9zZSBidXR0b25cbiAgICBsZXQgVEFCX0NMT1NFX0JUTiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgIFRBQl9DTE9TRV9CVE4uY2xhc3NMaXN0LmFkZChcImlubGluZS1idXR0b25cIik7XG4gICAgVEFCX0NMT1NFX0JUTi5jbGFzc0xpc3QuYWRkKFwicmVkLWJ1dHRvblwiKTtcbiAgICBUQUJfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJpbWctYnV0dG9uXCIpO1xuICAgIFRBQl9DTE9TRV9CVE4uY2xhc3NMaXN0LmFkZChcInRhYi1lbnRyeS1yZW1vdmUtYnRuXCIpO1xuICAgIFRBQl9DTE9TRV9CVE4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvY2xvc2Uuc3ZnKVwiO1xuICAgIC8vIFRhYiBwaW4gYnV0dG9uXG4gICAgbGV0IFRBQl9QSU5fQlROID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG4gICAgVEFCX1BJTl9CVE4uY2xhc3NMaXN0LmFkZChcImlubGluZS1idXR0b25cIik7XG4gICAgVEFCX1BJTl9CVE4uY2xhc3NMaXN0LmFkZChcImltZy1idXR0b25cIik7XG4gICAgVEFCX1BJTl9CVE4uY2xhc3NMaXN0LmFkZChcIm9wYWNpdHktY2hhbmdpbmctYnV0dG9uXCIpO1xuICAgIFRBQl9QSU5fQlROLmNsYXNzTGlzdC5hZGQoXCJ0YWItZW50cnktcGluLWJ0blwiKTtcbiAgICBUQUJfUElOX0JUTi5zdHlsZS5iYWNrZ3JvdW5kSW1hZ2UgPSBcInVybCguLi9pY29ucy9waW4uc3ZnKVwiO1xuICAgIC8vIExvb3AgdGhyb3VnaCB3aW5kb3dzXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3aW5kb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIC8vIFNldCB3IHRvIHdpbmRvd1xuICAgICAgICBsZXQgdyA9IHdpbmRvd3NbaV07XG5cbiAgICAgICAgLy8gQ3JlYXRlIHdpbmRvdyBlbnRyeVxuICAgICAgICBsZXQgd2luZG93RW50cnkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG4gICAgICAgIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5hZGQoXCJ3aW5kb3ctZW50cnlcIik7XG4gICAgICAgIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5hZGQoXCJjYXRlZ29yeVwiKTtcblxuICAgICAgICAvLyBDcmVhdGUgd2luZG93IGVudHJ5IGZyYWdtZW50XG4gICAgICAgIGxldCB3aW5kb3dFbnRyeUZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xuXG4gICAgICAgIC8vIFNldCB3aW5kb3cgaWQgdG8gd2luZG93IGVudHJ5XG4gICAgICAgIHdpbmRvd0VudHJ5LnNldEF0dHJpYnV0ZShcImRhdGEtd2luZG93X2lkXCIsIHcuaWQpO1xuICAgICAgICBsZXQgc3BhbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICBzcGFuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCB3aW5kb3dFbnRyeVRpdGxlQ2xpY2tlZCk7XG5cbiAgICAgICAgLy8gQ3JlYXRlIGNsb3NlIGJ1dHRvblxuICAgICAgICBsZXQgY2xvc2VCdG4gPSBXSU5ET1dfQ0xPU0VfQlROLmNsb25lTm9kZSh0cnVlKTtcbiAgICAgICAgY2xvc2VCdG4uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHdpbmRvd0Nsb3NlQ2xpY2spO1xuXG4gICAgICAgIC8vIEJ1dHRvbnMgd3JhcHBlclxuICAgICAgICBsZXQgYnV0dG9ucyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICBidXR0b25zLmNsYXNzTGlzdC5hZGQoXCJ3aW5kb3ctZW50cnktYnV0dG9uc1wiKTtcbiAgICAgICAgYnV0dG9ucy5hcHBlbmRDaGlsZChjbG9zZUJ0bik7XG4gICAgICAgIFxuICAgICAgICAvLyBDcmVhdGUgd2luZG93IG5hbWUgc3BhblxuICAgICAgICBsZXQgd2luZG93TmFtZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICB3aW5kb3dOYW1lLmNsYXNzTGlzdC5hZGQoXCJ3aW5kb3ctdGl0bGVcIik7XG4gICAgICAgIHdpbmRvd05hbWUudGV4dENvbnRlbnQgKz0gXCJXaW5kb3cgXCIgKyAoaSsxKTtcblxuICAgICAgICAvLyBDaGVjayBpZiB3aW5kb3cgaXMgZm9jdXNlZFxuICAgICAgICBpZiAody5mb2N1c2VkKSB7XG4gICAgICAgICAgICBjdXJyZW50V2luZG93RW50cnkgPSB3aW5kb3dFbnRyeTtcbiAgICAgICAgICAgIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXdpbmRvd1wiKTtcbiAgICAgICAgICAgIHdpbmRvd05hbWUudGV4dENvbnRlbnQgKz0gXCIgLSBDdXJyZW50XCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQ2hlY2sgaWYgd2luZG93IGlzIGluY29nbml0b1xuICAgICAgICBpZiAody5pbmNvZ25pdG8pIHtcbiAgICAgICAgICAgIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5hZGQoXCJpbmNvZ25pdG8td2luZG93XCIpO1xuICAgICAgICAgICAgd2luZG93TmFtZS50ZXh0Q29udGVudCArPSBcIiAoSW5jb2duaXRvKVwiO1xuICAgICAgICB9XG5cbiAgICAgICAgc3Bhbi5hcHBlbmRDaGlsZCh3aW5kb3dOYW1lKTtcbiAgICAgICAgc3Bhbi5hcHBlbmRDaGlsZChidXR0b25zKTtcblxuICAgICAgICBzcGFuLmNsYXNzTGlzdC5hZGQoXCJkYXJrZXItYnV0dG9uXCIpO1xuXG4gICAgICAgIHdpbmRvd0VudHJ5RnJhZ21lbnQuYXBwZW5kQ2hpbGQoc3Bhbik7XG5cbiAgICAgICAgLy8gQWRkIHdpbmRvdyBlbnRyeSBkcmFnc3RhcnQsIGRyYWdvdmVyLCBhbmQgZHJvcCBldmVudCBsaXN0ZW5lcnNcbiAgICAgICAgd2luZG93RW50cnkuYWRkRXZlbnRMaXN0ZW5lcihcImRyYWdzdGFydFwiLCB3aW5kb3dFbnRyeURyYWdTdGFydGVkKTtcbiAgICAgICAgd2luZG93RW50cnkuYWRkRXZlbnRMaXN0ZW5lcihcImRyYWdvdmVyXCIsIHdpbmRvd0VudHJ5RHJhZ2dpbmdPdmVyKTtcbiAgICAgICAgd2luZG93RW50cnkuYWRkRXZlbnRMaXN0ZW5lcihcImRyb3BcIiwgd2luZG93RW50cnlEcm9wcGVkKTtcbiAgICAgICAgd2luZG93RW50cnkuc2V0QXR0cmlidXRlKFwiZHJhZ2dhYmxlXCIsIFwidHJ1ZVwiKTtcblxuICAgICAgICBsZXQgd2luZG93VGFic0xpc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwidWxcIik7XG4gICAgICAgIHdpbmRvd1RhYnNMaXN0LmNsYXNzTGlzdC5hZGQoXCJjYXRlZ29yeS1saXN0XCIpO1xuICAgICAgICB3aW5kb3dUYWJzTGlzdC5jbGFzc0xpc3QuYWRkKFwid2luZG93LWVudHJ5LXRhYnNcIik7XG5cbiAgICAgICAgbGV0IHdpbmRvd1RhYnNMaXN0RnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICAgIC8vIExvb3AgdGhyb3VnaCB0YWJzXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdy50YWJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgdGFiID0gdy50YWJzW2ldO1xuICAgICAgICAgICAgLy8gQ2hlY2sgdGFiIGlkXG4gICAgICAgICAgICBpZiAodGFiLmlkICE9PSBicm93c2VyLnRhYnMuVEFCX0lEX05PTkUpIHtcbiAgICAgICAgICAgICAgICAvLyBDcmVhdGUgdGFiIGVudHJ5XG4gICAgICAgICAgICAgICAgbGV0IHRhYkVudHJ5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xuICAgICAgICAgICAgICAgIHRhYkVudHJ5LmNsYXNzTGlzdC5hZGQoXCJ0YWItZW50cnlcIik7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LmFkZChcImJ1dHRvblwiKTtcbiAgICAgICAgICAgICAgICAvLyBTZXQgdGFiIGVudHJ5IGFzIGRyYWdnYWJsZS4gUmVxdWlyZWQgdG8gZW5hYmxlIG1vdmUgdGFiIGZlYXR1cmVcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5zZXRBdHRyaWJ1dGUoXCJkcmFnZ2FibGVcIiwgXCJ0cnVlXCIpO1xuXG4gICAgICAgICAgICAgICAgLy8gQ3JlYXRlIHRhYiBlbnRyeSBmcmFnbWVudFxuICAgICAgICAgICAgICAgIGxldCB0YWJFbnRyeUZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xuXG4gICAgICAgICAgICAgICAgbGV0IGZhdmljb247XG4gICAgICAgICAgICAgICAgbGV0IHRpdGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG4gICAgICAgICAgICAgICAgdGl0bGUuY2xhc3NMaXN0LmFkZChcInRhYi10aXRsZVwiKTtcbiAgICAgICAgICAgICAgICB0aXRsZS50ZXh0Q29udGVudCArPSB0YWIudGl0bGU7XG4gICAgICAgICAgICAgICAgbGV0IHRpdGxlV3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgICAgICAgICAgdGl0bGVXcmFwcGVyLmNsYXNzTGlzdC5hZGQoXCJ0YWItdGl0bGUtd3JhcHBlclwiKTtcbiAgICAgICAgICAgICAgICB0aXRsZVdyYXBwZXIuYXBwZW5kQ2hpbGQodGl0bGUpO1xuXG4gICAgICAgICAgICAgICAgaWYgKHRhYi5hY3RpdmUpIHtcbiAgICAgICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LmFkZChcImN1cnJlbnQtdGFiXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodGFiLmZhdkljb25VcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgZmF2aWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIik7XG4gICAgICAgICAgICAgICAgICAgIGZhdmljb24uY2xhc3NMaXN0LmFkZChcInRhYi1lbnRyeS1mYXZpY29uXCIpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZmF2SWNvblByb21pc2U7XG4gICAgICAgICAgICAgICAgICAgIGlmICh3LmluY29nbml0bykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmF2SWNvblByb21pc2UgPSBnZXRJbWFnZSh0YWIuZmF2SWNvblVybCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmYXZJY29uUHJvbWlzZSA9IGdldEltYWdlKHRhYi5mYXZJY29uVXJsKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBmYXZJY29uUHJvbWlzZS50aGVuKGJhc2U2NEltYWdlID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhdmljb24uc3JjID0gYmFzZTY0SW1hZ2U7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBjbG9zZSBidXR0b25cbiAgICAgICAgICAgICAgICBjbG9zZUJ0biA9IFRBQl9DTE9TRV9CVE4uY2xvbmVOb2RlKGZhbHNlKTtcbiAgICAgICAgICAgICAgICBjbG9zZUJ0bi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgdGFiQ2xvc2VDbGljayk7XG5cbiAgICAgICAgICAgICAgICAvLyBDcmVhdGUgcGluIGJ1dHRvblxuICAgICAgICAgICAgICAgIGxldCBwaW5CdG4gPSBUQUJfUElOX0JUTi5jbG9uZU5vZGUoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHBpbkJ0bi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgdGFiUGluQ2xpY2spO1xuXG4gICAgICAgICAgICAgICAgLy8gQnV0dG9ucyB3cmFwcGVyXG4gICAgICAgICAgICAgICAgYnV0dG9ucyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICAgICAgICAgIGJ1dHRvbnMuY2xhc3NMaXN0LmFkZChcInRhYi1lbnRyeS1idXR0b25zXCIpO1xuICAgICAgICAgICAgICAgIGJ1dHRvbnMuYXBwZW5kQ2hpbGQocGluQnRuKTtcbiAgICAgICAgICAgICAgICBidXR0b25zLmFwcGVuZENoaWxkKGNsb3NlQnRuKTtcblxuICAgICAgICAgICAgICAgIC8vIFNldCB0YWIgZW50cnkgdGFiIGlkXG4gICAgICAgICAgICAgICAgdGFiRW50cnkuc2V0QXR0cmlidXRlKFwiZGF0YS10YWJfaWRcIiwgZ2V0Q29ycmVjdFRhYklkKHRhYi5pZCkpO1xuICAgICAgICAgICAgICAgIGlmIChmYXZpY29uICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGFiRW50cnlGcmFnbWVudC5hcHBlbmRDaGlsZChmYXZpY29uKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0YWJFbnRyeS5jbGFzc0xpc3QuYWRkKFwibm9pY29uXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0YWJFbnRyeUZyYWdtZW50LmFwcGVuZENoaWxkKHRpdGxlV3JhcHBlcik7XG4gICAgICAgICAgICAgICAgdGFiRW50cnlGcmFnbWVudC5hcHBlbmRDaGlsZChidXR0b25zKTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5hcHBlbmRDaGlsZCh0YWJFbnRyeUZyYWdtZW50KTtcblxuICAgICAgICAgICAgICAgIHRhYkVudHJ5LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgdGFiRW50cnlNb3VzZU92ZXIpO1xuICAgICAgICAgICAgICAgIHRhYkVudHJ5LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZWxlYXZlXCIsIHRhYkVudHJ5TW91c2VMZWF2ZSk7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHRhYkVudHJ5Q2xpY2tlZCk7XG5cbiAgICAgICAgICAgICAgICBpZiAodGFiLnBpbm5lZCkge1xuICAgICAgICAgICAgICAgICAgICBwaW5CdG4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvcGlucmVtb3ZlLnN2ZylcIjtcbiAgICAgICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LmFkZChcInBpbm5lZC10YWJcIik7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwaW5uZWRUYWJzID0gQXJyYXkuZnJvbSh3aW5kb3dUYWJzTGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwicGlubmVkLXRhYlwiKSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBsYXN0UGlubmVkVGFiID0gcGlubmVkVGFic1twaW5uZWRUYWJzLmxlbmd0aC0xXTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxhc3RQaW5uZWRUYWIgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93VGFic0xpc3RGcmFnbWVudC5pbnNlcnRCZWZvcmUodGFiRW50cnksIGxhc3RQaW5uZWRUYWIubmV4dFNpYmxpbmcpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93VGFic0xpc3RGcmFnbWVudC5pbnNlcnRCZWZvcmUodGFiRW50cnksIHdpbmRvd1RhYnNMaXN0LmNoaWxkTm9kZXNbMF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93VGFic0xpc3RGcmFnbWVudC5hcHBlbmRDaGlsZCh0YWJFbnRyeSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gQXBwZW5kIGZyYWdtZW50IHRvIGFjdHVhbCB3aW5kb3dUYWJzTGlzdFxuICAgICAgICB3aW5kb3dUYWJzTGlzdC5hcHBlbmRDaGlsZCh3aW5kb3dUYWJzTGlzdEZyYWdtZW50KTtcblxuICAgICAgICB3aW5kb3dFbnRyeUZyYWdtZW50LmFwcGVuZENoaWxkKHdpbmRvd1RhYnNMaXN0KTtcbiAgICAgICAgd2luZG93RW50cnkuYXBwZW5kQ2hpbGQod2luZG93RW50cnlGcmFnbWVudCk7XG4gICAgICAgIHRhYnNMaXN0RnJhZ21lbnQuYXBwZW5kQ2hpbGQod2luZG93RW50cnkpO1xuICAgIH1cbiAgICBHLnRhYnNMaXN0LmFwcGVuZENoaWxkKHRhYnNMaXN0RnJhZ21lbnQpO1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFic1wiKS5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xuICAgIGN1cnJlbnRXaW5kb3dFbnRyeS5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbn1cblxuLy8gQWRkIHRhYnMgdG8gbGlzdFxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBvcHVsYXRlVGFic0xpc3QoKSB7XG4gICAgbGV0IHdpbmRvd3MgPSBhd2FpdCBnZXRXaW5kb3dzKCk7XG4gICAgYXdhaXQgY29ycmVjdEZvY3VzZWQod2luZG93cyk7XG4gICAgdXBkYXRlVGFicyh3aW5kb3dzKTtcbn1cblxuLy8gU2V0IHRhYnMgbGlzdCBoZWlnaHQgdG8gYW55IGF2YWlsYWJsZSBoZWlnaHRcbmV4cG9ydCBmdW5jdGlvbiBleHRlbmRUYWJzTGlzdCgpIHtcbiAgICBsZXQgc2VhcmNoQXJlYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2VhcmNoLWFyZWFcIik7XG4gICAgbGV0IHNlYXJjaEFyZWFIZWlnaHQgPSBnZXRBY3R1YWxIZWlnaHQoc2VhcmNoQXJlYSk7XG4gICAgbGV0IHRhYnMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYnNcIik7XG4gICAgdGFicy5zdHlsZS5oZWlnaHQgPSBcImNhbGMoMTAwJSAtIFwiICsgc2VhcmNoQXJlYUhlaWdodCArIFwicHgpXCI7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5cbi8vIEdldCBhbGwgd2luZG93c1xuZXhwb3J0IGZ1bmN0aW9uIGdldFdpbmRvd3MoKSB7XG4gICAgcmV0dXJuIGJyb3dzZXIud2luZG93cy5nZXRBbGwoe1xuICAgICAgICBwb3B1bGF0ZTogdHJ1ZSxcbiAgICAgICAgd2luZG93VHlwZXM6IFtcIm5vcm1hbFwiLCBcInBvcHVwXCIsIFwiZGV2dG9vbHNcIl1cbiAgICB9KTtcbn1cblxuLy8gR2V0IHRoZSBjb3JyZWN0IGxhc3QgZm9jdXNlZCB3aW5kb3cgaWRcbmV4cG9ydCBmdW5jdGlvbiBnZXRMYXN0Rm9jdXNlZFdpbmRvd0lkKCkge1xuICAgIC8qXG4gICAgRHVlIHRvIGEgYnVnIGluIENocm9taXVtLCB3aW5kb3dzLmdldExhc3RGb2N1c2VkKCkgd2lsbCBzb21ldGltZXNcbiAgICByZXR1cm4gaW5jb3JyZWN0IHdpbmRvd3MuIFNvIGhlcmUsIGluc3RlYWQgb2YgY2FsbGluZyBnZXRMYXN0Rm9jdXNlZCgpLFxuICAgIHdlIGNhbGwgZ2V0Q3VycmVudCgpLlxuICAgIFJlZmVyZW5jZTogaHR0cHM6Ly9jcmJ1Zy5jb20vODA5ODIyXG4gICAgKi9cbiAgICByZXR1cm4gYnJvd3Nlci50YWJzLnF1ZXJ5KHsgbGFzdEZvY3VzZWRXaW5kb3c6IHRydWUgfSkudGhlbihmdW5jdGlvbiAodGFicykge1xuICAgICAgICBpZiAodGFicy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICByZXR1cm4gdGFic1swXS53aW5kb3dJZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gLTE7XG4gICAgfSk7XG59XG5cbi8vIENvcnJlY3QgZm9jdXNlZCBwcm9wZXJ0eSBvZiB3aW5kb3dzXG4vLyBJbiBDaHJvbWl1bSwgd2luZG93LmZvY3VzZWQgZG9lc24ndCB3b3JrLCBzbyB3ZSBtYW51YWxseSBzZXQgaXQgaGVyZVxuZXhwb3J0IGZ1bmN0aW9uIGNvcnJlY3RGb2N1c2VkKHdpbmRvd3MpIHtcbiAgICByZXR1cm4gZ2V0TGFzdEZvY3VzZWRXaW5kb3dJZCgpLnRoZW4oZnVuY3Rpb24gKGxhc3RGb2N1c2VkV2luZG93SWQpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3aW5kb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAod2luZG93c1tpXS5pZCA9PT0gbGFzdEZvY3VzZWRXaW5kb3dJZCkge1xuICAgICAgICAgICAgICAgIHdpbmRvd3NbaV0uZm9jdXNlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuLy8gR2V0IGN1cnJlbnQgd2luZG93XG5leHBvcnQgZnVuY3Rpb24gZ2V0TGFzdEZvY3VzZWRXaW5kb3coKSB7XG4gICAgLy8gcmV0dXJuIGJyb3dzZXIud2luZG93cy5nZXRMYXN0Rm9jdXNlZCh7fSk7IC8vIERvZXNuJ3Qgd29yayBkdWUgdG8gYSBidWcgaW4gQ2hyb21pdW0uIFNlZSBleHBsYW5hdGlvbiBpbiBnZXRMYXN0Rm9jdXNlZFdpbmRvd0lkXG4gICAgcmV0dXJuIGdldExhc3RGb2N1c2VkV2luZG93SWQoKS50aGVuKHdpbmRvd0lkID0+IGJyb3dzZXIud2luZG93cy5nZXQod2luZG93SWQpKTtcbn1cblxuLy8gUnVuIGNvZGUgYWZ0ZXIgYSB0YWIgbG9hZHNcbmV4cG9ydCBmdW5jdGlvbiBydW5BZnRlclRhYkxvYWQodGFiSWQsIGYpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBsZXQgbGlzdGVuZXIgPSAodVRhYklkLCBpbmZvKSA9PiB7XG4gICAgICAgICAgICBpZiAodVRhYklkID09PSB0YWJJZCAmJiBpbmZvLnN0YXR1cyA9PT0gJ2NvbXBsZXRlJykge1xuICAgICAgICAgICAgICAgIGJyb3dzZXIudGFicy5vblVwZGF0ZWQucmVtb3ZlTGlzdGVuZXIobGlzdGVuZXIpO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoZigpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgYnJvd3Nlci50YWJzLm9uVXBkYXRlZC5hZGRMaXN0ZW5lcihsaXN0ZW5lcik7XG4gICAgfSk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9