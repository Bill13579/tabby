/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/popup/popup.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*********************************************************************!*\
  !*** ./node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(this, function (module) {
  /* webextension-polyfill - v0.4.0 - Wed Feb 06 2019 11:58:31 */
  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */
  /* vim: set sts=2 sw=2 et tw=80: */
  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (typeof browser === "undefined" || Object.getPrototypeOf(browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
    const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)";

    // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.
    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getBrowserInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }

      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */
      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }
      }

      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */
      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };

      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.rejection
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {integer} metadata.maxResolvedArgs
       *        The maximum number of arguments which may be passed to the
       *        callback created by the wrapped async function.
       *
       * @returns {function}
       *        The generated callback function.
       */
      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(extensionAPIs.runtime.lastError);
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";

      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxResolvedArgs
       *        The maximum number of arguments which may be passed to the
       *        callback created by the wrapped async function.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */
      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({ resolve, reject }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);

                target[name](...args);

                // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.
                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;

                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({ resolve, reject }, metadata));
            }
          });
        };
      };

      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */
      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }
        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);

      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */
      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.

              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,
                get() {
                  return target[prop];
                },
                set(value) {
                  target[prop] = value;
                }
              });

              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }
            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }
        };

        // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.
        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };

      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */
      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }
      });

      // Keep track if the deprecation warning has been logged at least once.
      let loggedSendResponseDeprecationWarning = false;

      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }

        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */
        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;

          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              if (!loggedSendResponseDeprecationWarning) {
                console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                loggedSendResponseDeprecationWarning = true;
              }
              didCallSendResponse = true;
              resolve(response);
            };
          });

          let result;
          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result);

          // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.
          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          }

          // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).
          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;
              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          };

          // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.
          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          }

          // Let Chrome know that the listener is replying.
          return true;
        };
      });

      const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(extensionAPIs.runtime.lastError);
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, { resolve, reject });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", { minArgs: 1, maxArgs: 3 })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", { minArgs: 2, maxArgs: 3 })
        }
      };
      const settingMetadata = {
        clear: { minArgs: 1, maxArgs: 1 },
        get: { minArgs: 1, maxArgs: 1 },
        set: { minArgs: 1, maxArgs: 1 }
      };
      apiMetadata.privacy = {
        network: {
          networkPredictionEnabled: settingMetadata,
          webRTCIPHandlingPolicy: settingMetadata
        },
        services: {
          passwordSavingEnabled: settingMetadata
        },
        websites: {
          hyperlinkAuditingEnabled: settingMetadata,
          referrersEnabled: settingMetadata
        }
      };

      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    };

    // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.
    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),

/***/ "./src/options.js":
/*!************************!*\
  !*** ./src/options.js ***!
  \************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, options, setOptions, stbool */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "options", function() { return options; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setOptions", function() { return setOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stbool", function() { return stbool; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _options_states__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./options/states */ "./src/options/states.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]; });





async function options() {
    return browser.storage.local.get(["options"]).then(data => data.options);
}

async function setOptions(options) {
    return browser.storage.local.set({ options: options });
}

function stbool(switch_state) {
    switch (switch_state) {
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_ON"]:
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_ON"]:
            return true;
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_OFF"]:
        case _options_states__WEBPACK_IMPORTED_MODULE_1__["SWITCH_LOCKED_OFF"]:
            return false;
    }
}


/***/ }),

/***/ "./src/options/states.js":
/*!*******************************!*\
  !*** ./src/options/states.js ***!
  \*******************************/
/*! exports provided: SWITCH_ON, SWITCH_LOCKED_ON, SWITCH_OFF, SWITCH_LOCKED_OFF, INITIAL_OPTIONS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_ON", function() { return SWITCH_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_ON", function() { return SWITCH_LOCKED_ON; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_OFF", function() { return SWITCH_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SWITCH_LOCKED_OFF", function() { return SWITCH_LOCKED_OFF; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "INITIAL_OPTIONS", function() { return INITIAL_OPTIONS; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const SWITCH_ON = 1;
const SWITCH_LOCKED_ON = 2;
const SWITCH_OFF = 0;
const SWITCH_LOCKED_OFF = -1;

const INITIAL_OPTIONS = {
    popup: {
        size: {
            width: 730,
            height: 450
        },
        scale: 1.0,
        showDetails: SWITCH_ON,
        showPreview: SWITCH_ON,
        hideAfterTabSelection: SWITCH_ON,
        searchInURLs: SWITCH_OFF
    }
};
if (Polyfill__WEBPACK_IMPORTED_MODULE_0__["TargetBrowser"] === "chrome") {
    INITIAL_OPTIONS.popup.showPreview = SWITCH_LOCKED_OFF;
    INITIAL_OPTIONS.popup.hideAfterTabSelection = SWITCH_LOCKED_ON;
}


/***/ }),

/***/ "./src/polyfill.js":
/*!*************************!*\
  !*** ./src/polyfill.js ***!
  \*************************/
/*! exports provided: TargetBrowser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TargetBrowser", function() { return TargetBrowser; });
const TargetBrowser = "chrome";

if (true) {
    window["browser"] = __webpack_require__(/*! webextension-polyfill */ "./node_modules/webextension-polyfill/dist/browser-polyfill.js");
}

if (!Array.from) {
    Array.from = (function () {
        let toStr = Object.prototype.toString;
        let isCallable = function (fn) {
            return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
        };
        let toInteger = function (value) {
            let number = Number(value);
            if (isNaN(number)) { return 0; }
            if (number === 0 || !isFinite(number)) { return number; }
            return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
        };
        let maxSafeInteger = Math.pow(2, 53) - 1;
        let toLength = function (value) {
            let len = toInteger(value);
            return Math.min(Math.max(len, 0), maxSafeInteger);
        };

        // The length property of the from method is 1.
        return function from(arrayLike/*, mapFn, thisArg */) {
            // 1. Let C be the this value.
            let C = this;

            // 2. Let items be ToObject(arrayLike).
            let items = Object(arrayLike);

            // 3. ReturnIfAbrupt(items).
            if (arrayLike == null) {
                throw new TypeError('Array.from requires an array-like object - not null or undefined');
            }

            // 4. If mapfn is undefined, then let mapping be false.
            let mapFn = arguments.length > 1 ? arguments[1] : void undefined;
            let T;
            if (typeof mapFn !== 'undefined') {
                // 5. else
                // 5. a If IsCallable(mapfn) is false, throw a TypeError exception.
                if (!isCallable(mapFn)) {
                    throw new TypeError('Array.from: when provided, the second argument must be a function');
                }

                // 5. b. If thisArg was supplied, let T be thisArg; else let T be undefined.
                if (arguments.length > 2) {
                    T = arguments[2];
                }
            }

            // 10. Let lenValue be Get(items, "length").
            // 11. Let len be ToLength(lenValue).
            let len = toLength(items.length);

            // 13. If IsConstructor(C) is true, then
            // 13. a. Let A be the result of calling the [[Construct]] internal method 
            // of C with an argument list containing the single item len.
            // 14. a. Else, Let A be ArrayCreate(len).
            let A = isCallable(C) ? Object(new C(len)) : new Array(len);

            // 16. Let k be 0.
            let k = 0;
            // 17. Repeat, while k < len… (also steps a - h)
            let kValue;
            while (k < len) {
                kValue = items[k];
                if (mapFn) {
                    A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
                } else {
                    A[k] = kValue;
                }
                k += 1;
            }
            // 18. Let putStatus be Put(A, "length", len, true).
            A.length = len;
            // 20. Return A.
            return A;
        };
    }());
}


/***/ }),

/***/ "./src/popup/captureTab.js":
/*!*********************************!*\
  !*** ./src/popup/captureTab.js ***!
  \*********************************/
/*! exports provided: available, init, captureTab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "available", function() { return available; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "init", function() { return init; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "captureTab", function() { return captureTab; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


let available = false;

function init() {
    if (window["browser"] !== undefined
        && browser.tabs["captureTab"] !== undefined) {
        available = true;
        return;
    }
}

function captureTab(id) {
    return available ? browser.tabs.captureTab(id) : new Promise((resolve, reject) => resolve(null));
}


/***/ }),

/***/ "./src/popup/domutils.js":
/*!*******************************!*\
  !*** ./src/popup/domutils.js ***!
  \*******************************/
/*! exports provided: stopPropagation, toggleClass, getActualHeight, getActualWidth */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stopPropagation", function() { return stopPropagation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toggleClass", function() { return toggleClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActualHeight", function() { return getActualHeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActualWidth", function() { return getActualWidth; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Stop propagation event listener
function stopPropagation(e) {
    e.stopPropagation();
}

// Toggle a class of an element
function toggleClass(element, c) {
    if (element.classList.contains(c)) {
        element.classList.remove(c);
    } else {
        element.classList.add(c);
    }
}

// Get actual height of an element
function getActualHeight(element) {
    let styles = window.getComputedStyle(element);
    let margin = parseFloat(styles['marginTop']) +
               parseFloat(styles['marginBottom']);
    return element.offsetHeight + margin;
}

// Get actual width of an element
function getActualWidth(element) {
    let styles = window.getComputedStyle(element);
    let margin = parseFloat(styles['marginLeft']) +
               parseFloat(styles['marginRight']);
    return element.offsetWidth + margin;
}

// getElementByClassName
Element.prototype.getElementByClassName = function (classNames) {
    return this.getElementsByClassName(classNames)[0] || null;
};


/***/ }),

/***/ "./src/popup/event-listeners/document.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/document.js ***!
  \***********************************************/
/*! exports provided: documentMouseOver, documentMouseUp, documentClicked, documentKeyPressed */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentMouseOver", function() { return documentMouseOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentMouseUp", function() { return documentMouseUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentClicked", function() { return documentClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentKeyPressed", function() { return documentKeyPressed; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");




function documentMouseOver(e) {
    e.preventDefault();
}

function documentMouseUp(e) {
    if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding) Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["resetSlideSelection"])();
}

function documentClicked(e) {
    if (e.button === 0) {
        if (e.target.id === "details-close") {
            document.getElementById("details-placeholder").style.display = "inline-block";
            document.getElementById("tab-details").style.display = "none";
            browser.tabs.remove(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(document.getElementById("tab-details")));
        } else { // Note: May cause some problems
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting) Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["multiSelectReset"])();
        }
    }
}

function isInlinePrintableKey(e) {
    if (typeof e.which === "undefined") {
        return true;
    } else if (typeof e.which === "number" && e.which > 0) {
        return !e.ctrlKey && !e.metaKey && !e.altKey && e.which !== 8 && e.which !== 13;
    }
}

function documentKeyPressed(e) {
    if (isInlinePrintableKey(e)) {
        document.getElementById("search").focus();
    } else if (e.key === "Enter") {
        if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].selectedTabs === 1) {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["selectTabEntry"])(document.getElementsByClassName("multiselect")[0]);
        }
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/message.js":
/*!**********************************************!*\
  !*** ./src/popup/event-listeners/message.js ***!
  \**********************************************/
/*! exports provided: onMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMessage", function() { return onMessage; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../domutils */ "./src/popup/domutils.js");
/* harmony import */ var _net__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../net */ "./src/popup/net.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");





function onMessage(request, sender) {
    switch (request.type) {
        case "ACTIVE_TAB_CHANGED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["setActiveTab"])(request.details.windowId, request.details.tabId);
            break;
        case "TAB_FAV_ICON_CHANGED":
            browser.tabs.get(request.details.tabId).then(tab => {
                let favIconPromise;
                if (tab.incognito) {
                    favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(request.details.favIconUrl, true);
                } else {
                    favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(request.details.favIconUrl);
                }
                favIconPromise.then(function (base64Image){
                    Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getFavIconFromTabEntry"])(Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId)).src = base64Image;
                });
            });
            break;
        case "TAB_PINNED_STATUS_CHANGED":
            let tabEntry = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId);
            let pinBtn = tabEntry.getElementByClassName("tab-entry-pin-btn");
            let windowEntryList = tabEntry.parentElement;
            let pinnedTabs;
            if (request.details.pinned) {
                pinnedTabs = Array.from(windowEntryList.getElementsByClassName("pinned-tab"));
                tabEntry.classList.add("pinned-tab");
                pinBtn.style.backgroundImage = "url(../icons/pinremove.svg)";
            } else {
                pinnedTabs = Array.from(windowEntryList.getElementsByClassName("pinned-tab"));
                tabEntry.classList.remove("pinned-tab");
                pinBtn.style.backgroundImage = "url(../icons/pin.svg)";
            }
            let lastPinnedTab = pinnedTabs[pinnedTabs.length-1];
            if (lastPinnedTab !== undefined) {
                windowEntryList.insertBefore(tabEntry, lastPinnedTab.nextSibling);
            } else {
                windowEntryList.insertBefore(tabEntry, windowEntryList.childNodes[0]);
            }
            break;
        case "TAB_TITLE_CHANGED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["findTabEntryById"])(request.details.tabId).getElementByClassName("tab-title").textContent = request.details.title;
            break;
        case "TAB_REMOVED":
            if (!request.details.windowClosing) {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["removeTab"])(request.details.tabId, request.details.windowId);
            }
            break;
        case "WINDOW_REMOVED":
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["removeWindow"])(request.details.windowId);
            break;
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/recorder.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/recorder.js ***!
  \***********************************************/
/*! exports provided: saveForLater, restore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveForLater", function() { return saveForLater; });
/* harmony import */ var _recorder__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../recorder */ "./src/popup/recorder.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "restore", function() { return _recorder__WEBPACK_IMPORTED_MODULE_0__["restore"]; });



let saveForLaterBtn = document.getElementById("save-for-later");
let sflTimeout = () => {
    saveForLaterBtn.removeAttribute("done");
};
function saveForLater() {
    saveForLaterBtn.setAttribute("disabled", "");
    Object(_recorder__WEBPACK_IMPORTED_MODULE_0__["record"])().then(() => {
        saveForLaterBtn.removeAttribute("disabled");
        saveForLaterBtn.setAttribute("done", "");
        clearTimeout(sflTimeout); setTimeout(sflTimeout, 2000);
    });
}




/***/ }),

/***/ "./src/popup/event-listeners/search.js":
/*!*********************************************!*\
  !*** ./src/popup/event-listeners/search.js ***!
  \*********************************************/
/*! exports provided: initSearch, searchTextChanged */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initSearch", function() { return initSearch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchTextChanged", function() { return searchTextChanged; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../domutils */ "./src/popup/domutils.js");





// Init
function initSearch() {
    document.getElementById("search").addEventListener("keypress", _domutils__WEBPACK_IMPORTED_MODULE_3__["stopPropagation"]);
}

function keywordSearch(s, key) {
    let keywords = key.trim().split(" "), count = 0;
    for (let i = 0; i < keywords.length; i++) {
        let word = keywords[i];
        if (word.trim() !== "" && word.match(/^[a-zA-Z0-9]+$/)) {
            if (s.toUpperCase().includes(word.toUpperCase())) {
                count++;
            }
        }
    }
    return count >= 2;
}

function search(s, key) {
    return s.toUpperCase().includes(key.toUpperCase()) || keywordSearch(s, key);
}

// Search
async function searchTextChanged(e) {
    let input, filter, tabEntries;
    input = document.getElementById("search");
    filter = input.value;
    tabEntries = document.getElementsByClassName("tab-entry");
    if (filter !== "") {
        for (let i = 0; i < tabEntries.length; i++) {
            let tabEntry = tabEntries[i];
            if (!search(tabEntry.getElementByClassName("tab-title").innerText, filter) &&
                !(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].searchInURLs && search((await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry))).url, filter))) {
                tabEntry.style.display = "none";
            } else {
                tabEntry.style.display = "flex";
            }
        }
    } else {
        for (let i = 0; i < tabEntries.length; i++) {
            let tabEntry = tabEntries[i];
            tabEntry.style.display = "flex";
        }
    }
}


/***/ }),

/***/ "./src/popup/event-listeners/tabEntry.js":
/*!***********************************************!*\
  !*** ./src/popup/event-listeners/tabEntry.js ***!
  \***********************************************/
/*! exports provided: tabEntryMouseOver, tabEntryMouseLeave, tabEntryClicked, tabCloseClick, tabPinClick */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryMouseOver", function() { return tabEntryMouseOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryMouseLeave", function() { return tabEntryMouseLeave; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryClicked", function() { return tabEntryClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabCloseClick", function() { return tabCloseClick; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabPinClick", function() { return tabPinClick; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _keyutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../keyutils */ "./src/popup/keyutils.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtutils */ "./src/popup/wtutils.js");
/* harmony import */ var _captureTab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../captureTab */ "./src/popup/captureTab.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");







function tabEntryMouseOver(e) {
    e.target.getElementByClassName("tab-entry-pin-btn").style.display = "inline-block";
    if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])() && _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding) {
        if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator !== e.target) {
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator.classList.contains("multiselect")) {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelect"])(e.target);
            } else {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelectCancel"])(e.target);
            }
        }
    } else {
        let tabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getTabId"])(e.target);
        _captureTab__WEBPACK_IMPORTED_MODULE_4__["captureTab"](tabId).then(dataUri => {
            if (dataUri !== null) {
                let detailsImage = document.getElementById("details-img");
                detailsImage.src = dataUri;
            }
            let detailsTitle = document.getElementById("details-title");
            let detailsURL = document.getElementById("details-url");
            browser.tabs.get(tabId).then(tab => {
                detailsTitle.textContent = tab.title;
                detailsURL.textContent = tab.url;
                document.getElementById("details-placeholder").style.display = "none";
                document.getElementById("tab-details").style.display = "inline-block";
                document.getElementById("tab-details").setAttribute("data-tab_id", tabId);
                if (tab.pinned) {
                    document.getElementById("details-pinned").style.display = "inline";
                } else {
                    document.getElementById("details-pinned").style.display = "none";
                }
                if (tab.hidden) {
                    document.getElementById("details-hidden").style.display = "inline";
                } else {
                    document.getElementById("details-hidden").style.display = "none";
                }
                if (tab.pinned && tab.hidden) {
                    document.getElementById("details-comma").style.display = "inline";
                } else {
                    document.getElementById("details-comma").style.display = "none";
                }
            });
        });
    }
    e.preventDefault();
}

function tabEntryMouseLeave(e) {
    e.target.getElementByClassName("tab-entry-pin-btn").style.display = "none";
}

function tabEntryClicked(e) {
    if (e.button === 0) {
        if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])()) {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["multiSelectToggle"])(e.target);
            e.stopPropagation();
        } else {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["selectTabEntry"])(e.target);
        }
    }
}

function tabCloseClick(e) {
    e.stopPropagation();
    let tabId = e.target.parentElement.parentElement.getAttribute("data-tab_id");
    let tabDetails = document.getElementById("tab-details");
    if (tabDetails.getAttribute("data-tab_id") === tabId) {
        tabDetails.style.display = "none";
        document.getElementById("details-placeholder").style.display = "inline-block";
    }
    browser.tabs.remove(parseInt(tabId));
}

function tabPinClick(e) {
    e.stopPropagation();
    let tabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_5__["getTabId"])(e.target.parentElement.parentElement);
    browser.tabs.get(tabId).then(tab => {
        if (tab.pinned) {
            browser.tabs.update(tab.id, {
                pinned: false
            });
        } else {
            browser.tabs.update(tab.id, {
                pinned: true
            });
        }
    });
}


/***/ }),

/***/ "./src/popup/event-listeners/windowEntry.js":
/*!**************************************************!*\
  !*** ./src/popup/event-listeners/windowEntry.js ***!
  \**************************************************/
/*! exports provided: windowEntryDragStarted, windowEntryDraggingOver, windowEntryDropped, windowEntryTitleClicked, windowCloseClick */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDragStarted", function() { return windowEntryDragStarted; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDraggingOver", function() { return windowEntryDraggingOver; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryDropped", function() { return windowEntryDropped; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowEntryTitleClicked", function() { return windowEntryTitleClicked; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "windowCloseClick", function() { return windowCloseClick; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../globals */ "./src/popup/globals.js");
/* harmony import */ var _keyutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../keyutils */ "./src/popup/keyutils.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../wtdom */ "./src/popup/wtdom.js");





let multiDragging = false, sourceTab, targetTab, under, sourceWindow, sourceWindowId;

function getMultiDragImage(target, clientX, clientY) {
    let dragImage = document.createElement("div"), x, y;
    let selectedItems = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getSelectedItems"])();
    if (selectedItems.length === 1) return selectedItems[i];
    for (let i = 0; i < selectedItems.length - 1; i++) {
        let ref1 = selectedItems[i], ref2 = selectedItems[i+1];
        let ref1br = ref1.getBoundingClientRect(), ref2br = ref2.getBoundingClientRect();
        let distance = ref2br.top - (ref1br.top + ref1br.height);
        let ref1Clone = ref1.cloneNode(true);
        ref1Clone.style.marginBottom = distance + "px";
        dragImage.appendChild(ref1Clone);
    } dragImage.appendChild(selectedItems[selectedItems.length - 1].cloneNode(true));
    dragImage.style.width = selectedItems[0].getBoundingClientRect().width + "px";
    document.body.appendChild(dragImage);
    return {
        image: dragImage,
        x: 0,
        y: 0
    };
}

function windowEntryDragStarted(e) {
    if (e.target.classList.contains("tab-entry")) {
        if (Object(_keyutils__WEBPACK_IMPORTED_MODULE_2__["ctrlOrCmd"])()) {
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["multiSelectToggle"])(e.target);
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding = true;
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator = e.target;
            e.preventDefault();
        } else {
            sourceTab = e.target;
            sourceWindow = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(sourceTab);
            sourceWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(sourceWindow);
            e.dataTransfer.effectAllowed = "move";
            if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting && Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["multiSelected"])(e.target)) {
                multiDragging = true;
                let dragImage = getMultiDragImage();
                e.dataTransfer.setDragImage(dragImage.image, dragImage.x, dragImage.y);
            }
        }
        e.dataTransfer.setData('text/plain', null);
    }
}

function windowEntryDraggingOver(e) {
    e.preventDefault();
    let cursors = Array.from(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("insert-cursor"));
    for (let i = 0; i < cursors.length; i++) {
        let c = cursors[i];
        c.parentElement.removeChild(c);
    }
    let cursorWindow = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementByClassName("insert-cursor-window");
    if (cursorWindow !== null) {
        cursorWindow.classList.remove("insert-cursor-window");
    }

    let windowEntry;
    if (e.target.classList.contains("tab-entry")) {
        let tabEntryBoundingClientRect = e.target.getBoundingClientRect();
        targetTab = e.target;
        under = false;
        if ((e.clientY - tabEntryBoundingClientRect.top) >= tabEntryBoundingClientRect.height / 2) {
            targetTab = targetTab.nextSibling;
            if (targetTab === null) {
                under = true;
                targetTab = e.target;
            }
        }
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggable"])(sourceTab, targetTab, under, sourceWindow, multiDragging)) {
            let cursor = document.createElement("div");
            cursor.classList.add("insert-cursor");
            if (under) {
                targetTab.parentElement.appendChild(cursor);
            } else {
                targetTab.parentElement.insertBefore(cursor, targetTab);
            }
        }
    } else if ((windowEntry = e.target.parentElement) !== null && windowEntry.classList.contains("window-entry")) {
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggableToWindow"])(sourceTab, windowEntry, sourceWindow)) {
            e.target.classList.add("insert-cursor-window");
        }
    }
}

function windowEntryDropped(e) {
    e.preventDefault();
    e.stopPropagation();
    let cursors = Array.from(_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("insert-cursor"));
    for (let i = 0; i < cursors.length; i++) {
        let cursor = cursors[i];
        cursor.parentElement.removeChild(cursor);
    }
    let cursorWindow = _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementByClassName("insert-cursor-window");
    if (cursorWindow !== null) {
        cursorWindow.classList.remove("insert-cursor-window");
    }
    
    let windowEntry;
    if (e.target.classList.contains("tab-entry")) {
        if (!e.target.isSameNode(targetTab)) {
            let tabEntryBoundingClientRect = e.target.getBoundingClientRect();
            targetTab = e.target;
            under = false;
            if ((e.clientY - tabEntryBoundingClientRect.top) >= tabEntryBoundingClientRect.height / 2) {
                targetTab = targetTab.nextSibling;
                if (targetTab === null) {
                    under = true;
                    targetTab = e.target;
                }
            }
        }
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggable"])(sourceTab, targetTab, under, sourceWindow, multiDragging)) {
            let destinationWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(targetTab));
            let sourceTabIndex = Array.prototype.indexOf.call(targetTab.parentElement.childNodes, sourceTab);
            let destinationIndex = Array.prototype.indexOf.call(targetTab.parentElement.childNodes, targetTab);
            let moveIndex = under ? -1 : ((sourceTabIndex !== -1 && destinationIndex > sourceTabIndex && destinationWindowId === sourceWindowId) ? destinationIndex-1 : destinationIndex);
            let sourceTabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getTabId"])(sourceTab);
            browser.tabs.move(sourceTabId, {
                windowId: destinationWindowId,
                index: moveIndex
            });
            if (under) {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["attachTab"])(sourceTab, Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowFromTab"])(targetTab));
            } else {
                Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["moveTab"])(sourceTab, targetTab);
            }
        }
    } else if ((windowEntry = e.target.parentElement) !== null && windowEntry.classList.contains("window-entry")) {
        if (Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["tabDraggableToWindow"])(sourceTab, windowEntry, sourceWindow)) {
            let sourceTabId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getTabId"])(sourceTab);
            let destinationWindowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(windowEntry);
            browser.tabs.move(sourceTabId, {
                windowId: destinationWindowId,
                index: -1
            });
            Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["attachTab"])(sourceTab, windowEntry);
        }
    }
}

function windowEntryTitleClicked(e) {
    let windowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(e.target.parentElement);
    browser.windows.update(windowId, {
        focused: true
    });
}

function windowCloseClick(e) {
    let windowId = Object(_wtdom__WEBPACK_IMPORTED_MODULE_3__["getWindowId"])(e.target.parentElement.parentElement.parentElement);
    browser.windows.remove(windowId);
}


/***/ }),

/***/ "./src/popup/globals.js":
/*!******************************!*\
  !*** ./src/popup/globals.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


const globals = {
    tabsList: undefined,
    isSelecting: false,
    selectedTabs: 0,
    slideSelection: {
        sliding: false,
        initiator: undefined,
        vector: 0
    },
    hideAfterTabSelection: undefined,
    searchInURLs: undefined
};
/* harmony default export */ __webpack_exports__["default"] = (globals);


/***/ }),

/***/ "./src/popup/keyutils.js":
/*!*******************************!*\
  !*** ./src/popup/keyutils.js ***!
  \*******************************/
/*! exports provided: KeyTracker, Keys, ctrlOrCmd */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyTracker", function() { return KeyTracker; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Keys", function() { return Keys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ctrlOrCmd", function() { return ctrlOrCmd; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Key tracker
function KeyTracker() {
    this.keys = {};
    window.addEventListener("keydown", e => {
        this.keys[e.code] = true;
    });
    window.addEventListener("keyup", e => {
        this.keys[e.code] = false;
    });
}
KeyTracker.prototype.pressed = function (code) {
    return Boolean(this.keys[code]);
};
KeyTracker.prototype.ctrl = function () {
    return this.pressed("ControlLeft") || this.pressed("ControlRight");
};
KeyTracker.prototype.cmd = function () {
    return this.pressed("OSRight") || this.pressed("OSLeft");
};
KeyTracker.prototype.ctrlOrCmd = function () {
    if (window.navigator.platform.toUpperCase().indexOf("MAC") >= 0) {
        return this.cmd();
    }
    return this.ctrl();
};
KeyTracker.prototype.shift = function () {
    return this.pressed("ShiftLeft") || this.pressed("ShiftRight");
};
let Keys = new KeyTracker();

// Checks if either Ctrl(Windows & Linux) or Command(Mac) is pressed
function ctrlOrCmd() {
    return Keys.ctrlOrCmd();
}


/***/ }),

/***/ "./src/popup/messaging.js":
/*!********************************!*\
  !*** ./src/popup/messaging.js ***!
  \********************************/
/*! exports provided: sendRuntimeMessage, sendTabMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendRuntimeMessage", function() { return sendRuntimeMessage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendTabMessage", function() { return sendTabMessage; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Function to send a message to the runtime
function sendRuntimeMessage(type, data) {
    return browser.runtime.sendMessage({
        type: type,
        data: data
    });
}

// Function to send a message to a tab
function sendTabMessage(tabId, target, data) {
    return browser.tabs.sendMessage(tabId, {
        target: target,
        data: data
    });
}


/***/ }),

/***/ "./src/popup/net.js":
/*!**************************!*\
  !*** ./src/popup/net.js ***!
  \**************************/
/*! exports provided: getImage, arrayBufferToBase64 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getImage", function() { return getImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "arrayBufferToBase64", function() { return arrayBufferToBase64; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Function to get image from URL
function getImage(url, noCache=false) {
    return new Promise((resolve, reject) => {
        try {
            if (!url.startsWith("chrome://")) {
                let xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function(){
                    if (this.readyState == 4 && this.status == 200) {
                        let contentType = xhr.getResponseHeader("Content-Type").trim();
                        if (contentType.startsWith("image/")) {
                            let flag = "data:" + contentType + ";charset=utf-8;base64,";
                            let imageStr = arrayBufferToBase64(xhr.response);
                            resolve(flag + imageStr);
                        } else {
                            reject("Image Request Failed: Content-Type is not an image! (Content-Type: \"" + contentType + "\")");
                        }
                    }
                };
                xhr.responseType = "arraybuffer";
                xhr.open("GET", url, true);
                if (noCache) { xhr.setRequestHeader("Cache-Control", "no-store"); }
                xhr.send();
            } else {
                resolve();
            }
        } catch (err) {
            reject(err.message);
        }
    });
}

// Function to transform ArrayBuffer into a Base64 String
function arrayBufferToBase64(buffer) {
    let binary = "";
    let bytes = [].slice.call(new Uint8Array(buffer));
    bytes.forEach((b) => binary += String.fromCharCode(b));
    return window.btoa(binary);
}


/***/ }),

/***/ "./src/popup/popup.js":
/*!****************************!*\
  !*** ./src/popup/popup.js ***!
  \****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");
/* harmony import */ var _wtinit__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wtinit */ "./src/popup/wtinit.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./domutils */ "./src/popup/domutils.js");
/* harmony import */ var _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./event-listeners/document */ "./src/popup/event-listeners/document.js");
/* harmony import */ var _event_listeners_search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-listeners/search */ "./src/popup/event-listeners/search.js");
/* harmony import */ var _event_listeners_message__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./event-listeners/message */ "./src/popup/event-listeners/message.js");
/* harmony import */ var _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./event-listeners/recorder */ "./src/popup/event-listeners/recorder.js");
/* harmony import */ var _captureTab__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./captureTab */ "./src/popup/captureTab.js");
/* harmony import */ var _options__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../options */ "./src/options.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./wtdom */ "./src/popup/wtdom.js");
/* harmony import */ var _recorder__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./recorder */ "./src/popup/recorder.js");














_globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList = document.getElementById("tabs-list");

function setPopupSize(width, height) {
    document.documentElement.style.width = width + "px";
    document.documentElement.style.height = height + "px";
    document.body.style.width = width + "px";
    document.body.style.height = height + "px";
}

async function fulfillOptions() {
    let popupOptions = (await _options__WEBPACK_IMPORTED_MODULE_10__["options"]()).popup;
    // popup.size
    setPopupSize(popupOptions.size.width, popupOptions.size.height);
    // popup.scale
    document.documentElement.style.setProperty('--scale', popupOptions.scale.toString());
    // popup.showDetails
    if (!_options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.showDetails)) {
        let leftContainer = document.getElementById("left-container");
        popupOptions.size.width = popupOptions.size.width - Object(_domutils__WEBPACK_IMPORTED_MODULE_4__["getActualWidth"])(leftContainer);
        setPopupSize(popupOptions.size.width, popupOptions.size.height);
        leftContainer.style.display = "none";
        document.getElementById("tabs-container").style.width = "100%";
    } else {
        // popup.showPreview
        if (!_options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.showPreview)) Object(_wtdom__WEBPACK_IMPORTED_MODULE_11__["hideTabPreview"])();
    }
    // popup.hideAfterTabSelection
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].hideAfterTabSelection = _options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.hideAfterTabSelection);
    // popup.searchInURLs
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].searchInURLs = _options__WEBPACK_IMPORTED_MODULE_10__["stbool"](popupOptions.searchInURLs);
}

async function main() {
    // Initialize captureTab based on environment
    _captureTab__WEBPACK_IMPORTED_MODULE_9__["init"]();
    // Fulfill user options
    await fulfillOptions();
    // Make tabs list fit the panel
    Object(_wtinit__WEBPACK_IMPORTED_MODULE_3__["extendTabsList"])();
    // Fix for cross-window dragging issue
    await Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_2__["getWrongToRight"])();
    // Populate tabs list with tabs
    await Object(_wtinit__WEBPACK_IMPORTED_MODULE_3__["populateTabsList"])();
    // Update recorder tooltip
    await Object(_recorder__WEBPACK_IMPORTED_MODULE_12__["updateRecorderToolTip"])();
    // Initialize components
    Object(_event_listeners_search__WEBPACK_IMPORTED_MODULE_6__["initSearch"])();
}

/* Add event listeners */

// Starting point
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
} else {
    main();
}

document.addEventListener("mouseover", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentMouseOver"]);
document.addEventListener("mouseup", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentMouseUp"]);
document.addEventListener("click", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentClicked"]);
document.addEventListener("keypress", _event_listeners_document__WEBPACK_IMPORTED_MODULE_5__["documentKeyPressed"]);

// Add keyup event listener and put focus on search
let search = document.getElementById("search");
search.addEventListener("keyup", _event_listeners_search__WEBPACK_IMPORTED_MODULE_6__["searchTextChanged"]);
search.focus();

// Add event listeners to all copy buttons
let copyButtons = Array.from(document.getElementsByClassName("copy-button"));
for (let i = 0; i < copyButtons.length; i++) {
    copyButtons[i].addEventListener("click", e => {
        document.oncopy = ce => {
            ce.clipboardData.setData("text", document.getElementById(e.target.getAttribute("for")).innerText);
            ce.preventDefault();
        };
        document.execCommand("copy", false, null);
        e.target.innerText = "Copied!";
        setTimeout(() => {
            e.target.innerText = "Copy";
        }, 2000);
    });
}

// Add event listener for recorder.js
document.getElementById("save-for-later").addEventListener("click", _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__["saveForLater"]);
document.getElementById("restore-now").addEventListener("click", _event_listeners_recorder__WEBPACK_IMPORTED_MODULE_8__["restore"]);

// Add event listener to listen for any messages from background.js
if (!browser.runtime.onMessage.hasListener(_event_listeners_message__WEBPACK_IMPORTED_MODULE_7__["onMessage"])) {
    browser.runtime.onMessage.addListener(_event_listeners_message__WEBPACK_IMPORTED_MODULE_7__["onMessage"]);
}


/***/ }),

/***/ "./src/popup/recorder.js":
/*!*******************************!*\
  !*** ./src/popup/recorder.js ***!
  \*******************************/
/*! exports provided: lastRecord, updateRecorderToolTip, record, restore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lastRecord", function() { return lastRecord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateRecorderToolTip", function() { return updateRecorderToolTip; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "record", function() { return record; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "restore", function() { return restore; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wtdom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wtdom */ "./src/popup/wtdom.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wtutils */ "./src/popup/wtutils.js");





async function lastRecord() {
    return browser.storage.sync.get(["record"]).then(data => data.record);
}

async function updateRecorderToolTip() {
    let r = await lastRecord();
    let restoreBtn = document.getElementById("restore-now");
    if (r) {
        restoreBtn.setAttribute("title", "Restore websites that have been saved on " + (new Date(r.timestamp)).toLocaleString());
        restoreBtn.removeAttribute("disabled");
    } else {
        restoreBtn.setAttribute("title", "Restore websites that have been saved");
        restoreBtn.setAttribute("disabled", "");
    }
}

function tabInfoToRecord(info) {
    return {
        url: info.url,
        pinned: info.pinned
    };
}
async function record() {
    let recordArray = [];
    for (let windowEntry of _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.getElementsByClassName("window-entry")) {
        let windowRecord = [];
        for (let tabEntry of windowEntry.getElementsByClassName("tab-entry")) {
            await browser.tabs.sendMessage(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry), { target: "packd", data: { action: "pack" } }).then(async pack => {
                windowRecord.push(Object.assign({
                    pack: pack
                }, tabInfoToRecord(await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry)))));
            }).catch(async reason => {
                windowRecord.push(Object.assign({
                    pack: undefined
                }, tabInfoToRecord(await browser.tabs.get(Object(_wtdom__WEBPACK_IMPORTED_MODULE_2__["getTabId"])(tabEntry)))));
            });
        }
        recordArray.push(windowRecord);
    }
    let record = {
        timestamp: Date.now(),
        record: recordArray
    };
    return browser.storage.sync.set({ record: record }).then(() => updateRecorderToolTip());
}

async function restore() {
    let { record: r } = await lastRecord();
    for (let windowRecord of r) {
        if (browser.runtime.getBrowserInfo) {
            windowRecord = windowRecord.filter(tabRecord => !tabRecord.url.startsWith("about:"))
        }
        browser.windows.create({
            url: windowRecord.map(tabRecord => tabRecord.url)
        }).then(async w => {
            for (let i = 0; i < windowRecord.length; i++) {
                let tabRecord = windowRecord[i];
                await browser.tabs.update(w.tabs[i].id, {
                    pinned: tabRecord.pinned
                }).then(t => {
                    if (tabRecord.pack) {
                        Object(_wtutils__WEBPACK_IMPORTED_MODULE_3__["runAfterTabLoad"])(t.id, () => {
                            browser.tabs.sendMessage(t.id, {
                                target: "packd",
                                data: Object.assign({action: "unpack"}, tabRecord.pack)
                            });
                        });
                    }
                }).catch(e => {
                    console.log(e);
                });
            }
        });
    }
}


/***/ }),

/***/ "./src/popup/wrong-to-right.js":
/*!*************************************!*\
  !*** ./src/popup/wrong-to-right.js ***!
  \*************************************/
/*! exports provided: getWrongToRight, getCorrectTabId */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWrongToRight", function() { return getWrongToRight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCorrectTabId", function() { return getCorrectTabId; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _messaging__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./messaging */ "./src/popup/messaging.js");



let wrongToRight;

function getWrongToRight() {
    return Object(_messaging__WEBPACK_IMPORTED_MODULE_1__["sendRuntimeMessage"])("WRONG_TO_RIGHT_GET", {}).then(response => {
        wrongToRight = response.wrongToRight;
    });
}

// Function to get correct tab id
function getCorrectTabId(tabId) {
    return wrongToRight[tabId] || tabId;
}


/***/ }),

/***/ "./src/popup/wtdom.js":
/*!****************************!*\
  !*** ./src/popup/wtdom.js ***!
  \****************************/
/*! exports provided: selectTabEntry, hideTabPreview, getTabByTabEntry, getTabId, getWindowId, findTabEntryById, findCorrectTabEntryById, getFavIconFromTabEntry, findWindowEntryById, findTabEntryInWindow, getActiveTab, setActiveTab, removeTab, moveTab, moveTabs, attachTab, attachTabs, removeWindow, getWindowFromTab, getTabEntriesFromWindow, tabDraggable, tabDraggableToWindow, tabEntryIndex, getNextTabEntry, getLastTabEntry, getSelectedItems, multiSelected, multiSelect, multiSelectCancel, multiSelectReset, multiSelectToggle, resetSlideSelection */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectTabEntry", function() { return selectTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hideTabPreview", function() { return hideTabPreview; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabByTabEntry", function() { return getTabByTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabId", function() { return getTabId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindowId", function() { return getWindowId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findTabEntryById", function() { return findTabEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findCorrectTabEntryById", function() { return findCorrectTabEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFavIconFromTabEntry", function() { return getFavIconFromTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findWindowEntryById", function() { return findWindowEntryById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findTabEntryInWindow", function() { return findTabEntryInWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActiveTab", function() { return getActiveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setActiveTab", function() { return setActiveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeTab", function() { return removeTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveTab", function() { return moveTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moveTabs", function() { return moveTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachTab", function() { return attachTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachTabs", function() { return attachTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeWindow", function() { return removeWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindowFromTab", function() { return getWindowFromTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabEntriesFromWindow", function() { return getTabEntriesFromWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabDraggable", function() { return tabDraggable; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabDraggableToWindow", function() { return tabDraggableToWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tabEntryIndex", function() { return tabEntryIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNextTabEntry", function() { return getNextTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastTabEntry", function() { return getLastTabEntry; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectedItems", function() { return getSelectedItems; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelected", function() { return multiSelected; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelect", function() { return multiSelect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectCancel", function() { return multiSelectCancel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectReset", function() { return multiSelectReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "multiSelectToggle", function() { return multiSelectToggle; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetSlideSelection", function() { return resetSlideSelection; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wtutils */ "./src/popup/wtutils.js");





// Select tab and go to it
function selectTabEntry(tabEntry) {
    let tabId = getTabId(tabEntry);
    let parentWindowId = getWindowId(getWindowFromTab(tabEntry));
    browser.tabs.update(tabId, {
        active: true
    });
    browser.windows.get(parentWindowId).then(w => {
        Object(_wtutils__WEBPACK_IMPORTED_MODULE_3__["getLastFocusedWindow"])().then(cw => {
            if (w.id !== cw.id) {
                browser.windows.update(w.id, {
                    focused: true
                });
            } else {
                if (_globals__WEBPACK_IMPORTED_MODULE_1__["default"].hideAfterTabSelection) window.close();
            }
        });
    });
}

// Hides the tab preview
function hideTabPreview() {
    document.getElementById("details-img").style.display = "none";
}

// Get a tab by a tab entry
function getTabByTabEntry(entry) {
    return browser.tabs.get(getTabId(entry));
}

// Get the TabId of a tab entry
function getTabId(entry) {
    return parseInt(entry.getAttribute("data-tab_id"));
}

// Get the WindowId of a window entry
function getWindowId(entry) {
    return parseInt(entry.getAttribute("data-window_id"));
}

// Find tab entry by tab id
function findTabEntryById(tabId) {
    return document.querySelector(".tab-entry[data-tab_id=\"" + tabId + "\"]");
}

// Find correct tab entry by tab id
function findCorrectTabEntryById(tabId) {
    return findTabEntryById(Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_2__["getCorrectTabId"])(tabId));
}

// Get favicon from a tab entry
function getFavIconFromTabEntry(entry) {
    return entry.getElementByClassName("tab-entry-favicon");
}

// Find window entry by tab id
function findWindowEntryById(windowId) {
    return _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.querySelector("li[data-window_id=\"" + windowId + "\"]");
}

// Find tab entry inside a window entry
function findTabEntryInWindow(windowEntry, tabId) {
    return windowEntry.querySelector("li[data-tab_id=\"" + tabId + "\"]");
}

// Get active tab in the specified window
function getActiveTab(windowId) {
    let window = findWindowEntryById(windowId);
    return window.getElementByClassName("current-tab");
}

// Set active tab in the specified window
function setActiveTab(windowId, tabId) {
    let window = findWindowEntryById(windowId), lastActiveTab;
    if ((lastActiveTab = getActiveTab(windowId)) !== null) {
        lastActiveTab.classList.remove("current-tab");
    }
    findTabEntryInWindow(window, tabId).classList.add("current-tab");
}

// Remove tab
function removeTab(tabId, windowId) {
    let tabEntry = findTabEntryById(tabId);
    tabEntry.parentElement.removeChild(tabEntry);
    browser.tabs.query({
        active: true,
        windowId: windowId
    }).then(tabs => {
        findCorrectTabEntryById(tabs[0].id).classList.add("current-tab");
    });
}

// Move tab
function moveTab(target, dest) {
    getWindowFromTab(dest).getElementByClassName("window-entry-tabs").insertBefore(target, dest);
}

// Move tabs
function moveTabs(targets, dest) {
    for (let i = 0; i < targets.length; i++) moveTab(targets[i], dest);
}

// Attach tab
function attachTab(target, dest) {
    dest.getElementByClassName("window-entry-tabs").appendChild(target);
}

// Attach tabs
function attachTabs(targets, dest) {
    for (let i = 0; i < targets.length; i++) attachTab(targets[i], dest);
}

// Remove window
function removeWindow(windowId) {
    let windowEntry = findWindowEntryById(windowId);
    windowEntry.parentElement.removeChild(windowEntry);
    browser.windows.getCurrent({}).then(window => {
        findWindowEntryById(window.id).classList.add("current-window");
    });
}

function getWindowFromTab(tab) {
    return tab.parentElement.parentElement;
}
function getTabEntriesFromWindow(windowEntry) {
    return Array.from(windowEntry.getElementsByClassName("tab-entry"));
}

// Test if tab is draggable
function tabDraggable(sourceTab, targetTab, under, sourceWindow, multiDragging) {
    return !sourceTab.isSameNode(targetTab)
            && (!multiDragging || (multiSelected(sourceTab) && multiSelected(targetTab)))
            && ((!sourceTab.classList.contains("pinned-tab") && !targetTab.classList.contains("pinned-tab"))
                || (sourceTab.classList.contains("pinned-tab") && targetTab.classList.contains("pinned-tab"))
                || (under && !sourceTab.classList.contains("pinned-tab")))
            && ((!sourceWindow.classList.contains("incognito-window") && !getWindowFromTab(targetTab).classList.contains("incognito-window"))
                || (sourceWindow.classList.contains("incognito-window") && getWindowFromTab(targetTab).classList.contains("incognito-window")));
}

// Test if tab is draggable to window
function tabDraggableToWindow(sourceTab, targetWindow, sourceWindow) {
    return !sourceWindow.isSameNode(targetWindow)
            && !sourceTab.classList.contains("pinned-tab")
            && ((!sourceWindow.classList.contains("incognito-window") && !targetWindow.classList.contains("incognito-window"))
                || (sourceWindow.classList.contains("incognito-window") && targetWindow.classList.contains("incognito-window")));
}

// Returns the index of a tab entry
function tabEntryIndex(tabEntry) {
    let tabs = Array.from(document.getElementsByClassName("tab-entry"));
    for (let i = 0; i < tabs.length; i++) {
        if (tabs[i] === tabEntry) {
            return i;
        }
    }
    return -1;
}

// Get next tab
function getNextTabEntry(tabEntry) {
    if (tabEntry.nextElementSibling !== null) {
        return tabEntry.nextElementSibling;
    } else if (getWindowFromTab(tabEntry).nextElementSibling !== null) {
        return getTabEntriesFromWindow(getWindowFromTab(tabEntry).nextElementSibling)[0];
    } else {
        return null;
    }
}
// Get last tab
function getLastTabEntry(tabEntry) {
    if (tabEntry.previousElementSibling !== null) {
        return tabEntry.previousElementSibling;
    } else if (getWindowFromTab(tabEntry).previousElementSibling !== null) {
        return getTabEntriesFromWindow(getWindowFromTab(tabEntry).previousElementSibling)[0];
    } else {
        return null;
    }
}

/* Multiselect */
// On multiselect start
function onMultiselectStart() {

}
// On multiselect change
function onMultiselectChange() {

}
// On multiselect end
function onMultiselectEnd() {

}
// Get Selected Items
function getSelectedItems() {
    return Array.from(document.getElementsByClassName("multiselect"));
}
// Multiselected
function multiSelected(element) {
    return element.classList.contains("multiselect");
}
// Select
function multiSelect(element) {
    if (!element.classList.contains("multiselect")) {
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].selectedTabs++;
        _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = true;
        element.classList.add("multiselect");
    }
}
// Cancel Selection
function multiSelectCancel(element) {
    if (element.classList.contains("multiselect")) {
        if (--_globals__WEBPACK_IMPORTED_MODULE_1__["default"].selectedTabs == 0) {
            _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = false;
        }
        element.classList.remove("multiselect");
    }
}
// Reset multiselect
function multiSelectReset() {
    for (let element of Array.from(document.getElementsByClassName("multiselect"))) {
        element.classList.remove("multiselect");
    }
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].selectedTabs = 0;
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].isSelecting = false;
}
// Toggle Selection
function multiSelectToggle(element) {
    if (element.classList.contains("multiselect")) {
        multiSelectCancel(element);
    } else {
        multiSelect(element);
    }
}
// Reset slide selection
function resetSlideSelection() {
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.sliding = false;
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].slideSelection.initiator = undefined;
}


/***/ }),

/***/ "./src/popup/wtinit.js":
/*!*****************************!*\
  !*** ./src/popup/wtinit.js ***!
  \*****************************/
/*! exports provided: updateTabs, populateTabsList, extendTabsList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateTabs", function() { return updateTabs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "populateTabsList", function() { return populateTabsList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "extendTabsList", function() { return extendTabsList; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals */ "./src/popup/globals.js");
/* harmony import */ var _net__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./net */ "./src/popup/net.js");
/* harmony import */ var _wrong_to_right__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wrong-to-right */ "./src/popup/wrong-to-right.js");
/* harmony import */ var _wtutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./wtutils */ "./src/popup/wtutils.js");
/* harmony import */ var _domutils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./domutils */ "./src/popup/domutils.js");
/* harmony import */ var _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./event-listeners/windowEntry */ "./src/popup/event-listeners/windowEntry.js");
/* harmony import */ var _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./event-listeners/tabEntry */ "./src/popup/event-listeners/tabEntry.js");









// Update tabs
function updateTabs(windows) {
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.innerHTML = "";
    let tabsListFragment = document.createDocumentFragment();
    let currentWindowEntry;
    /* Predefined elements for faster performance */
    // Window close button
    let WINDOW_CLOSE_BTN = document.createElement("span");
    WINDOW_CLOSE_BTN.classList.add("inline-button");
    WINDOW_CLOSE_BTN.classList.add("img-button");
    WINDOW_CLOSE_BTN.classList.add("opacity-changing-button");
    WINDOW_CLOSE_BTN.classList.add("window-entry-remove-btn");
    WINDOW_CLOSE_BTN.style.backgroundImage = "url(../icons/close.svg)";
    let DIV = document.createElement("div");
    DIV.style.display = "inline-block";
    WINDOW_CLOSE_BTN.appendChild(DIV);
    // Tab close button
    let TAB_CLOSE_BTN = document.createElement("span");
    TAB_CLOSE_BTN.classList.add("inline-button");
    TAB_CLOSE_BTN.classList.add("red-button");
    TAB_CLOSE_BTN.classList.add("img-button");
    TAB_CLOSE_BTN.classList.add("tab-entry-remove-btn");
    TAB_CLOSE_BTN.style.backgroundImage = "url(../icons/close.svg)";
    // Tab pin button
    let TAB_PIN_BTN = document.createElement("span");
    TAB_PIN_BTN.classList.add("inline-button");
    TAB_PIN_BTN.classList.add("img-button");
    TAB_PIN_BTN.classList.add("opacity-changing-button");
    TAB_PIN_BTN.classList.add("tab-entry-pin-btn");
    TAB_PIN_BTN.style.backgroundImage = "url(../icons/pin.svg)";
    // Loop through windows
    for (let i = 0; i < windows.length; i++) {
        // Set w to window
        let w = windows[i];

        // Create window entry
        let windowEntry = document.createElement("li");
        windowEntry.classList.add("window-entry");
        windowEntry.classList.add("category");

        // Create window entry fragment
        let windowEntryFragment = document.createDocumentFragment();

        // Set window id to window entry
        windowEntry.setAttribute("data-window_id", w.id);
        let span = document.createElement("span");
        span.addEventListener("click", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryTitleClicked"]);

        // Create close button
        let closeBtn = WINDOW_CLOSE_BTN.cloneNode(true);
        closeBtn.addEventListener("click", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowCloseClick"]);

        // Buttons wrapper
        let buttons = document.createElement("span");
        buttons.classList.add("window-entry-buttons");
        buttons.appendChild(closeBtn);
        
        // Create window name span
        let windowName = document.createElement("span");
        windowName.classList.add("window-title");
        windowName.textContent += "Window " + (i+1);

        // Check if window is focused
        if (w.focused) {
            currentWindowEntry = windowEntry;
            windowEntry.classList.add("current-window");
            windowName.textContent += " - Current";
        }
        // Check if window is incognito
        if (w.incognito) {
            windowEntry.classList.add("incognito-window");
            windowName.textContent += " (Incognito)";
        }

        span.appendChild(windowName);
        span.appendChild(buttons);

        span.classList.add("darker-button");

        windowEntryFragment.appendChild(span);

        // Add window entry dragstart, dragover, and drop event listeners
        windowEntry.addEventListener("dragstart", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDragStarted"]);
        windowEntry.addEventListener("dragover", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDraggingOver"]);
        windowEntry.addEventListener("drop", _event_listeners_windowEntry__WEBPACK_IMPORTED_MODULE_6__["windowEntryDropped"]);
        windowEntry.setAttribute("draggable", "true");

        let windowTabsList = document.createElement("ul");
        windowTabsList.classList.add("category-list");
        windowTabsList.classList.add("window-entry-tabs");

        let windowTabsListFragment = document.createDocumentFragment();
        // Loop through tabs
        for (let i = 0; i < w.tabs.length; i++) {
            let tab = w.tabs[i];
            // Check tab id
            if (tab.id !== browser.tabs.TAB_ID_NONE) {
                // Create tab entry
                let tabEntry = document.createElement("li");
                tabEntry.classList.add("tab-entry");
                tabEntry.classList.add("button");
                // Set tab entry as draggable. Required to enable move tab feature
                tabEntry.setAttribute("draggable", "true");

                // Create tab entry fragment
                let tabEntryFragment = document.createDocumentFragment();

                let favicon;
                let title = document.createElement("span");
                title.classList.add("tab-title");
                title.textContent += tab.title;
                let titleWrapper = document.createElement("div");
                titleWrapper.classList.add("tab-title-wrapper");
                titleWrapper.appendChild(title);

                if (tab.active) {
                    tabEntry.classList.add("current-tab");
                }
                if (tab.favIconUrl) {
                    favicon = document.createElement("img");
                    favicon.classList.add("tab-entry-favicon");
                    let favIconPromise;
                    if (w.incognito) {
                        favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(tab.favIconUrl, true);
                    } else {
                        favIconPromise = Object(_net__WEBPACK_IMPORTED_MODULE_2__["getImage"])(tab.favIconUrl);
                    }
                    favIconPromise.then(base64Image => {
                        favicon.src = base64Image;
                    });
                }

                // Create close button
                closeBtn = TAB_CLOSE_BTN.cloneNode(false);
                closeBtn.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabCloseClick"]);
                closeBtn.addEventListener("mouseover", _domutils__WEBPACK_IMPORTED_MODULE_5__["stopPropagation"]);

                // Create pin button
                let pinBtn = TAB_PIN_BTN.cloneNode(false);
                pinBtn.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabPinClick"]);
                pinBtn.addEventListener("mouseover", _domutils__WEBPACK_IMPORTED_MODULE_5__["stopPropagation"]);

                // Buttons wrapper
                buttons = document.createElement("span");
                buttons.classList.add("tab-entry-buttons");
                buttons.appendChild(pinBtn);
                buttons.appendChild(closeBtn);

                // Set tab entry tab id
                tabEntry.setAttribute("data-tab_id", Object(_wrong_to_right__WEBPACK_IMPORTED_MODULE_3__["getCorrectTabId"])(tab.id));
                if (favicon !== undefined) {
                    tabEntryFragment.appendChild(favicon);
                } else {
                    tabEntry.classList.add("noicon");
                }
                tabEntryFragment.appendChild(titleWrapper);
                tabEntryFragment.appendChild(buttons);
                
                tabEntry.appendChild(tabEntryFragment);

                tabEntry.addEventListener("mouseover", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryMouseOver"]);
                tabEntry.addEventListener("mouseleave", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryMouseLeave"]);
                tabEntry.addEventListener("click", _event_listeners_tabEntry__WEBPACK_IMPORTED_MODULE_7__["tabEntryClicked"]);

                if (tab.pinned) {
                    pinBtn.style.backgroundImage = "url(../icons/pinremove.svg)";
                    tabEntry.classList.add("pinned-tab");
                    let pinnedTabs = Array.from(windowTabsList.getElementsByClassName("pinned-tab"));
                    let lastPinnedTab = pinnedTabs[pinnedTabs.length-1];
                    if (lastPinnedTab !== undefined) {
                        windowTabsListFragment.insertBefore(tabEntry, lastPinnedTab.nextSibling);
                    } else {
                        windowTabsListFragment.insertBefore(tabEntry, windowTabsList.childNodes[0]);
                    }
                } else {
                    windowTabsListFragment.appendChild(tabEntry);
                }
            }
        }

        // Append fragment to actual windowTabsList
        windowTabsList.appendChild(windowTabsListFragment);

        windowEntryFragment.appendChild(windowTabsList);
        windowEntry.appendChild(windowEntryFragment);
        tabsListFragment.appendChild(windowEntry);
    }
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.appendChild(tabsListFragment);
    _globals__WEBPACK_IMPORTED_MODULE_1__["default"].tabsList.addEventListener("click", _domutils__WEBPACK_IMPORTED_MODULE_5__["stopPropagation"]);
    document.getElementById("tabs").style.display = "block";
    currentWindowEntry.scrollIntoView({ behavior: 'smooth' });
}

// Add tabs to list
async function populateTabsList() {
    let windows = await Object(_wtutils__WEBPACK_IMPORTED_MODULE_4__["getWindows"])();
    await Object(_wtutils__WEBPACK_IMPORTED_MODULE_4__["correctFocused"])(windows);
    updateTabs(windows);
}

// Set tabs list height to any available height
function extendTabsList() {
    let searchArea = document.getElementById("search-area");
    let searchAreaHeight = Object(_domutils__WEBPACK_IMPORTED_MODULE_5__["getActualHeight"])(searchArea);
    let tabs = document.getElementById("tabs");
    tabs.style.height = "calc(100% - " + searchAreaHeight + "px)";
}


/***/ }),

/***/ "./src/popup/wtutils.js":
/*!******************************!*\
  !*** ./src/popup/wtutils.js ***!
  \******************************/
/*! exports provided: getWindows, getLastFocusedWindowId, correctFocused, getLastFocusedWindow, runAfterTabLoad */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWindows", function() { return getWindows; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastFocusedWindowId", function() { return getLastFocusedWindowId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "correctFocused", function() { return correctFocused; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLastFocusedWindow", function() { return getLastFocusedWindow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "runAfterTabLoad", function() { return runAfterTabLoad; });
/* harmony import */ var Polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! Polyfill */ "./src/polyfill.js");


// Get all windows
function getWindows() {
    return browser.windows.getAll({
        populate: true,
        windowTypes: ["normal", "popup", "devtools"]
    });
}

// Get the correct last focused window id
function getLastFocusedWindowId() {
    /*
    Due to a bug in Chromium, windows.getLastFocused() will sometimes
    return incorrect windows. So here, instead of calling getLastFocused(),
    we call getCurrent().
    Reference: https://crbug.com/809822
    */
    return browser.tabs.query({ lastFocusedWindow: true }).then(function (tabs) {
        if (tabs.length > 0) {
            return tabs[0].windowId;
        }
        return -1;
    });
}

// Correct focused property of windows
// In Chromium, window.focused doesn't work, so we manually set it here
function correctFocused(windows) {
    return getLastFocusedWindowId().then(function (lastFocusedWindowId) {
        for (let i = 0; i < windows.length; i++) {
            if (windows[i].id === lastFocusedWindowId) {
                windows[i].focused = true;
            }
        }
    });
}

// Get current window
function getLastFocusedWindow() {
    // return browser.windows.getLastFocused({}); // Doesn't work due to a bug in Chromium. See explanation in getLastFocusedWindowId
    return getLastFocusedWindowId().then(windowId => browser.windows.get(windowId));
}

// Run code after a tab loads
function runAfterTabLoad(tabId, f) {
    return new Promise((resolve, reject) => {
        let listener = (uTabId, info) => {
            if (uTabId === tabId && info.status === 'complete') {
                browser.tabs.onUpdated.removeListener(listener);
                resolve(f());
            }
        };
        browser.tabs.onUpdated.addListener(listener);
    });
}


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9kaXN0L2Jyb3dzZXItcG9seWZpbGwuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL29wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL29wdGlvbnMvc3RhdGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9wb2x5ZmlsbC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvY2FwdHVyZVRhYi5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZG9tdXRpbHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2V2ZW50LWxpc3RlbmVycy9kb2N1bWVudC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL21lc3NhZ2UuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2V2ZW50LWxpc3RlbmVycy9yZWNvcmRlci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL3NlYXJjaC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvZXZlbnQtbGlzdGVuZXJzL3RhYkVudHJ5LmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC9ldmVudC1saXN0ZW5lcnMvd2luZG93RW50cnkuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2dsb2JhbHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL2tleXV0aWxzLmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC9tZXNzYWdpbmcuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL25ldC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvcG9wdXAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL3JlY29yZGVyLmpzIiwid2VicGFjazovLy8uL3NyYy9wb3B1cC93cm9uZy10by1yaWdodC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvd3Rkb20uanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BvcHVwL3d0aW5pdC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcG9wdXAvd3R1dGlscy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUNsRkE7QUFDQSxNQUFNLElBQTBDO0FBQ2hELElBQUksaUNBQWdDLENBQUMsTUFBUSxDQUFDLG9DQUFFLE9BQU87QUFBQTtBQUFBO0FBQUEsb0dBQUM7QUFDeEQsR0FBRyxNQUFNLFlBUU47QUFDSCxDQUFDO0FBQ0Q7QUFDQSxxQ0FBcUM7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFNBQVM7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixFQUFFO0FBQ25CLG1CQUFtQixRQUFRO0FBQzNCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsT0FBTztBQUN4QjtBQUNBO0FBQ0EsaUJBQWlCLFNBQVM7QUFDMUI7QUFDQSxpQkFBaUIsU0FBUztBQUMxQjtBQUNBLGlCQUFpQixPQUFPO0FBQ3hCO0FBQ0EsaUJBQWlCLFFBQVE7QUFDekI7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsT0FBTztBQUN4QjtBQUNBLGlCQUFpQixPQUFPO0FBQ3hCO0FBQ0EsaUJBQWlCLFFBQVE7QUFDekI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFFBQVE7QUFDekI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFFBQVE7QUFDekI7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsaUJBQWlCLEdBQUcscUNBQXFDLE9BQU8sS0FBSyxVQUFVLFlBQVk7QUFDNUk7O0FBRUE7QUFDQSxnREFBZ0QsaUJBQWlCLEdBQUcscUNBQXFDLE9BQU8sS0FBSyxVQUFVLFlBQVk7QUFDM0k7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELGtCQUFrQjtBQUN0RSxlQUFlO0FBQ2YsZ0NBQWdDLEtBQUs7O0FBRXJDOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYixrREFBa0Qsa0JBQWtCO0FBQ3BFO0FBQ0EsV0FBVztBQUNYO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLE9BQU87QUFDeEI7QUFDQSxpQkFBaUIsU0FBUztBQUMxQjtBQUNBO0FBQ0EsaUJBQWlCLFNBQVM7QUFDMUI7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsT0FBTztBQUN4QjtBQUNBO0FBQ0EsaUJBQWlCLE9BQU8sZUFBZTtBQUN2QztBQUNBO0FBQ0E7QUFDQSw2REFBNkQsZ0JBQWdCO0FBQzdFO0FBQ0EsaUJBQWlCLE9BQU8sZUFBZTtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0EsK0NBQStDLGVBQWU7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXOztBQUVYO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLGVBQWU7O0FBRWY7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsV0FBVzs7QUFFWDtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsV0FBVzs7QUFFWDtBQUNBO0FBQ0EsV0FBVzs7QUFFWDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsbUNBQW1DO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUzs7QUFFVDtBQUNBO0FBQ0EsU0FBUzs7QUFFVDtBQUNBO0FBQ0E7QUFDQSxPQUFPOztBQUVQO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLEVBQUU7QUFDckI7QUFDQSxtQkFBbUIsT0FBTztBQUMxQjtBQUNBLG1CQUFtQixZQUFZO0FBQy9CO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7O0FBRVg7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZixhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsT0FBTzs7QUFFUCwyQ0FBMkMsa0JBQWtCO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLCtDQUErQyxpQkFBaUIsR0FBRyxxQ0FBcUMsT0FBTyxLQUFLLFVBQVUsWUFBWTtBQUMxSTs7QUFFQTtBQUNBLDhDQUE4QyxpQkFBaUIsR0FBRyxxQ0FBcUMsT0FBTyxLQUFLLFVBQVUsWUFBWTtBQUN6STs7QUFFQTtBQUNBLG1FQUFtRSxrQkFBa0I7QUFDckY7QUFDQTtBQUNBLFNBQVM7QUFDVDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFFQUFxRSx5QkFBeUI7QUFDOUYsU0FBUztBQUNUO0FBQ0EscUVBQXFFLHlCQUF5QjtBQUM5RjtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IseUJBQXlCO0FBQ3pDLGNBQWMseUJBQXlCO0FBQ3ZDLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsQ0FBQztBQUNEOzs7Ozs7Ozs7Ozs7O0FDbHFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQzRFO0FBQ3hCOztBQUU5RDtBQUNQO0FBQ0E7O0FBRU87QUFDUCxzQ0FBc0MsbUJBQW1CO0FBQ3pEOztBQUVPO0FBQ1A7QUFDQSxhQUFhLHlEQUFTO0FBQ3RCLGFBQWEsZ0VBQWdCO0FBQzdCO0FBQ0EsYUFBYSwwREFBVTtBQUN2QixhQUFhLGlFQUFpQjtBQUM5QjtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNyQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBd0M7O0FBRWpDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLHNEQUFhO0FBQ2pCO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3ZCQTtBQUFBO0FBQU8sc0JBQXNCLFFBQU07O0FBRW5DLElBQUksSUFBbUI7QUFDdkIsd0JBQXdCLG1CQUFPLENBQUMsNEZBQXVCO0FBQ3ZEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsVUFBVTtBQUMxQyxvREFBb0QsZUFBZTtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxtRUFBbUU7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjs7QUFFVjs7QUFFQTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNkQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7O0FBRWpCO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ25DQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ1M7QUFDZ0U7O0FBRW5GO0FBQ1A7QUFDQTs7QUFFTztBQUNQLFFBQVEsZ0RBQUMseUJBQXlCLGtFQUFtQjtBQUNyRDs7QUFFTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLHVEQUFRO0FBQ3hDLFNBQVMsT0FBTztBQUNoQixnQkFBZ0IsZ0RBQUMsY0FBYywrREFBZ0I7QUFDL0M7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMLFlBQVksZ0RBQUM7QUFDYixZQUFZLDZEQUFjO0FBQzFCO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3hDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDRztBQUNhO0FBQzJGOztBQUVySDtBQUNQO0FBQ0E7QUFDQSxZQUFZLDJEQUFZO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMscURBQVE7QUFDN0MsaUJBQWlCO0FBQ2pCLHFDQUFxQyxxREFBUTtBQUM3QztBQUNBO0FBQ0Esb0JBQW9CLHFFQUFzQixDQUFDLCtEQUFnQjtBQUMzRCxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0E7QUFDQSwyQkFBMkIsK0RBQWdCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwrREFBZ0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCLHdEQUFTO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBLFlBQVksMkRBQVk7QUFDeEI7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDeERBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBeUQ7O0FBRXpEO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLElBQUksd0RBQU07QUFDVjtBQUNBO0FBQ0EsaUNBQWlDO0FBQ2pDLEtBQUs7QUFDTDs7QUFFa0I7Ozs7Ozs7Ozs7Ozs7QUNmbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUztBQUNTO0FBQ1c7O0FBRTlDO0FBQ087QUFDUCxtRUFBbUUseURBQWU7QUFDbEY7O0FBRUE7QUFDQTtBQUNBLG1CQUFtQixxQkFBcUI7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1Qix1QkFBdUI7QUFDOUM7QUFDQTtBQUNBLGtCQUFrQixnREFBQyxnREFBZ0QsdURBQVE7QUFDM0U7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLHVCQUF1Qix1QkFBdUI7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2pEQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUI7QUFDUztBQUNhO0FBQ1U7QUFDTjtBQUMwRjs7QUFFOUg7QUFDUDtBQUNBLFFBQVEsMkRBQVMsTUFBTSxnREFBQztBQUN4QixZQUFZLGdEQUFDO0FBQ2IsZ0JBQWdCLGdEQUFDO0FBQ2pCLGdCQUFnQiwwREFBVztBQUMzQixhQUFhO0FBQ2IsZ0JBQWdCLGdFQUFpQjtBQUNqQztBQUNBO0FBQ0EsS0FBSztBQUNMLG9CQUFvQix1REFBUTtBQUM1QixRQUFRLHNEQUFxQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0E7O0FBRU87QUFDUDtBQUNBLFlBQVksMkRBQVM7QUFDckIsWUFBWSxnRUFBaUI7QUFDN0I7QUFDQSxTQUFTO0FBQ1QsWUFBWSw2REFBYztBQUMxQjtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBLGdCQUFnQix1REFBUTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLEtBQUs7QUFDTDs7Ozs7Ozs7Ozs7OztBQzdGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNTO0FBQ2E7QUFDb0o7O0FBRTNMOztBQUVBO0FBQ0E7QUFDQSx3QkFBd0IsK0RBQWdCO0FBQ3hDO0FBQ0EsbUJBQW1CLDhCQUE4QjtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFTztBQUNQO0FBQ0EsWUFBWSwyREFBUztBQUNyQixZQUFZLGdFQUFpQjtBQUM3QixZQUFZLGdEQUFDO0FBQ2IsWUFBWSxnREFBQztBQUNiO0FBQ0EsU0FBUztBQUNUO0FBQ0EsMkJBQTJCLCtEQUFnQjtBQUMzQyw2QkFBNkIsMERBQVc7QUFDeEM7QUFDQSxnQkFBZ0IsZ0RBQUMsZ0JBQWdCLDREQUFhO0FBQzlDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBLDZCQUE2QixnREFBQztBQUM5QixtQkFBbUIsb0JBQW9CO0FBQ3ZDO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixnREFBQztBQUN4QjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwyREFBWTtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsWUFBWSxtRUFBb0I7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7O0FBRU87QUFDUDtBQUNBO0FBQ0EsNkJBQTZCLGdEQUFDO0FBQzlCLG1CQUFtQixvQkFBb0I7QUFDdkM7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLGdEQUFDO0FBQ3hCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSwyREFBWTtBQUN4QixzQ0FBc0MsMERBQVcsQ0FBQywrREFBZ0I7QUFDbEU7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLHVEQUFRO0FBQ3RDO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLGdCQUFnQix3REFBUyxZQUFZLCtEQUFnQjtBQUNyRCxhQUFhO0FBQ2IsZ0JBQWdCLHNEQUFPO0FBQ3ZCO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsWUFBWSxtRUFBb0I7QUFDaEMsOEJBQThCLHVEQUFRO0FBQ3RDLHNDQUFzQywwREFBVztBQUNqRDtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsWUFBWSx3REFBUztBQUNyQjtBQUNBO0FBQ0E7O0FBRU87QUFDUCxtQkFBbUIsMERBQVc7QUFDOUI7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFTztBQUNQLG1CQUFtQiwwREFBVztBQUM5QjtBQUNBOzs7Ozs7Ozs7Ozs7O0FDNUpBO0FBQUE7QUFBaUI7O0FBRWpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ2Usc0VBQU8sRUFBQzs7Ozs7Ozs7Ozs7OztBQ2R2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCOztBQUVqQjtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTzs7QUFFUDtBQUNPO0FBQ1A7QUFDQTs7Ozs7Ozs7Ozs7OztBQ25DQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjs7QUFFakI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOzs7Ozs7Ozs7Ozs7O0FDaEJBO0FBQUE7QUFBQTtBQUFBO0FBQWlCOztBQUVqQjtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRSxjQUFjO0FBQy9FO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEJBQThCLG1EQUFtRDtBQUNqRjtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN2Q0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNRO0FBQ3lCO0FBQ1M7QUFDaEI7QUFDeUU7QUFDNUM7QUFDbkI7QUFDZ0M7QUFDM0M7QUFDTDtBQUNHO0FBQ1c7O0FBRW5ELGdEQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhCQUE4QixpREFBZTtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxnREFBYztBQUN2QjtBQUNBLDREQUE0RCxnRUFBYztBQUMxRTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxhQUFhLGdEQUFjLDRCQUE0Qiw4REFBYztBQUNyRTtBQUNBO0FBQ0EsSUFBSSxnREFBQyx5QkFBeUIsZ0RBQWM7QUFDNUM7QUFDQSxJQUFJLGdEQUFDLGdCQUFnQixnREFBYztBQUNuQzs7QUFFQTtBQUNBO0FBQ0EsSUFBSSxnREFBZTtBQUNuQjtBQUNBO0FBQ0E7QUFDQSxJQUFJLDhEQUFjO0FBQ2xCO0FBQ0EsVUFBVSx1RUFBZTtBQUN6QjtBQUNBLFVBQVUsZ0VBQWdCO0FBQzFCO0FBQ0EsVUFBVSx3RUFBcUI7QUFDL0I7QUFDQSxJQUFJLDBFQUFVO0FBQ2Q7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7O0FBRUEsdUNBQXVDLDJFQUFpQjtBQUN4RCxxQ0FBcUMseUVBQWU7QUFDcEQsbUNBQW1DLHlFQUFlO0FBQ2xELHNDQUFzQyw0RUFBa0I7O0FBRXhEO0FBQ0E7QUFDQSxpQ0FBaUMseUVBQWlCO0FBQ2xEOztBQUVBO0FBQ0E7QUFDQSxlQUFlLHdCQUF3QjtBQUN2QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMOztBQUVBO0FBQ0Esb0VBQW9FLHNFQUFZO0FBQ2hGLGlFQUFpRSxpRUFBZTs7QUFFaEY7QUFDQSwyQ0FBMkMsa0VBQVM7QUFDcEQsMENBQTBDLGtFQUFTO0FBQ25EOzs7Ozs7Ozs7Ozs7O0FDekdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNRO0FBQ1M7QUFDVTs7QUFFckM7QUFDUDtBQUNBOztBQUVPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0EsNEJBQTRCLGdEQUFDO0FBQzdCO0FBQ0E7QUFDQSwyQ0FBMkMsdURBQVEsYUFBYSx5QkFBeUIsaUJBQWlCLEVBQUU7QUFDNUc7QUFDQTtBQUNBLGlCQUFpQix5Q0FBeUMsdURBQVE7QUFDbEUsYUFBYTtBQUNiO0FBQ0E7QUFDQSxpQkFBaUIseUNBQXlDLHVEQUFRO0FBQ2xFLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxpQkFBaUI7QUFDdEQ7O0FBRU87QUFDUCxTQUFTLFlBQVk7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULDJCQUEyQix5QkFBeUI7QUFDcEQ7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0Esd0JBQXdCLGdFQUFlO0FBQ3ZDO0FBQ0E7QUFDQSxxREFBcUQsaUJBQWlCO0FBQ3RFLDZCQUE2QjtBQUM3Qix5QkFBeUI7QUFDekI7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxpQkFBaUI7QUFDakI7QUFDQSxTQUFTO0FBQ1Q7QUFDQTs7Ozs7Ozs7Ozs7OztBQy9FQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQytCOztBQUVoRDs7QUFFTztBQUNQLFdBQVcscUVBQWtCLHlCQUF5QjtBQUN0RDtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNPO0FBQ1A7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2RBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlCO0FBQ1E7QUFDeUI7QUFDRDs7QUFFakQ7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsUUFBUSxxRUFBb0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYixvQkFBb0IsZ0RBQUM7QUFDckI7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUCw0QkFBNEIsdUVBQWU7QUFDM0M7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLFdBQVcsZ0RBQUM7QUFDWjs7QUFFQTtBQUNPO0FBQ1A7QUFDQTs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLG1CQUFtQixvQkFBb0I7QUFDdkM7O0FBRUE7QUFDTztBQUNQO0FBQ0E7O0FBRUE7QUFDTztBQUNQLG1CQUFtQixvQkFBb0I7QUFDdkM7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQSxpQ0FBaUM7QUFDakM7QUFDQSxLQUFLO0FBQ0w7O0FBRU87QUFDUDtBQUNBO0FBQ087QUFDUDtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBLG1CQUFtQixpQkFBaUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ087QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQSxRQUFRLGdEQUFDO0FBQ1QsUUFBUSxnREFBQztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDtBQUNBLGNBQWMsZ0RBQUM7QUFDZixZQUFZLGdEQUFDO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0EsSUFBSSxnREFBQztBQUNMLElBQUksZ0RBQUM7QUFDTDtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUCxJQUFJLGdEQUFDO0FBQ0wsSUFBSSxnREFBQztBQUNMOzs7Ozs7Ozs7Ozs7O0FDbFBBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjtBQUNRO0FBQ087QUFDa0I7QUFDSTtBQUNPO0FBQ2lHO0FBQy9COztBQUUvSDtBQUNPO0FBQ1AsSUFBSSxnREFBQztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLG9CQUFvQjtBQUN2QztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLG9GQUF1Qjs7QUFFOUQ7QUFDQTtBQUNBLDJDQUEyQyw2RUFBZ0I7O0FBRTNEO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQTs7QUFFQTtBQUNBLGtEQUFrRCxtRkFBc0I7QUFDeEUsaURBQWlELG9GQUF1QjtBQUN4RSw2Q0FBNkMsK0VBQWtCO0FBQy9EOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsdUJBQXVCLG1CQUFtQjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLHFEQUFRO0FBQ2pELHFCQUFxQjtBQUNyQix5Q0FBeUMscURBQVE7QUFDakQ7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCOztBQUVBO0FBQ0E7QUFDQSxtREFBbUQsdUVBQWE7QUFDaEUsdURBQXVELHlEQUFlOztBQUV0RTtBQUNBO0FBQ0EsaURBQWlELHFFQUFXO0FBQzVELHFEQUFxRCx5REFBZTs7QUFFcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHFEQUFxRCx1RUFBZTtBQUNwRTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBLHVEQUF1RCwyRUFBaUI7QUFDeEUsd0RBQXdELDRFQUFrQjtBQUMxRSxtREFBbUQseUVBQWU7O0FBRWxFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUksZ0RBQUM7QUFDTCxJQUFJLGdEQUFDLG9DQUFvQyx5REFBZTtBQUN4RDtBQUNBLHVDQUF1QyxxQkFBcUI7QUFDNUQ7O0FBRUE7QUFDTztBQUNQLHdCQUF3QiwyREFBVTtBQUNsQyxVQUFVLCtEQUFjO0FBQ3hCO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0EsMkJBQTJCLGlFQUFlO0FBQzFDO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3ZOQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQjs7QUFFakI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLDBCQUEwQjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ087QUFDUDtBQUNBLHVCQUF1QixvQkFBb0I7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDTztBQUNQLCtDQUErQyxFQUFFO0FBQ2pEO0FBQ0E7O0FBRUE7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wiLCJmaWxlIjoicG9wdXAvcG9wdXAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy9wb3B1cC9wb3B1cC5qc1wiKTtcbiIsIihmdW5jdGlvbiAoZ2xvYmFsLCBmYWN0b3J5KSB7XG4gIGlmICh0eXBlb2YgZGVmaW5lID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmaW5lLmFtZCkge1xuICAgIGRlZmluZShcIndlYmV4dGVuc2lvbi1wb2x5ZmlsbFwiLCBbXCJtb2R1bGVcIl0sIGZhY3RvcnkpO1xuICB9IGVsc2UgaWYgKHR5cGVvZiBleHBvcnRzICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgZmFjdG9yeShtb2R1bGUpO1xuICB9IGVsc2Uge1xuICAgIHZhciBtb2QgPSB7XG4gICAgICBleHBvcnRzOiB7fVxuICAgIH07XG4gICAgZmFjdG9yeShtb2QpO1xuICAgIGdsb2JhbC5icm93c2VyID0gbW9kLmV4cG9ydHM7XG4gIH1cbn0pKHRoaXMsIGZ1bmN0aW9uIChtb2R1bGUpIHtcbiAgLyogd2ViZXh0ZW5zaW9uLXBvbHlmaWxsIC0gdjAuNC4wIC0gV2VkIEZlYiAwNiAyMDE5IDExOjU4OjMxICovXG4gIC8qIC0qLSBNb2RlOiBpbmRlbnQtdGFicy1tb2RlOiBuaWw7IGpzLWluZGVudC1sZXZlbDogMiAtKi0gKi9cbiAgLyogdmltOiBzZXQgc3RzPTIgc3c9MiBldCB0dz04MDogKi9cbiAgLyogVGhpcyBTb3VyY2UgQ29kZSBGb3JtIGlzIHN1YmplY3QgdG8gdGhlIHRlcm1zIG9mIHRoZSBNb3ppbGxhIFB1YmxpY1xuICAgKiBMaWNlbnNlLCB2LiAyLjAuIElmIGEgY29weSBvZiB0aGUgTVBMIHdhcyBub3QgZGlzdHJpYnV0ZWQgd2l0aCB0aGlzXG4gICAqIGZpbGUsIFlvdSBjYW4gb2J0YWluIG9uZSBhdCBodHRwOi8vbW96aWxsYS5vcmcvTVBMLzIuMC8uICovXG4gIFwidXNlIHN0cmljdFwiO1xuXG4gIGlmICh0eXBlb2YgYnJvd3NlciA9PT0gXCJ1bmRlZmluZWRcIiB8fCBPYmplY3QuZ2V0UHJvdG90eXBlT2YoYnJvd3NlcikgIT09IE9iamVjdC5wcm90b3R5cGUpIHtcbiAgICBjb25zdCBDSFJPTUVfU0VORF9NRVNTQUdFX0NBTExCQUNLX05PX1JFU1BPTlNFX01FU1NBR0UgPSBcIlRoZSBtZXNzYWdlIHBvcnQgY2xvc2VkIGJlZm9yZSBhIHJlc3BvbnNlIHdhcyByZWNlaXZlZC5cIjtcbiAgICBjb25zdCBTRU5EX1JFU1BPTlNFX0RFUFJFQ0FUSU9OX1dBUk5JTkcgPSBcIlJldHVybmluZyBhIFByb21pc2UgaXMgdGhlIHByZWZlcnJlZCB3YXkgdG8gc2VuZCBhIHJlcGx5IGZyb20gYW4gb25NZXNzYWdlL29uTWVzc2FnZUV4dGVybmFsIGxpc3RlbmVyLCBhcyB0aGUgc2VuZFJlc3BvbnNlIHdpbGwgYmUgcmVtb3ZlZCBmcm9tIHRoZSBzcGVjcyAoU2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2RvY3MvTW96aWxsYS9BZGQtb25zL1dlYkV4dGVuc2lvbnMvQVBJL3J1bnRpbWUvb25NZXNzYWdlKVwiO1xuXG4gICAgLy8gV3JhcHBpbmcgdGhlIGJ1bGsgb2YgdGhpcyBwb2x5ZmlsbCBpbiBhIG9uZS10aW1lLXVzZSBmdW5jdGlvbiBpcyBhIG1pbm9yXG4gICAgLy8gb3B0aW1pemF0aW9uIGZvciBGaXJlZm94LiBTaW5jZSBTcGlkZXJtb25rZXkgZG9lcyBub3QgZnVsbHkgcGFyc2UgdGhlXG4gICAgLy8gY29udGVudHMgb2YgYSBmdW5jdGlvbiB1bnRpbCB0aGUgZmlyc3QgdGltZSBpdCdzIGNhbGxlZCwgYW5kIHNpbmNlIGl0IHdpbGxcbiAgICAvLyBuZXZlciBhY3R1YWxseSBuZWVkIHRvIGJlIGNhbGxlZCwgdGhpcyBhbGxvd3MgdGhlIHBvbHlmaWxsIHRvIGJlIGluY2x1ZGVkXG4gICAgLy8gaW4gRmlyZWZveCBuZWFybHkgZm9yIGZyZWUuXG4gICAgY29uc3Qgd3JhcEFQSXMgPSBleHRlbnNpb25BUElzID0+IHtcbiAgICAgIC8vIE5PVEU6IGFwaU1ldGFkYXRhIGlzIGFzc29jaWF0ZWQgdG8gdGhlIGNvbnRlbnQgb2YgdGhlIGFwaS1tZXRhZGF0YS5qc29uIGZpbGVcbiAgICAgIC8vIGF0IGJ1aWxkIHRpbWUgYnkgcmVwbGFjaW5nIHRoZSBmb2xsb3dpbmcgXCJpbmNsdWRlXCIgd2l0aCB0aGUgY29udGVudCBvZiB0aGVcbiAgICAgIC8vIEpTT04gZmlsZS5cbiAgICAgIGNvbnN0IGFwaU1ldGFkYXRhID0ge1xuICAgICAgICBcImFsYXJtc1wiOiB7XG4gICAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImNsZWFyQWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiYm9va21hcmtzXCI6IHtcbiAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldENoaWxkcmVuXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UmVjZW50XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0U3ViVHJlZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFRyZWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlVHJlZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImJyb3dzZXJBY3Rpb25cIjoge1xuICAgICAgICAgIFwiZGlzYWJsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImVuYWJsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEJhZGdlQmFja2dyb3VuZENvbG9yXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QmFkZ2VUZXh0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UG9wdXBcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRUaXRsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm9wZW5Qb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEJhZGdlQmFja2dyb3VuZENvbG9yXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0QmFkZ2VUZXh0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0SWNvblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJicm93c2luZ0RhdGFcIjoge1xuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlQ2FjaGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVDb29raWVzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlRG93bmxvYWRzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlRm9ybURhdGFcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVIaXN0b3J5XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlTG9jYWxTdG9yYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlUGFzc3dvcmRzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlUGx1Z2luRGF0YVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldHRpbmdzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiY29tbWFuZHNcIjoge1xuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiY29udGV4dE1lbnVzXCI6IHtcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImNvb2tpZXNcIjoge1xuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsQ29va2llU3RvcmVzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiZGV2dG9vbHNcIjoge1xuICAgICAgICAgIFwiaW5zcGVjdGVkV2luZG93XCI6IHtcbiAgICAgICAgICAgIFwiZXZhbFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMixcbiAgICAgICAgICAgICAgXCJzaW5nbGVDYWxsYmFja0FyZ1wiOiBmYWxzZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJwYW5lbHNcIjoge1xuICAgICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMyxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDMsXG4gICAgICAgICAgICAgIFwic2luZ2xlQ2FsbGJhY2tBcmdcIjogdHJ1ZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJkb3dubG9hZHNcIjoge1xuICAgICAgICAgIFwiY2FuY2VsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZG93bmxvYWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJlcmFzZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEZpbGVJY29uXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwib3BlblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInBhdXNlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlRmlsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlc3VtZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNob3dcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJleHRlbnNpb25cIjoge1xuICAgICAgICAgIFwiaXNBbGxvd2VkRmlsZVNjaGVtZUFjY2Vzc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImlzQWxsb3dlZEluY29nbml0b0FjY2Vzc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImhpc3RvcnlcIjoge1xuICAgICAgICAgIFwiYWRkVXJsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGVsZXRlQWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGVsZXRlUmFuZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkZWxldGVVcmxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRWaXNpdHNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZWFyY2hcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJpMThuXCI6IHtcbiAgICAgICAgICBcImRldGVjdExhbmd1YWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWNjZXB0TGFuZ3VhZ2VzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiaWRlbnRpdHlcIjoge1xuICAgICAgICAgIFwibGF1bmNoV2ViQXV0aEZsb3dcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJpZGxlXCI6IHtcbiAgICAgICAgICBcInF1ZXJ5U3RhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJtYW5hZ2VtZW50XCI6IHtcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFNlbGZcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRFbmFibGVkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidW5pbnN0YWxsU2VsZlwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIm5vdGlmaWNhdGlvbnNcIjoge1xuICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRQZXJtaXNzaW9uTGV2ZWxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJwYWdlQWN0aW9uXCI6IHtcbiAgICAgICAgICBcImdldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJoaWRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0SWNvblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzaG93XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicGVybWlzc2lvbnNcIjoge1xuICAgICAgICAgIFwiY29udGFpbnNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXF1ZXN0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicnVudGltZVwiOiB7XG4gICAgICAgICAgXCJnZXRCYWNrZ3JvdW5kUGFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEJyb3dzZXJJbmZvXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UGxhdGZvcm1JbmZvXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwib3Blbk9wdGlvbnNQYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVxdWVzdFVwZGF0ZUNoZWNrXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VuZE1lc3NhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogM1xuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZW5kTmF0aXZlTWVzc2FnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFVuaW5zdGFsbFVSTFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInNlc3Npb25zXCI6IHtcbiAgICAgICAgICBcImdldERldmljZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRSZWNlbnRseUNsb3NlZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlc3RvcmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJzdG9yYWdlXCI6IHtcbiAgICAgICAgICBcImxvY2FsXCI6IHtcbiAgICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0Qnl0ZXNJblVzZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIFwibWFuYWdlZFwiOiB7XG4gICAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0Qnl0ZXNJblVzZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzeW5jXCI6IHtcbiAgICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0Qnl0ZXNJblVzZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwidGFic1wiOiB7XG4gICAgICAgICAgXCJjYXB0dXJlVmlzaWJsZVRhYlwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRldGVjdExhbmd1YWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGlzY2FyZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImR1cGxpY2F0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImV4ZWN1dGVTY3JpcHRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRDdXJyZW50XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Wm9vbVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFpvb21TZXR0aW5nc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImhpZ2hsaWdodFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImluc2VydENTU1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJxdWVyeVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbG9hZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUNTU1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlbmRNZXNzYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDNcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0Wm9vbVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFpvb21TZXR0aW5nc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInRvcFNpdGVzXCI6IHtcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIndlYk5hdmlnYXRpb25cIjoge1xuICAgICAgICAgIFwiZ2V0QWxsRnJhbWVzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0RnJhbWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ3ZWJSZXF1ZXN0XCI6IHtcbiAgICAgICAgICBcImhhbmRsZXJCZWhhdmlvckNoYW5nZWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ3aW5kb3dzXCI6IHtcbiAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEN1cnJlbnRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRMYXN0Rm9jdXNlZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBpZiAoT2JqZWN0LmtleXMoYXBpTWV0YWRhdGEpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJhcGktbWV0YWRhdGEuanNvbiBoYXMgbm90IGJlZW4gaW5jbHVkZWQgaW4gYnJvd3Nlci1wb2x5ZmlsbFwiKTtcbiAgICAgIH1cblxuICAgICAgLyoqXG4gICAgICAgKiBBIFdlYWtNYXAgc3ViY2xhc3Mgd2hpY2ggY3JlYXRlcyBhbmQgc3RvcmVzIGEgdmFsdWUgZm9yIGFueSBrZXkgd2hpY2ggZG9lc1xuICAgICAgICogbm90IGV4aXN0IHdoZW4gYWNjZXNzZWQsIGJ1dCBiZWhhdmVzIGV4YWN0bHkgYXMgYW4gb3JkaW5hcnkgV2Vha01hcFxuICAgICAgICogb3RoZXJ3aXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IGNyZWF0ZUl0ZW1cbiAgICAgICAqICAgICAgICBBIGZ1bmN0aW9uIHdoaWNoIHdpbGwgYmUgY2FsbGVkIGluIG9yZGVyIHRvIGNyZWF0ZSB0aGUgdmFsdWUgZm9yIGFueVxuICAgICAgICogICAgICAgIGtleSB3aGljaCBkb2VzIG5vdCBleGlzdCwgdGhlIGZpcnN0IHRpbWUgaXQgaXMgYWNjZXNzZWQuIFRoZVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uIHJlY2VpdmVzLCBhcyBpdHMgb25seSBhcmd1bWVudCwgdGhlIGtleSBiZWluZyBjcmVhdGVkLlxuICAgICAgICovXG4gICAgICBjbGFzcyBEZWZhdWx0V2Vha01hcCBleHRlbmRzIFdlYWtNYXAge1xuICAgICAgICBjb25zdHJ1Y3RvcihjcmVhdGVJdGVtLCBpdGVtcyA9IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHN1cGVyKGl0ZW1zKTtcbiAgICAgICAgICB0aGlzLmNyZWF0ZUl0ZW0gPSBjcmVhdGVJdGVtO1xuICAgICAgICB9XG5cbiAgICAgICAgZ2V0KGtleSkge1xuICAgICAgICAgIGlmICghdGhpcy5oYXMoa2V5KSkge1xuICAgICAgICAgICAgdGhpcy5zZXQoa2V5LCB0aGlzLmNyZWF0ZUl0ZW0oa2V5KSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIHN1cGVyLmdldChrZXkpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBvYmplY3QgaXMgYW4gb2JqZWN0IHdpdGggYSBgdGhlbmAgbWV0aG9kLCBhbmQgY2FuXG4gICAgICAgKiB0aGVyZWZvcmUgYmUgYXNzdW1lZCB0byBiZWhhdmUgYXMgYSBQcm9taXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7Kn0gdmFsdWUgVGhlIHZhbHVlIHRvIHRlc3QuXG4gICAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgdmFsdWUgaXMgdGhlbmFibGUuXG4gICAgICAgKi9cbiAgICAgIGNvbnN0IGlzVGhlbmFibGUgPSB2YWx1ZSA9PiB7XG4gICAgICAgIHJldHVybiB2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHZhbHVlLnRoZW4gPT09IFwiZnVuY3Rpb25cIjtcbiAgICAgIH07XG5cbiAgICAgIC8qKlxuICAgICAgICogQ3JlYXRlcyBhbmQgcmV0dXJucyBhIGZ1bmN0aW9uIHdoaWNoLCB3aGVuIGNhbGxlZCwgd2lsbCByZXNvbHZlIG9yIHJlamVjdFxuICAgICAgICogdGhlIGdpdmVuIHByb21pc2UgYmFzZWQgb24gaG93IGl0IGlzIGNhbGxlZDpcbiAgICAgICAqXG4gICAgICAgKiAtIElmLCB3aGVuIGNhbGxlZCwgYGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcmAgY29udGFpbnMgYSBub24tbnVsbCBvYmplY3QsXG4gICAgICAgKiAgIHRoZSBwcm9taXNlIGlzIHJlamVjdGVkIHdpdGggdGhhdCB2YWx1ZS5cbiAgICAgICAqIC0gSWYgdGhlIGZ1bmN0aW9uIGlzIGNhbGxlZCB3aXRoIGV4YWN0bHkgb25lIGFyZ3VtZW50LCB0aGUgcHJvbWlzZSBpc1xuICAgICAgICogICByZXNvbHZlZCB0byB0aGF0IHZhbHVlLlxuICAgICAgICogLSBPdGhlcndpc2UsIHRoZSBwcm9taXNlIGlzIHJlc29sdmVkIHRvIGFuIGFycmF5IGNvbnRhaW5pbmcgYWxsIG9mIHRoZVxuICAgICAgICogICBmdW5jdGlvbidzIGFyZ3VtZW50cy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gcHJvbWlzZVxuICAgICAgICogICAgICAgIEFuIG9iamVjdCBjb250YWluaW5nIHRoZSByZXNvbHV0aW9uIGFuZCByZWplY3Rpb24gZnVuY3Rpb25zIG9mIGFcbiAgICAgICAqICAgICAgICBwcm9taXNlLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gcHJvbWlzZS5yZXNvbHZlXG4gICAgICAgKiAgICAgICAgVGhlIHByb21pc2UncyByZXNvbHV0aW9uIGZ1bmN0aW9uLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gcHJvbWlzZS5yZWplY3Rpb25cbiAgICAgICAqICAgICAgICBUaGUgcHJvbWlzZSdzIHJlamVjdGlvbiBmdW5jdGlvbi5cbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBtZXRhZGF0YVxuICAgICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSB3cmFwcGVkIG1ldGhvZCB3aGljaCBoYXMgY3JlYXRlZCB0aGUgY2FsbGJhY2suXG4gICAgICAgKiBAcGFyYW0ge2ludGVnZXJ9IG1ldGFkYXRhLm1heFJlc29sdmVkQXJnc1xuICAgICAgICogICAgICAgIFRoZSBtYXhpbXVtIG51bWJlciBvZiBhcmd1bWVudHMgd2hpY2ggbWF5IGJlIHBhc3NlZCB0byB0aGVcbiAgICAgICAqICAgICAgICBjYWxsYmFjayBjcmVhdGVkIGJ5IHRoZSB3cmFwcGVkIGFzeW5jIGZ1bmN0aW9uLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAgICAgICAqICAgICAgICBUaGUgZ2VuZXJhdGVkIGNhbGxiYWNrIGZ1bmN0aW9uLlxuICAgICAgICovXG4gICAgICBjb25zdCBtYWtlQ2FsbGJhY2sgPSAocHJvbWlzZSwgbWV0YWRhdGEpID0+IHtcbiAgICAgICAgcmV0dXJuICguLi5jYWxsYmFja0FyZ3MpID0+IHtcbiAgICAgICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgICAgcHJvbWlzZS5yZWplY3QoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcik7XG4gICAgICAgICAgfSBlbHNlIGlmIChtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZyB8fCBjYWxsYmFja0FyZ3MubGVuZ3RoIDw9IDEgJiYgbWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmcgIT09IGZhbHNlKSB7XG4gICAgICAgICAgICBwcm9taXNlLnJlc29sdmUoY2FsbGJhY2tBcmdzWzBdKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHJvbWlzZS5yZXNvbHZlKGNhbGxiYWNrQXJncyk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfTtcblxuICAgICAgY29uc3QgcGx1cmFsaXplQXJndW1lbnRzID0gbnVtQXJncyA9PiBudW1BcmdzID09IDEgPyBcImFyZ3VtZW50XCIgOiBcImFyZ3VtZW50c1wiO1xuXG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSB3cmFwcGVyIGZ1bmN0aW9uIGZvciBhIG1ldGhvZCB3aXRoIHRoZSBnaXZlbiBuYW1lIGFuZCBtZXRhZGF0YS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZVxuICAgICAgICogICAgICAgIFRoZSBuYW1lIG9mIHRoZSBtZXRob2Qgd2hpY2ggaXMgYmVpbmcgd3JhcHBlZC5cbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBtZXRhZGF0YVxuICAgICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC5cbiAgICAgICAqIEBwYXJhbSB7aW50ZWdlcn0gbWV0YWRhdGEubWluQXJnc1xuICAgICAgICogICAgICAgIFRoZSBtaW5pbXVtIG51bWJlciBvZiBhcmd1bWVudHMgd2hpY2ggbXVzdCBiZSBwYXNzZWQgdG8gdGhlXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24uIElmIGNhbGxlZCB3aXRoIGZld2VyIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAgICogQHBhcmFtIHtpbnRlZ2VyfSBtZXRhZGF0YS5tYXhBcmdzXG4gICAgICAgKiAgICAgICAgVGhlIG1heGltdW0gbnVtYmVyIG9mIGFyZ3VtZW50cyB3aGljaCBtYXkgYmUgcGFzc2VkIHRvIHRoZVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uLiBJZiBjYWxsZWQgd2l0aCBtb3JlIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAgICogQHBhcmFtIHtpbnRlZ2VyfSBtZXRhZGF0YS5tYXhSZXNvbHZlZEFyZ3NcbiAgICAgICAqICAgICAgICBUaGUgbWF4aW11bSBudW1iZXIgb2YgYXJndW1lbnRzIHdoaWNoIG1heSBiZSBwYXNzZWQgdG8gdGhlXG4gICAgICAgKiAgICAgICAgY2FsbGJhY2sgY3JlYXRlZCBieSB0aGUgd3JhcHBlZCBhc3luYyBmdW5jdGlvbi5cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJucyB7ZnVuY3Rpb24ob2JqZWN0LCAuLi4qKX1cbiAgICAgICAqICAgICAgIFRoZSBnZW5lcmF0ZWQgd3JhcHBlciBmdW5jdGlvbi5cbiAgICAgICAqL1xuICAgICAgY29uc3Qgd3JhcEFzeW5jRnVuY3Rpb24gPSAobmFtZSwgbWV0YWRhdGEpID0+IHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGFzeW5jRnVuY3Rpb25XcmFwcGVyKHRhcmdldCwgLi4uYXJncykge1xuICAgICAgICAgIGlmIChhcmdzLmxlbmd0aCA8IG1ldGFkYXRhLm1pbkFyZ3MpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbGVhc3QgJHttZXRhZGF0YS5taW5BcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5taW5BcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGFyZ3MubGVuZ3RoID4gbWV0YWRhdGEubWF4QXJncykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBtb3N0ICR7bWV0YWRhdGEubWF4QXJnc30gJHtwbHVyYWxpemVBcmd1bWVudHMobWV0YWRhdGEubWF4QXJncyl9IGZvciAke25hbWV9KCksIGdvdCAke2FyZ3MubGVuZ3RofWApO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICBpZiAobWV0YWRhdGEuZmFsbGJhY2tUb05vQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgLy8gVGhpcyBBUEkgbWV0aG9kIGhhcyBjdXJyZW50bHkgbm8gY2FsbGJhY2sgb24gQ2hyb21lLCBidXQgaXQgcmV0dXJuIGEgcHJvbWlzZSBvbiBGaXJlZm94LFxuICAgICAgICAgICAgICAvLyBhbmQgc28gdGhlIHBvbHlmaWxsIHdpbGwgdHJ5IHRvIGNhbGwgaXQgd2l0aCBhIGNhbGxiYWNrIGZpcnN0LCBhbmQgaXQgd2lsbCBmYWxsYmFja1xuICAgICAgICAgICAgICAvLyB0byBub3QgcGFzc2luZyB0aGUgY2FsbGJhY2sgaWYgdGhlIGZpcnN0IGNhbGwgZmFpbHMuXG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MsIG1ha2VDYWxsYmFjayh7IHJlc29sdmUsIHJlamVjdCB9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgICAgICB9IGNhdGNoIChjYkVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGAke25hbWV9IEFQSSBtZXRob2QgZG9lc24ndCBzZWVtIHRvIHN1cHBvcnQgdGhlIGNhbGxiYWNrIHBhcmFtZXRlciwgYCArIFwiZmFsbGluZyBiYWNrIHRvIGNhbGwgaXQgd2l0aG91dCBhIGNhbGxiYWNrOiBcIiwgY2JFcnJvcik7XG5cbiAgICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncyk7XG5cbiAgICAgICAgICAgICAgICAvLyBVcGRhdGUgdGhlIEFQSSBtZXRob2QgbWV0YWRhdGEsIHNvIHRoYXQgdGhlIG5leHQgQVBJIGNhbGxzIHdpbGwgbm90IHRyeSB0b1xuICAgICAgICAgICAgICAgIC8vIHVzZSB0aGUgdW5zdXBwb3J0ZWQgY2FsbGJhY2sgYW55bW9yZS5cbiAgICAgICAgICAgICAgICBtZXRhZGF0YS5mYWxsYmFja1RvTm9DYWxsYmFjayA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIG1ldGFkYXRhLm5vQ2FsbGJhY2sgPSB0cnVlO1xuXG4gICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1ldGFkYXRhLm5vQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpO1xuICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHsgcmVzb2x2ZSwgcmVqZWN0IH0sIG1ldGFkYXRhKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgICB9O1xuXG4gICAgICAvKipcbiAgICAgICAqIFdyYXBzIGFuIGV4aXN0aW5nIG1ldGhvZCBvZiB0aGUgdGFyZ2V0IG9iamVjdCwgc28gdGhhdCBjYWxscyB0byBpdCBhcmVcbiAgICAgICAqIGludGVyY2VwdGVkIGJ5IHRoZSBnaXZlbiB3cmFwcGVyIGZ1bmN0aW9uLiBUaGUgd3JhcHBlciBmdW5jdGlvbiByZWNlaXZlcyxcbiAgICAgICAqIGFzIGl0cyBmaXJzdCBhcmd1bWVudCwgdGhlIG9yaWdpbmFsIGB0YXJnZXRgIG9iamVjdCwgZm9sbG93ZWQgYnkgZWFjaCBvZlxuICAgICAgICogdGhlIGFyZ3VtZW50cyBwYXNzZWQgdG8gdGhlIG9yaWdpbmFsIG1ldGhvZC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gdGFyZ2V0XG4gICAgICAgKiAgICAgICAgVGhlIG9yaWdpbmFsIHRhcmdldCBvYmplY3QgdGhhdCB0aGUgd3JhcHBlZCBtZXRob2QgYmVsb25ncyB0by5cbiAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IG1ldGhvZFxuICAgICAgICogICAgICAgIFRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC4gVGhpcyBpcyB1c2VkIGFzIHRoZSB0YXJnZXQgb2YgdGhlIFByb3h5XG4gICAgICAgKiAgICAgICAgb2JqZWN0IHdoaWNoIGlzIGNyZWF0ZWQgdG8gd3JhcCB0aGUgbWV0aG9kLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gd3JhcHBlclxuICAgICAgICogICAgICAgIFRoZSB3cmFwcGVyIGZ1bmN0aW9uIHdoaWNoIGlzIGNhbGxlZCBpbiBwbGFjZSBvZiBhIGRpcmVjdCBpbnZvY2F0aW9uXG4gICAgICAgKiAgICAgICAgb2YgdGhlIHdyYXBwZWQgbWV0aG9kLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtQcm94eTxmdW5jdGlvbj59XG4gICAgICAgKiAgICAgICAgQSBQcm94eSBvYmplY3QgZm9yIHRoZSBnaXZlbiBtZXRob2QsIHdoaWNoIGludm9rZXMgdGhlIGdpdmVuIHdyYXBwZXJcbiAgICAgICAqICAgICAgICBtZXRob2QgaW4gaXRzIHBsYWNlLlxuICAgICAgICovXG4gICAgICBjb25zdCB3cmFwTWV0aG9kID0gKHRhcmdldCwgbWV0aG9kLCB3cmFwcGVyKSA9PiB7XG4gICAgICAgIHJldHVybiBuZXcgUHJveHkobWV0aG9kLCB7XG4gICAgICAgICAgYXBwbHkodGFyZ2V0TWV0aG9kLCB0aGlzT2JqLCBhcmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gd3JhcHBlci5jYWxsKHRoaXNPYmosIHRhcmdldCwgLi4uYXJncyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH07XG5cbiAgICAgIGxldCBoYXNPd25Qcm9wZXJ0eSA9IEZ1bmN0aW9uLmNhbGwuYmluZChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5KTtcblxuICAgICAgLyoqXG4gICAgICAgKiBXcmFwcyBhbiBvYmplY3QgaW4gYSBQcm94eSB3aGljaCBpbnRlcmNlcHRzIGFuZCB3cmFwcyBjZXJ0YWluIG1ldGhvZHNcbiAgICAgICAqIGJhc2VkIG9uIHRoZSBnaXZlbiBgd3JhcHBlcnNgIGFuZCBgbWV0YWRhdGFgIG9iamVjdHMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IHRhcmdldFxuICAgICAgICogICAgICAgIFRoZSB0YXJnZXQgb2JqZWN0IHRvIHdyYXAuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IFt3cmFwcGVycyA9IHt9XVxuICAgICAgICogICAgICAgIEFuIG9iamVjdCB0cmVlIGNvbnRhaW5pbmcgd3JhcHBlciBmdW5jdGlvbnMgZm9yIHNwZWNpYWwgY2FzZXMuIEFueVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uIHByZXNlbnQgaW4gdGhpcyBvYmplY3QgdHJlZSBpcyBjYWxsZWQgaW4gcGxhY2Ugb2YgdGhlXG4gICAgICAgKiAgICAgICAgbWV0aG9kIGluIHRoZSBzYW1lIGxvY2F0aW9uIGluIHRoZSBgdGFyZ2V0YCBvYmplY3QgdHJlZS4gVGhlc2VcbiAgICAgICAqICAgICAgICB3cmFwcGVyIG1ldGhvZHMgYXJlIGludm9rZWQgYXMgZGVzY3JpYmVkIGluIHtAc2VlIHdyYXBNZXRob2R9LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBbbWV0YWRhdGEgPSB7fV1cbiAgICAgICAqICAgICAgICBBbiBvYmplY3QgdHJlZSBjb250YWluaW5nIG1ldGFkYXRhIHVzZWQgdG8gYXV0b21hdGljYWxseSBnZW5lcmF0ZVxuICAgICAgICogICAgICAgIFByb21pc2UtYmFzZWQgd3JhcHBlciBmdW5jdGlvbnMgZm9yIGFzeW5jaHJvbm91cy4gQW55IGZ1bmN0aW9uIGluXG4gICAgICAgKiAgICAgICAgdGhlIGB0YXJnZXRgIG9iamVjdCB0cmVlIHdoaWNoIGhhcyBhIGNvcnJlc3BvbmRpbmcgbWV0YWRhdGEgb2JqZWN0XG4gICAgICAgKiAgICAgICAgaW4gdGhlIHNhbWUgbG9jYXRpb24gaW4gdGhlIGBtZXRhZGF0YWAgdHJlZSBpcyByZXBsYWNlZCB3aXRoIGFuXG4gICAgICAgKiAgICAgICAgYXV0b21hdGljYWxseS1nZW5lcmF0ZWQgd3JhcHBlciBmdW5jdGlvbiwgYXMgZGVzY3JpYmVkIGluXG4gICAgICAgKiAgICAgICAge0BzZWUgd3JhcEFzeW5jRnVuY3Rpb259XG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge1Byb3h5PG9iamVjdD59XG4gICAgICAgKi9cbiAgICAgIGNvbnN0IHdyYXBPYmplY3QgPSAodGFyZ2V0LCB3cmFwcGVycyA9IHt9LCBtZXRhZGF0YSA9IHt9KSA9PiB7XG4gICAgICAgIGxldCBjYWNoZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgIGxldCBoYW5kbGVycyA9IHtcbiAgICAgICAgICBoYXMocHJveHlUYXJnZXQsIHByb3ApIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9wIGluIHRhcmdldCB8fCBwcm9wIGluIGNhY2hlO1xuICAgICAgICAgIH0sXG5cbiAgICAgICAgICBnZXQocHJveHlUYXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgICBpZiAocHJvcCBpbiBjYWNoZSkge1xuICAgICAgICAgICAgICByZXR1cm4gY2FjaGVbcHJvcF07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghKHByb3AgaW4gdGFyZ2V0KSkge1xuICAgICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBsZXQgdmFsdWUgPSB0YXJnZXRbcHJvcF07XG5cbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAvLyBUaGlzIGlzIGEgbWV0aG9kIG9uIHRoZSB1bmRlcmx5aW5nIG9iamVjdC4gQ2hlY2sgaWYgd2UgbmVlZCB0byBkb1xuICAgICAgICAgICAgICAvLyBhbnkgd3JhcHBpbmcuXG5cbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiB3cmFwcGVyc1twcm9wXSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgICAgLy8gV2UgaGF2ZSBhIHNwZWNpYWwtY2FzZSB3cmFwcGVyIGZvciB0aGlzIG1ldGhvZC5cbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBNZXRob2QodGFyZ2V0LCB0YXJnZXRbcHJvcF0sIHdyYXBwZXJzW3Byb3BdKTtcbiAgICAgICAgICAgICAgfSBlbHNlIGlmIChoYXNPd25Qcm9wZXJ0eShtZXRhZGF0YSwgcHJvcCkpIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIGFzeW5jIG1ldGhvZCB0aGF0IHdlIGhhdmUgbWV0YWRhdGEgZm9yLiBDcmVhdGUgYVxuICAgICAgICAgICAgICAgIC8vIFByb21pc2Ugd3JhcHBlciBmb3IgaXQuXG4gICAgICAgICAgICAgICAgbGV0IHdyYXBwZXIgPSB3cmFwQXN5bmNGdW5jdGlvbihwcm9wLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwTWV0aG9kKHRhcmdldCwgdGFyZ2V0W3Byb3BdLCB3cmFwcGVyKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGEgbWV0aG9kIHRoYXQgd2UgZG9uJ3Qga25vdyBvciBjYXJlIGFib3V0LiBSZXR1cm4gdGhlXG4gICAgICAgICAgICAgICAgLy8gb3JpZ2luYWwgbWV0aG9kLCBib3VuZCB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS5iaW5kKHRhcmdldCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsICYmIChoYXNPd25Qcm9wZXJ0eSh3cmFwcGVycywgcHJvcCkgfHwgaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIHByb3ApKSkge1xuICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIG9iamVjdCB0aGF0IHdlIG5lZWQgdG8gZG8gc29tZSB3cmFwcGluZyBmb3IgdGhlIGNoaWxkcmVuXG4gICAgICAgICAgICAgIC8vIG9mLiBDcmVhdGUgYSBzdWItb2JqZWN0IHdyYXBwZXIgZm9yIGl0IHdpdGggdGhlIGFwcHJvcHJpYXRlIGNoaWxkXG4gICAgICAgICAgICAgIC8vIG1ldGFkYXRhLlxuICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBPYmplY3QodmFsdWUsIHdyYXBwZXJzW3Byb3BdLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAvLyBXZSBkb24ndCBuZWVkIHRvIGRvIGFueSB3cmFwcGluZyBmb3IgdGhpcyBwcm9wZXJ0eSxcbiAgICAgICAgICAgICAgLy8gc28ganVzdCBmb3J3YXJkIGFsbCBhY2Nlc3MgdG8gdGhlIHVuZGVybHlpbmcgb2JqZWN0LlxuICAgICAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2FjaGUsIHByb3AsIHtcbiAgICAgICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBnZXQoKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gdGFyZ2V0W3Byb3BdO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgc2V0KHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICB0YXJnZXRbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY2FjaGVbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICB9LFxuXG4gICAgICAgICAgc2V0KHByb3h5VGFyZ2V0LCBwcm9wLCB2YWx1ZSwgcmVjZWl2ZXIpIHtcbiAgICAgICAgICAgIGlmIChwcm9wIGluIGNhY2hlKSB7XG4gICAgICAgICAgICAgIGNhY2hlW3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0YXJnZXRbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH0sXG5cbiAgICAgICAgICBkZWZpbmVQcm9wZXJ0eShwcm94eVRhcmdldCwgcHJvcCwgZGVzYykge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuZGVmaW5lUHJvcGVydHkoY2FjaGUsIHByb3AsIGRlc2MpO1xuICAgICAgICAgIH0sXG5cbiAgICAgICAgICBkZWxldGVQcm9wZXJ0eShwcm94eVRhcmdldCwgcHJvcCkge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuZGVsZXRlUHJvcGVydHkoY2FjaGUsIHByb3ApO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvLyBQZXIgY29udHJhY3Qgb2YgdGhlIFByb3h5IEFQSSwgdGhlIFwiZ2V0XCIgcHJveHkgaGFuZGxlciBtdXN0IHJldHVybiB0aGVcbiAgICAgICAgLy8gb3JpZ2luYWwgdmFsdWUgb2YgdGhlIHRhcmdldCBpZiB0aGF0IHZhbHVlIGlzIGRlY2xhcmVkIHJlYWQtb25seSBhbmRcbiAgICAgICAgLy8gbm9uLWNvbmZpZ3VyYWJsZS4gRm9yIHRoaXMgcmVhc29uLCB3ZSBjcmVhdGUgYW4gb2JqZWN0IHdpdGggdGhlXG4gICAgICAgIC8vIHByb3RvdHlwZSBzZXQgdG8gYHRhcmdldGAgaW5zdGVhZCBvZiB1c2luZyBgdGFyZ2V0YCBkaXJlY3RseS5cbiAgICAgICAgLy8gT3RoZXJ3aXNlIHdlIGNhbm5vdCByZXR1cm4gYSBjdXN0b20gb2JqZWN0IGZvciBBUElzIHRoYXRcbiAgICAgICAgLy8gYXJlIGRlY2xhcmVkIHJlYWQtb25seSBhbmQgbm9uLWNvbmZpZ3VyYWJsZSwgc3VjaCBhcyBgY2hyb21lLmRldnRvb2xzYC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gVGhlIHByb3h5IGhhbmRsZXJzIHRoZW1zZWx2ZXMgd2lsbCBzdGlsbCB1c2UgdGhlIG9yaWdpbmFsIGB0YXJnZXRgXG4gICAgICAgIC8vIGluc3RlYWQgb2YgdGhlIGBwcm94eVRhcmdldGAsIHNvIHRoYXQgdGhlIG1ldGhvZHMgYW5kIHByb3BlcnRpZXMgYXJlXG4gICAgICAgIC8vIGRlcmVmZXJlbmNlZCB2aWEgdGhlIG9yaWdpbmFsIHRhcmdldHMuXG4gICAgICAgIGxldCBwcm94eVRhcmdldCA9IE9iamVjdC5jcmVhdGUodGFyZ2V0KTtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm94eShwcm94eVRhcmdldCwgaGFuZGxlcnMpO1xuICAgICAgfTtcblxuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGEgc2V0IG9mIHdyYXBwZXIgZnVuY3Rpb25zIGZvciBhbiBldmVudCBvYmplY3QsIHdoaWNoIGhhbmRsZXNcbiAgICAgICAqIHdyYXBwaW5nIG9mIGxpc3RlbmVyIGZ1bmN0aW9ucyB0aGF0IHRob3NlIG1lc3NhZ2VzIGFyZSBwYXNzZWQuXG4gICAgICAgKlxuICAgICAgICogQSBzaW5nbGUgd3JhcHBlciBpcyBjcmVhdGVkIGZvciBlYWNoIGxpc3RlbmVyIGZ1bmN0aW9uLCBhbmQgc3RvcmVkIGluIGFcbiAgICAgICAqIG1hcC4gU3Vic2VxdWVudCBjYWxscyB0byBgYWRkTGlzdGVuZXJgLCBgaGFzTGlzdGVuZXJgLCBvciBgcmVtb3ZlTGlzdGVuZXJgXG4gICAgICAgKiByZXRyaWV2ZSB0aGUgb3JpZ2luYWwgd3JhcHBlciwgc28gdGhhdCAgYXR0ZW1wdHMgdG8gcmVtb3ZlIGFcbiAgICAgICAqIHByZXZpb3VzbHktYWRkZWQgbGlzdGVuZXIgd29yayBhcyBleHBlY3RlZC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0RlZmF1bHRXZWFrTWFwPGZ1bmN0aW9uLCBmdW5jdGlvbj59IHdyYXBwZXJNYXBcbiAgICAgICAqICAgICAgICBBIERlZmF1bHRXZWFrTWFwIG9iamVjdCB3aGljaCB3aWxsIGNyZWF0ZSB0aGUgYXBwcm9wcmlhdGUgd3JhcHBlclxuICAgICAgICogICAgICAgIGZvciBhIGdpdmVuIGxpc3RlbmVyIGZ1bmN0aW9uIHdoZW4gb25lIGRvZXMgbm90IGV4aXN0LCBhbmQgcmV0cmlldmVcbiAgICAgICAqICAgICAgICBhbiBleGlzdGluZyBvbmUgd2hlbiBpdCBkb2VzLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtvYmplY3R9XG4gICAgICAgKi9cbiAgICAgIGNvbnN0IHdyYXBFdmVudCA9IHdyYXBwZXJNYXAgPT4gKHtcbiAgICAgICAgYWRkTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lciwgLi4uYXJncykge1xuICAgICAgICAgIHRhcmdldC5hZGRMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lciksIC4uLmFyZ3MpO1xuICAgICAgICB9LFxuXG4gICAgICAgIGhhc0xpc3RlbmVyKHRhcmdldCwgbGlzdGVuZXIpIHtcbiAgICAgICAgICByZXR1cm4gdGFyZ2V0Lmhhc0xpc3RlbmVyKHdyYXBwZXJNYXAuZ2V0KGxpc3RlbmVyKSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVtb3ZlTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lcikge1xuICAgICAgICAgIHRhcmdldC5yZW1vdmVMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lcikpO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgLy8gS2VlcCB0cmFjayBpZiB0aGUgZGVwcmVjYXRpb24gd2FybmluZyBoYXMgYmVlbiBsb2dnZWQgYXQgbGVhc3Qgb25jZS5cbiAgICAgIGxldCBsb2dnZWRTZW5kUmVzcG9uc2VEZXByZWNhdGlvbldhcm5pbmcgPSBmYWxzZTtcblxuICAgICAgY29uc3Qgb25NZXNzYWdlV3JhcHBlcnMgPSBuZXcgRGVmYXVsdFdlYWtNYXAobGlzdGVuZXIgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIGxpc3RlbmVyICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICByZXR1cm4gbGlzdGVuZXI7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogV3JhcHMgYSBtZXNzYWdlIGxpc3RlbmVyIGZ1bmN0aW9uIHNvIHRoYXQgaXQgbWF5IHNlbmQgcmVzcG9uc2VzIGJhc2VkIG9uXG4gICAgICAgICAqIGl0cyByZXR1cm4gdmFsdWUsIHJhdGhlciB0aGFuIGJ5IHJldHVybmluZyBhIHNlbnRpbmVsIHZhbHVlIGFuZCBjYWxsaW5nIGFcbiAgICAgICAgICogY2FsbGJhY2suIElmIHRoZSBsaXN0ZW5lciBmdW5jdGlvbiByZXR1cm5zIGEgUHJvbWlzZSwgdGhlIHJlc3BvbnNlIGlzXG4gICAgICAgICAqIHNlbnQgd2hlbiB0aGUgcHJvbWlzZSBlaXRoZXIgcmVzb2x2ZXMgb3IgcmVqZWN0cy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHsqfSBtZXNzYWdlXG4gICAgICAgICAqICAgICAgICBUaGUgbWVzc2FnZSBzZW50IGJ5IHRoZSBvdGhlciBlbmQgb2YgdGhlIGNoYW5uZWwuXG4gICAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBzZW5kZXJcbiAgICAgICAgICogICAgICAgIERldGFpbHMgYWJvdXQgdGhlIHNlbmRlciBvZiB0aGUgbWVzc2FnZS5cbiAgICAgICAgICogQHBhcmFtIHtmdW5jdGlvbigqKX0gc2VuZFJlc3BvbnNlXG4gICAgICAgICAqICAgICAgICBBIGNhbGxiYWNrIHdoaWNoLCB3aGVuIGNhbGxlZCB3aXRoIGFuIGFyYml0cmFyeSBhcmd1bWVudCwgc2VuZHNcbiAgICAgICAgICogICAgICAgIHRoYXQgdmFsdWUgYXMgYSByZXNwb25zZS5cbiAgICAgICAgICogQHJldHVybnMge2Jvb2xlYW59XG4gICAgICAgICAqICAgICAgICBUcnVlIGlmIHRoZSB3cmFwcGVkIGxpc3RlbmVyIHJldHVybmVkIGEgUHJvbWlzZSwgd2hpY2ggd2lsbCBsYXRlclxuICAgICAgICAgKiAgICAgICAgeWllbGQgYSByZXNwb25zZS4gRmFsc2Ugb3RoZXJ3aXNlLlxuICAgICAgICAgKi9cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIG9uTWVzc2FnZShtZXNzYWdlLCBzZW5kZXIsIHNlbmRSZXNwb25zZSkge1xuICAgICAgICAgIGxldCBkaWRDYWxsU2VuZFJlc3BvbnNlID0gZmFsc2U7XG5cbiAgICAgICAgICBsZXQgd3JhcHBlZFNlbmRSZXNwb25zZTtcbiAgICAgICAgICBsZXQgc2VuZFJlc3BvbnNlUHJvbWlzZSA9IG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgICAgICAgICAgd3JhcHBlZFNlbmRSZXNwb25zZSA9IGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICBpZiAoIWxvZ2dlZFNlbmRSZXNwb25zZURlcHJlY2F0aW9uV2FybmluZykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihTRU5EX1JFU1BPTlNFX0RFUFJFQ0FUSU9OX1dBUk5JTkcsIG5ldyBFcnJvcigpLnN0YWNrKTtcbiAgICAgICAgICAgICAgICBsb2dnZWRTZW5kUmVzcG9uc2VEZXByZWNhdGlvbldhcm5pbmcgPSB0cnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGRpZENhbGxTZW5kUmVzcG9uc2UgPSB0cnVlO1xuICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBsZXQgcmVzdWx0O1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXN1bHQgPSBsaXN0ZW5lcihtZXNzYWdlLCBzZW5kZXIsIHdyYXBwZWRTZW5kUmVzcG9uc2UpO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgcmVzdWx0ID0gUHJvbWlzZS5yZWplY3QoZXJyKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCBpc1Jlc3VsdFRoZW5hYmxlID0gcmVzdWx0ICE9PSB0cnVlICYmIGlzVGhlbmFibGUocmVzdWx0KTtcblxuICAgICAgICAgIC8vIElmIHRoZSBsaXN0ZW5lciBkaWRuJ3QgcmV0dXJuZWQgdHJ1ZSBvciBhIFByb21pc2UsIG9yIGNhbGxlZFxuICAgICAgICAgIC8vIHdyYXBwZWRTZW5kUmVzcG9uc2Ugc3luY2hyb25vdXNseSwgd2UgY2FuIGV4aXQgZWFybGllclxuICAgICAgICAgIC8vIGJlY2F1c2UgdGhlcmUgd2lsbCBiZSBubyByZXNwb25zZSBzZW50IGZyb20gdGhpcyBsaXN0ZW5lci5cbiAgICAgICAgICBpZiAocmVzdWx0ICE9PSB0cnVlICYmICFpc1Jlc3VsdFRoZW5hYmxlICYmICFkaWRDYWxsU2VuZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gQSBzbWFsbCBoZWxwZXIgdG8gc2VuZCB0aGUgbWVzc2FnZSBpZiB0aGUgcHJvbWlzZSByZXNvbHZlc1xuICAgICAgICAgIC8vIGFuZCBhbiBlcnJvciBpZiB0aGUgcHJvbWlzZSByZWplY3RzIChhIHdyYXBwZWQgc2VuZE1lc3NhZ2UgaGFzXG4gICAgICAgICAgLy8gdG8gdHJhbnNsYXRlIHRoZSBtZXNzYWdlIGludG8gYSByZXNvbHZlZCBwcm9taXNlIG9yIGEgcmVqZWN0ZWRcbiAgICAgICAgICAvLyBwcm9taXNlKS5cbiAgICAgICAgICBjb25zdCBzZW5kUHJvbWlzZWRSZXN1bHQgPSBwcm9taXNlID0+IHtcbiAgICAgICAgICAgIHByb21pc2UudGhlbihtc2cgPT4ge1xuICAgICAgICAgICAgICAvLyBzZW5kIHRoZSBtZXNzYWdlIHZhbHVlLlxuICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UobXNnKTtcbiAgICAgICAgICAgIH0sIGVycm9yID0+IHtcbiAgICAgICAgICAgICAgLy8gU2VuZCBhIEpTT04gcmVwcmVzZW50YXRpb24gb2YgdGhlIGVycm9yIGlmIHRoZSByZWplY3RlZCB2YWx1ZVxuICAgICAgICAgICAgICAvLyBpcyBhbiBpbnN0YW5jZSBvZiBlcnJvciwgb3IgdGhlIG9iamVjdCBpdHNlbGYgb3RoZXJ3aXNlLlxuICAgICAgICAgICAgICBsZXQgbWVzc2FnZTtcbiAgICAgICAgICAgICAgaWYgKGVycm9yICYmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yIHx8IHR5cGVvZiBlcnJvci5tZXNzYWdlID09PSBcInN0cmluZ1wiKSkge1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWRcIjtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7XG4gICAgICAgICAgICAgICAgX19tb3pXZWJFeHRlbnNpb25Qb2x5ZmlsbFJlamVjdF9fOiB0cnVlLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2VcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgICAgICAvLyBQcmludCBhbiBlcnJvciBvbiB0aGUgY29uc29sZSBpZiB1bmFibGUgdG8gc2VuZCB0aGUgcmVzcG9uc2UuXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc2VuZCBvbk1lc3NhZ2UgcmVqZWN0ZWQgcmVwbHlcIiwgZXJyKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvLyBJZiB0aGUgbGlzdGVuZXIgcmV0dXJuZWQgYSBQcm9taXNlLCBzZW5kIHRoZSByZXNvbHZlZCB2YWx1ZSBhcyBhXG4gICAgICAgICAgLy8gcmVzdWx0LCBvdGhlcndpc2Ugd2FpdCB0aGUgcHJvbWlzZSByZWxhdGVkIHRvIHRoZSB3cmFwcGVkU2VuZFJlc3BvbnNlXG4gICAgICAgICAgLy8gY2FsbGJhY2sgdG8gcmVzb2x2ZSBhbmQgc2VuZCBpdCBhcyBhIHJlc3BvbnNlLlxuICAgICAgICAgIGlmIChpc1Jlc3VsdFRoZW5hYmxlKSB7XG4gICAgICAgICAgICBzZW5kUHJvbWlzZWRSZXN1bHQocmVzdWx0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2VuZFByb21pc2VkUmVzdWx0KHNlbmRSZXNwb25zZVByb21pc2UpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIExldCBDaHJvbWUga25vdyB0aGF0IHRoZSBsaXN0ZW5lciBpcyByZXBseWluZy5cbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCB3cmFwcGVkU2VuZE1lc3NhZ2VDYWxsYmFjayA9ICh7IHJlamVjdCwgcmVzb2x2ZSB9LCByZXBseSkgPT4ge1xuICAgICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgIC8vIERldGVjdCB3aGVuIG5vbmUgb2YgdGhlIGxpc3RlbmVycyByZXBsaWVkIHRvIHRoZSBzZW5kTWVzc2FnZSBjYWxsIGFuZCByZXNvbHZlXG4gICAgICAgICAgLy8gdGhlIHByb21pc2UgdG8gdW5kZWZpbmVkIGFzIGluIEZpcmVmb3guXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tb3ppbGxhL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9pc3N1ZXMvMTMwXG4gICAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSA9PT0gQ0hST01FX1NFTkRfTUVTU0FHRV9DQUxMQkFDS19OT19SRVNQT05TRV9NRVNTQUdFKSB7XG4gICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlamVjdChleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAocmVwbHkgJiYgcmVwbHkuX19tb3pXZWJFeHRlbnNpb25Qb2x5ZmlsbFJlamVjdF9fKSB7XG4gICAgICAgICAgLy8gQ29udmVydCBiYWNrIHRoZSBKU09OIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBlcnJvciBpbnRvXG4gICAgICAgICAgLy8gYW4gRXJyb3IgaW5zdGFuY2UuXG4gICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihyZXBseS5tZXNzYWdlKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzb2x2ZShyZXBseSk7XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHdyYXBwZWRTZW5kTWVzc2FnZSA9IChuYW1lLCBtZXRhZGF0YSwgYXBpTmFtZXNwYWNlT2JqLCAuLi5hcmdzKSA9PiB7XG4gICAgICAgIGlmIChhcmdzLmxlbmd0aCA8IG1ldGFkYXRhLm1pbkFyZ3MpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IGxlYXN0ICR7bWV0YWRhdGEubWluQXJnc30gJHtwbHVyYWxpemVBcmd1bWVudHMobWV0YWRhdGEubWluQXJncyl9IGZvciAke25hbWV9KCksIGdvdCAke2FyZ3MubGVuZ3RofWApO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGFyZ3MubGVuZ3RoID4gbWV0YWRhdGEubWF4QXJncykge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbW9zdCAke21ldGFkYXRhLm1heEFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1heEFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgY29uc3Qgd3JhcHBlZENiID0gd3JhcHBlZFNlbmRNZXNzYWdlQ2FsbGJhY2suYmluZChudWxsLCB7IHJlc29sdmUsIHJlamVjdCB9KTtcbiAgICAgICAgICBhcmdzLnB1c2god3JhcHBlZENiKTtcbiAgICAgICAgICBhcGlOYW1lc3BhY2VPYmouc2VuZE1lc3NhZ2UoLi4uYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgfTtcblxuICAgICAgY29uc3Qgc3RhdGljV3JhcHBlcnMgPSB7XG4gICAgICAgIHJ1bnRpbWU6IHtcbiAgICAgICAgICBvbk1lc3NhZ2U6IHdyYXBFdmVudChvbk1lc3NhZ2VXcmFwcGVycyksXG4gICAgICAgICAgb25NZXNzYWdlRXh0ZXJuYWw6IHdyYXBFdmVudChvbk1lc3NhZ2VXcmFwcGVycyksXG4gICAgICAgICAgc2VuZE1lc3NhZ2U6IHdyYXBwZWRTZW5kTWVzc2FnZS5iaW5kKG51bGwsIFwic2VuZE1lc3NhZ2VcIiwgeyBtaW5BcmdzOiAxLCBtYXhBcmdzOiAzIH0pXG4gICAgICAgIH0sXG4gICAgICAgIHRhYnM6IHtcbiAgICAgICAgICBzZW5kTWVzc2FnZTogd3JhcHBlZFNlbmRNZXNzYWdlLmJpbmQobnVsbCwgXCJzZW5kTWVzc2FnZVwiLCB7IG1pbkFyZ3M6IDIsIG1heEFyZ3M6IDMgfSlcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IHNldHRpbmdNZXRhZGF0YSA9IHtcbiAgICAgICAgY2xlYXI6IHsgbWluQXJnczogMSwgbWF4QXJnczogMSB9LFxuICAgICAgICBnZXQ6IHsgbWluQXJnczogMSwgbWF4QXJnczogMSB9LFxuICAgICAgICBzZXQ6IHsgbWluQXJnczogMSwgbWF4QXJnczogMSB9XG4gICAgICB9O1xuICAgICAgYXBpTWV0YWRhdGEucHJpdmFjeSA9IHtcbiAgICAgICAgbmV0d29yazoge1xuICAgICAgICAgIG5ldHdvcmtQcmVkaWN0aW9uRW5hYmxlZDogc2V0dGluZ01ldGFkYXRhLFxuICAgICAgICAgIHdlYlJUQ0lQSGFuZGxpbmdQb2xpY3k6IHNldHRpbmdNZXRhZGF0YVxuICAgICAgICB9LFxuICAgICAgICBzZXJ2aWNlczoge1xuICAgICAgICAgIHBhc3N3b3JkU2F2aW5nRW5hYmxlZDogc2V0dGluZ01ldGFkYXRhXG4gICAgICAgIH0sXG4gICAgICAgIHdlYnNpdGVzOiB7XG4gICAgICAgICAgaHlwZXJsaW5rQXVkaXRpbmdFbmFibGVkOiBzZXR0aW5nTWV0YWRhdGEsXG4gICAgICAgICAgcmVmZXJyZXJzRW5hYmxlZDogc2V0dGluZ01ldGFkYXRhXG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIHJldHVybiB3cmFwT2JqZWN0KGV4dGVuc2lvbkFQSXMsIHN0YXRpY1dyYXBwZXJzLCBhcGlNZXRhZGF0YSk7XG4gICAgfTtcblxuICAgIC8vIFRoZSBidWlsZCBwcm9jZXNzIGFkZHMgYSBVTUQgd3JhcHBlciBhcm91bmQgdGhpcyBmaWxlLCB3aGljaCBtYWtlcyB0aGVcbiAgICAvLyBgbW9kdWxlYCB2YXJpYWJsZSBhdmFpbGFibGUuXG4gICAgbW9kdWxlLmV4cG9ydHMgPSB3cmFwQVBJcyhjaHJvbWUpO1xuICB9IGVsc2Uge1xuICAgIG1vZHVsZS5leHBvcnRzID0gYnJvd3NlcjtcbiAgfVxufSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1icm93c2VyLXBvbHlmaWxsLmpzLm1hcFxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IHsgU1dJVENIX09OLCBTV0lUQ0hfTE9DS0VEX09OLCBTV0lUQ0hfT0ZGLCBTV0lUQ0hfTE9DS0VEX09GRiB9IGZyb20gXCIuL29wdGlvbnMvc3RhdGVzXCJcbmV4cG9ydCB7IFNXSVRDSF9PTiwgU1dJVENIX0xPQ0tFRF9PTiwgU1dJVENIX09GRiwgU1dJVENIX0xPQ0tFRF9PRkYgfVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3B0aW9ucygpIHtcbiAgICByZXR1cm4gYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChbXCJvcHRpb25zXCJdKS50aGVuKGRhdGEgPT4gZGF0YS5vcHRpb25zKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldE9wdGlvbnMob3B0aW9ucykge1xuICAgIHJldHVybiBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgb3B0aW9uczogb3B0aW9ucyB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHN0Ym9vbChzd2l0Y2hfc3RhdGUpIHtcbiAgICBzd2l0Y2ggKHN3aXRjaF9zdGF0ZSkge1xuICAgICAgICBjYXNlIFNXSVRDSF9PTjpcbiAgICAgICAgY2FzZSBTV0lUQ0hfTE9DS0VEX09OOlxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIGNhc2UgU1dJVENIX09GRjpcbiAgICAgICAgY2FzZSBTV0lUQ0hfTE9DS0VEX09GRjpcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBUYXJnZXRCcm93c2VyIH0gZnJvbSBcIlBvbHlmaWxsXCJcblxuZXhwb3J0IGNvbnN0IFNXSVRDSF9PTiA9IDE7XG5leHBvcnQgY29uc3QgU1dJVENIX0xPQ0tFRF9PTiA9IDI7XG5leHBvcnQgY29uc3QgU1dJVENIX09GRiA9IDA7XG5leHBvcnQgY29uc3QgU1dJVENIX0xPQ0tFRF9PRkYgPSAtMTtcblxuZXhwb3J0IGNvbnN0IElOSVRJQUxfT1BUSU9OUyA9IHtcbiAgICBwb3B1cDoge1xuICAgICAgICBzaXplOiB7XG4gICAgICAgICAgICB3aWR0aDogNzMwLFxuICAgICAgICAgICAgaGVpZ2h0OiA0NTBcbiAgICAgICAgfSxcbiAgICAgICAgc2NhbGU6IDEuMCxcbiAgICAgICAgc2hvd0RldGFpbHM6IFNXSVRDSF9PTixcbiAgICAgICAgc2hvd1ByZXZpZXc6IFNXSVRDSF9PTixcbiAgICAgICAgaGlkZUFmdGVyVGFiU2VsZWN0aW9uOiBTV0lUQ0hfT04sXG4gICAgICAgIHNlYXJjaEluVVJMczogU1dJVENIX09GRlxuICAgIH1cbn07XG5pZiAoVGFyZ2V0QnJvd3NlciA9PT0gXCJjaHJvbWVcIikge1xuICAgIElOSVRJQUxfT1BUSU9OUy5wb3B1cC5zaG93UHJldmlldyA9IFNXSVRDSF9MT0NLRURfT0ZGO1xuICAgIElOSVRJQUxfT1BUSU9OUy5wb3B1cC5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb24gPSBTV0lUQ0hfTE9DS0VEX09OO1xufVxuIiwiZXhwb3J0IGNvbnN0IFRhcmdldEJyb3dzZXIgPSBUQVJHRVQ7XG5cbmlmIChUQVJHRVQgPT09IFwiY2hyb21lXCIpIHtcbiAgICB3aW5kb3dbXCJicm93c2VyXCJdID0gcmVxdWlyZShcIndlYmV4dGVuc2lvbi1wb2x5ZmlsbFwiKTtcbn1cblxuaWYgKCFBcnJheS5mcm9tKSB7XG4gICAgQXJyYXkuZnJvbSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgIGxldCB0b1N0ciA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG4gICAgICAgIGxldCBpc0NhbGxhYmxlID0gZnVuY3Rpb24gKGZuKSB7XG4gICAgICAgICAgICByZXR1cm4gdHlwZW9mIGZuID09PSAnZnVuY3Rpb24nIHx8IHRvU3RyLmNhbGwoZm4pID09PSAnW29iamVjdCBGdW5jdGlvbl0nO1xuICAgICAgICB9O1xuICAgICAgICBsZXQgdG9JbnRlZ2VyID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBsZXQgbnVtYmVyID0gTnVtYmVyKHZhbHVlKTtcbiAgICAgICAgICAgIGlmIChpc05hTihudW1iZXIpKSB7IHJldHVybiAwOyB9XG4gICAgICAgICAgICBpZiAobnVtYmVyID09PSAwIHx8ICFpc0Zpbml0ZShudW1iZXIpKSB7IHJldHVybiBudW1iZXI7IH1cbiAgICAgICAgICAgIHJldHVybiAobnVtYmVyID4gMCA/IDEgOiAtMSkgKiBNYXRoLmZsb29yKE1hdGguYWJzKG51bWJlcikpO1xuICAgICAgICB9O1xuICAgICAgICBsZXQgbWF4U2FmZUludGVnZXIgPSBNYXRoLnBvdygyLCA1MykgLSAxO1xuICAgICAgICBsZXQgdG9MZW5ndGggPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIGxldCBsZW4gPSB0b0ludGVnZXIodmFsdWUpO1xuICAgICAgICAgICAgcmV0dXJuIE1hdGgubWluKE1hdGgubWF4KGxlbiwgMCksIG1heFNhZmVJbnRlZ2VyKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvLyBUaGUgbGVuZ3RoIHByb3BlcnR5IG9mIHRoZSBmcm9tIG1ldGhvZCBpcyAxLlxuICAgICAgICByZXR1cm4gZnVuY3Rpb24gZnJvbShhcnJheUxpa2UvKiwgbWFwRm4sIHRoaXNBcmcgKi8pIHtcbiAgICAgICAgICAgIC8vIDEuIExldCBDIGJlIHRoZSB0aGlzIHZhbHVlLlxuICAgICAgICAgICAgbGV0IEMgPSB0aGlzO1xuXG4gICAgICAgICAgICAvLyAyLiBMZXQgaXRlbXMgYmUgVG9PYmplY3QoYXJyYXlMaWtlKS5cbiAgICAgICAgICAgIGxldCBpdGVtcyA9IE9iamVjdChhcnJheUxpa2UpO1xuXG4gICAgICAgICAgICAvLyAzLiBSZXR1cm5JZkFicnVwdChpdGVtcykuXG4gICAgICAgICAgICBpZiAoYXJyYXlMaWtlID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBcnJheS5mcm9tIHJlcXVpcmVzIGFuIGFycmF5LWxpa2Ugb2JqZWN0IC0gbm90IG51bGwgb3IgdW5kZWZpbmVkJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIDQuIElmIG1hcGZuIGlzIHVuZGVmaW5lZCwgdGhlbiBsZXQgbWFwcGluZyBiZSBmYWxzZS5cbiAgICAgICAgICAgIGxldCBtYXBGbiA9IGFyZ3VtZW50cy5sZW5ndGggPiAxID8gYXJndW1lbnRzWzFdIDogdm9pZCB1bmRlZmluZWQ7XG4gICAgICAgICAgICBsZXQgVDtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWFwRm4gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgLy8gNS4gZWxzZVxuICAgICAgICAgICAgICAgIC8vIDUuIGEgSWYgSXNDYWxsYWJsZShtYXBmbikgaXMgZmFsc2UsIHRocm93IGEgVHlwZUVycm9yIGV4Y2VwdGlvbi5cbiAgICAgICAgICAgICAgICBpZiAoIWlzQ2FsbGFibGUobWFwRm4pKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0FycmF5LmZyb206IHdoZW4gcHJvdmlkZWQsIHRoZSBzZWNvbmQgYXJndW1lbnQgbXVzdCBiZSBhIGZ1bmN0aW9uJyk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLy8gNS4gYi4gSWYgdGhpc0FyZyB3YXMgc3VwcGxpZWQsIGxldCBUIGJlIHRoaXNBcmc7IGVsc2UgbGV0IFQgYmUgdW5kZWZpbmVkLlxuICAgICAgICAgICAgICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID4gMikge1xuICAgICAgICAgICAgICAgICAgICBUID0gYXJndW1lbnRzWzJdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gMTAuIExldCBsZW5WYWx1ZSBiZSBHZXQoaXRlbXMsIFwibGVuZ3RoXCIpLlxuICAgICAgICAgICAgLy8gMTEuIExldCBsZW4gYmUgVG9MZW5ndGgobGVuVmFsdWUpLlxuICAgICAgICAgICAgbGV0IGxlbiA9IHRvTGVuZ3RoKGl0ZW1zLmxlbmd0aCk7XG5cbiAgICAgICAgICAgIC8vIDEzLiBJZiBJc0NvbnN0cnVjdG9yKEMpIGlzIHRydWUsIHRoZW5cbiAgICAgICAgICAgIC8vIDEzLiBhLiBMZXQgQSBiZSB0aGUgcmVzdWx0IG9mIGNhbGxpbmcgdGhlIFtbQ29uc3RydWN0XV0gaW50ZXJuYWwgbWV0aG9kIFxuICAgICAgICAgICAgLy8gb2YgQyB3aXRoIGFuIGFyZ3VtZW50IGxpc3QgY29udGFpbmluZyB0aGUgc2luZ2xlIGl0ZW0gbGVuLlxuICAgICAgICAgICAgLy8gMTQuIGEuIEVsc2UsIExldCBBIGJlIEFycmF5Q3JlYXRlKGxlbikuXG4gICAgICAgICAgICBsZXQgQSA9IGlzQ2FsbGFibGUoQykgPyBPYmplY3QobmV3IEMobGVuKSkgOiBuZXcgQXJyYXkobGVuKTtcblxuICAgICAgICAgICAgLy8gMTYuIExldCBrIGJlIDAuXG4gICAgICAgICAgICBsZXQgayA9IDA7XG4gICAgICAgICAgICAvLyAxNy4gUmVwZWF0LCB3aGlsZSBrIDwgbGVu4oCmIChhbHNvIHN0ZXBzIGEgLSBoKVxuICAgICAgICAgICAgbGV0IGtWYWx1ZTtcbiAgICAgICAgICAgIHdoaWxlIChrIDwgbGVuKSB7XG4gICAgICAgICAgICAgICAga1ZhbHVlID0gaXRlbXNba107XG4gICAgICAgICAgICAgICAgaWYgKG1hcEZuKSB7XG4gICAgICAgICAgICAgICAgICAgIEFba10gPSB0eXBlb2YgVCA9PT0gJ3VuZGVmaW5lZCcgPyBtYXBGbihrVmFsdWUsIGspIDogbWFwRm4uY2FsbChULCBrVmFsdWUsIGspO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIEFba10gPSBrVmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGsgKz0gMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIDE4LiBMZXQgcHV0U3RhdHVzIGJlIFB1dChBLCBcImxlbmd0aFwiLCBsZW4sIHRydWUpLlxuICAgICAgICAgICAgQS5sZW5ndGggPSBsZW47XG4gICAgICAgICAgICAvLyAyMC4gUmV0dXJuIEEuXG4gICAgICAgICAgICByZXR1cm4gQTtcbiAgICAgICAgfTtcbiAgICB9KCkpO1xufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuXG5leHBvcnQgbGV0IGF2YWlsYWJsZSA9IGZhbHNlO1xuXG5leHBvcnQgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICBpZiAod2luZG93W1wiYnJvd3NlclwiXSAhPT0gdW5kZWZpbmVkXG4gICAgICAgICYmIGJyb3dzZXIudGFic1tcImNhcHR1cmVUYWJcIl0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBhdmFpbGFibGUgPSB0cnVlO1xuICAgICAgICByZXR1cm47XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY2FwdHVyZVRhYihpZCkge1xuICAgIHJldHVybiBhdmFpbGFibGUgPyBicm93c2VyLnRhYnMuY2FwdHVyZVRhYihpZCkgOiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiByZXNvbHZlKG51bGwpKTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuLy8gU3RvcCBwcm9wYWdhdGlvbiBldmVudCBsaXN0ZW5lclxuZXhwb3J0IGZ1bmN0aW9uIHN0b3BQcm9wYWdhdGlvbihlKSB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbn1cblxuLy8gVG9nZ2xlIGEgY2xhc3Mgb2YgYW4gZWxlbWVudFxuZXhwb3J0IGZ1bmN0aW9uIHRvZ2dsZUNsYXNzKGVsZW1lbnQsIGMpIHtcbiAgICBpZiAoZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoYykpIHtcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKGMpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZChjKTtcbiAgICB9XG59XG5cbi8vIEdldCBhY3R1YWwgaGVpZ2h0IG9mIGFuIGVsZW1lbnRcbmV4cG9ydCBmdW5jdGlvbiBnZXRBY3R1YWxIZWlnaHQoZWxlbWVudCkge1xuICAgIGxldCBzdHlsZXMgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KTtcbiAgICBsZXQgbWFyZ2luID0gcGFyc2VGbG9hdChzdHlsZXNbJ21hcmdpblRvcCddKSArXG4gICAgICAgICAgICAgICBwYXJzZUZsb2F0KHN0eWxlc1snbWFyZ2luQm90dG9tJ10pO1xuICAgIHJldHVybiBlbGVtZW50Lm9mZnNldEhlaWdodCArIG1hcmdpbjtcbn1cblxuLy8gR2V0IGFjdHVhbCB3aWR0aCBvZiBhbiBlbGVtZW50XG5leHBvcnQgZnVuY3Rpb24gZ2V0QWN0dWFsV2lkdGgoZWxlbWVudCkge1xuICAgIGxldCBzdHlsZXMgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbGVtZW50KTtcbiAgICBsZXQgbWFyZ2luID0gcGFyc2VGbG9hdChzdHlsZXNbJ21hcmdpbkxlZnQnXSkgK1xuICAgICAgICAgICAgICAgcGFyc2VGbG9hdChzdHlsZXNbJ21hcmdpblJpZ2h0J10pO1xuICAgIHJldHVybiBlbGVtZW50Lm9mZnNldFdpZHRoICsgbWFyZ2luO1xufVxuXG4vLyBnZXRFbGVtZW50QnlDbGFzc05hbWVcbkVsZW1lbnQucHJvdG90eXBlLmdldEVsZW1lbnRCeUNsYXNzTmFtZSA9IGZ1bmN0aW9uIChjbGFzc05hbWVzKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShjbGFzc05hbWVzKVswXSB8fCBudWxsO1xufTtcbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCBHIGZyb20gXCIuLi9nbG9iYWxzXCJcbmltcG9ydCB7IHJlc2V0U2xpZGVTZWxlY3Rpb24sIG11bHRpU2VsZWN0UmVzZXQsIGdldFRhYklkLCBzZWxlY3RUYWJFbnRyeSB9IGZyb20gXCIuLi93dGRvbVwiXG5cbmV4cG9ydCBmdW5jdGlvbiBkb2N1bWVudE1vdXNlT3ZlcihlKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZG9jdW1lbnRNb3VzZVVwKGUpIHtcbiAgICBpZiAoRy5zbGlkZVNlbGVjdGlvbi5zbGlkaW5nKSByZXNldFNsaWRlU2VsZWN0aW9uKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkb2N1bWVudENsaWNrZWQoZSkge1xuICAgIGlmIChlLmJ1dHRvbiA9PT0gMCkge1xuICAgICAgICBpZiAoZS50YXJnZXQuaWQgPT09IFwiZGV0YWlscy1jbG9zZVwiKSB7XG4gICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtcGxhY2Vob2xkZXJcIikuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lLWJsb2NrXCI7XG4gICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYi1kZXRhaWxzXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgIGJyb3dzZXIudGFicy5yZW1vdmUoZ2V0VGFiSWQoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0YWItZGV0YWlsc1wiKSkpO1xuICAgICAgICB9IGVsc2UgeyAvLyBOb3RlOiBNYXkgY2F1c2Ugc29tZSBwcm9ibGVtc1xuICAgICAgICAgICAgaWYgKEcuaXNTZWxlY3RpbmcpIG11bHRpU2VsZWN0UmVzZXQoKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZnVuY3Rpb24gaXNJbmxpbmVQcmludGFibGVLZXkoZSkge1xuICAgIGlmICh0eXBlb2YgZS53aGljaCA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBlLndoaWNoID09PSBcIm51bWJlclwiICYmIGUud2hpY2ggPiAwKSB7XG4gICAgICAgIHJldHVybiAhZS5jdHJsS2V5ICYmICFlLm1ldGFLZXkgJiYgIWUuYWx0S2V5ICYmIGUud2hpY2ggIT09IDggJiYgZS53aGljaCAhPT0gMTM7XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZG9jdW1lbnRLZXlQcmVzc2VkKGUpIHtcbiAgICBpZiAoaXNJbmxpbmVQcmludGFibGVLZXkoZSkpIHtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJzZWFyY2hcIikuZm9jdXMoKTtcbiAgICB9IGVsc2UgaWYgKGUua2V5ID09PSBcIkVudGVyXCIpIHtcbiAgICAgICAgaWYgKEcuc2VsZWN0ZWRUYWJzID09PSAxKSB7XG4gICAgICAgICAgICBzZWxlY3RUYWJFbnRyeShkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwibXVsdGlzZWxlY3RcIilbMF0pO1xuICAgICAgICB9XG4gICAgfVxufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IFwiLi4vZG9tdXRpbHNcIlxuaW1wb3J0IHsgZ2V0SW1hZ2UgfSBmcm9tIFwiLi4vbmV0XCJcbmltcG9ydCB7IGZpbmRUYWJFbnRyeUJ5SWQsIGdldEZhdkljb25Gcm9tVGFiRW50cnksIHNldEFjdGl2ZVRhYiwgcmVtb3ZlVGFiLCByZW1vdmVXaW5kb3csIGdldFdpbmRvd0Zyb21UYWIgfSBmcm9tIFwiLi4vd3Rkb21cIlxuXG5leHBvcnQgZnVuY3Rpb24gb25NZXNzYWdlKHJlcXVlc3QsIHNlbmRlcikge1xuICAgIHN3aXRjaCAocmVxdWVzdC50eXBlKSB7XG4gICAgICAgIGNhc2UgXCJBQ1RJVkVfVEFCX0NIQU5HRURcIjpcbiAgICAgICAgICAgIHNldEFjdGl2ZVRhYihyZXF1ZXN0LmRldGFpbHMud2luZG93SWQsIHJlcXVlc3QuZGV0YWlscy50YWJJZCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcIlRBQl9GQVZfSUNPTl9DSEFOR0VEXCI6XG4gICAgICAgICAgICBicm93c2VyLnRhYnMuZ2V0KHJlcXVlc3QuZGV0YWlscy50YWJJZCkudGhlbih0YWIgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBmYXZJY29uUHJvbWlzZTtcbiAgICAgICAgICAgICAgICBpZiAodGFiLmluY29nbml0bykge1xuICAgICAgICAgICAgICAgICAgICBmYXZJY29uUHJvbWlzZSA9IGdldEltYWdlKHJlcXVlc3QuZGV0YWlscy5mYXZJY29uVXJsLCB0cnVlKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmYXZJY29uUHJvbWlzZSA9IGdldEltYWdlKHJlcXVlc3QuZGV0YWlscy5mYXZJY29uVXJsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZmF2SWNvblByb21pc2UudGhlbihmdW5jdGlvbiAoYmFzZTY0SW1hZ2Upe1xuICAgICAgICAgICAgICAgICAgICBnZXRGYXZJY29uRnJvbVRhYkVudHJ5KGZpbmRUYWJFbnRyeUJ5SWQocmVxdWVzdC5kZXRhaWxzLnRhYklkKSkuc3JjID0gYmFzZTY0SW1hZ2U7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiVEFCX1BJTk5FRF9TVEFUVVNfQ0hBTkdFRFwiOlxuICAgICAgICAgICAgbGV0IHRhYkVudHJ5ID0gZmluZFRhYkVudHJ5QnlJZChyZXF1ZXN0LmRldGFpbHMudGFiSWQpO1xuICAgICAgICAgICAgbGV0IHBpbkJ0biA9IHRhYkVudHJ5LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi1lbnRyeS1waW4tYnRuXCIpO1xuICAgICAgICAgICAgbGV0IHdpbmRvd0VudHJ5TGlzdCA9IHRhYkVudHJ5LnBhcmVudEVsZW1lbnQ7XG4gICAgICAgICAgICBsZXQgcGlubmVkVGFicztcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0LmRldGFpbHMucGlubmVkKSB7XG4gICAgICAgICAgICAgICAgcGlubmVkVGFicyA9IEFycmF5LmZyb20od2luZG93RW50cnlMaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJwaW5uZWQtdGFiXCIpKTtcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5jbGFzc0xpc3QuYWRkKFwicGlubmVkLXRhYlwiKTtcbiAgICAgICAgICAgICAgICBwaW5CdG4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvcGlucmVtb3ZlLnN2ZylcIjtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcGlubmVkVGFicyA9IEFycmF5LmZyb20od2luZG93RW50cnlMaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJwaW5uZWQtdGFiXCIpKTtcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5jbGFzc0xpc3QucmVtb3ZlKFwicGlubmVkLXRhYlwiKTtcbiAgICAgICAgICAgICAgICBwaW5CdG4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvcGluLnN2ZylcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxldCBsYXN0UGlubmVkVGFiID0gcGlubmVkVGFic1twaW5uZWRUYWJzLmxlbmd0aC0xXTtcbiAgICAgICAgICAgIGlmIChsYXN0UGlubmVkVGFiICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3dFbnRyeUxpc3QuaW5zZXJ0QmVmb3JlKHRhYkVudHJ5LCBsYXN0UGlubmVkVGFiLm5leHRTaWJsaW5nKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgd2luZG93RW50cnlMaXN0Lmluc2VydEJlZm9yZSh0YWJFbnRyeSwgd2luZG93RW50cnlMaXN0LmNoaWxkTm9kZXNbMF0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJUQUJfVElUTEVfQ0hBTkdFRFwiOlxuICAgICAgICAgICAgZmluZFRhYkVudHJ5QnlJZChyZXF1ZXN0LmRldGFpbHMudGFiSWQpLmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi10aXRsZVwiKS50ZXh0Q29udGVudCA9IHJlcXVlc3QuZGV0YWlscy50aXRsZTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiVEFCX1JFTU9WRURcIjpcbiAgICAgICAgICAgIGlmICghcmVxdWVzdC5kZXRhaWxzLndpbmRvd0Nsb3NpbmcpIHtcbiAgICAgICAgICAgICAgICByZW1vdmVUYWIocmVxdWVzdC5kZXRhaWxzLnRhYklkLCByZXF1ZXN0LmRldGFpbHMud2luZG93SWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJXSU5ET1dfUkVNT1ZFRFwiOlxuICAgICAgICAgICAgcmVtb3ZlV2luZG93KHJlcXVlc3QuZGV0YWlscy53aW5kb3dJZCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBsYXN0UmVjb3JkLCByZWNvcmQsIHJlc3RvcmUgfSBmcm9tIFwiLi4vcmVjb3JkZXJcIlxyXG5cclxubGV0IHNhdmVGb3JMYXRlckJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic2F2ZS1mb3ItbGF0ZXJcIik7XHJcbmxldCBzZmxUaW1lb3V0ID0gKCkgPT4ge1xyXG4gICAgc2F2ZUZvckxhdGVyQnRuLnJlbW92ZUF0dHJpYnV0ZShcImRvbmVcIik7XHJcbn07XHJcbmV4cG9ydCBmdW5jdGlvbiBzYXZlRm9yTGF0ZXIoKSB7XHJcbiAgICBzYXZlRm9yTGF0ZXJCdG4uc2V0QXR0cmlidXRlKFwiZGlzYWJsZWRcIiwgXCJcIik7XHJcbiAgICByZWNvcmQoKS50aGVuKCgpID0+IHtcclxuICAgICAgICBzYXZlRm9yTGF0ZXJCdG4ucmVtb3ZlQXR0cmlidXRlKFwiZGlzYWJsZWRcIik7XHJcbiAgICAgICAgc2F2ZUZvckxhdGVyQnRuLnNldEF0dHJpYnV0ZShcImRvbmVcIiwgXCJcIik7XHJcbiAgICAgICAgY2xlYXJUaW1lb3V0KHNmbFRpbWVvdXQpOyBzZXRUaW1lb3V0KHNmbFRpbWVvdXQsIDIwMDApO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCB7IHJlc3RvcmUgfVxyXG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBnZXRUYWJJZCB9IGZyb20gXCIuLi93dGRvbVwiXG5pbXBvcnQgeyBzdG9wUHJvcGFnYXRpb24gfSBmcm9tIFwiLi4vZG9tdXRpbHNcIjtcblxuLy8gSW5pdFxuZXhwb3J0IGZ1bmN0aW9uIGluaXRTZWFyY2goKSB7XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJzZWFyY2hcIikuYWRkRXZlbnRMaXN0ZW5lcihcImtleXByZXNzXCIsIHN0b3BQcm9wYWdhdGlvbik7XG59XG5cbmZ1bmN0aW9uIGtleXdvcmRTZWFyY2gocywga2V5KSB7XG4gICAgbGV0IGtleXdvcmRzID0ga2V5LnRyaW0oKS5zcGxpdChcIiBcIiksIGNvdW50ID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleXdvcmRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGxldCB3b3JkID0ga2V5d29yZHNbaV07XG4gICAgICAgIGlmICh3b3JkLnRyaW0oKSAhPT0gXCJcIiAmJiB3b3JkLm1hdGNoKC9eW2EtekEtWjAtOV0rJC8pKSB7XG4gICAgICAgICAgICBpZiAocy50b1VwcGVyQ2FzZSgpLmluY2x1ZGVzKHdvcmQudG9VcHBlckNhc2UoKSkpIHtcbiAgICAgICAgICAgICAgICBjb3VudCsrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjb3VudCA+PSAyO1xufVxuXG5mdW5jdGlvbiBzZWFyY2gocywga2V5KSB7XG4gICAgcmV0dXJuIHMudG9VcHBlckNhc2UoKS5pbmNsdWRlcyhrZXkudG9VcHBlckNhc2UoKSkgfHwga2V5d29yZFNlYXJjaChzLCBrZXkpO1xufVxuXG4vLyBTZWFyY2hcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZWFyY2hUZXh0Q2hhbmdlZChlKSB7XG4gICAgbGV0IGlucHV0LCBmaWx0ZXIsIHRhYkVudHJpZXM7XG4gICAgaW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNlYXJjaFwiKTtcbiAgICBmaWx0ZXIgPSBpbnB1dC52YWx1ZTtcbiAgICB0YWJFbnRyaWVzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInRhYi1lbnRyeVwiKTtcbiAgICBpZiAoZmlsdGVyICE9PSBcIlwiKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFiRW50cmllcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbGV0IHRhYkVudHJ5ID0gdGFiRW50cmllc1tpXTtcbiAgICAgICAgICAgIGlmICghc2VhcmNoKHRhYkVudHJ5LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi10aXRsZVwiKS5pbm5lclRleHQsIGZpbHRlcikgJiZcbiAgICAgICAgICAgICAgICAhKEcuc2VhcmNoSW5VUkxzICYmIHNlYXJjaCgoYXdhaXQgYnJvd3Nlci50YWJzLmdldChnZXRUYWJJZCh0YWJFbnRyeSkpKS51cmwsIGZpbHRlcikpKSB7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhYkVudHJpZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxldCB0YWJFbnRyeSA9IHRhYkVudHJpZXNbaV07XG4gICAgICAgICAgICB0YWJFbnRyeS5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBjdHJsT3JDbWQgfSBmcm9tIFwiLi4va2V5dXRpbHNcIlxuaW1wb3J0IHsgZ2V0TGFzdEZvY3VzZWRXaW5kb3cgfSBmcm9tIFwiLi4vd3R1dGlsc1wiXG5pbXBvcnQgKiBhcyBjYXB0dXJlVGFiIGZyb20gXCIuLi9jYXB0dXJlVGFiXCJcbmltcG9ydCB7IGdldFdpbmRvd0Zyb21UYWIsIG11bHRpU2VsZWN0LCBtdWx0aVNlbGVjdFRvZ2dsZSwgZ2V0VGFiSWQsIGdldFdpbmRvd0lkLCBtdWx0aVNlbGVjdENhbmNlbCwgc2VsZWN0VGFiRW50cnkgfSBmcm9tIFwiLi4vd3Rkb21cIlxuXG5leHBvcnQgZnVuY3Rpb24gdGFiRW50cnlNb3VzZU92ZXIoZSkge1xuICAgIGUudGFyZ2V0LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi1lbnRyeS1waW4tYnRuXCIpLnN0eWxlLmRpc3BsYXkgPSBcImlubGluZS1ibG9ja1wiO1xuICAgIGlmIChjdHJsT3JDbWQoKSAmJiBHLnNsaWRlU2VsZWN0aW9uLnNsaWRpbmcpIHtcbiAgICAgICAgaWYgKEcuc2xpZGVTZWxlY3Rpb24uaW5pdGlhdG9yICE9PSBlLnRhcmdldCkge1xuICAgICAgICAgICAgaWYgKEcuc2xpZGVTZWxlY3Rpb24uaW5pdGlhdG9yLmNsYXNzTGlzdC5jb250YWlucyhcIm11bHRpc2VsZWN0XCIpKSB7XG4gICAgICAgICAgICAgICAgbXVsdGlTZWxlY3QoZS50YXJnZXQpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBtdWx0aVNlbGVjdENhbmNlbChlLnRhcmdldCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgICBsZXQgdGFiSWQgPSBnZXRUYWJJZChlLnRhcmdldCk7XG4gICAgICAgIGNhcHR1cmVUYWIuY2FwdHVyZVRhYih0YWJJZCkudGhlbihkYXRhVXJpID0+IHtcbiAgICAgICAgICAgIGlmIChkYXRhVXJpICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgbGV0IGRldGFpbHNJbWFnZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGV0YWlscy1pbWdcIik7XG4gICAgICAgICAgICAgICAgZGV0YWlsc0ltYWdlLnNyYyA9IGRhdGFVcmk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgZGV0YWlsc1RpdGxlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXRpdGxlXCIpO1xuICAgICAgICAgICAgbGV0IGRldGFpbHNVUkwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtdXJsXCIpO1xuICAgICAgICAgICAgYnJvd3Nlci50YWJzLmdldCh0YWJJZCkudGhlbih0YWIgPT4ge1xuICAgICAgICAgICAgICAgIGRldGFpbHNUaXRsZS50ZXh0Q29udGVudCA9IHRhYi50aXRsZTtcbiAgICAgICAgICAgICAgICBkZXRhaWxzVVJMLnRleHRDb250ZW50ID0gdGFiLnVybDtcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtcGxhY2Vob2xkZXJcIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFiLWRldGFpbHNcIikuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lLWJsb2NrXCI7XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0YWItZGV0YWlsc1wiKS5zZXRBdHRyaWJ1dGUoXCJkYXRhLXRhYl9pZFwiLCB0YWJJZCk7XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5waW5uZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXBpbm5lZFwiKS5zdHlsZS5kaXNwbGF5ID0gXCJpbmxpbmVcIjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtcGlubmVkXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5oaWRkZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLWhpZGRlblwiKS5zdHlsZS5kaXNwbGF5ID0gXCJpbmxpbmVcIjtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtaGlkZGVuXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHRhYi5waW5uZWQgJiYgdGFiLmhpZGRlbikge1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtY29tbWFcIikuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lXCI7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLWNvbW1hXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGUucHJldmVudERlZmF1bHQoKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRhYkVudHJ5TW91c2VMZWF2ZShlKSB7XG4gICAgZS50YXJnZXQuZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lKFwidGFiLWVudHJ5LXBpbi1idG5cIikuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdGFiRW50cnlDbGlja2VkKGUpIHtcbiAgICBpZiAoZS5idXR0b24gPT09IDApIHtcbiAgICAgICAgaWYgKGN0cmxPckNtZCgpKSB7XG4gICAgICAgICAgICBtdWx0aVNlbGVjdFRvZ2dsZShlLnRhcmdldCk7XG4gICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2VsZWN0VGFiRW50cnkoZS50YXJnZXQpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdGFiQ2xvc2VDbGljayhlKSB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBsZXQgdGFiSWQgPSBlLnRhcmdldC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQuZ2V0QXR0cmlidXRlKFwiZGF0YS10YWJfaWRcIik7XG4gICAgbGV0IHRhYkRldGFpbHMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYi1kZXRhaWxzXCIpO1xuICAgIGlmICh0YWJEZXRhaWxzLmdldEF0dHJpYnV0ZShcImRhdGEtdGFiX2lkXCIpID09PSB0YWJJZCkge1xuICAgICAgICB0YWJEZXRhaWxzLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkZXRhaWxzLXBsYWNlaG9sZGVyXCIpLnN0eWxlLmRpc3BsYXkgPSBcImlubGluZS1ibG9ja1wiO1xuICAgIH1cbiAgICBicm93c2VyLnRhYnMucmVtb3ZlKHBhcnNlSW50KHRhYklkKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0YWJQaW5DbGljayhlKSB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBsZXQgdGFiSWQgPSBnZXRUYWJJZChlLnRhcmdldC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQpO1xuICAgIGJyb3dzZXIudGFicy5nZXQodGFiSWQpLnRoZW4odGFiID0+IHtcbiAgICAgICAgaWYgKHRhYi5waW5uZWQpIHtcbiAgICAgICAgICAgIGJyb3dzZXIudGFicy51cGRhdGUodGFiLmlkLCB7XG4gICAgICAgICAgICAgICAgcGlubmVkOiBmYWxzZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBicm93c2VyLnRhYnMudXBkYXRlKHRhYi5pZCwge1xuICAgICAgICAgICAgICAgIHBpbm5lZDogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCBHIGZyb20gXCIuLi9nbG9iYWxzXCJcbmltcG9ydCB7IGN0cmxPckNtZCB9IGZyb20gXCIuLi9rZXl1dGlsc1wiXG5pbXBvcnQgeyBtb3ZlVGFiLCBhdHRhY2hUYWIsIGdldFdpbmRvd0Zyb21UYWIsIHRhYkRyYWdnYWJsZSwgbXVsdGlTZWxlY3QsIGdldFNlbGVjdGVkSXRlbXMsIG11bHRpU2VsZWN0ZWQsIHRhYkRyYWdnYWJsZVRvV2luZG93LCBnZXRUYWJJZCwgZ2V0V2luZG93SWQsIG11bHRpU2VsZWN0VG9nZ2xlIH0gZnJvbSBcIi4uL3d0ZG9tXCJcblxubGV0IG11bHRpRHJhZ2dpbmcgPSBmYWxzZSwgc291cmNlVGFiLCB0YXJnZXRUYWIsIHVuZGVyLCBzb3VyY2VXaW5kb3csIHNvdXJjZVdpbmRvd0lkO1xuXG5mdW5jdGlvbiBnZXRNdWx0aURyYWdJbWFnZSh0YXJnZXQsIGNsaWVudFgsIGNsaWVudFkpIHtcbiAgICBsZXQgZHJhZ0ltYWdlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSwgeCwgeTtcbiAgICBsZXQgc2VsZWN0ZWRJdGVtcyA9IGdldFNlbGVjdGVkSXRlbXMoKTtcbiAgICBpZiAoc2VsZWN0ZWRJdGVtcy5sZW5ndGggPT09IDEpIHJldHVybiBzZWxlY3RlZEl0ZW1zW2ldO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VsZWN0ZWRJdGVtcy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICAgICAgbGV0IHJlZjEgPSBzZWxlY3RlZEl0ZW1zW2ldLCByZWYyID0gc2VsZWN0ZWRJdGVtc1tpKzFdO1xuICAgICAgICBsZXQgcmVmMWJyID0gcmVmMS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSwgcmVmMmJyID0gcmVmMi5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgbGV0IGRpc3RhbmNlID0gcmVmMmJyLnRvcCAtIChyZWYxYnIudG9wICsgcmVmMWJyLmhlaWdodCk7XG4gICAgICAgIGxldCByZWYxQ2xvbmUgPSByZWYxLmNsb25lTm9kZSh0cnVlKTtcbiAgICAgICAgcmVmMUNsb25lLnN0eWxlLm1hcmdpbkJvdHRvbSA9IGRpc3RhbmNlICsgXCJweFwiO1xuICAgICAgICBkcmFnSW1hZ2UuYXBwZW5kQ2hpbGQocmVmMUNsb25lKTtcbiAgICB9IGRyYWdJbWFnZS5hcHBlbmRDaGlsZChzZWxlY3RlZEl0ZW1zW3NlbGVjdGVkSXRlbXMubGVuZ3RoIC0gMV0uY2xvbmVOb2RlKHRydWUpKTtcbiAgICBkcmFnSW1hZ2Uuc3R5bGUud2lkdGggPSBzZWxlY3RlZEl0ZW1zWzBdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoICsgXCJweFwiO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZHJhZ0ltYWdlKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBpbWFnZTogZHJhZ0ltYWdlLFxuICAgICAgICB4OiAwLFxuICAgICAgICB5OiAwXG4gICAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdpbmRvd0VudHJ5RHJhZ1N0YXJ0ZWQoZSkge1xuICAgIGlmIChlLnRhcmdldC5jbGFzc0xpc3QuY29udGFpbnMoXCJ0YWItZW50cnlcIikpIHtcbiAgICAgICAgaWYgKGN0cmxPckNtZCgpKSB7XG4gICAgICAgICAgICBtdWx0aVNlbGVjdFRvZ2dsZShlLnRhcmdldCk7XG4gICAgICAgICAgICBHLnNsaWRlU2VsZWN0aW9uLnNsaWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgRy5zbGlkZVNlbGVjdGlvbi5pbml0aWF0b3IgPSBlLnRhcmdldDtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNvdXJjZVRhYiA9IGUudGFyZ2V0O1xuICAgICAgICAgICAgc291cmNlV2luZG93ID0gZ2V0V2luZG93RnJvbVRhYihzb3VyY2VUYWIpO1xuICAgICAgICAgICAgc291cmNlV2luZG93SWQgPSBnZXRXaW5kb3dJZChzb3VyY2VXaW5kb3cpO1xuICAgICAgICAgICAgZS5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9IFwibW92ZVwiO1xuICAgICAgICAgICAgaWYgKEcuaXNTZWxlY3RpbmcgJiYgbXVsdGlTZWxlY3RlZChlLnRhcmdldCkpIHtcbiAgICAgICAgICAgICAgICBtdWx0aURyYWdnaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICBsZXQgZHJhZ0ltYWdlID0gZ2V0TXVsdGlEcmFnSW1hZ2UoKTtcbiAgICAgICAgICAgICAgICBlLmRhdGFUcmFuc2Zlci5zZXREcmFnSW1hZ2UoZHJhZ0ltYWdlLmltYWdlLCBkcmFnSW1hZ2UueCwgZHJhZ0ltYWdlLnkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGUuZGF0YVRyYW5zZmVyLnNldERhdGEoJ3RleHQvcGxhaW4nLCBudWxsKTtcbiAgICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dFbnRyeURyYWdnaW5nT3ZlcihlKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGxldCBjdXJzb3JzID0gQXJyYXkuZnJvbShHLnRhYnNMaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJpbnNlcnQtY3Vyc29yXCIpKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGN1cnNvcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbGV0IGMgPSBjdXJzb3JzW2ldO1xuICAgICAgICBjLnBhcmVudEVsZW1lbnQucmVtb3ZlQ2hpbGQoYyk7XG4gICAgfVxuICAgIGxldCBjdXJzb3JXaW5kb3cgPSBHLnRhYnNMaXN0LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcImluc2VydC1jdXJzb3Itd2luZG93XCIpO1xuICAgIGlmIChjdXJzb3JXaW5kb3cgIT09IG51bGwpIHtcbiAgICAgICAgY3Vyc29yV2luZG93LmNsYXNzTGlzdC5yZW1vdmUoXCJpbnNlcnQtY3Vyc29yLXdpbmRvd1wiKTtcbiAgICB9XG5cbiAgICBsZXQgd2luZG93RW50cnk7XG4gICAgaWYgKGUudGFyZ2V0LmNsYXNzTGlzdC5jb250YWlucyhcInRhYi1lbnRyeVwiKSkge1xuICAgICAgICBsZXQgdGFiRW50cnlCb3VuZGluZ0NsaWVudFJlY3QgPSBlLnRhcmdldC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgdGFyZ2V0VGFiID0gZS50YXJnZXQ7XG4gICAgICAgIHVuZGVyID0gZmFsc2U7XG4gICAgICAgIGlmICgoZS5jbGllbnRZIC0gdGFiRW50cnlCb3VuZGluZ0NsaWVudFJlY3QudG9wKSA+PSB0YWJFbnRyeUJvdW5kaW5nQ2xpZW50UmVjdC5oZWlnaHQgLyAyKSB7XG4gICAgICAgICAgICB0YXJnZXRUYWIgPSB0YXJnZXRUYWIubmV4dFNpYmxpbmc7XG4gICAgICAgICAgICBpZiAodGFyZ2V0VGFiID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgdW5kZXIgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRhcmdldFRhYiA9IGUudGFyZ2V0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0YWJEcmFnZ2FibGUoc291cmNlVGFiLCB0YXJnZXRUYWIsIHVuZGVyLCBzb3VyY2VXaW5kb3csIG11bHRpRHJhZ2dpbmcpKSB7XG4gICAgICAgICAgICBsZXQgY3Vyc29yID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgICAgIGN1cnNvci5jbGFzc0xpc3QuYWRkKFwiaW5zZXJ0LWN1cnNvclwiKTtcbiAgICAgICAgICAgIGlmICh1bmRlcikge1xuICAgICAgICAgICAgICAgIHRhcmdldFRhYi5wYXJlbnRFbGVtZW50LmFwcGVuZENoaWxkKGN1cnNvcik7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRhcmdldFRhYi5wYXJlbnRFbGVtZW50Lmluc2VydEJlZm9yZShjdXJzb3IsIHRhcmdldFRhYik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCh3aW5kb3dFbnRyeSA9IGUudGFyZ2V0LnBhcmVudEVsZW1lbnQpICE9PSBudWxsICYmIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5jb250YWlucyhcIndpbmRvdy1lbnRyeVwiKSkge1xuICAgICAgICBpZiAodGFiRHJhZ2dhYmxlVG9XaW5kb3coc291cmNlVGFiLCB3aW5kb3dFbnRyeSwgc291cmNlV2luZG93KSkge1xuICAgICAgICAgICAgZS50YXJnZXQuY2xhc3NMaXN0LmFkZChcImluc2VydC1jdXJzb3Itd2luZG93XCIpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gd2luZG93RW50cnlEcm9wcGVkKGUpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBsZXQgY3Vyc29ycyA9IEFycmF5LmZyb20oRy50YWJzTGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwiaW5zZXJ0LWN1cnNvclwiKSk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjdXJzb3JzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGxldCBjdXJzb3IgPSBjdXJzb3JzW2ldO1xuICAgICAgICBjdXJzb3IucGFyZW50RWxlbWVudC5yZW1vdmVDaGlsZChjdXJzb3IpO1xuICAgIH1cbiAgICBsZXQgY3Vyc29yV2luZG93ID0gRy50YWJzTGlzdC5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJpbnNlcnQtY3Vyc29yLXdpbmRvd1wiKTtcbiAgICBpZiAoY3Vyc29yV2luZG93ICE9PSBudWxsKSB7XG4gICAgICAgIGN1cnNvcldpbmRvdy5jbGFzc0xpc3QucmVtb3ZlKFwiaW5zZXJ0LWN1cnNvci13aW5kb3dcIik7XG4gICAgfVxuICAgIFxuICAgIGxldCB3aW5kb3dFbnRyeTtcbiAgICBpZiAoZS50YXJnZXQuY2xhc3NMaXN0LmNvbnRhaW5zKFwidGFiLWVudHJ5XCIpKSB7XG4gICAgICAgIGlmICghZS50YXJnZXQuaXNTYW1lTm9kZSh0YXJnZXRUYWIpKSB7XG4gICAgICAgICAgICBsZXQgdGFiRW50cnlCb3VuZGluZ0NsaWVudFJlY3QgPSBlLnRhcmdldC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgIHRhcmdldFRhYiA9IGUudGFyZ2V0O1xuICAgICAgICAgICAgdW5kZXIgPSBmYWxzZTtcbiAgICAgICAgICAgIGlmICgoZS5jbGllbnRZIC0gdGFiRW50cnlCb3VuZGluZ0NsaWVudFJlY3QudG9wKSA+PSB0YWJFbnRyeUJvdW5kaW5nQ2xpZW50UmVjdC5oZWlnaHQgLyAyKSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0VGFiID0gdGFyZ2V0VGFiLm5leHRTaWJsaW5nO1xuICAgICAgICAgICAgICAgIGlmICh0YXJnZXRUYWIgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgdW5kZXIgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB0YXJnZXRUYWIgPSBlLnRhcmdldDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRhYkRyYWdnYWJsZShzb3VyY2VUYWIsIHRhcmdldFRhYiwgdW5kZXIsIHNvdXJjZVdpbmRvdywgbXVsdGlEcmFnZ2luZykpIHtcbiAgICAgICAgICAgIGxldCBkZXN0aW5hdGlvbldpbmRvd0lkID0gZ2V0V2luZG93SWQoZ2V0V2luZG93RnJvbVRhYih0YXJnZXRUYWIpKTtcbiAgICAgICAgICAgIGxldCBzb3VyY2VUYWJJbmRleCA9IEFycmF5LnByb3RvdHlwZS5pbmRleE9mLmNhbGwodGFyZ2V0VGFiLnBhcmVudEVsZW1lbnQuY2hpbGROb2Rlcywgc291cmNlVGFiKTtcbiAgICAgICAgICAgIGxldCBkZXN0aW5hdGlvbkluZGV4ID0gQXJyYXkucHJvdG90eXBlLmluZGV4T2YuY2FsbCh0YXJnZXRUYWIucGFyZW50RWxlbWVudC5jaGlsZE5vZGVzLCB0YXJnZXRUYWIpO1xuICAgICAgICAgICAgbGV0IG1vdmVJbmRleCA9IHVuZGVyID8gLTEgOiAoKHNvdXJjZVRhYkluZGV4ICE9PSAtMSAmJiBkZXN0aW5hdGlvbkluZGV4ID4gc291cmNlVGFiSW5kZXggJiYgZGVzdGluYXRpb25XaW5kb3dJZCA9PT0gc291cmNlV2luZG93SWQpID8gZGVzdGluYXRpb25JbmRleC0xIDogZGVzdGluYXRpb25JbmRleCk7XG4gICAgICAgICAgICBsZXQgc291cmNlVGFiSWQgPSBnZXRUYWJJZChzb3VyY2VUYWIpO1xuICAgICAgICAgICAgYnJvd3Nlci50YWJzLm1vdmUoc291cmNlVGFiSWQsIHtcbiAgICAgICAgICAgICAgICB3aW5kb3dJZDogZGVzdGluYXRpb25XaW5kb3dJZCxcbiAgICAgICAgICAgICAgICBpbmRleDogbW92ZUluZGV4XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICh1bmRlcikge1xuICAgICAgICAgICAgICAgIGF0dGFjaFRhYihzb3VyY2VUYWIsIGdldFdpbmRvd0Zyb21UYWIodGFyZ2V0VGFiKSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG1vdmVUYWIoc291cmNlVGFiLCB0YXJnZXRUYWIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSBlbHNlIGlmICgod2luZG93RW50cnkgPSBlLnRhcmdldC5wYXJlbnRFbGVtZW50KSAhPT0gbnVsbCAmJiB3aW5kb3dFbnRyeS5jbGFzc0xpc3QuY29udGFpbnMoXCJ3aW5kb3ctZW50cnlcIikpIHtcbiAgICAgICAgaWYgKHRhYkRyYWdnYWJsZVRvV2luZG93KHNvdXJjZVRhYiwgd2luZG93RW50cnksIHNvdXJjZVdpbmRvdykpIHtcbiAgICAgICAgICAgIGxldCBzb3VyY2VUYWJJZCA9IGdldFRhYklkKHNvdXJjZVRhYik7XG4gICAgICAgICAgICBsZXQgZGVzdGluYXRpb25XaW5kb3dJZCA9IGdldFdpbmRvd0lkKHdpbmRvd0VudHJ5KTtcbiAgICAgICAgICAgIGJyb3dzZXIudGFicy5tb3ZlKHNvdXJjZVRhYklkLCB7XG4gICAgICAgICAgICAgICAgd2luZG93SWQ6IGRlc3RpbmF0aW9uV2luZG93SWQsXG4gICAgICAgICAgICAgICAgaW5kZXg6IC0xXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGF0dGFjaFRhYihzb3VyY2VUYWIsIHdpbmRvd0VudHJ5KTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdpbmRvd0VudHJ5VGl0bGVDbGlja2VkKGUpIHtcbiAgICBsZXQgd2luZG93SWQgPSBnZXRXaW5kb3dJZChlLnRhcmdldC5wYXJlbnRFbGVtZW50KTtcbiAgICBicm93c2VyLndpbmRvd3MudXBkYXRlKHdpbmRvd0lkLCB7XG4gICAgICAgIGZvY3VzZWQ6IHRydWVcbiAgICB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdpbmRvd0Nsb3NlQ2xpY2soZSkge1xuICAgIGxldCB3aW5kb3dJZCA9IGdldFdpbmRvd0lkKGUudGFyZ2V0LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50KTtcbiAgICBicm93c2VyLndpbmRvd3MucmVtb3ZlKHdpbmRvd0lkKTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuY29uc3QgZ2xvYmFscyA9IHtcbiAgICB0YWJzTGlzdDogdW5kZWZpbmVkLFxuICAgIGlzU2VsZWN0aW5nOiBmYWxzZSxcbiAgICBzZWxlY3RlZFRhYnM6IDAsXG4gICAgc2xpZGVTZWxlY3Rpb246IHtcbiAgICAgICAgc2xpZGluZzogZmFsc2UsXG4gICAgICAgIGluaXRpYXRvcjogdW5kZWZpbmVkLFxuICAgICAgICB2ZWN0b3I6IDBcbiAgICB9LFxuICAgIGhpZGVBZnRlclRhYlNlbGVjdGlvbjogdW5kZWZpbmVkLFxuICAgIHNlYXJjaEluVVJMczogdW5kZWZpbmVkXG59O1xuZXhwb3J0IGRlZmF1bHQgZ2xvYmFscztcbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuLy8gS2V5IHRyYWNrZXJcbmV4cG9ydCBmdW5jdGlvbiBLZXlUcmFja2VyKCkge1xuICAgIHRoaXMua2V5cyA9IHt9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBlID0+IHtcbiAgICAgICAgdGhpcy5rZXlzW2UuY29kZV0gPSB0cnVlO1xuICAgIH0pO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwia2V5dXBcIiwgZSA9PiB7XG4gICAgICAgIHRoaXMua2V5c1tlLmNvZGVdID0gZmFsc2U7XG4gICAgfSk7XG59XG5LZXlUcmFja2VyLnByb3RvdHlwZS5wcmVzc2VkID0gZnVuY3Rpb24gKGNvZGUpIHtcbiAgICByZXR1cm4gQm9vbGVhbih0aGlzLmtleXNbY29kZV0pO1xufTtcbktleVRyYWNrZXIucHJvdG90eXBlLmN0cmwgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMucHJlc3NlZChcIkNvbnRyb2xMZWZ0XCIpIHx8IHRoaXMucHJlc3NlZChcIkNvbnRyb2xSaWdodFwiKTtcbn07XG5LZXlUcmFja2VyLnByb3RvdHlwZS5jbWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMucHJlc3NlZChcIk9TUmlnaHRcIikgfHwgdGhpcy5wcmVzc2VkKFwiT1NMZWZ0XCIpO1xufTtcbktleVRyYWNrZXIucHJvdG90eXBlLmN0cmxPckNtZCA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAod2luZG93Lm5hdmlnYXRvci5wbGF0Zm9ybS50b1VwcGVyQ2FzZSgpLmluZGV4T2YoXCJNQUNcIikgPj0gMCkge1xuICAgICAgICByZXR1cm4gdGhpcy5jbWQoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuY3RybCgpO1xufTtcbktleVRyYWNrZXIucHJvdG90eXBlLnNoaWZ0ID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLnByZXNzZWQoXCJTaGlmdExlZnRcIikgfHwgdGhpcy5wcmVzc2VkKFwiU2hpZnRSaWdodFwiKTtcbn07XG5leHBvcnQgbGV0IEtleXMgPSBuZXcgS2V5VHJhY2tlcigpO1xuXG4vLyBDaGVja3MgaWYgZWl0aGVyIEN0cmwoV2luZG93cyAmIExpbnV4KSBvciBDb21tYW5kKE1hYykgaXMgcHJlc3NlZFxuZXhwb3J0IGZ1bmN0aW9uIGN0cmxPckNtZCgpIHtcbiAgICByZXR1cm4gS2V5cy5jdHJsT3JDbWQoKTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuLy8gRnVuY3Rpb24gdG8gc2VuZCBhIG1lc3NhZ2UgdG8gdGhlIHJ1bnRpbWVcbmV4cG9ydCBmdW5jdGlvbiBzZW5kUnVudGltZU1lc3NhZ2UodHlwZSwgZGF0YSkge1xuICAgIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICBkYXRhOiBkYXRhXG4gICAgfSk7XG59XG5cbi8vIEZ1bmN0aW9uIHRvIHNlbmQgYSBtZXNzYWdlIHRvIGEgdGFiXG5leHBvcnQgZnVuY3Rpb24gc2VuZFRhYk1lc3NhZ2UodGFiSWQsIHRhcmdldCwgZGF0YSkge1xuICAgIHJldHVybiBicm93c2VyLnRhYnMuc2VuZE1lc3NhZ2UodGFiSWQsIHtcbiAgICAgICAgdGFyZ2V0OiB0YXJnZXQsXG4gICAgICAgIGRhdGE6IGRhdGFcbiAgICB9KTtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuLy8gRnVuY3Rpb24gdG8gZ2V0IGltYWdlIGZyb20gVVJMXG5leHBvcnQgZnVuY3Rpb24gZ2V0SW1hZ2UodXJsLCBub0NhY2hlPWZhbHNlKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmICghdXJsLnN0YXJ0c1dpdGgoXCJjaHJvbWU6Ly9cIikpIHtcbiAgICAgICAgICAgICAgICBsZXQgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG4gICAgICAgICAgICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnJlYWR5U3RhdGUgPT0gNCAmJiB0aGlzLnN0YXR1cyA9PSAyMDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb250ZW50VHlwZSA9IHhoci5nZXRSZXNwb25zZUhlYWRlcihcIkNvbnRlbnQtVHlwZVwiKS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29udGVudFR5cGUuc3RhcnRzV2l0aChcImltYWdlL1wiKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBmbGFnID0gXCJkYXRhOlwiICsgY29udGVudFR5cGUgKyBcIjtjaGFyc2V0PXV0Zi04O2Jhc2U2NCxcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaW1hZ2VTdHIgPSBhcnJheUJ1ZmZlclRvQmFzZTY0KHhoci5yZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShmbGFnICsgaW1hZ2VTdHIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoXCJJbWFnZSBSZXF1ZXN0IEZhaWxlZDogQ29udGVudC1UeXBlIGlzIG5vdCBhbiBpbWFnZSEgKENvbnRlbnQtVHlwZTogXFxcIlwiICsgY29udGVudFR5cGUgKyBcIlxcXCIpXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB4aHIucmVzcG9uc2VUeXBlID0gXCJhcnJheWJ1ZmZlclwiO1xuICAgICAgICAgICAgICAgIHhoci5vcGVuKFwiR0VUXCIsIHVybCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKG5vQ2FjaGUpIHsgeGhyLnNldFJlcXVlc3RIZWFkZXIoXCJDYWNoZS1Db250cm9sXCIsIFwibm8tc3RvcmVcIik7IH1cbiAgICAgICAgICAgICAgICB4aHIuc2VuZCgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgcmVqZWN0KGVyci5tZXNzYWdlKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG4vLyBGdW5jdGlvbiB0byB0cmFuc2Zvcm0gQXJyYXlCdWZmZXIgaW50byBhIEJhc2U2NCBTdHJpbmdcbmV4cG9ydCBmdW5jdGlvbiBhcnJheUJ1ZmZlclRvQmFzZTY0KGJ1ZmZlcikge1xuICAgIGxldCBiaW5hcnkgPSBcIlwiO1xuICAgIGxldCBieXRlcyA9IFtdLnNsaWNlLmNhbGwobmV3IFVpbnQ4QXJyYXkoYnVmZmVyKSk7XG4gICAgYnl0ZXMuZm9yRWFjaCgoYikgPT4gYmluYXJ5ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYikpO1xuICAgIHJldHVybiB3aW5kb3cuYnRvYShiaW5hcnkpO1xufVxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IEcgZnJvbSBcIi4vZ2xvYmFsc1wiXG5pbXBvcnQgeyBnZXRXcm9uZ1RvUmlnaHQgfSBmcm9tIFwiLi93cm9uZy10by1yaWdodFwiXG5pbXBvcnQgeyBwb3B1bGF0ZVRhYnNMaXN0LCBleHRlbmRUYWJzTGlzdCB9IGZyb20gXCIuL3d0aW5pdFwiXG5pbXBvcnQgeyBnZXRBY3R1YWxXaWR0aCB9IGZyb20gXCIuL2RvbXV0aWxzXCJcbmltcG9ydCB7IGRvY3VtZW50TW91c2VPdmVyLCBkb2N1bWVudE1vdXNlVXAsIGRvY3VtZW50Q2xpY2tlZCwgZG9jdW1lbnRLZXlQcmVzc2VkIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL2RvY3VtZW50XCJcbmltcG9ydCB7IHNlYXJjaFRleHRDaGFuZ2VkLCBpbml0U2VhcmNoIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL3NlYXJjaFwiXG5pbXBvcnQgeyBvbk1lc3NhZ2UgfSBmcm9tIFwiLi9ldmVudC1saXN0ZW5lcnMvbWVzc2FnZVwiXG5pbXBvcnQgeyBzYXZlRm9yTGF0ZXIsIHJlc3RvcmUgYXMgcmVjb3JkZXJSZXN0b3JlIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL3JlY29yZGVyXCJcbmltcG9ydCAqIGFzIGNhcHR1cmVUYWIgZnJvbSBcIi4vY2FwdHVyZVRhYlwiXG5pbXBvcnQgKiBhcyBPcHRpb25zIGZyb20gXCIuLi9vcHRpb25zXCJcbmltcG9ydCB7IGhpZGVUYWJQcmV2aWV3IH0gZnJvbSBcIi4vd3Rkb21cIlxuaW1wb3J0IHsgdXBkYXRlUmVjb3JkZXJUb29sVGlwIH0gZnJvbSBcIi4vcmVjb3JkZXJcIjtcblxuRy50YWJzTGlzdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFicy1saXN0XCIpO1xuXG5mdW5jdGlvbiBzZXRQb3B1cFNpemUod2lkdGgsIGhlaWdodCkge1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS53aWR0aCA9IHdpZHRoICsgXCJweFwiO1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS5oZWlnaHQgPSBoZWlnaHQgKyBcInB4XCI7XG4gICAgZG9jdW1lbnQuYm9keS5zdHlsZS53aWR0aCA9IHdpZHRoICsgXCJweFwiO1xuICAgIGRvY3VtZW50LmJvZHkuc3R5bGUuaGVpZ2h0ID0gaGVpZ2h0ICsgXCJweFwiO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmdWxmaWxsT3B0aW9ucygpIHtcbiAgICBsZXQgcG9wdXBPcHRpb25zID0gKGF3YWl0IE9wdGlvbnMub3B0aW9ucygpKS5wb3B1cDtcbiAgICAvLyBwb3B1cC5zaXplXG4gICAgc2V0UG9wdXBTaXplKHBvcHVwT3B0aW9ucy5zaXplLndpZHRoLCBwb3B1cE9wdGlvbnMuc2l6ZS5oZWlnaHQpO1xuICAgIC8vIHBvcHVwLnNjYWxlXG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlLnNldFByb3BlcnR5KCctLXNjYWxlJywgcG9wdXBPcHRpb25zLnNjYWxlLnRvU3RyaW5nKCkpO1xuICAgIC8vIHBvcHVwLnNob3dEZXRhaWxzXG4gICAgaWYgKCFPcHRpb25zLnN0Ym9vbChwb3B1cE9wdGlvbnMuc2hvd0RldGFpbHMpKSB7XG4gICAgICAgIGxldCBsZWZ0Q29udGFpbmVyID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJsZWZ0LWNvbnRhaW5lclwiKTtcbiAgICAgICAgcG9wdXBPcHRpb25zLnNpemUud2lkdGggPSBwb3B1cE9wdGlvbnMuc2l6ZS53aWR0aCAtIGdldEFjdHVhbFdpZHRoKGxlZnRDb250YWluZXIpO1xuICAgICAgICBzZXRQb3B1cFNpemUocG9wdXBPcHRpb25zLnNpemUud2lkdGgsIHBvcHVwT3B0aW9ucy5zaXplLmhlaWdodCk7XG4gICAgICAgIGxlZnRDb250YWluZXIuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRhYnMtY29udGFpbmVyXCIpLnN0eWxlLndpZHRoID0gXCIxMDAlXCI7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgLy8gcG9wdXAuc2hvd1ByZXZpZXdcbiAgICAgICAgaWYgKCFPcHRpb25zLnN0Ym9vbChwb3B1cE9wdGlvbnMuc2hvd1ByZXZpZXcpKSBoaWRlVGFiUHJldmlldygpO1xuICAgIH1cbiAgICAvLyBwb3B1cC5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb25cbiAgICBHLmhpZGVBZnRlclRhYlNlbGVjdGlvbiA9IE9wdGlvbnMuc3Rib29sKHBvcHVwT3B0aW9ucy5oaWRlQWZ0ZXJUYWJTZWxlY3Rpb24pO1xuICAgIC8vIHBvcHVwLnNlYXJjaEluVVJMc1xuICAgIEcuc2VhcmNoSW5VUkxzID0gT3B0aW9ucy5zdGJvb2wocG9wdXBPcHRpb25zLnNlYXJjaEluVVJMcyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG4gICAgLy8gSW5pdGlhbGl6ZSBjYXB0dXJlVGFiIGJhc2VkIG9uIGVudmlyb25tZW50XG4gICAgY2FwdHVyZVRhYi5pbml0KCk7XG4gICAgLy8gRnVsZmlsbCB1c2VyIG9wdGlvbnNcbiAgICBhd2FpdCBmdWxmaWxsT3B0aW9ucygpO1xuICAgIC8vIE1ha2UgdGFicyBsaXN0IGZpdCB0aGUgcGFuZWxcbiAgICBleHRlbmRUYWJzTGlzdCgpO1xuICAgIC8vIEZpeCBmb3IgY3Jvc3Mtd2luZG93IGRyYWdnaW5nIGlzc3VlXG4gICAgYXdhaXQgZ2V0V3JvbmdUb1JpZ2h0KCk7XG4gICAgLy8gUG9wdWxhdGUgdGFicyBsaXN0IHdpdGggdGFic1xuICAgIGF3YWl0IHBvcHVsYXRlVGFic0xpc3QoKTtcbiAgICAvLyBVcGRhdGUgcmVjb3JkZXIgdG9vbHRpcFxuICAgIGF3YWl0IHVwZGF0ZVJlY29yZGVyVG9vbFRpcCgpO1xuICAgIC8vIEluaXRpYWxpemUgY29tcG9uZW50c1xuICAgIGluaXRTZWFyY2goKTtcbn1cblxuLyogQWRkIGV2ZW50IGxpc3RlbmVycyAqL1xuXG4vLyBTdGFydGluZyBwb2ludFxuaWYgKGRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwibG9hZGluZ1wiKSB7XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIkRPTUNvbnRlbnRMb2FkZWRcIiwgbWFpbik7XG59IGVsc2Uge1xuICAgIG1haW4oKTtcbn1cblxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlb3ZlclwiLCBkb2N1bWVudE1vdXNlT3Zlcik7XG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwibW91c2V1cFwiLCBkb2N1bWVudE1vdXNlVXApO1xuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGRvY3VtZW50Q2xpY2tlZCk7XG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwia2V5cHJlc3NcIiwgZG9jdW1lbnRLZXlQcmVzc2VkKTtcblxuLy8gQWRkIGtleXVwIGV2ZW50IGxpc3RlbmVyIGFuZCBwdXQgZm9jdXMgb24gc2VhcmNoXG5sZXQgc2VhcmNoID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJzZWFyY2hcIik7XG5zZWFyY2guYWRkRXZlbnRMaXN0ZW5lcihcImtleXVwXCIsIHNlYXJjaFRleHRDaGFuZ2VkKTtcbnNlYXJjaC5mb2N1cygpO1xuXG4vLyBBZGQgZXZlbnQgbGlzdGVuZXJzIHRvIGFsbCBjb3B5IGJ1dHRvbnNcbmxldCBjb3B5QnV0dG9ucyA9IEFycmF5LmZyb20oZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImNvcHktYnV0dG9uXCIpKTtcbmZvciAobGV0IGkgPSAwOyBpIDwgY29weUJ1dHRvbnMubGVuZ3RoOyBpKyspIHtcbiAgICBjb3B5QnV0dG9uc1tpXS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZSA9PiB7XG4gICAgICAgIGRvY3VtZW50Lm9uY29weSA9IGNlID0+IHtcbiAgICAgICAgICAgIGNlLmNsaXBib2FyZERhdGEuc2V0RGF0YShcInRleHRcIiwgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoZS50YXJnZXQuZ2V0QXR0cmlidXRlKFwiZm9yXCIpKS5pbm5lclRleHQpO1xuICAgICAgICAgICAgY2UucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfTtcbiAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJjb3B5XCIsIGZhbHNlLCBudWxsKTtcbiAgICAgICAgZS50YXJnZXQuaW5uZXJUZXh0ID0gXCJDb3BpZWQhXCI7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgZS50YXJnZXQuaW5uZXJUZXh0ID0gXCJDb3B5XCI7XG4gICAgICAgIH0sIDIwMDApO1xuICAgIH0pO1xufVxuXG4vLyBBZGQgZXZlbnQgbGlzdGVuZXIgZm9yIHJlY29yZGVyLmpzXG5kb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNhdmUtZm9yLWxhdGVyXCIpLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBzYXZlRm9yTGF0ZXIpO1xuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyZXN0b3JlLW5vd1wiKS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgcmVjb3JkZXJSZXN0b3JlKTtcblxuLy8gQWRkIGV2ZW50IGxpc3RlbmVyIHRvIGxpc3RlbiBmb3IgYW55IG1lc3NhZ2VzIGZyb20gYmFja2dyb3VuZC5qc1xuaWYgKCFicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmhhc0xpc3RlbmVyKG9uTWVzc2FnZSkpIHtcbiAgICBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKG9uTWVzc2FnZSk7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXHJcbmltcG9ydCBHIGZyb20gXCIuL2dsb2JhbHNcIlxyXG5pbXBvcnQgeyBnZXRUYWJJZCB9IGZyb20gXCIuL3d0ZG9tXCJcclxuaW1wb3J0IHsgcnVuQWZ0ZXJUYWJMb2FkIH0gZnJvbSBcIi4vd3R1dGlsc1wiO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxhc3RSZWNvcmQoKSB7XHJcbiAgICByZXR1cm4gYnJvd3Nlci5zdG9yYWdlLnN5bmMuZ2V0KFtcInJlY29yZFwiXSkudGhlbihkYXRhID0+IGRhdGEucmVjb3JkKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVJlY29yZGVyVG9vbFRpcCgpIHtcclxuICAgIGxldCByID0gYXdhaXQgbGFzdFJlY29yZCgpO1xyXG4gICAgbGV0IHJlc3RvcmVCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJlc3RvcmUtbm93XCIpO1xyXG4gICAgaWYgKHIpIHtcclxuICAgICAgICByZXN0b3JlQnRuLnNldEF0dHJpYnV0ZShcInRpdGxlXCIsIFwiUmVzdG9yZSB3ZWJzaXRlcyB0aGF0IGhhdmUgYmVlbiBzYXZlZCBvbiBcIiArIChuZXcgRGF0ZShyLnRpbWVzdGFtcCkpLnRvTG9jYWxlU3RyaW5nKCkpO1xyXG4gICAgICAgIHJlc3RvcmVCdG4ucmVtb3ZlQXR0cmlidXRlKFwiZGlzYWJsZWRcIik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHJlc3RvcmVCdG4uc2V0QXR0cmlidXRlKFwidGl0bGVcIiwgXCJSZXN0b3JlIHdlYnNpdGVzIHRoYXQgaGF2ZSBiZWVuIHNhdmVkXCIpO1xyXG4gICAgICAgIHJlc3RvcmVCdG4uc2V0QXR0cmlidXRlKFwiZGlzYWJsZWRcIiwgXCJcIik7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHRhYkluZm9Ub1JlY29yZChpbmZvKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIHVybDogaW5mby51cmwsXHJcbiAgICAgICAgcGlubmVkOiBpbmZvLnBpbm5lZFxyXG4gICAgfTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVjb3JkKCkge1xyXG4gICAgbGV0IHJlY29yZEFycmF5ID0gW107XHJcbiAgICBmb3IgKGxldCB3aW5kb3dFbnRyeSBvZiBHLnRhYnNMaXN0LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ3aW5kb3ctZW50cnlcIikpIHtcclxuICAgICAgICBsZXQgd2luZG93UmVjb3JkID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgdGFiRW50cnkgb2Ygd2luZG93RW50cnkuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcInRhYi1lbnRyeVwiKSkge1xyXG4gICAgICAgICAgICBhd2FpdCBicm93c2VyLnRhYnMuc2VuZE1lc3NhZ2UoZ2V0VGFiSWQodGFiRW50cnkpLCB7IHRhcmdldDogXCJwYWNrZFwiLCBkYXRhOiB7IGFjdGlvbjogXCJwYWNrXCIgfSB9KS50aGVuKGFzeW5jIHBhY2sgPT4ge1xyXG4gICAgICAgICAgICAgICAgd2luZG93UmVjb3JkLnB1c2goT2JqZWN0LmFzc2lnbih7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFjazogcGFja1xyXG4gICAgICAgICAgICAgICAgfSwgdGFiSW5mb1RvUmVjb3JkKGF3YWl0IGJyb3dzZXIudGFicy5nZXQoZ2V0VGFiSWQodGFiRW50cnkpKSkpKTtcclxuICAgICAgICAgICAgfSkuY2F0Y2goYXN5bmMgcmVhc29uID0+IHtcclxuICAgICAgICAgICAgICAgIHdpbmRvd1JlY29yZC5wdXNoKE9iamVjdC5hc3NpZ24oe1xyXG4gICAgICAgICAgICAgICAgICAgIHBhY2s6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgfSwgdGFiSW5mb1RvUmVjb3JkKGF3YWl0IGJyb3dzZXIudGFicy5nZXQoZ2V0VGFiSWQodGFiRW50cnkpKSkpKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJlY29yZEFycmF5LnB1c2god2luZG93UmVjb3JkKTtcclxuICAgIH1cclxuICAgIGxldCByZWNvcmQgPSB7XHJcbiAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxyXG4gICAgICAgIHJlY29yZDogcmVjb3JkQXJyYXlcclxuICAgIH07XHJcbiAgICByZXR1cm4gYnJvd3Nlci5zdG9yYWdlLnN5bmMuc2V0KHsgcmVjb3JkOiByZWNvcmQgfSkudGhlbigoKSA9PiB1cGRhdGVSZWNvcmRlclRvb2xUaXAoKSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZXN0b3JlKCkge1xyXG4gICAgbGV0IHsgcmVjb3JkOiByIH0gPSBhd2FpdCBsYXN0UmVjb3JkKCk7XHJcbiAgICBmb3IgKGxldCB3aW5kb3dSZWNvcmQgb2Ygcikge1xyXG4gICAgICAgIGlmIChicm93c2VyLnJ1bnRpbWUuZ2V0QnJvd3NlckluZm8pIHtcclxuICAgICAgICAgICAgd2luZG93UmVjb3JkID0gd2luZG93UmVjb3JkLmZpbHRlcih0YWJSZWNvcmQgPT4gIXRhYlJlY29yZC51cmwuc3RhcnRzV2l0aChcImFib3V0OlwiKSlcclxuICAgICAgICB9XHJcbiAgICAgICAgYnJvd3Nlci53aW5kb3dzLmNyZWF0ZSh7XHJcbiAgICAgICAgICAgIHVybDogd2luZG93UmVjb3JkLm1hcCh0YWJSZWNvcmQgPT4gdGFiUmVjb3JkLnVybClcclxuICAgICAgICB9KS50aGVuKGFzeW5jIHcgPT4ge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHdpbmRvd1JlY29yZC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRhYlJlY29yZCA9IHdpbmRvd1JlY29yZFtpXTtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUody50YWJzW2ldLmlkLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGlubmVkOiB0YWJSZWNvcmQucGlubmVkXHJcbiAgICAgICAgICAgICAgICB9KS50aGVuKHQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0YWJSZWNvcmQucGFjaykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBydW5BZnRlclRhYkxvYWQodC5pZCwgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJvd3Nlci50YWJzLnNlbmRNZXNzYWdlKHQuaWQsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6IFwicGFja2RcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiBPYmplY3QuYXNzaWduKHthY3Rpb246IFwidW5wYWNrXCJ9LCB0YWJSZWNvcmQucGFjaylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KS5jYXRjaChlID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuIiwiaW1wb3J0IFwiUG9seWZpbGxcIlxuaW1wb3J0IHsgc2VuZFJ1bnRpbWVNZXNzYWdlIH0gZnJvbSBcIi4vbWVzc2FnaW5nXCJcblxubGV0IHdyb25nVG9SaWdodDtcblxuZXhwb3J0IGZ1bmN0aW9uIGdldFdyb25nVG9SaWdodCgpIHtcbiAgICByZXR1cm4gc2VuZFJ1bnRpbWVNZXNzYWdlKFwiV1JPTkdfVE9fUklHSFRfR0VUXCIsIHt9KS50aGVuKHJlc3BvbnNlID0+IHtcbiAgICAgICAgd3JvbmdUb1JpZ2h0ID0gcmVzcG9uc2Uud3JvbmdUb1JpZ2h0O1xuICAgIH0pO1xufVxuXG4vLyBGdW5jdGlvbiB0byBnZXQgY29ycmVjdCB0YWIgaWRcbmV4cG9ydCBmdW5jdGlvbiBnZXRDb3JyZWN0VGFiSWQodGFiSWQpIHtcbiAgICByZXR1cm4gd3JvbmdUb1JpZ2h0W3RhYklkXSB8fCB0YWJJZDtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcbmltcG9ydCBHIGZyb20gXCIuL2dsb2JhbHNcIlxuaW1wb3J0IHsgZ2V0Q29ycmVjdFRhYklkIH0gZnJvbSBcIi4vd3JvbmctdG8tcmlnaHRcIlxuaW1wb3J0IHsgZ2V0TGFzdEZvY3VzZWRXaW5kb3cgfSBmcm9tIFwiLi93dHV0aWxzXCI7XG5cbi8vIFNlbGVjdCB0YWIgYW5kIGdvIHRvIGl0XG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0VGFiRW50cnkodGFiRW50cnkpIHtcbiAgICBsZXQgdGFiSWQgPSBnZXRUYWJJZCh0YWJFbnRyeSk7XG4gICAgbGV0IHBhcmVudFdpbmRvd0lkID0gZ2V0V2luZG93SWQoZ2V0V2luZG93RnJvbVRhYih0YWJFbnRyeSkpO1xuICAgIGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHtcbiAgICAgICAgYWN0aXZlOiB0cnVlXG4gICAgfSk7XG4gICAgYnJvd3Nlci53aW5kb3dzLmdldChwYXJlbnRXaW5kb3dJZCkudGhlbih3ID0+IHtcbiAgICAgICAgZ2V0TGFzdEZvY3VzZWRXaW5kb3coKS50aGVuKGN3ID0+IHtcbiAgICAgICAgICAgIGlmICh3LmlkICE9PSBjdy5pZCkge1xuICAgICAgICAgICAgICAgIGJyb3dzZXIud2luZG93cy51cGRhdGUody5pZCwge1xuICAgICAgICAgICAgICAgICAgICBmb2N1c2VkOiB0cnVlXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChHLmhpZGVBZnRlclRhYlNlbGVjdGlvbikgd2luZG93LmNsb3NlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuXG4vLyBIaWRlcyB0aGUgdGFiIHByZXZpZXdcbmV4cG9ydCBmdW5jdGlvbiBoaWRlVGFiUHJldmlldygpIHtcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRldGFpbHMtaW1nXCIpLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbn1cblxuLy8gR2V0IGEgdGFiIGJ5IGEgdGFiIGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gZ2V0VGFiQnlUYWJFbnRyeShlbnRyeSkge1xuICAgIHJldHVybiBicm93c2VyLnRhYnMuZ2V0KGdldFRhYklkKGVudHJ5KSk7XG59XG5cbi8vIEdldCB0aGUgVGFiSWQgb2YgYSB0YWIgZW50cnlcbmV4cG9ydCBmdW5jdGlvbiBnZXRUYWJJZChlbnRyeSkge1xuICAgIHJldHVybiBwYXJzZUludChlbnRyeS5nZXRBdHRyaWJ1dGUoXCJkYXRhLXRhYl9pZFwiKSk7XG59XG5cbi8vIEdldCB0aGUgV2luZG93SWQgb2YgYSB3aW5kb3cgZW50cnlcbmV4cG9ydCBmdW5jdGlvbiBnZXRXaW5kb3dJZChlbnRyeSkge1xuICAgIHJldHVybiBwYXJzZUludChlbnRyeS5nZXRBdHRyaWJ1dGUoXCJkYXRhLXdpbmRvd19pZFwiKSk7XG59XG5cbi8vIEZpbmQgdGFiIGVudHJ5IGJ5IHRhYiBpZFxuZXhwb3J0IGZ1bmN0aW9uIGZpbmRUYWJFbnRyeUJ5SWQodGFiSWQpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIi50YWItZW50cnlbZGF0YS10YWJfaWQ9XFxcIlwiICsgdGFiSWQgKyBcIlxcXCJdXCIpO1xufVxuXG4vLyBGaW5kIGNvcnJlY3QgdGFiIGVudHJ5IGJ5IHRhYiBpZFxuZXhwb3J0IGZ1bmN0aW9uIGZpbmRDb3JyZWN0VGFiRW50cnlCeUlkKHRhYklkKSB7XG4gICAgcmV0dXJuIGZpbmRUYWJFbnRyeUJ5SWQoZ2V0Q29ycmVjdFRhYklkKHRhYklkKSk7XG59XG5cbi8vIEdldCBmYXZpY29uIGZyb20gYSB0YWIgZW50cnlcbmV4cG9ydCBmdW5jdGlvbiBnZXRGYXZJY29uRnJvbVRhYkVudHJ5KGVudHJ5KSB7XG4gICAgcmV0dXJuIGVudHJ5LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcInRhYi1lbnRyeS1mYXZpY29uXCIpO1xufVxuXG4vLyBGaW5kIHdpbmRvdyBlbnRyeSBieSB0YWIgaWRcbmV4cG9ydCBmdW5jdGlvbiBmaW5kV2luZG93RW50cnlCeUlkKHdpbmRvd0lkKSB7XG4gICAgcmV0dXJuIEcudGFic0xpc3QucXVlcnlTZWxlY3RvcihcImxpW2RhdGEtd2luZG93X2lkPVxcXCJcIiArIHdpbmRvd0lkICsgXCJcXFwiXVwiKTtcbn1cblxuLy8gRmluZCB0YWIgZW50cnkgaW5zaWRlIGEgd2luZG93IGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gZmluZFRhYkVudHJ5SW5XaW5kb3cod2luZG93RW50cnksIHRhYklkKSB7XG4gICAgcmV0dXJuIHdpbmRvd0VudHJ5LnF1ZXJ5U2VsZWN0b3IoXCJsaVtkYXRhLXRhYl9pZD1cXFwiXCIgKyB0YWJJZCArIFwiXFxcIl1cIik7XG59XG5cbi8vIEdldCBhY3RpdmUgdGFiIGluIHRoZSBzcGVjaWZpZWQgd2luZG93XG5leHBvcnQgZnVuY3Rpb24gZ2V0QWN0aXZlVGFiKHdpbmRvd0lkKSB7XG4gICAgbGV0IHdpbmRvdyA9IGZpbmRXaW5kb3dFbnRyeUJ5SWQod2luZG93SWQpO1xuICAgIHJldHVybiB3aW5kb3cuZ2V0RWxlbWVudEJ5Q2xhc3NOYW1lKFwiY3VycmVudC10YWJcIik7XG59XG5cbi8vIFNldCBhY3RpdmUgdGFiIGluIHRoZSBzcGVjaWZpZWQgd2luZG93XG5leHBvcnQgZnVuY3Rpb24gc2V0QWN0aXZlVGFiKHdpbmRvd0lkLCB0YWJJZCkge1xuICAgIGxldCB3aW5kb3cgPSBmaW5kV2luZG93RW50cnlCeUlkKHdpbmRvd0lkKSwgbGFzdEFjdGl2ZVRhYjtcbiAgICBpZiAoKGxhc3RBY3RpdmVUYWIgPSBnZXRBY3RpdmVUYWIod2luZG93SWQpKSAhPT0gbnVsbCkge1xuICAgICAgICBsYXN0QWN0aXZlVGFiLmNsYXNzTGlzdC5yZW1vdmUoXCJjdXJyZW50LXRhYlwiKTtcbiAgICB9XG4gICAgZmluZFRhYkVudHJ5SW5XaW5kb3cod2luZG93LCB0YWJJZCkuY2xhc3NMaXN0LmFkZChcImN1cnJlbnQtdGFiXCIpO1xufVxuXG4vLyBSZW1vdmUgdGFiXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlVGFiKHRhYklkLCB3aW5kb3dJZCkge1xuICAgIGxldCB0YWJFbnRyeSA9IGZpbmRUYWJFbnRyeUJ5SWQodGFiSWQpO1xuICAgIHRhYkVudHJ5LnBhcmVudEVsZW1lbnQucmVtb3ZlQ2hpbGQodGFiRW50cnkpO1xuICAgIGJyb3dzZXIudGFicy5xdWVyeSh7XG4gICAgICAgIGFjdGl2ZTogdHJ1ZSxcbiAgICAgICAgd2luZG93SWQ6IHdpbmRvd0lkXG4gICAgfSkudGhlbih0YWJzID0+IHtcbiAgICAgICAgZmluZENvcnJlY3RUYWJFbnRyeUJ5SWQodGFic1swXS5pZCkuY2xhc3NMaXN0LmFkZChcImN1cnJlbnQtdGFiXCIpO1xuICAgIH0pO1xufVxuXG4vLyBNb3ZlIHRhYlxuZXhwb3J0IGZ1bmN0aW9uIG1vdmVUYWIodGFyZ2V0LCBkZXN0KSB7XG4gICAgZ2V0V2luZG93RnJvbVRhYihkZXN0KS5nZXRFbGVtZW50QnlDbGFzc05hbWUoXCJ3aW5kb3ctZW50cnktdGFic1wiKS5pbnNlcnRCZWZvcmUodGFyZ2V0LCBkZXN0KTtcbn1cblxuLy8gTW92ZSB0YWJzXG5leHBvcnQgZnVuY3Rpb24gbW92ZVRhYnModGFyZ2V0cywgZGVzdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFyZ2V0cy5sZW5ndGg7IGkrKykgbW92ZVRhYih0YXJnZXRzW2ldLCBkZXN0KTtcbn1cblxuLy8gQXR0YWNoIHRhYlxuZXhwb3J0IGZ1bmN0aW9uIGF0dGFjaFRhYih0YXJnZXQsIGRlc3QpIHtcbiAgICBkZXN0LmdldEVsZW1lbnRCeUNsYXNzTmFtZShcIndpbmRvdy1lbnRyeS10YWJzXCIpLmFwcGVuZENoaWxkKHRhcmdldCk7XG59XG5cbi8vIEF0dGFjaCB0YWJzXG5leHBvcnQgZnVuY3Rpb24gYXR0YWNoVGFicyh0YXJnZXRzLCBkZXN0KSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0YXJnZXRzLmxlbmd0aDsgaSsrKSBhdHRhY2hUYWIodGFyZ2V0c1tpXSwgZGVzdCk7XG59XG5cbi8vIFJlbW92ZSB3aW5kb3dcbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVXaW5kb3cod2luZG93SWQpIHtcbiAgICBsZXQgd2luZG93RW50cnkgPSBmaW5kV2luZG93RW50cnlCeUlkKHdpbmRvd0lkKTtcbiAgICB3aW5kb3dFbnRyeS5wYXJlbnRFbGVtZW50LnJlbW92ZUNoaWxkKHdpbmRvd0VudHJ5KTtcbiAgICBicm93c2VyLndpbmRvd3MuZ2V0Q3VycmVudCh7fSkudGhlbih3aW5kb3cgPT4ge1xuICAgICAgICBmaW5kV2luZG93RW50cnlCeUlkKHdpbmRvdy5pZCkuY2xhc3NMaXN0LmFkZChcImN1cnJlbnQtd2luZG93XCIpO1xuICAgIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0V2luZG93RnJvbVRhYih0YWIpIHtcbiAgICByZXR1cm4gdGFiLnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRUYWJFbnRyaWVzRnJvbVdpbmRvdyh3aW5kb3dFbnRyeSkge1xuICAgIHJldHVybiBBcnJheS5mcm9tKHdpbmRvd0VudHJ5LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJ0YWItZW50cnlcIikpO1xufVxuXG4vLyBUZXN0IGlmIHRhYiBpcyBkcmFnZ2FibGVcbmV4cG9ydCBmdW5jdGlvbiB0YWJEcmFnZ2FibGUoc291cmNlVGFiLCB0YXJnZXRUYWIsIHVuZGVyLCBzb3VyY2VXaW5kb3csIG11bHRpRHJhZ2dpbmcpIHtcbiAgICByZXR1cm4gIXNvdXJjZVRhYi5pc1NhbWVOb2RlKHRhcmdldFRhYilcbiAgICAgICAgICAgICYmICghbXVsdGlEcmFnZ2luZyB8fCAobXVsdGlTZWxlY3RlZChzb3VyY2VUYWIpICYmIG11bHRpU2VsZWN0ZWQodGFyZ2V0VGFiKSkpXG4gICAgICAgICAgICAmJiAoKCFzb3VyY2VUYWIuY2xhc3NMaXN0LmNvbnRhaW5zKFwicGlubmVkLXRhYlwiKSAmJiAhdGFyZ2V0VGFiLmNsYXNzTGlzdC5jb250YWlucyhcInBpbm5lZC10YWJcIikpXG4gICAgICAgICAgICAgICAgfHwgKHNvdXJjZVRhYi5jbGFzc0xpc3QuY29udGFpbnMoXCJwaW5uZWQtdGFiXCIpICYmIHRhcmdldFRhYi5jbGFzc0xpc3QuY29udGFpbnMoXCJwaW5uZWQtdGFiXCIpKVxuICAgICAgICAgICAgICAgIHx8ICh1bmRlciAmJiAhc291cmNlVGFiLmNsYXNzTGlzdC5jb250YWlucyhcInBpbm5lZC10YWJcIikpKVxuICAgICAgICAgICAgJiYgKCghc291cmNlV2luZG93LmNsYXNzTGlzdC5jb250YWlucyhcImluY29nbml0by13aW5kb3dcIikgJiYgIWdldFdpbmRvd0Zyb21UYWIodGFyZ2V0VGFiKS5jbGFzc0xpc3QuY29udGFpbnMoXCJpbmNvZ25pdG8td2luZG93XCIpKVxuICAgICAgICAgICAgICAgIHx8IChzb3VyY2VXaW5kb3cuY2xhc3NMaXN0LmNvbnRhaW5zKFwiaW5jb2duaXRvLXdpbmRvd1wiKSAmJiBnZXRXaW5kb3dGcm9tVGFiKHRhcmdldFRhYikuY2xhc3NMaXN0LmNvbnRhaW5zKFwiaW5jb2duaXRvLXdpbmRvd1wiKSkpO1xufVxuXG4vLyBUZXN0IGlmIHRhYiBpcyBkcmFnZ2FibGUgdG8gd2luZG93XG5leHBvcnQgZnVuY3Rpb24gdGFiRHJhZ2dhYmxlVG9XaW5kb3coc291cmNlVGFiLCB0YXJnZXRXaW5kb3csIHNvdXJjZVdpbmRvdykge1xuICAgIHJldHVybiAhc291cmNlV2luZG93LmlzU2FtZU5vZGUodGFyZ2V0V2luZG93KVxuICAgICAgICAgICAgJiYgIXNvdXJjZVRhYi5jbGFzc0xpc3QuY29udGFpbnMoXCJwaW5uZWQtdGFiXCIpXG4gICAgICAgICAgICAmJiAoKCFzb3VyY2VXaW5kb3cuY2xhc3NMaXN0LmNvbnRhaW5zKFwiaW5jb2duaXRvLXdpbmRvd1wiKSAmJiAhdGFyZ2V0V2luZG93LmNsYXNzTGlzdC5jb250YWlucyhcImluY29nbml0by13aW5kb3dcIikpXG4gICAgICAgICAgICAgICAgfHwgKHNvdXJjZVdpbmRvdy5jbGFzc0xpc3QuY29udGFpbnMoXCJpbmNvZ25pdG8td2luZG93XCIpICYmIHRhcmdldFdpbmRvdy5jbGFzc0xpc3QuY29udGFpbnMoXCJpbmNvZ25pdG8td2luZG93XCIpKSk7XG59XG5cbi8vIFJldHVybnMgdGhlIGluZGV4IG9mIGEgdGFiIGVudHJ5XG5leHBvcnQgZnVuY3Rpb24gdGFiRW50cnlJbmRleCh0YWJFbnRyeSkge1xuICAgIGxldCB0YWJzID0gQXJyYXkuZnJvbShkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwidGFiLWVudHJ5XCIpKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhYnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaWYgKHRhYnNbaV0gPT09IHRhYkVudHJ5KSB7XG4gICAgICAgICAgICByZXR1cm4gaTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gLTE7XG59XG5cbi8vIEdldCBuZXh0IHRhYlxuZXhwb3J0IGZ1bmN0aW9uIGdldE5leHRUYWJFbnRyeSh0YWJFbnRyeSkge1xuICAgIGlmICh0YWJFbnRyeS5uZXh0RWxlbWVudFNpYmxpbmcgIT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRhYkVudHJ5Lm5leHRFbGVtZW50U2libGluZztcbiAgICB9IGVsc2UgaWYgKGdldFdpbmRvd0Zyb21UYWIodGFiRW50cnkpLm5leHRFbGVtZW50U2libGluZyAhPT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gZ2V0VGFiRW50cmllc0Zyb21XaW5kb3coZ2V0V2luZG93RnJvbVRhYih0YWJFbnRyeSkubmV4dEVsZW1lbnRTaWJsaW5nKVswXTtcbiAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG4vLyBHZXQgbGFzdCB0YWJcbmV4cG9ydCBmdW5jdGlvbiBnZXRMYXN0VGFiRW50cnkodGFiRW50cnkpIHtcbiAgICBpZiAodGFiRW50cnkucHJldmlvdXNFbGVtZW50U2libGluZyAhPT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gdGFiRW50cnkucHJldmlvdXNFbGVtZW50U2libGluZztcbiAgICB9IGVsc2UgaWYgKGdldFdpbmRvd0Zyb21UYWIodGFiRW50cnkpLnByZXZpb3VzRWxlbWVudFNpYmxpbmcgIT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIGdldFRhYkVudHJpZXNGcm9tV2luZG93KGdldFdpbmRvd0Zyb21UYWIodGFiRW50cnkpLnByZXZpb3VzRWxlbWVudFNpYmxpbmcpWzBdO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuLyogTXVsdGlzZWxlY3QgKi9cbi8vIE9uIG11bHRpc2VsZWN0IHN0YXJ0XG5mdW5jdGlvbiBvbk11bHRpc2VsZWN0U3RhcnQoKSB7XG5cbn1cbi8vIE9uIG11bHRpc2VsZWN0IGNoYW5nZVxuZnVuY3Rpb24gb25NdWx0aXNlbGVjdENoYW5nZSgpIHtcblxufVxuLy8gT24gbXVsdGlzZWxlY3QgZW5kXG5mdW5jdGlvbiBvbk11bHRpc2VsZWN0RW5kKCkge1xuXG59XG4vLyBHZXQgU2VsZWN0ZWQgSXRlbXNcbmV4cG9ydCBmdW5jdGlvbiBnZXRTZWxlY3RlZEl0ZW1zKCkge1xuICAgIHJldHVybiBBcnJheS5mcm9tKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJtdWx0aXNlbGVjdFwiKSk7XG59XG4vLyBNdWx0aXNlbGVjdGVkXG5leHBvcnQgZnVuY3Rpb24gbXVsdGlTZWxlY3RlZChlbGVtZW50KSB7XG4gICAgcmV0dXJuIGVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKFwibXVsdGlzZWxlY3RcIik7XG59XG4vLyBTZWxlY3RcbmV4cG9ydCBmdW5jdGlvbiBtdWx0aVNlbGVjdChlbGVtZW50KSB7XG4gICAgaWYgKCFlbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcIm11bHRpc2VsZWN0XCIpKSB7XG4gICAgICAgIEcuc2VsZWN0ZWRUYWJzKys7XG4gICAgICAgIEcuaXNTZWxlY3RpbmcgPSB0cnVlO1xuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoXCJtdWx0aXNlbGVjdFwiKTtcbiAgICB9XG59XG4vLyBDYW5jZWwgU2VsZWN0aW9uXG5leHBvcnQgZnVuY3Rpb24gbXVsdGlTZWxlY3RDYW5jZWwoZWxlbWVudCkge1xuICAgIGlmIChlbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcIm11bHRpc2VsZWN0XCIpKSB7XG4gICAgICAgIGlmICgtLUcuc2VsZWN0ZWRUYWJzID09IDApIHtcbiAgICAgICAgICAgIEcuaXNTZWxlY3RpbmcgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoXCJtdWx0aXNlbGVjdFwiKTtcbiAgICB9XG59XG4vLyBSZXNldCBtdWx0aXNlbGVjdFxuZXhwb3J0IGZ1bmN0aW9uIG11bHRpU2VsZWN0UmVzZXQoKSB7XG4gICAgZm9yIChsZXQgZWxlbWVudCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJtdWx0aXNlbGVjdFwiKSkpIHtcbiAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKFwibXVsdGlzZWxlY3RcIik7XG4gICAgfVxuICAgIEcuc2VsZWN0ZWRUYWJzID0gMDtcbiAgICBHLmlzU2VsZWN0aW5nID0gZmFsc2U7XG59XG4vLyBUb2dnbGUgU2VsZWN0aW9uXG5leHBvcnQgZnVuY3Rpb24gbXVsdGlTZWxlY3RUb2dnbGUoZWxlbWVudCkge1xuICAgIGlmIChlbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhcIm11bHRpc2VsZWN0XCIpKSB7XG4gICAgICAgIG11bHRpU2VsZWN0Q2FuY2VsKGVsZW1lbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIG11bHRpU2VsZWN0KGVsZW1lbnQpO1xuICAgIH1cbn1cbi8vIFJlc2V0IHNsaWRlIHNlbGVjdGlvblxuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0U2xpZGVTZWxlY3Rpb24oKSB7XG4gICAgRy5zbGlkZVNlbGVjdGlvbi5zbGlkaW5nID0gZmFsc2U7XG4gICAgRy5zbGlkZVNlbGVjdGlvbi5pbml0aWF0b3IgPSB1bmRlZmluZWQ7XG59XG4iLCJpbXBvcnQgXCJQb2x5ZmlsbFwiXG5pbXBvcnQgRyBmcm9tIFwiLi9nbG9iYWxzXCJcbmltcG9ydCB7IGdldEltYWdlIH0gZnJvbSBcIi4vbmV0XCJcbmltcG9ydCB7IGdldENvcnJlY3RUYWJJZCB9IGZyb20gXCIuL3dyb25nLXRvLXJpZ2h0XCJcbmltcG9ydCB7IGdldFdpbmRvd3MsIGNvcnJlY3RGb2N1c2VkIH0gZnJvbSBcIi4vd3R1dGlsc1wiXG5pbXBvcnQgeyBnZXRBY3R1YWxIZWlnaHQsIHN0b3BQcm9wYWdhdGlvbiB9IGZyb20gXCIuL2RvbXV0aWxzXCJcbmltcG9ydCB7IHdpbmRvd0VudHJ5RHJhZ1N0YXJ0ZWQsIHdpbmRvd0VudHJ5RHJhZ2dpbmdPdmVyLCB3aW5kb3dFbnRyeURyb3BwZWQsIHdpbmRvd0VudHJ5VGl0bGVDbGlja2VkLCB3aW5kb3dDbG9zZUNsaWNrIH0gZnJvbSBcIi4vZXZlbnQtbGlzdGVuZXJzL3dpbmRvd0VudHJ5XCJcbmltcG9ydCB7IHRhYkVudHJ5TW91c2VPdmVyLCB0YWJFbnRyeU1vdXNlTGVhdmUsIHRhYkVudHJ5Q2xpY2tlZCwgdGFiQ2xvc2VDbGljaywgdGFiUGluQ2xpY2sgfSBmcm9tIFwiLi9ldmVudC1saXN0ZW5lcnMvdGFiRW50cnlcIlxuXG4vLyBVcGRhdGUgdGFic1xuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZVRhYnMod2luZG93cykge1xuICAgIEcudGFic0xpc3QuaW5uZXJIVE1MID0gXCJcIjtcbiAgICBsZXQgdGFic0xpc3RGcmFnbWVudCA9IGRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKTtcbiAgICBsZXQgY3VycmVudFdpbmRvd0VudHJ5O1xuICAgIC8qIFByZWRlZmluZWQgZWxlbWVudHMgZm9yIGZhc3RlciBwZXJmb3JtYW5jZSAqL1xuICAgIC8vIFdpbmRvdyBjbG9zZSBidXR0b25cbiAgICBsZXQgV0lORE9XX0NMT1NFX0JUTiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgIFdJTkRPV19DTE9TRV9CVE4uY2xhc3NMaXN0LmFkZChcImlubGluZS1idXR0b25cIik7XG4gICAgV0lORE9XX0NMT1NFX0JUTi5jbGFzc0xpc3QuYWRkKFwiaW1nLWJ1dHRvblwiKTtcbiAgICBXSU5ET1dfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJvcGFjaXR5LWNoYW5naW5nLWJ1dHRvblwiKTtcbiAgICBXSU5ET1dfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJ3aW5kb3ctZW50cnktcmVtb3ZlLWJ0blwiKTtcbiAgICBXSU5ET1dfQ0xPU0VfQlROLnN0eWxlLmJhY2tncm91bmRJbWFnZSA9IFwidXJsKC4uL2ljb25zL2Nsb3NlLnN2ZylcIjtcbiAgICBsZXQgRElWID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICBESVYuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lLWJsb2NrXCI7XG4gICAgV0lORE9XX0NMT1NFX0JUTi5hcHBlbmRDaGlsZChESVYpO1xuICAgIC8vIFRhYiBjbG9zZSBidXR0b25cbiAgICBsZXQgVEFCX0NMT1NFX0JUTiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgIFRBQl9DTE9TRV9CVE4uY2xhc3NMaXN0LmFkZChcImlubGluZS1idXR0b25cIik7XG4gICAgVEFCX0NMT1NFX0JUTi5jbGFzc0xpc3QuYWRkKFwicmVkLWJ1dHRvblwiKTtcbiAgICBUQUJfQ0xPU0VfQlROLmNsYXNzTGlzdC5hZGQoXCJpbWctYnV0dG9uXCIpO1xuICAgIFRBQl9DTE9TRV9CVE4uY2xhc3NMaXN0LmFkZChcInRhYi1lbnRyeS1yZW1vdmUtYnRuXCIpO1xuICAgIFRBQl9DTE9TRV9CVE4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvY2xvc2Uuc3ZnKVwiO1xuICAgIC8vIFRhYiBwaW4gYnV0dG9uXG4gICAgbGV0IFRBQl9QSU5fQlROID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG4gICAgVEFCX1BJTl9CVE4uY2xhc3NMaXN0LmFkZChcImlubGluZS1idXR0b25cIik7XG4gICAgVEFCX1BJTl9CVE4uY2xhc3NMaXN0LmFkZChcImltZy1idXR0b25cIik7XG4gICAgVEFCX1BJTl9CVE4uY2xhc3NMaXN0LmFkZChcIm9wYWNpdHktY2hhbmdpbmctYnV0dG9uXCIpO1xuICAgIFRBQl9QSU5fQlROLmNsYXNzTGlzdC5hZGQoXCJ0YWItZW50cnktcGluLWJ0blwiKTtcbiAgICBUQUJfUElOX0JUTi5zdHlsZS5iYWNrZ3JvdW5kSW1hZ2UgPSBcInVybCguLi9pY29ucy9waW4uc3ZnKVwiO1xuICAgIC8vIExvb3AgdGhyb3VnaCB3aW5kb3dzXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB3aW5kb3dzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIC8vIFNldCB3IHRvIHdpbmRvd1xuICAgICAgICBsZXQgdyA9IHdpbmRvd3NbaV07XG5cbiAgICAgICAgLy8gQ3JlYXRlIHdpbmRvdyBlbnRyeVxuICAgICAgICBsZXQgd2luZG93RW50cnkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGlcIik7XG4gICAgICAgIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5hZGQoXCJ3aW5kb3ctZW50cnlcIik7XG4gICAgICAgIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5hZGQoXCJjYXRlZ29yeVwiKTtcblxuICAgICAgICAvLyBDcmVhdGUgd2luZG93IGVudHJ5IGZyYWdtZW50XG4gICAgICAgIGxldCB3aW5kb3dFbnRyeUZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xuXG4gICAgICAgIC8vIFNldCB3aW5kb3cgaWQgdG8gd2luZG93IGVudHJ5XG4gICAgICAgIHdpbmRvd0VudHJ5LnNldEF0dHJpYnV0ZShcImRhdGEtd2luZG93X2lkXCIsIHcuaWQpO1xuICAgICAgICBsZXQgc3BhbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICBzcGFuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCB3aW5kb3dFbnRyeVRpdGxlQ2xpY2tlZCk7XG5cbiAgICAgICAgLy8gQ3JlYXRlIGNsb3NlIGJ1dHRvblxuICAgICAgICBsZXQgY2xvc2VCdG4gPSBXSU5ET1dfQ0xPU0VfQlROLmNsb25lTm9kZSh0cnVlKTtcbiAgICAgICAgY2xvc2VCdG4uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHdpbmRvd0Nsb3NlQ2xpY2spO1xuXG4gICAgICAgIC8vIEJ1dHRvbnMgd3JhcHBlclxuICAgICAgICBsZXQgYnV0dG9ucyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICBidXR0b25zLmNsYXNzTGlzdC5hZGQoXCJ3aW5kb3ctZW50cnktYnV0dG9uc1wiKTtcbiAgICAgICAgYnV0dG9ucy5hcHBlbmRDaGlsZChjbG9zZUJ0bik7XG4gICAgICAgIFxuICAgICAgICAvLyBDcmVhdGUgd2luZG93IG5hbWUgc3BhblxuICAgICAgICBsZXQgd2luZG93TmFtZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICB3aW5kb3dOYW1lLmNsYXNzTGlzdC5hZGQoXCJ3aW5kb3ctdGl0bGVcIik7XG4gICAgICAgIHdpbmRvd05hbWUudGV4dENvbnRlbnQgKz0gXCJXaW5kb3cgXCIgKyAoaSsxKTtcblxuICAgICAgICAvLyBDaGVjayBpZiB3aW5kb3cgaXMgZm9jdXNlZFxuICAgICAgICBpZiAody5mb2N1c2VkKSB7XG4gICAgICAgICAgICBjdXJyZW50V2luZG93RW50cnkgPSB3aW5kb3dFbnRyeTtcbiAgICAgICAgICAgIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5hZGQoXCJjdXJyZW50LXdpbmRvd1wiKTtcbiAgICAgICAgICAgIHdpbmRvd05hbWUudGV4dENvbnRlbnQgKz0gXCIgLSBDdXJyZW50XCI7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQ2hlY2sgaWYgd2luZG93IGlzIGluY29nbml0b1xuICAgICAgICBpZiAody5pbmNvZ25pdG8pIHtcbiAgICAgICAgICAgIHdpbmRvd0VudHJ5LmNsYXNzTGlzdC5hZGQoXCJpbmNvZ25pdG8td2luZG93XCIpO1xuICAgICAgICAgICAgd2luZG93TmFtZS50ZXh0Q29udGVudCArPSBcIiAoSW5jb2duaXRvKVwiO1xuICAgICAgICB9XG5cbiAgICAgICAgc3Bhbi5hcHBlbmRDaGlsZCh3aW5kb3dOYW1lKTtcbiAgICAgICAgc3Bhbi5hcHBlbmRDaGlsZChidXR0b25zKTtcblxuICAgICAgICBzcGFuLmNsYXNzTGlzdC5hZGQoXCJkYXJrZXItYnV0dG9uXCIpO1xuXG4gICAgICAgIHdpbmRvd0VudHJ5RnJhZ21lbnQuYXBwZW5kQ2hpbGQoc3Bhbik7XG5cbiAgICAgICAgLy8gQWRkIHdpbmRvdyBlbnRyeSBkcmFnc3RhcnQsIGRyYWdvdmVyLCBhbmQgZHJvcCBldmVudCBsaXN0ZW5lcnNcbiAgICAgICAgd2luZG93RW50cnkuYWRkRXZlbnRMaXN0ZW5lcihcImRyYWdzdGFydFwiLCB3aW5kb3dFbnRyeURyYWdTdGFydGVkKTtcbiAgICAgICAgd2luZG93RW50cnkuYWRkRXZlbnRMaXN0ZW5lcihcImRyYWdvdmVyXCIsIHdpbmRvd0VudHJ5RHJhZ2dpbmdPdmVyKTtcbiAgICAgICAgd2luZG93RW50cnkuYWRkRXZlbnRMaXN0ZW5lcihcImRyb3BcIiwgd2luZG93RW50cnlEcm9wcGVkKTtcbiAgICAgICAgd2luZG93RW50cnkuc2V0QXR0cmlidXRlKFwiZHJhZ2dhYmxlXCIsIFwidHJ1ZVwiKTtcblxuICAgICAgICBsZXQgd2luZG93VGFic0xpc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwidWxcIik7XG4gICAgICAgIHdpbmRvd1RhYnNMaXN0LmNsYXNzTGlzdC5hZGQoXCJjYXRlZ29yeS1saXN0XCIpO1xuICAgICAgICB3aW5kb3dUYWJzTGlzdC5jbGFzc0xpc3QuYWRkKFwid2luZG93LWVudHJ5LXRhYnNcIik7XG5cbiAgICAgICAgbGV0IHdpbmRvd1RhYnNMaXN0RnJhZ21lbnQgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgICAgIC8vIExvb3AgdGhyb3VnaCB0YWJzXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdy50YWJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBsZXQgdGFiID0gdy50YWJzW2ldO1xuICAgICAgICAgICAgLy8gQ2hlY2sgdGFiIGlkXG4gICAgICAgICAgICBpZiAodGFiLmlkICE9PSBicm93c2VyLnRhYnMuVEFCX0lEX05PTkUpIHtcbiAgICAgICAgICAgICAgICAvLyBDcmVhdGUgdGFiIGVudHJ5XG4gICAgICAgICAgICAgICAgbGV0IHRhYkVudHJ5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxpXCIpO1xuICAgICAgICAgICAgICAgIHRhYkVudHJ5LmNsYXNzTGlzdC5hZGQoXCJ0YWItZW50cnlcIik7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LmFkZChcImJ1dHRvblwiKTtcbiAgICAgICAgICAgICAgICAvLyBTZXQgdGFiIGVudHJ5IGFzIGRyYWdnYWJsZS4gUmVxdWlyZWQgdG8gZW5hYmxlIG1vdmUgdGFiIGZlYXR1cmVcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5zZXRBdHRyaWJ1dGUoXCJkcmFnZ2FibGVcIiwgXCJ0cnVlXCIpO1xuXG4gICAgICAgICAgICAgICAgLy8gQ3JlYXRlIHRhYiBlbnRyeSBmcmFnbWVudFxuICAgICAgICAgICAgICAgIGxldCB0YWJFbnRyeUZyYWdtZW50ID0gZG9jdW1lbnQuY3JlYXRlRG9jdW1lbnRGcmFnbWVudCgpO1xuXG4gICAgICAgICAgICAgICAgbGV0IGZhdmljb247XG4gICAgICAgICAgICAgICAgbGV0IHRpdGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG4gICAgICAgICAgICAgICAgdGl0bGUuY2xhc3NMaXN0LmFkZChcInRhYi10aXRsZVwiKTtcbiAgICAgICAgICAgICAgICB0aXRsZS50ZXh0Q29udGVudCArPSB0YWIudGl0bGU7XG4gICAgICAgICAgICAgICAgbGV0IHRpdGxlV3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgICAgICAgICAgdGl0bGVXcmFwcGVyLmNsYXNzTGlzdC5hZGQoXCJ0YWItdGl0bGUtd3JhcHBlclwiKTtcbiAgICAgICAgICAgICAgICB0aXRsZVdyYXBwZXIuYXBwZW5kQ2hpbGQodGl0bGUpO1xuXG4gICAgICAgICAgICAgICAgaWYgKHRhYi5hY3RpdmUpIHtcbiAgICAgICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LmFkZChcImN1cnJlbnQtdGFiXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodGFiLmZhdkljb25VcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgZmF2aWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIik7XG4gICAgICAgICAgICAgICAgICAgIGZhdmljb24uY2xhc3NMaXN0LmFkZChcInRhYi1lbnRyeS1mYXZpY29uXCIpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZmF2SWNvblByb21pc2U7XG4gICAgICAgICAgICAgICAgICAgIGlmICh3LmluY29nbml0bykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmF2SWNvblByb21pc2UgPSBnZXRJbWFnZSh0YWIuZmF2SWNvblVybCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmYXZJY29uUHJvbWlzZSA9IGdldEltYWdlKHRhYi5mYXZJY29uVXJsKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBmYXZJY29uUHJvbWlzZS50aGVuKGJhc2U2NEltYWdlID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhdmljb24uc3JjID0gYmFzZTY0SW1hZ2U7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBjbG9zZSBidXR0b25cbiAgICAgICAgICAgICAgICBjbG9zZUJ0biA9IFRBQl9DTE9TRV9CVE4uY2xvbmVOb2RlKGZhbHNlKTtcbiAgICAgICAgICAgICAgICBjbG9zZUJ0bi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgdGFiQ2xvc2VDbGljayk7XG4gICAgICAgICAgICAgICAgY2xvc2VCdG4uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlb3ZlclwiLCBzdG9wUHJvcGFnYXRpb24pO1xuXG4gICAgICAgICAgICAgICAgLy8gQ3JlYXRlIHBpbiBidXR0b25cbiAgICAgICAgICAgICAgICBsZXQgcGluQnRuID0gVEFCX1BJTl9CVE4uY2xvbmVOb2RlKGZhbHNlKTtcbiAgICAgICAgICAgICAgICBwaW5CdG4uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHRhYlBpbkNsaWNrKTtcbiAgICAgICAgICAgICAgICBwaW5CdG4uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlb3ZlclwiLCBzdG9wUHJvcGFnYXRpb24pO1xuXG4gICAgICAgICAgICAgICAgLy8gQnV0dG9ucyB3cmFwcGVyXG4gICAgICAgICAgICAgICAgYnV0dG9ucyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuICAgICAgICAgICAgICAgIGJ1dHRvbnMuY2xhc3NMaXN0LmFkZChcInRhYi1lbnRyeS1idXR0b25zXCIpO1xuICAgICAgICAgICAgICAgIGJ1dHRvbnMuYXBwZW5kQ2hpbGQocGluQnRuKTtcbiAgICAgICAgICAgICAgICBidXR0b25zLmFwcGVuZENoaWxkKGNsb3NlQnRuKTtcblxuICAgICAgICAgICAgICAgIC8vIFNldCB0YWIgZW50cnkgdGFiIGlkXG4gICAgICAgICAgICAgICAgdGFiRW50cnkuc2V0QXR0cmlidXRlKFwiZGF0YS10YWJfaWRcIiwgZ2V0Q29ycmVjdFRhYklkKHRhYi5pZCkpO1xuICAgICAgICAgICAgICAgIGlmIChmYXZpY29uICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGFiRW50cnlGcmFnbWVudC5hcHBlbmRDaGlsZChmYXZpY29uKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0YWJFbnRyeS5jbGFzc0xpc3QuYWRkKFwibm9pY29uXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0YWJFbnRyeUZyYWdtZW50LmFwcGVuZENoaWxkKHRpdGxlV3JhcHBlcik7XG4gICAgICAgICAgICAgICAgdGFiRW50cnlGcmFnbWVudC5hcHBlbmRDaGlsZChidXR0b25zKTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB0YWJFbnRyeS5hcHBlbmRDaGlsZCh0YWJFbnRyeUZyYWdtZW50KTtcblxuICAgICAgICAgICAgICAgIHRhYkVudHJ5LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgdGFiRW50cnlNb3VzZU92ZXIpO1xuICAgICAgICAgICAgICAgIHRhYkVudHJ5LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZWxlYXZlXCIsIHRhYkVudHJ5TW91c2VMZWF2ZSk7XG4gICAgICAgICAgICAgICAgdGFiRW50cnkuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHRhYkVudHJ5Q2xpY2tlZCk7XG5cbiAgICAgICAgICAgICAgICBpZiAodGFiLnBpbm5lZCkge1xuICAgICAgICAgICAgICAgICAgICBwaW5CdG4uc3R5bGUuYmFja2dyb3VuZEltYWdlID0gXCJ1cmwoLi4vaWNvbnMvcGlucmVtb3ZlLnN2ZylcIjtcbiAgICAgICAgICAgICAgICAgICAgdGFiRW50cnkuY2xhc3NMaXN0LmFkZChcInBpbm5lZC10YWJcIik7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwaW5uZWRUYWJzID0gQXJyYXkuZnJvbSh3aW5kb3dUYWJzTGlzdC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKFwicGlubmVkLXRhYlwiKSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCBsYXN0UGlubmVkVGFiID0gcGlubmVkVGFic1twaW5uZWRUYWJzLmxlbmd0aC0xXTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxhc3RQaW5uZWRUYWIgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93VGFic0xpc3RGcmFnbWVudC5pbnNlcnRCZWZvcmUodGFiRW50cnksIGxhc3RQaW5uZWRUYWIubmV4dFNpYmxpbmcpO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93VGFic0xpc3RGcmFnbWVudC5pbnNlcnRCZWZvcmUodGFiRW50cnksIHdpbmRvd1RhYnNMaXN0LmNoaWxkTm9kZXNbMF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93VGFic0xpc3RGcmFnbWVudC5hcHBlbmRDaGlsZCh0YWJFbnRyeSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gQXBwZW5kIGZyYWdtZW50IHRvIGFjdHVhbCB3aW5kb3dUYWJzTGlzdFxuICAgICAgICB3aW5kb3dUYWJzTGlzdC5hcHBlbmRDaGlsZCh3aW5kb3dUYWJzTGlzdEZyYWdtZW50KTtcblxuICAgICAgICB3aW5kb3dFbnRyeUZyYWdtZW50LmFwcGVuZENoaWxkKHdpbmRvd1RhYnNMaXN0KTtcbiAgICAgICAgd2luZG93RW50cnkuYXBwZW5kQ2hpbGQod2luZG93RW50cnlGcmFnbWVudCk7XG4gICAgICAgIHRhYnNMaXN0RnJhZ21lbnQuYXBwZW5kQ2hpbGQod2luZG93RW50cnkpO1xuICAgIH1cbiAgICBHLnRhYnNMaXN0LmFwcGVuZENoaWxkKHRhYnNMaXN0RnJhZ21lbnQpO1xuICAgIEcudGFic0xpc3QuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHN0b3BQcm9wYWdhdGlvbik7XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0YWJzXCIpLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgY3VycmVudFdpbmRvd0VudHJ5LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xufVxuXG4vLyBBZGQgdGFicyB0byBsaXN0XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcG9wdWxhdGVUYWJzTGlzdCgpIHtcbiAgICBsZXQgd2luZG93cyA9IGF3YWl0IGdldFdpbmRvd3MoKTtcbiAgICBhd2FpdCBjb3JyZWN0Rm9jdXNlZCh3aW5kb3dzKTtcbiAgICB1cGRhdGVUYWJzKHdpbmRvd3MpO1xufVxuXG4vLyBTZXQgdGFicyBsaXN0IGhlaWdodCB0byBhbnkgYXZhaWxhYmxlIGhlaWdodFxuZXhwb3J0IGZ1bmN0aW9uIGV4dGVuZFRhYnNMaXN0KCkge1xuICAgIGxldCBzZWFyY2hBcmVhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJzZWFyY2gtYXJlYVwiKTtcbiAgICBsZXQgc2VhcmNoQXJlYUhlaWdodCA9IGdldEFjdHVhbEhlaWdodChzZWFyY2hBcmVhKTtcbiAgICBsZXQgdGFicyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidGFic1wiKTtcbiAgICB0YWJzLnN0eWxlLmhlaWdodCA9IFwiY2FsYygxMDAlIC0gXCIgKyBzZWFyY2hBcmVhSGVpZ2h0ICsgXCJweClcIjtcbn1cbiIsImltcG9ydCBcIlBvbHlmaWxsXCJcblxuLy8gR2V0IGFsbCB3aW5kb3dzXG5leHBvcnQgZnVuY3Rpb24gZ2V0V2luZG93cygpIHtcbiAgICByZXR1cm4gYnJvd3Nlci53aW5kb3dzLmdldEFsbCh7XG4gICAgICAgIHBvcHVsYXRlOiB0cnVlLFxuICAgICAgICB3aW5kb3dUeXBlczogW1wibm9ybWFsXCIsIFwicG9wdXBcIiwgXCJkZXZ0b29sc1wiXVxuICAgIH0pO1xufVxuXG4vLyBHZXQgdGhlIGNvcnJlY3QgbGFzdCBmb2N1c2VkIHdpbmRvdyBpZFxuZXhwb3J0IGZ1bmN0aW9uIGdldExhc3RGb2N1c2VkV2luZG93SWQoKSB7XG4gICAgLypcbiAgICBEdWUgdG8gYSBidWcgaW4gQ2hyb21pdW0sIHdpbmRvd3MuZ2V0TGFzdEZvY3VzZWQoKSB3aWxsIHNvbWV0aW1lc1xuICAgIHJldHVybiBpbmNvcnJlY3Qgd2luZG93cy4gU28gaGVyZSwgaW5zdGVhZCBvZiBjYWxsaW5nIGdldExhc3RGb2N1c2VkKCksXG4gICAgd2UgY2FsbCBnZXRDdXJyZW50KCkuXG4gICAgUmVmZXJlbmNlOiBodHRwczovL2NyYnVnLmNvbS84MDk4MjJcbiAgICAqL1xuICAgIHJldHVybiBicm93c2VyLnRhYnMucXVlcnkoeyBsYXN0Rm9jdXNlZFdpbmRvdzogdHJ1ZSB9KS50aGVuKGZ1bmN0aW9uICh0YWJzKSB7XG4gICAgICAgIGlmICh0YWJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiB0YWJzWzBdLndpbmRvd0lkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAtMTtcbiAgICB9KTtcbn1cblxuLy8gQ29ycmVjdCBmb2N1c2VkIHByb3BlcnR5IG9mIHdpbmRvd3Ncbi8vIEluIENocm9taXVtLCB3aW5kb3cuZm9jdXNlZCBkb2Vzbid0IHdvcmssIHNvIHdlIG1hbnVhbGx5IHNldCBpdCBoZXJlXG5leHBvcnQgZnVuY3Rpb24gY29ycmVjdEZvY3VzZWQod2luZG93cykge1xuICAgIHJldHVybiBnZXRMYXN0Rm9jdXNlZFdpbmRvd0lkKCkudGhlbihmdW5jdGlvbiAobGFzdEZvY3VzZWRXaW5kb3dJZCkge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHdpbmRvd3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGlmICh3aW5kb3dzW2ldLmlkID09PSBsYXN0Rm9jdXNlZFdpbmRvd0lkKSB7XG4gICAgICAgICAgICAgICAgd2luZG93c1tpXS5mb2N1c2VkID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG4vLyBHZXQgY3VycmVudCB3aW5kb3dcbmV4cG9ydCBmdW5jdGlvbiBnZXRMYXN0Rm9jdXNlZFdpbmRvdygpIHtcbiAgICAvLyByZXR1cm4gYnJvd3Nlci53aW5kb3dzLmdldExhc3RGb2N1c2VkKHt9KTsgLy8gRG9lc24ndCB3b3JrIGR1ZSB0byBhIGJ1ZyBpbiBDaHJvbWl1bS4gU2VlIGV4cGxhbmF0aW9uIGluIGdldExhc3RGb2N1c2VkV2luZG93SWRcbiAgICByZXR1cm4gZ2V0TGFzdEZvY3VzZWRXaW5kb3dJZCgpLnRoZW4od2luZG93SWQgPT4gYnJvd3Nlci53aW5kb3dzLmdldCh3aW5kb3dJZCkpO1xufVxuXG4vLyBSdW4gY29kZSBhZnRlciBhIHRhYiBsb2Fkc1xuZXhwb3J0IGZ1bmN0aW9uIHJ1bkFmdGVyVGFiTG9hZCh0YWJJZCwgZikge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGxldCBsaXN0ZW5lciA9ICh1VGFiSWQsIGluZm8pID0+IHtcbiAgICAgICAgICAgIGlmICh1VGFiSWQgPT09IHRhYklkICYmIGluZm8uc3RhdHVzID09PSAnY29tcGxldGUnKSB7XG4gICAgICAgICAgICAgICAgYnJvd3Nlci50YWJzLm9uVXBkYXRlZC5yZW1vdmVMaXN0ZW5lcihsaXN0ZW5lcik7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZShmKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBicm93c2VyLnRhYnMub25VcGRhdGVkLmFkZExpc3RlbmVyKGxpc3RlbmVyKTtcbiAgICB9KTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0=